ABS <- function(x) abs(x)
AND <- function(...) all(...)
AND_PRESENT <- function(...) all(...,na.rm=TRUE)
AVERAGE <- function(...) mean(...)
AVERAGE_PRESENT <- function(...) mean(...,na.rm=TRUE)
BETWEEN <- function(x,a,b) all(x>=a & x <= b)
CEILING <- function(x) ceiling(x)
CHAR <- function(...).NotYetImplemented()
COS <- cos
COUNT_MISSING <- function(...) length(which(is.na(...)))
CUBIC_SPLINE <- function(...).NotYetImplemented()
CUBIC_SPLINE_3D <- function(...).NotYetImplemented()
CUMULATIVE <- function(...).NotYetImplemented()
DATE <- function(y,m,d) .NotYetImplemented()
DATE_SINCE_1960 <- function(...).NotYetImplemented()
DAY_OF_MONTH <- function(...).NotYetImplemented()
DAY_OF_WEEK <- function(...).NotYetImplemented()
DAY_OF_YEAR <- function(...).NotYetImplemented()
DAYS_BETWEEN <- function(...).NotYetImplemented()
DAYS_SINCE_1960 <- function(...).NotYetImplemented()
DENSITY <- function(...).NotYetImplemented()
E <- function() exp(0)
ENDS <- function(x,y) identical(y,substr(x,length(x)-length(y)))
EXP <- function(x=0) exp(x)
FLOOR <- function(x) floor(x)
GET_GAM_RESPONSE <- function(...).NotYetImplemented()
GET_MNR_RESPONSE <- function(...).NotYetImplemented()
IF <- function(x,y,z) if(missing(y) && missing(z)) return(as.logical(x)) else return(ifelse(x,y,z))
IF_MISSING <- function(x,y) if(is.na(x)) return(y) else return(x)
IF_MULTI <- function(...){
	x <- list(...)
	while(length(x) >= 2){
		if(x[[1]]) return(x[[2]])
		x <- x[c(-1L,-2L)]
	}
	if(length(x) == 1L) return(x[[1]])
	return(NA)
}
INCLUDES <- function(x,y) length(grep(y,x,fixed=TRUE))
INDEX_CLASSES <- function(x,...){
	dots <- list(...)
	return(match(x,dots))
}
INDEX_FIRST_TRUE <- function(...){
	dots <- list(...)
	x <- min(which(sapply(dots,isTRUE)))
	if(!is.finite(x)) x <- length(dots) + 1
	return(x)
}
INDEX_RANGES <- function(x,...) sum(sapply(list(...),"<",x))
INDEX_UNIFORM_RANGES <- function(x,mn,mx,n){
	s <- seq(mn,mx,length.out=n)
	return(INDEX_RANGES(x,s))
}
INDEX_VALUES <- function(x,...){
	dots <- list(...)
	x <- min(which(sapply(dots,identical,x)))
	if(!is.finite(x)) x <- length(dots) + 1
	return(x)
}
INTEREST_PAY <- function(...).NotYetImplemented()
IS_MISSING <- is.na
LEAFID <- function(...).NotYetImplemented()
LEFT <- function(x,n) strtrim(x,n)
LEN <- function(x) nchar(x)
LEVELED_TREE_LEAF_ID_INT <- function(...).NotYetImplemented()
LEVELED_TREE_LEAF_ID_REAL <- function(...).NotYetImplemented()
LN <- LOG <- log
LOG10 <- function(x) log(x,10)
LOOP_AVG <- function(...).NotYetImplemented()
LOOP_LAST <- function(...).NotYetImplemented()
LOOP_MAX <- function(...).NotYetImplemented()
LOOP_MIN <- function(...).NotYetImplemented()
LOOP_MULT <- function(...).NotYetImplemented()
LOOP_SUM <- function(...).NotYetImplemented()
LOWER <- function(...).NotYetImplemented()
MAX <- max
MAX_INDEX <- function(x) which.max(x)
MAX_PRESENT <- function(...) max(...,na.rm=TRUE)
MIN <- min
MIN_INDEX <- function(x) which.min(x)
MIN_PRESENT <- function(...) min(...,na.rm=TRUE)
MISSING_DATE <- function(...).NotYetImplemented()
MISSING_NUMERIC <- function() NA_real_
MISSING_STRING <- function() NA_character_
MONTH <- function(...).NotYetImplemented()
NOMINAL <- function(...).NotYetImplemented()
NOT <- function(x) !x
ONEOF <- function(x,...) as.logical(match(x,...))
OR <- any
OR_PRESENT <- function(...) any(...,na.rm=TRUE)
PARSE_DATE <- function(...).NotYetImplemented()
PI <- function() pi
QUANTILE <- function(k,...){
	dots <- list(...)
	return(dots[[order(dots)[k]]])
}
QUANTILE_INDEX <- function(k,...) order(list(...))[k]
RANGE <- function(x,a,b) x >= a && x < b
REGEX_MATCH <- function(x,r) as.logical(length(grep(r,x)))
RIGHT <- function(x,n) substr(x,length(x)-n+1,length(x))
ROLL_DATE <- function(...).NotYetImplemented()
ROLL_DATE_YEARS <- function(...).NotYetImplemented()
ROUND <- ROUND_DIGITS <- round
ROUND_DIGITS_END <- function(...).NotYetImplemented()
SCRAMBLE <- function(...).NotYetImplemented()
SEARCH <- function(...).NotYetImplemented()
SEARCH_LAST <- function(...).NotYetImplemented()
SELECT <- function(x,...) if(x > nargs()+1) return(NA) else return(switch(x,...))
SELECT_MATCH <- function(...).NotYetImplemented()
SIN <- sin
SMOOTH_GT <- function(...).NotYetImplemented()
SMOOTH_I <- function(...).NotYetImplemented()
SMOOTH_LT <- function(...).NotYetImplemented()
SMOOTH_MAX <- function(...).NotYetImplemented()
SMOOTH_MIN <- function(...).NotYetImplemented()
SPLIT <- function(x,y,a,b) if(isTRUE(x<y)) return(a) else return(b)
SPLIT_ONEOF <- function(x,a,b,...) if(length(match(x,list(...)))) return(a) else return(b)
SQRT <- sqrt
STARTS <- function(x,y) identical(substr(y,nchar(x)),x)
SUBSTRING <- function(...) substr(...)
SUM <- sum
SUM_ARGE <- function(...).NotYetImplemented()
SUM_GEOM <- function(...).NotYetImplemented()
SUM_PRESENT <- function(...) sum(...,na.rm=TRUE)
TAN <- tan
TEXT <- as.character
##`+`.character
TEXT_PADDED <- function(...).NotYetImplemented()
TP_SPLINE <- function(...).NotYetImplemented()
TREE_LEVEL_MEMBER_INDEX <- function(...).NotYetImplemented()
TRIM <- function(...).NotYetImplemented()
UPPER <- function(...).NotYetImplemented()
VALUE <- function(x,y=NA_real_){
	z <- as.numeric(x)
	z[is.na(z)] <- y
	return(z)
}
VAR <- function(...).NotYetImplemented()
XOR <- xor
YEAR <- function(...).NotYetImplemented()
