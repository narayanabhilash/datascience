#####  rebasePreds  #####
#' Rebase predictions so that the intercept fits the observed data.
#' @description This function takes a set of predictions and a set of observed results and rebases the predictions
#' so that the intercept fits the data. Returns a new vector of predictions.
#' @usage rebasePreds(y, y_hat, family="Poisson", w=NULL, p=1.5)
#' @param y a numeric vector of observations.
#' @param y_hat a numeric vector of predictions for y (must have same length as y.)
#' @param family Distribution we assume the observed is drawn from. Must be one of: Normal, Bernoulli, Poisson, Gamma, Tweedie.
#' @param w Optional. A numeric vector of weights.
#' @param p Tweedie power parameter. Only used when family is Tweedie. Must be between 1 and 2.
#' @return a numeric vector of rebased predictions.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # n <- 1000
#' # 
#' # true <- runif(n, 0, 3)
#' # observed <- rpois(n, true)
#' # predicted <- exp(log(1.5)/2 + log(true)/2 + rnorm(n, sd=0.1))
#' # 
#' # rebasedPreds <- rebasePreds(observed, predicted, family="Poisson")
#' @export


rebasePreds <- function(
  y,
  y_hat,
  family = "Poisson",
  w = NULL,
  p = 1.5
) {
  
  epsilon <- 1E-15
  
  if (is.null(w)) w <- 1
  
  # Check lengths of vectors are the same
  if (length(y) != length(y_hat)) stop("y and y_hat must be the same length.")
  if (length(w) == 1){
    w <- rep(w, length(y))
  } else if(length(y) != length(w)){
    stop("w should be a constant or the same length as y.")
  }
  
  if (family == "Normal"){
    # Easiest of all
    return(y_hat+weighted.mean(y-y_hat, w))
    
  } else if (family == "Bernoulli"){
    # Cheat and use glm to rebase
    tempdata <- data.table(
      y = y,
      y_hat = pmin(1 - epsilon, pmax(epsilon, y_hat))
    )
    outside = (y_hat != tempdata$y_hat)
    tempdata[!(outside), logitPred := logit(y_hat)]
    if (all(outside)){
      warning("All data too extreme for rebasing. Returning original predictions.")
      return(tempdata$y_hat)
    }
    if (any(outside)){
      cat("Note: Some extreme data ignored for rebasing\n")
    }
    
    glmModel <- glm(
      y ~ offset(logitPred) - logitPred,
      family = binomial(link = "logit"),
      data = tempdata[!(outside)],
      weights = w[!(outside)]
    )
    
    tempdata[, preds := inv.logit(logit(y_hat) + glmModel$coefficients)]
    
    return(tempdata$preds)
    
  } else if (family == "Poisson"){
    # Poisson rebasing constant
    k <- sum(w * y) / sum(w * y_hat)
    return(k * y_hat)
    
  } else if (family == "Gamma"){
    # Gamma rebasing constant
    k <- sum(w * y / y_hat) / sum(w)
    return(k * y_hat)
    
  } else if (family == "Tweedie"){
    if (p < 1 | p > 2) stop("p should be between 1 and 2.")
    # Tweedie rebasing constant
    k <- sum(w * y * y_hat^(1 - p)) / sum(w * y_hat^(2 - p))
    return(k * y_hat)
    
  } else stop("family must be one of: Normal, Bernoulli, Poisson, Gamma, Tweedie.")
}

