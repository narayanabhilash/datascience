
# add repeat binner for stratification: put it outside ideally
# even more ideally make everything a data table once loaded in and use
# lazy eval for speed?
# even more ideally, get beter data to strt etc.

repeatBin <- function (df) {
  for (nm in colnames (df)) {
    # if binBoundaries specified, go apply them...
    if (nm %in% names (binBoundaries)) {
      df[[nm]] <- applyBin(as.numeric(df[[nm]]), binBoundaries[[nm]])
    } else {
      if (n2 <= chunkSize & binLimit) {
        # if binBoundaries not specified, go see if they're needed on first block
        values <- unique (as.numeric (df[[nm]]))
        if (length(values) > binLimit & !(anyNA(values))) {
          cat (
            nm,
            "contains more values than binLimit in first downsample:\n",
            "setting bin boundaries based on this distribution \n",
            "\n"
          )
          # set quantile bin boundaries
          binBoundaries[[nm]] <-
            unique(sapply(1:binLimit,
                          function (x) {
                            quantile(as.numeric(df[[nm]]),
                                     x / binLimit,
                                     na.rm = T)
                          }))
          df[[nm]] <- applyBin(df[[nm]], binBoundaries[[nm]])
          
        }
      }
    }
  }
  return (df)
}



downsampleExisting <- function (
  df.tmp,
  outfile,
  # chunkSize = 50000L,
  sampleProb = 1 / 15,
  sampleNo = 1L,
  responseColumnName = "Response",
  rNAval = 0,
  responseKeepCondition = function(x) as.numeric(x) > 0,
  updateWeight = TRUE,
  weightColumnName = "Weight",
  seed = NULL,
  # nlines = NULL,
  # DD = NULL,
  # rowNo = FALSE,
  # rowName = "rowNumber",
  stratCols = NULL,
  binBoundaries = list(),
  binLimit = 20,
  policyNumber = NULL,
  ...)
{
  
  # error checking ----------------------------------------------------------
  binLimit <- as.integer (binLimit)
  if ((is.na(binLimit))|(binLimit == 1 | binLimit < 0)){
    stop ("binLimit should be zero or an integer > 1")
  }

  if (!missing(seed)) set.seed(seed)
  
  tableHeader <- colnames(setDT(df.tmp))
  #    cat (tableHeader)
  for (nm in responseColumnName) {
    if (!(nm %in% tableHeader))
      stop("not all response column names are present in the data")
  }
  if (!is.null(stratCols)) {
    for (nm in stratCols) {
      if (!(nm %in% tableHeader))
        stop("not all stratify column names are present in the data")
    }
  }
  
  for (nm in names (binBoundaries)) {
    if (!(nm %in% stratCols)) stop ("all binBoundary names must be in stratCols")
  }
  
  if (length (weightColumnName) > 1) {
    for (nm in weightColumnName) {
      if (updateWeight && !(nm %in% tableHeader))
        stop(
          "all the strings in 'weightColumnName' need to be column names if more than one selected"
        )
    }
  }
  
  n2 <- 0
  keep2 <- list()
  for (i in sampleNo)
    keep2[[i]] <- 0
  header <- TRUE
  
  # ayou have already applied the data dictionary
  for (n in 1:1) {#lol
    colCToApply <- ddCstring
    keep.rows <- rep (FALSE, nrow(df.tmp))
    for (nm in responseColumnName) {
      # set NA values to the rNAvalue
      df.tmp[[nm]][is.na(df.tmp[[nm]])]<-rNAval
      keep.rows <- keep.rows | responseKeepCondition(df.tmp[[nm]])
    }
    # The remainder need downsampling:
    rows <- which(keep.rows == FALSE)
    orig_rows = copy(rows)
    #  cat ("359\n", head(rows), "\n")
    # stratified downsample ---------------------------------------------------
    
    # first of all want a subsample which is the first record by policy number...
    #get random values...
    rand <- runif(length(rows), 0, 1)
    
    if (!is.null(policyNumber)) {
      
      if (!(policyNumber %in% names (df.tmp))){
        stop (
          "policyNumber provided is not a column in the data:
          you don't have the excuse of name changes caused by read.csv"
        )
      }
      
      top_rows <- match(df.tmp[[policyNumber]][rows], df.tmp[[policyNumber]][rows])

      few = 2
      bucketnos = trunc(1E-9 + 1/sampleProb)
      while (gcd(c(few, bucketnos)) > 1){
        few = 1 + few
      }
      rand <- (rand + (few * sampleProb * (seq_along(top_rows) - top_rows))) %% 1 
      
      }
    
    
    # stratify by "other" -----------------------------------------------------
  
    
    # turn warnings off temporarily:      
    currentWarn <- getOption("warn")
    options(warn = -1)
    # set buckets to stratify:
    if (length (stratCols)){
      if (length (stratCols) == 1){
        stratData <- repeatBin (df.tmp[orig_rows, eval(stratCols)])
      } else
        stratData <-
          apply (repeatBin (df.tmp[orig_rows, stratCols, with = F]), 1, paste, collapse = "~+~")
      options (warn = currentWarn)
      
      for (string in unique (stratData)){
        #add randpermute on to our rand: this means you get a nice even distribution of non claims
        randpermute <- runif (1, 0, 1)
        subSet = which(stratData == string)
        if (length (subSet) > 0)
          rand[subSet] <- (ecdf(rand[subSet])(rand[subSet]) + randpermute) %% 1
      }
    }  
    
    
    
    # finally, keep these:
    for (i in sampleNo) {
      sample.rows <- keep.rows
      temp <- (sampleProb * (i - 1) <=  rand & rand  < sampleProb * i)
      sample.rows[which(keep.rows == FALSE)]<- temp
      
      if (updateWeight) {
        for (nm in weightColumnName) {
          if (!(nm %in% colnames (df.tmp)))
            df.tmp[[nm]] <- 1
          if (!(class (df.tmp[[nm]]) == "integer" |
                class (df.tmp[[nm]]) == "numeric"))
            df.tmp[[nm]] <- as.numeric(df.tmp[[nm]])
          df.tmp[[nm]][sample.rows & !keep.rows] <-
            as.numeric(df.tmp[[nm]][sample.rows &
                                      !keep.rows]) / sampleProb
        }
      }
      cat("keeping some rows\n")
      keep <- df.tmp[keep.rows | sample.rows]
      saveRDS(
        keep,
        file  = paste0(
          gsub("\\.[A-z]{3}$","",outfile,ignore.case = T),
          i,
          ".RDS"
        ))
      
      if (updateWeight) {
        for (nm in weightColumnName) {
          df.tmp[[nm]][sample.rows & !keep.rows] <-
            as.numeric(df.tmp[[nm]][sample.rows &
                                      !keep.rows]) * sampleProb
        }
      }
    }
    header <- FALSE
  }
  invisible (NULL)
}

#' Reduce a data set probabilistically
#'
#' @description Reads a data set, 
#' then samples rows according to a logical condition. Any
#' row passing the condition is kept, together with a proportion of the rows
#' which do not. Data is read in chunks to minimise memory usage.
#'
#' It is necessary that the data has a header row with column names that match
#' the values of \code{DD} and, if used, \code{weightColumnName}.
#'
#' A running commentary is printed to the console, showing how many rows have
#' been read and how many have been kept.
#'
#' @aliases downsample
#' @usage
#' downsampleNonClaims(infile, outfile,
#' chunkSize = 50000L,
#' sampleProb = 1/15,
#' sampleNo = 1L,
#' responseColumnName = "Response",
#' rNAval = 0,
#' responseKeepCondition = function(x) as.numeric(x) > 0,
#' updateWeight=TRUE,
#' weightColumnName = "Weight",
#' seed = NULL,
#' nlines = NULL,
#' DD = NULL,
#' rowNo = FALSE,
#' rowName = "rowNumber",
#' stratCols =NULL,
#' binBoundaries = list(),
#' binLimit = 20,
#' policyNumber = NULL,
#' ...)
#' @param infile Filename of the input. Note this must be a filename only, not
#' an active connection as might be created by \code{\link{file}} and similar.
#' From 2020.05 this can also be a data frame you have in R: in which case
#' the function will not apply a data dictionary, and saves out a .RDS R file
#'  (and will likely make changes to the original.)
#' @param outfile Filename of the output. As with \code{infile}, this must be a
#' filename, not a connection.
#' @param chunkSize Number of rows to read in at once. More will be quicker up
#' to a point, but will use more memory.
#' @param sampleProb Probability that a row \emph{not} meeting the condition
#' \code{responseKeepCondition} will be kept.
#' @param sampleNo Controls \emph{which} of the rows not meeting the condition
#' \code{responseKeepCondition} will be kept, in conjunction with \code{seed}.
#' If \code{seed} is held constant and different integer values of
#' \code{sampleNo} are selected, distinct sets of rows not meeting
#' \code{responseKeepCondition} will be kept. \code{sampleNo} takes a list of
#' integers between 1 and 1/\code{sampleProb} , and the default value will
#' produce a downsample consistent with previous versions. \cr If more than one
#' value is specified, \code{downsampleNonClaims} creates multiple files and
#' appends the values of \code{sampleNo} onto the specified \code{outfile}.
#' @param responseColumnName The column name(s) to check
#' \code{responseKeepCondition} against. This doesn't actually have to be
#' response column(s), but it usually is. All its elements need to
#' \code{\link{match}} one of the column names of the input data (bear in mind
#' that most non-alphanumeric characters get converted to "." in a column
#' name).
#' @param rNAval any \code{NA} values in the response columns will be set to this
#' (otherwise the function crashes) 
#' @param responseKeepCondition The function to apply to column(s)
#' \code{responseColumnName} to determine if it should be kept. Should be a
#' function of one argument, and vectorised (if it isn't, then
#' \code{\link{Vectorize}} will do that for you).
#'
#' If more than one response column is chosen, then the downsampling will keep
#' (and not alter the weight of) _any_ row where \code{responseKeepCondition}
#' is kept. The intention here is to enable production of downsampled files
#' which can be applied to multiple perils.
#' @param updateWeight Logical. If \code{FALSE}, then the weights are kept the
#' same for each row regardless of whether \code{responseKeepCondition} was
#' met.
#' @param weightColumnName Name of the column which represents the data weight
#' (or a list of such names). This will be left unchanged for rows passing
#' \code{responseKeepCondition} and multiplied by \code{1/sampleProb} for other
#' rows which were sampled. \cr Setting this to a value which is not one of the
#' column names of the data will create a new weight column in the downsampled
#' file. \cr Not used if \code{updateWeight=FALSE}.
#' @param seed Random number seed to use. If not specified, the current RNG
#' state is used, and results may not be reproducible.
#' NOTE: if \code{stratCols} are specified, then \code{chunksize} must also be
#' kept constant for reproducibility.
#' @param nlines Number of lines in the input dataset (not counting the
#' header). You can leave this blank but if you know it you will save some
#' time. Alternatively you can specify less than the size of the dataset if you
#' want to ignore the last rows. Specifying more rows than are present may
#' cause an error. If left blank, the number of rows will be determined from
#' the data.
#' @param DD If specified, applies a data dictionary to the downsampled data
#' (see \code{\link{extractDataDictionary}}). Note that this will coerce column
#' classes and may set some data to NA; however, because the downsampled file
#' is not written out as a .Rdata file, not all of the factor levels in the
#' data dictionary will be preserved.
#'
#' if DD is specified, its column names will need to match the column names of
#' the data file as read in. Note that \code{downsampleNonClaims} uses read.csv
#' internally, and by default this will convert column names to syntactically
#' valid ones; happily, you can pass \code{check.names=FALSE} as an additional
#' argument if you need to prevent this.
#'
#' If DD is not specified, all columns will be read in (and saved) as character
#' data, except that exposure fields (as listed in \code{weightColumnName} ) 
#' are subsequently coerced to numeric.  This
#' avoids issues with successive chunks of the file being read in with
#' inconsistent treatment of leading zeroes. However, note that the response
#' column will need to be coerced to the appropriate class in
#' \code{responseKeepCondition}. (To see the problem you can get if you don't
#' do this, try running ' "10" < "3" ' in the R console.)
#' @param rowNo If \code{TRUE}, writes the row numbers of the original file
#' into a new column at the start of the downsampled files. This allows for
#' reference back to the original file where no key field was supplied.
#' @param rowName The name of the new column if \code{rowNo} is \code{TRUE}.
#' @param stratCols Optional column names in the data. 
#' If supplied the downsample of non claim records is stratified with respect to them.
#' @param binBoundaries Named list. If stratifying with respect to numeric data,
#' optional argument to bin it using \code{applyBin}.
#' Names of list should also be in \code{stratCols}.
#' @param binLimit Optional integer. Ignored if zero. Otherwise, where binBoundaries
#' are not supplied and the number of unique values of a numeric column in the first
#' data chunk read in exceeds\code{binLimit}, the function sets stratification
#' bins automatically based on the contents of the first chunk.
#' @param policyNumber Optional Argument - if used needs to be a column name of
#' infile as would be read in by \code{read.csv} (so for example spaces get 
#' coerced to dots). Because records with identical policy numbers tend to be very
#' similar, if this argument is specified the function will do its level best to
#' assign records with the same policy number to different downsamples. 
#' This will work best if your data is ordered by policy number and does not generally 
#' fall into different stratification "buckets".
#' @param \dots Other arguments to \code{\link{read.csv}} or
#' \code{\link{read.table}}, eg \code{check.names}.
#' @return NULL, invisibly. There may be an option in future to return a data
#' table, but for now if you want to work with the downsampled data you will
#' have to read it in again.
#' @details It is necessary that the data has a header row with column names that match
#' the values of \code{DD} and, if used, \code{weightColumnName}.
#'
#' A running commentary is printed to the console, showing how many rows have been read and how many have been kept.
#' @note The downsampling routine has been refined in rsai 2019.03.12.  
#' This means that its results will NOT be backwards compatible -
#' if you update the package your old code will still run
#' but the downsamples will differ. If this is a problem the package managers can send you the code
#' for the old function.
#' @author Tom Bratcher
#' @seealso \code{\link{read.csv}}, \code{\link{Vectorize}},
#' \code{\link{sample}}, \code{fread} in package \code{data.table}.
#' @export
#' @importFrom R.utils countLines
#' @examples
#'
#' ## make some synthetic data, where claims are fairly uncommon
#' df.testDownsample <- data.table(
#'   'Policy Number'=sample(1:500,100000,TRUE),
#'   claimone=rpois(100000, 0.07),
#'   'claim two'=rpois(100000, 0.03),
#'   class=1:625,
#'   classtwo=rep(c("A","B","C","D"), 25000)
#' )
#' ## write it to disk
#' write.csv(
#'   df.testDownsample,
#'   file="testDownsample.csv",
#'   row.names=FALSE)
#'
#' downsampleNonClaims(
#'   infile="testDownsample.csv",
#'   outfile="downsampledTest.csv",
#'   chunkSize=25000L,
#'   sampleProb=1/10,
#'   responseColumnName=c("claimone","claim.two"),
#' ## note that column names are case sensitive and that
#' ## write.csv makes changes to column names.
#' ## the default "Weight" will not work here
#' ## since the column is called "weight"
#' 	weightColumnName="weight",
#' 	nlines=100000L,
#' 	stratCols=c("classtwo"),
#'  policyNumber = "Policy.Number", # Note the dot!
#' 	rowNo=TRUE
#' )
#' temp <- fread("downsampledTest.csv")
#' table(df.testDownsample[(claimone + `claim two`) == 0]$classtwo)
#' table(temp[weight == 10]$classtwo)
#' head(temp)
#'## clean up
#' unlink("testDownsample.csv")
#' unlink("downsampledTest.csv")
#' rm(df.testDownsample)
#' rm (temp)
#'

downsampleNonClaims <-
  function (
    infile,
    outfile,
    chunkSize = 50000L,
    sampleProb = 1 / 15,
    sampleNo = 1L,
    responseColumnName = "Response",
    rNAval = 0,
    responseKeepCondition = function(x) as.numeric(x) > 0,
    updateWeight = TRUE,
    weightColumnName = "Weight",
    seed = NULL,
    nlines = NULL,
    DD = NULL,
    rowNo = FALSE,
    rowName = "rowNumber",
    stratCols = NULL,
    binBoundaries = list(),
    binLimit = 20,
    policyNumber = NULL,
    ...)
  {
    

# error checking ----------------------------------------------------------
  binLimit <- as.integer (binLimit)
    if ((is.na(binLimit))|(binLimit == 1 | binLimit < 0)){
      stop ("binLimit should be zero or an integer > 1")
    }
    
    if (is(infile, "connection"))
      stop("'infile' should be a file name, not an actual connection")
    if (is(outfile, "connection"))
      stop("'outfile' should be a file name, not an actual connection")
  

# existing data.... -------------------------------------------------------
 
  if(inherits(infile, "data.frame")){
  
  setDT(infile)
    
   return (downsampleExisting (
    df.tmp = infile,
    outfile = outfile,
    # chunkSize = 50000L,
    sampleProb = sampleProb,
    sampleNo = sampleNo,
    responseColumnName = responseColumnName,
    rNAval = rNAval,
    responseKeepCondition = responseKeepCondition,
    updateWeight = updateWeight,
    weightColumnName = weightColumnName,
    seed = seed,
    stratCols = stratCols,
    binBoundaries = binBoundaries,
    binLimit = binLimit,
    policyNumber = policyNumber))
}
# seeds and samples -------------------------------------------------------

  
    if (!missing(seed))
      set.seed(seed)
    if (missing(nlines)) {
      cat("'nlines' not specified. Counting lines...\n")
      
      nlines <- R.utils::countLines(infile) - 1
      cat("found", nlines, "lines\n")
    }
    if (length (sampleNo) == 0)
      stop ("'SampleNo' should have length more than zero")
    for (i in sampleNo) {
      if (i <= 0 |
          i >= (1 + 1 / sampleProb))
        stop ("'sampleNo' out of range: no rows not meeting 'responseKeepCondition' would be kept")
      if (any(i != floor(i)))
        stop ("'SampleNo' must consist only of integers")
    }
    
    cvec <-
      c(rep(chunkSize, nlines %/% chunkSize), nlines %% chunkSize)
    if (cvec[length(cvec)] == 0L)
      cvec <- cvec[-length(cvec)]
    tableHeader <- colnames(read.csv(infile, nrows = 1, ...))
    #    cat (tableHeader)
    for (nm in responseColumnName) {
      if (!(nm %in% tableHeader))
        stop("not all response column names are present in the data")
    }
    if (!is.null(stratCols)) {
      for (nm in stratCols) {
        if (!(nm %in% tableHeader))
          stop("not all stratify column names are present in the data")
      }
    }
    
    for (nm in names (binBoundaries)) {
      if (!(nm %in% stratCols)) stop ("all binBoundary names must be in stratCols")
          }
    
    if (length (weightColumnName) > 1) {
      for (nm in weightColumnName) {
        if (updateWeight && !(nm %in% tableHeader))
          stop(
            "all the strings in 'weightColumnName' need to be column names if more than one selected"
          )
      }
    }
    
    outfile <- gsub (".csv$","",outfile)
    
    fin <- gzfile(infile, "rt")
    fout <- file (paste0 (outfile,".csv"), "wt")
    if (length (sampleNo) > 1) {
      close (fout)
      for (i in sampleNo) {
        assign (paste0("fout", i), file(paste0 (outfile, i,".csv"), "wt"))
      }
    }
    on.exit({
      close(fin)
      if (length (sampleNo) == 1) {
        close (fout)
      } else {
        for (i in sampleNo)
          close (get(paste0("fout", i)))
      }
    })
    
        n2 <- 0
    keep2 <- list()
    for (i in sampleNo)
      keep2[[i]] <- 0
    header <- TRUE
    
    # and now, get some data dictionary
    
    if (!is.null(DD)) {
      ddClass <- DD@colClasses
      ddCstring <- ddClass
      names(ddClass) <- DD@colNames
    } else {
      ddCstring <- "character"
    }
    n2 <- 0
    for (n in cvec) {
      colCToApply <- ddCstring
      
      df.tmp <-
        read.csv(
          fin,
          nrows = n,
          header = header,
          stringsAsFactors = FALSE,
          colClasses = colCToApply,
          ...
        )
      
      colnames(df.tmp) <- tableHeader
      if (rowNo) {
        df.tmp <- data.frame (rows = (1:n) + n2, df.tmp)
        colnames(df.tmp)[1] <-
          rowName
        
      }
      
      if ((!is.null(DD)))
        applyDataDictionary (DD, df.tmp) -> df.tmp
      cat("read", n2 <- n2 + n, "rows,\n")
      keep.rows <- rep (FALSE, n)
      for (nm in responseColumnName) {
        # set NA values to the rNAvalue
         df.tmp[[nm]][is.na(df.tmp[[nm]])]<-rNAval
        keep.rows <- keep.rows | responseKeepCondition(df.tmp[[nm]])
      }
 # The remainder need downsampling:
      rows <- which(keep.rows == FALSE)
      orig_rows = copy(rows)
    #  cat ("359\n", head(rows), "\n")
      # stratified downsample ---------------------------------------------------

  # first of all want a subsample which is the first record by policy number...
            #get random values...
      rand <- runif(length(rows), 0, 1)

      if (!is.null(policyNumber)) {
        
        if (!(policyNumber %in% names (df.tmp))){
                   stop (
            "policyNumber provided is not a column in the data:
            you may need to allow for name changes caused by read.csv"
          )
        }
        
        top_rows <- match(df.tmp[[policyNumber]][rows], df.tmp[[policyNumber]][rows])
         
        #stuff
        
        #field testing suggested doing this properly horrifically slow, so let's speed it up.
        # just try to move on a few buckets per row...
        few = 2
        bucketnos = trunc(1E-9 + 1/sampleProb)
        while (gcd (c(few, bucketnos)) > 1){
          few = 1 + few
        }
        rand <- (rand + (few * sampleProb * (seq_along(top_rows) - top_rows))) %% 1 

      }
      

# stratify by "other" -----------------------------------------------------

  
      # turn warnings off temporarily:      
      currentWarn <- getOption("warn")
      options(warn = -1)
      # set buckets to stratify:
      if (length (stratCols)){
        if (length (stratCols) == 1){
          stratData <- repeatBin (df.tmp[orig_rows, stratCols])
        } else
          stratData <-
            apply (repeatBin (df.tmp[orig_rows, stratCols]), 1, paste, collapse = "~+~")
        options (warn = currentWarn)
        
        for (string in unique (stratData)){
          #add randpermute on to our rand: this means you get a nice even distribution of non claims
          randpermute <- runif (1, 0, 1)
          subSet = which(stratData == string)
          if (length (subSet) > 0)
            rand[subSet] <- (ecdf(rand[subSet])(rand[subSet]) + randpermute) %% 1
        }
      }  
      
      
      
      # finally, keep these:
      for (i in sampleNo) {
        sample.rows <- keep.rows
        temp <- (sampleProb * (i - 1) <=  rand & rand  < sampleProb * i)
        sample.rows[which(keep.rows == FALSE)]<- temp
         
        if (updateWeight) {
          for (nm in weightColumnName) {
            if (!(nm %in% colnames (df.tmp)))
              df.tmp[[nm]] <- 1
            if (!(class (df.tmp[[nm]]) == "integer" |
                  class (df.tmp[[nm]]) == "numeric"))
              df.tmp[[nm]] <- as.numeric(df.tmp[[nm]])
            df.tmp[[nm]][sample.rows & !keep.rows] <-
              as.numeric(df.tmp[[nm]][sample.rows &
                                        !keep.rows]) / sampleProb
          }
        }
        cat("keeping", keep2[[i]] <-
              keep2[[i]] + sum(sample.rows | keep.rows))
        if (length (sampleNo) > 1) {
          write.table(
            df.tmp[keep.rows | sample.rows,],
            get(paste0("fout", i)),
            col.names = header,
            row.names = FALSE,
            sep = ","
          )
          
        } else {
          write.table(
            df.tmp[keep.rows | sample.rows,],
            fout,
            col.names = header,
            row.names = FALSE,
            sep = ",",
            ...
          )
        }
        cat(",written to file\n")
        if (updateWeight) {
          for (nm in weightColumnName) {
            df.tmp[[nm]][sample.rows & !keep.rows] <-
              as.numeric(df.tmp[[nm]][sample.rows &
                                        !keep.rows]) * sampleProb
          }
        }
      }
      header <- FALSE
    }
    invisible(NULL)
  }



