#####################################################
# Function for feature selection testing
#####################################################

#' Function to test features for inclusion in an \code{xgboost} model.
#' 
#' @description \code{xgbFeatureSelection} repeatedly runs
#' \code{\link[xgboost]{xgb.cv}} with different features included/excluded to
#' converge towards an optimal set of features to include in your model.
#' 
#' The routine first calls \code{\link{xgbSetupdata2}} to create the design
#' matrix for \code{xgb.cv}. All the relevant arguments to \code{xgbSetupdata2}
#' are also arguments for this function, and the values are passed straight
#' through to the internal call.
#' 
#' For each column of the design matrix that \code{xgbSetupdata2} produces,
#' the routine will compare a "bag" of \code{xgb.cv} objects that include that
#' column as a feature, with a bag that excludes it. If the bag including the
#' feature is "better" than the bag excluding the feature then that feature
#' passes the test and will continue to be included for the rest of the routine.
#' 
#' If it doesn't pass the test it is dropped. There is a bias towards \emph{not}
#' including features.
#' 
#' Most of the arguments to \code{xgb.cv} are included in this function. If
#' there is one you normally use that isn't included you can probably add it to
#' the parameter list using the \code{params} argument instead. 
#' 
#' @usage xgbFeatureSelection(
#'  data,
#'  exVars,
#'  response,
#'  nrounds,
#'  bagSize                =  1,
#'  cutoff                 =  0.5,
#'  exposure               =  NULL,
#'  sampleWeight           =  NULL,
#'  offset_model           =  NULL,
#'  link                   =  log,
#'  defaultEncoding        =  "oneHot",
#'  encodingExceptions     =  NULL,
#'  NA_treatment           =  "fix",
#'  NA_exceptions          =  NULL,
#'  NA_default             =  2.14E+9,
#'  NA_defaultExceptions   =  NULL,
#'  sparse                 =  TRUE,
#'  trainMode              =  NULL,
#'  orderedAsNum           =  TRUE,
#'  filterCols             =  character(0),
#'  startingFeats          =  NULL,
#'  startingTest           =  1L,
#'  maxColsPerModel        =  NULL,
#'  monotonicInc           =  NULL,
#'  monotonicDec           =  NULL,
#'  monotonicInc_test      =  NULL,
#'  monotonicDec_test      =  NULL,
#'  intConstraints         =  NULL,
#'  initialSeed            =  1984L,
#'  modelDetailsCSV        =  NULL,
#'  testSummaryCSV         =  NULL,
#'  params                 =  list(),
#'  testSet                =  NULL,
#'  nfold                  =  NULL,
#'  metrics                =  list(),
#'  obj                    =  NULL,
#'  feval                  =  NULL,
#'  stratified             =  TRUE,
#'  folds                  =  NULL,
#'  train_folds            =  NULL,
#'  verbose                =  FALSE,
#'  print_every_n          =  1L,
#'  early_stopping_rounds  =  NULL,
#'  maximize               =  NULL
#')
#' @param data The data frame or data table containing all the data required
#' for modelling.
#' @param exVars A character vector containing the column names that contain
#' all the explanatory variables.
#' @param response The column name of your response variable within \code{data}.
#' @param nrounds The maximum number of trees within each \code{xgboost} model.
#' @param bagSize The number of times to test each feature. The higher this
#' number the longer the routine will take to run, but the lower the number,
#' the less reliable the result (apparent improvements can simply be due to a
#' "lucky seed"). Note that any improvement in reliability requires an
#' element of randomness in the model (e.g. row proportion < 1)
#' @param  cutoff required proportion of test model runs _with_ the included 
#' feature to give better cv scores than model runs _without_ the feature. 
#' Thus a higher value increases the skepticism of the process.
#' @param testSet Optional additional test set not used for training but purely
#' as a performance monitor.
#' @param exposure Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param sampleWeight Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param offset_model Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param link Argument passed directly through to \code{\link{xgbSetupdata2}}.
#' @param defaultEncoding Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param encodingExceptions Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param NA_treatment Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param NA_exceptions Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param NA_default Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param NA_defaultExceptions Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param sparse Argument passed directly through to \code{\link{xgbSetupdata2}}
#' @param trainMode Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param orderedAsNum Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param filterCols Argument passed directly through
#' to \code{\link{xgbSetupdata2}}.
#' @param startingFeats To specify the starting state of the routine, I.E.
#' which features start in, which start out and what order to test them.
#' This should be a named logical vector with the following properties:
#' \describe{
#'   \item{Names}{The names should be the names of feature columns that are in
#'   the design matrix from \code{xgbSetupdata2}. You can find the names by
#'   running the \code{\link{xgbSetupdata2_colnames}} function first.
#'   }
#'   \item{Order}{The order the names appear in determines the order which the
#'   routine will test each feature.
#'   }
#'   \item{Values}{The values, \code{TRUE} or \code{FALSE}, determine whether
#'   the associated feature is included or excluded at the start of the process. 
#'   }
#' }
#' @param startingTest If you want to start testing further along the
#' \code{startingFeats} vector, you can set this argument. This is useful if the
#' function crashes out before finishing. You can still review the output and
#' then get it to restart from a later point. 
#' @param maxColsPerModel The maximum number of columns in the design matrix
#' for the \code{xgboost} modelling. If the routine reaches this number of
#' included columns it will stop early.
#' @param monotonicInc A character vector of design matrix column names that
#' at first must be fit with a monotonically increasing constraint.
#' If any of these features also appear in \code{monotonicInc_test} then
#' the routine will test the effect of removing the monotonic constraint.
#' Otherwise the constraint will be fixed throughout the routine.
#' @param monotonicDec A character vector of design matrix column names that
#' must at first be fit with a monotonically decreasing constraint.
#' As \code{monotonicInc}.
#' @param monotonicInc_test A character vector of design matrix column names
#' that should be tested for a monotonically increasing constraint.
#' The routine will favour including the constraint over not unless there is
#' strong evidence that this degrades the model.
#' @param monotonicDec_test A character vector of design matrix column names
#' that should be tested for a monotonically decreasing constraint.
#' As \code{monotonicInc_test}.
#' @param intConstraints A list of character vectors. Each vector must include
#' only names of design matrix column names. The features that are included in
#' the same list element will be allowed to interact with each other. This uses
#' the \code{interaction_constraints} parameter for the call to \code{xgb.cv}. 
#' @param initialSeed For replicability you can set a seed. To re-run with
#' different random outcomes change from the default (1984).
#' @param modelDetailsCSV Specify a valid filepath to output a CSV file with
#' details of each \code{xgb.cv} run. This updates as the function runs so if
#' the function is stopped somehow, you still have the results.
#' @param testSummaryCSV Specify a valid filepath to output a CSV file with
#' details of each test to include/exclude a feature. This updates as the
#' function runs so if the function is stopped somehow, you still have the
#' results.
#' @param params Argument passed directly through to \code{\link{xgb.cv}}
#' with the following exceptions:
#' \describe{
#'   \item{tree_method defaults}{If \code{tree_method} and \code{max_bin} are
#'   not explicitly included in \code{params}, they will be set to
#'   \code{tree_method = "hist"} and \code{max_bin = 64}, essentially changing
#'   the default method to increase speed.
#'   }
#'   \item{Monotone constraints}{\code{monotone_constraints} will be ignored
#'   but you can still use the monotonic constraint feature of \code{xgboost}
#'   by using the \code{monotonicInc} and \code{monotonicDec} arguments.
#'   }
#'   \item{Interaction constraints}{\code{interaction_constraints} will be
#'   ignored and is not currently supported in this routine.
#'   }
#' }
#' @param nfold Argument passed directly through to \code{\link{xgb.cv}}.
#' @param metrics Argument passed directly through to \code{\link{xgb.cv}}.
#' @param obj Argument passed directly through to \code{\link{xgb.cv}}.
#' @param feval Argument passed directly through to \code{\link{xgb.cv}}.
#' @param stratified Argument passed directly through to \code{\link{xgb.cv}}.
#' @param folds Argument passed directly through to \code{\link{xgb.cv}}.
#' @param train_folds Argument passed directly through to \code{\link{xgb.cv}}.
#' @param verbose Argument passed directly through to \code{\link{xgb.cv}}.
#' The deault is now set to \code{FALSE}.
#' @param print_every_n Argument passed directly through to
#' \code{\link{xgb.cv}}.
#' @param early_stopping_rounds Argument passed directly through
#' to \code{\link{xgb.cv}}.
#' @param maximize Argument passed directly through to \code{\link{xgb.cv}}.
#' @param callbacks Argument passed directly through to \code{\link{xgb.cv}}.
#' @seealso \code{\link{xgbSetupdata2}} \code{\link[xgboost]{xgb.cv}}
#' \code{\link{xgbSetupdata2_colnames}}
#' @importFrom xgboost xgb.cv xgb.train
#' @importFrom data.table data.table
#' @export
#' @author Edwin Graham, Tom Bratcher, James Hamilton

xgbFeatureSelection <- function(
  # Fundamental arguments
  data,
  exVars,
  response,
  nrounds,
  bagSize = 1,
  cutoff = 0.5,
  # In case it's required...
  testSet = NULL,
  
  # Arguments passed directly to xgbSetupdata2
  exposure               =  NULL,
  sampleWeight           =  NULL,
  offset_model           =  NULL,
  link                   =  log,
  defaultEncoding        =  "oneHot",
  encodingExceptions     =  NULL,
  NA_treatment           =  "fix",
  NA_exceptions          =  NULL,
  NA_default             =  2.14E+9,
  NA_defaultExceptions   =  NULL,
  sparse                 =  TRUE,
  trainMode              =  NULL,
  orderedAsNum           =  TRUE,
  filterCols             =  character(0),
  
  # Arguments controlling feature testing process
  startingFeats          =  NULL,
  startingTest           =  1L,
  maxColsPerModel        =  NULL,
  monotonicInc           =  NULL,
  monotonicDec           =  NULL,
  monotonicInc_test      =  NULL,
  monotonicDec_test      =  NULL,
  intConstraints         =  NULL,
  initialSeed            =  1984L,
  modelDetailsCSV        =  NULL,
  testSummaryCSV         =  NULL,
  
  # Arguments passed directly to xgb.cv
  params                 =  list(),
  nfold                  =  NULL,
  metrics                =  list(),
  obj                    =  NULL,
  feval                  =  NULL,
  stratified             =  TRUE,
  folds                  =  NULL,
  train_folds            =  NULL,
  verbose                =  FALSE,
  print_every_n          =  1L,
  early_stopping_rounds  =  NULL,
  maximize               =  NULL,
  callbacks              =  list()
){
  
  ## Validate arguments that aren't validated
  ## as an argument to another function call
  # initialSeed
  if (! (is.numeric(initialSeed) &
         is.vector(initialSeed) &
         length(initialSeed) == 1)){
    stop("initialSeed should be an integer")
  } else if (! is.integer(initialSeed)){
    initialSeed <- as.integer(initialSeed)
  }
  
  # bagSize
  if (! (bagSize == as.integer(bagSize) &
         is.vector(bagSize) &
         length(bagSize) == 1 &
         bagSize > 0)){
    stop("bagSize should be an integer greater than 0")
  }
  
  # Find the list of feature columns
  colFeats <- xgbSetupdata2_colnames(
    data,
    exVars              =  exVars,
    defaultEncoding     =  defaultEncoding,
    encodingExceptions  =  encodingExceptions,
    NA_treatment        =  NA_treatment,
    NA_exceptions       =  NA_exceptions,
    orderedAsNum        =  orderedAsNum,
    filterCols          =  filterCols
  )
  if (length(colFeats) < 2){
    stop("Fewer than 2 features to test")
  }
  
  # maxColsPerModel
  if (is.null(maxColsPerModel)){
    maxColsPerModel <- length(colFeats)
  } else if (! (maxColsPerModel == as.integer(maxColsPerModel) &
                is.vector(maxColsPerModel) &
                length(maxColsPerModel) == 1 &
                maxColsPerModel > 1)){
    stop("maxColsPerModel should be an integer greater than 1")
  }
  
  # Set maxColsPerModel to maximum possible
  if (maxColsPerModel > length(colFeats)){
    maxColsPerModel <- length(colFeats)
  }
  
  # Validate startingFeats
  if (! is.null(startingFeats)){
    if (! (is.logical(startingFeats) &
           is.vector(startingFeats) &
           length(startingFeats) > 0 &
           ! (is.null(names(startingFeats))))){
      stop(
        "startingFeats must be a named logical vector with at least 1 entry."
      )
    }
    if (anyDuplicated(names(startingFeats))){
      stop("startingFeats must have unique names.")
    }
    if (! all(names(startingFeats) %in% colFeats)){
      stop("At least one starting feature cannot be created.")
    }
    if (! any(startingFeats)){
      stop("At least one starting feature must be used in the initial model")
    }
  } else{
    startingFeats <- rep(FALSE, length(colFeats))
    startingFeats[seq(2, maxColsPerModel, by = 2)] <- TRUE
    names(startingFeats) <- colFeats
  }
  
  # Validate startingTest
  if (is.null(startingTest)){
    startingTest <- 1L
  } else if (! (startingTest == as.integer(startingTest) &
                is.vector(startingTest) &
                length(startingTest) == 1 &
                startingTest > 0 &
                startingTest <= length(startingFeats))){
    stop(
      paste0(
        "startingTest should be an integer within the range 1 to n",
        " where n is the number of features we are testing."
      )
    )
  }
  
  # Set base score where no offset exists
  if (is.null(params$base_score)){
    if (is.null(offset_model)){
      if (is.null(sampleWeight)){
        if (is.null(exposure)){
          params$base_score <- mean(data[[response]])
        } else{
          params$base_score <- weighted.mean(
            data[[response]]/data[[exposure]],
            data[[exposure]]
          )
        }
      } else{
        if (is.null(exposure)){
          params$base_score <- weighted.mean(
            data[[response]],
            data[[sampleWeight]]
          )
        } else{
          params$base_score <- weighted.mean(
            data[[response]]/data[[exposure]],
            data[[exposure]] * data[[sampleWeight]]
          )
        }
      }
    } else{
      if (link(1) == 0){
        params$base_score <- 1
      } else if (link(0) == 0){
        params$base_score <- 0
      } else{
        params$base_score <- 0.5
      }
    }
  }
  
  # Default tree_method to 'hist' with max_bin = 64 for speed
  if (is.null(params$tree_method)){
    params$tree_method <- "hist"
  }
  if (params$tree_method == "hist"){
    if (is.null(params$max_bin)){
      params$max_bin <- 64
    }
  }
  
  
  
  # Fix monotonicity constraints
  if (! is.null(params$monotone_constraints)){
    warning(
      paste0(
        "'monotone_constraints' in the 'params' list will be ignored.",
        " To set monotonic constraints use the",
        " 'monotonicInc' and 'monotonicDec' arguments."
      )
    )
  }
  # Ensure we're only testing monotonicity consistent with starting model
  monotonicInc_test <- intersect(
    intersect(colFeats, names(startingFeats)),
    setdiff(monotonicInc_test, monotonicDec)
  )
  monotonicDec_test <- intersect(
    intersect(colFeats, names(startingFeats)),
    setdiff(
      monotonicDec_test,
      c(monotonicInc, monotonicInc_test)
    )
  )
  
  # Update monotonicInc and monotonicDec for features not include in the
  # starting model since the first test includes monotonicity constraints
  # for new features
  monotonicInc <- union(
    monotonicInc,
    intersect(monotonicInc_test, names(startingFeats)[! startingFeats])
  )
  
  monotonicDec <- union(
    monotonicDec,
    intersect(monotonicDec_test, names(startingFeats)[! startingFeats])
  )
  
  # Update parameters
  params$monotone_constraints <- suppressWarnings(
    xgbMonotone(
      cols = colFeats,
      increasing = monotonicInc,
      decreasing = monotonicDec
    )
  )
  
  # Setup data set of current best settings (I.E. starting settings)
  dtBest <- data.table(
    Feature = names(startingFeats)
  )
  dtBest[
    ,
    monotonicity := params$monotone_constraints[
      match(Feature, names(params$monotone_constraints))
    ]
  ]
  dtBest[
    ,
    include := startingFeats[
      match(Feature, names(startingFeats))
    ]
  ]

  # Interaction constraints
  if (! is.null(params$interaction_constraints)){
    warning(
      paste0(
        "'interaction_constraints' in the 'params' list will be ignored.",
        " To set interaction constraints use the 'intConstraints' argument."
      )
    )
    params$interaction_constraints <- NULL
  }
  if (! is.null(intConstraints)){
    if (! is.list(intConstraints)){
      stop("intConstraints must be a list")
    }
    if (! all(sapply(intConstraints, is.character))){
      stop("intConstraints must be a list of character vectors")
    }
    if (! all(unlist(intConstraints) %in% colFeats)){
      stop("All elements of intConstraints must be valid column names")
    }
  }
  
  
  # Create internal xgbSetupdata2 clone
  internalSetupdata <- function(feats, justMatrices = TRUE, testData = FALSE){
    # Which original explanatory variables are required
    exVarsSubset <- unique(names(colFeats[which(colFeats %in% feats)]))
    # Build the data
    
    xgbData <- suppressWarnings(
      xgbSetupdata2(
        
        dt                    =  if(testData) testSet else data,
        response              =  response,
        explanatory_vars      =  exVarsSubset,
        exposure              =  exposure,
        sampleWeight          =  sampleWeight,
        offset_model          =  offset_model,
        link                  =  link,
        defaultEncoding       =  defaultEncoding,
        encodingExceptions    =  encodingExceptions,
        NA_treatment          =  NA_treatment,
        NA_exceptions         =  NA_exceptions,
        NA_default            =  NA_default,
        NA_defaultExceptions  =  NA_defaultExceptions,
        sparse                =  sparse,
        trainMode             =  trainMode,
        orderedAsNum          =  orderedAsNum,
        justMatrices          =  justMatrices,
        filterCols            =  c(filterCols, setdiff(colFeats, feats))
      )
    )
    
    # return
    return(xgbData[[1]])
  }
  
  # Initialise iter (count of models built)
  iter <- 0L
  
  # Initialise model details table
  dt_modelDetails <- data.table(
    feats = vector(mode = "list", length = 0),
    featsInc = vector(mode = "list", length = 0),
    featsDec = vector(mode = "list", length = 0),
    seed = integer(0),
    bestIteration = integer(0),
    train_mean = numeric(0),
    train_std = numeric(0),
    test_mean = numeric(0),
    test_std = numeric(0)
  )
  # if test set...
  if(! is.null(testSet)){
    dt_modelDetails[, testSetScore := numeric(0)]
  }
  
  
  # Write CSV
  if (! is.null(modelDetailsCSV)){
    write.csv(dt_modelDetails, file = modelDetailsCSV, row.names = FALSE)
  }
  
  # Initialise test summary table
  dt_testSummary <- data.table(
    testNum = integer(0),
    feature = character(0),
    include = integer(0),
    monotonicity = integer(0),
    otherFeatures = character(0),
    otherFeaturesInc = character(0),
    otherFeaturesDec = character(0),
    scoreExc = numeric(0),
    scoreInc = numeric(0),
    scorePlus1SDExc = numeric(0),
    scorePlus1SDInc = numeric(0),
    propImproved = numeric(0),
    propPlus1SDImproved = numeric(0),
    includeFeature = logical(0)
  )
  
  # Write CSV
  if (! is.null(testSummaryCSV)){
    write.csv(dt_testSummary, file = testSummaryCSV, row.names = FALSE)
  }
  
  # Remove unnecessary metrics from metrics parameter
  # Only the last is used as the evaluation metric
  # important for setting 'maximize'
  # and pulling scores from evaluation log later
  if (! is.null(metrics)){
    metrics <- metrics[length(metrics)]
  }
  
  # Create internal xgb.cv clone
  internalXgb.cv <- function(testData = FALSE){
    # Update model count
    assign("iter", iter + 1, envir = parent.frame())
    
    # Set a seed
    set.seed(initialSeed + iter)
    
    # interaction constraints
    params_ <- params
    if (! is.null(intConstraints)){
      params_$interaction_constraints <- lapply(
        intConstraints,
        function(x){
          sapply(
            x,
            function(y){
              which(y == colnames(xgbData)) - 1
            }
          )
        }
      )
    }
    
    # Call to xgb.cv
    xgbCV <- xgb.cv(
      params                 =  params_,
      data                   =  xgbData,
      nrounds                =  nrounds,
      folds                  =  folds,
      verbose                =  verbose,
      early_stopping_rounds  =  early_stopping_rounds,
      nfold                  =  nfold,
      metrics                =  metrics,
      obj                    =  obj,
      feval                  =  feval,
      stratified             =  stratified,
      train_folds            =  train_folds,
      print_every_n          =  print_every_n,
      maximize               =  maximize,
      callbacks              =  callbacks
    )
    
    # Features used
    feats <- colnames(xgbData)
    featsInc <- intersect(
      feats,
      names(params$monotone_constraints)[params$monotone_constraints == 1]
    )
    featsDec <- intersect(
      feats,
      names(params$monotone_constraints)[params$monotone_constraints == -1]
    )
    
    if (is.null(xgbCV$best_iteration)){
      xgbCV$best_iteration <- which.min(xgbCV$evaluation_log[[5]])
    }
    
    # Create data table of unique details
    dt_modelDetailsToAppend <- cbind(
      data.table(
        feats = list(feats),
        featsInc = list(featsInc),
        featsDec = list(featsDec),
        seed = initialSeed + iter
      ),
      xgbCV$evaluation_log[iter == xgbCV$best_iteration]
    )
    
    # test Set score...---------------
    if (testData){
      # run train
      xgbTrain <- xgb.train(
        params                 =  params,
        data                   =  xgbData,
        nrounds                =  xgbCV$best_iteration,
        verbose                =  verbose,
        print_every_n          =  print_every_n,
        maximize               =  maximize,
        obj                    =  obj,
        feval                  =  feval,
        watchlist              =  list(testEval = xgbDataTest)
      )
      
      # append data
      dt_modelDetailsToAppend$testSetScore <- as.numeric(
        xgbTrain$evaluation_log[xgbCV$best_iteration, 2])
      
    }
    # Append to master table
    
    # in case it's missing...
    if(ncol(dt_modelDetailsToAppend) < ncol(dt_modelDetails)) {
      dt_modelDetailsToAppend[, testSetScore:= NA]
    }
    
    assign(
      "dt_modelDetails",
      rbindlist(
        list(
          dt_modelDetails,
          dt_modelDetailsToAppend
        ),
        use.names = FALSE
      ),
      envir = parent.frame()
    )
    
    # Save output
    if (! is.null(modelDetailsCSV)){
      # Collapse features list to character
      dt_modelDetailsToAppend[
        ,
        ':='(
          feats = paste0(feats[[1]], collapse = ', '),
          featsInc = paste0(featsInc[[1]], collapse = ', '),
          featsDec = paste0(featsDec[[1]], collapse = ', ')
        )
        
      ]
      
      # Write to disc
      write.table(
        dt_modelDetailsToAppend,
        file = modelDetailsCSV,
        append = TRUE,
        row.names = FALSE,
        col.names = FALSE,
        sep = ","
      )
    }
    gc()
    # return
    return(xgbCV)
  }
  
  # Data set to track tests
  dtTestTracker <- data.table(
    Feature = c(names(startingFeats), monotonicInc_test, monotonicDec_test)
  )
  dtTestTracker[, order := match(Feature, names(startingFeats))]
  setorder(dtTestTracker, order)
  dtTestTracker <- dtTestTracker[
    ,
    .(order, suborder = seq_len(.N)),
    by = "Feature"
  ]
  dtTestTracker[
    ,
    suborder2 := suborder *
      (-1)^(Feature %in% names(startingFeats)[! startingFeats])
  ]
  setorder(dtTestTracker, order, suborder2)
  dtTestTracker <- dtTestTracker[
    ,
    .(order, suborder, suborder3 = seq_len(.N)),
    by = "Feature"
  ]
  dtTestTracker[
    Feature %in% monotonicInc_test & suborder3 == 1,
    monotonicity := 1 * (! Feature %in% monotonicInc)
  ]
  dtTestTracker[
    Feature %in% monotonicDec_test & suborder3 == 1,
    monotonicity := -1 * (! Feature %in% monotonicDec)
  ]
  dtTestTracker[
    is.na(monotonicity),
    include := !startingFeats[match(Feature, names(startingFeats))]
  ]
  setorder(dtTestTracker, order, suborder)
  dtTestTracker[, testNum := .I]
  dtTestTracker[, ':='(order = NULL, suborder = NULL, suborder3 = NULL)]
  dtTestTracker[monotonicity == 0 | include == TRUE, simplify := 0]
  dtTestTracker[is.na(simplify), simplify := 1]
  
  # Rename starting objects
  testCount <- startingTest
  
  # Get starting best data matrix
  bestDataMat <- internalSetupdata(dtBest[include == TRUE, Feature])
  # get equivalent for the testSet..--------
  if (! (is.null(testSet))){
    bestDataMatTest <- internalSetupdata(
      dtBest[include == TRUE, Feature], testData = TRUE
    )
  }
  # Get info to add to every xgbdmatrix
  tempXgbData <- internalSetupdata(
    dtBest[include == TRUE, Feature][1], justMatrices = FALSE
  )
  
  info <- list(
    label = getinfo(tempXgbData, "label"),
    weight = getinfo(tempXgbData, "weight"),
    base_margin = getinfo(tempXgbData, "base_margin")
  )
  if (is.null(info$weight)){
    info$weight <- NULL
  }
  if (is.null(info$base_margin)){
    info$base_margin <- NULL
  }
  
  
  # Setup xgbData ready for modelling
  xgbData <- xgb.DMatrix(data = bestDataMat, info = info)
  if (! (is.null(testSet))){
    tempXgbData <- internalSetupdata(
      dtBest[include == TRUE, Feature][1],
      justMatrices = FALSE, testData = TRUE)
    
    infoTest <- list(
      label = getinfo(tempXgbData, "label"),
      weight = getinfo(tempXgbData, "weight"),
      base_margin = getinfo(tempXgbData, "base_margin")
    )
    if (is.null(infoTest$weight)){
      infoTest$weight <- NULL
    }
    if (is.null(infoTest$base_margin)){
      infoTest$base_margin <- NULL
    }
    xgbDataTest <- xgb.DMatrix(data = bestDataMatTest, info = infoTest)
  }
  rm(tempXgbData)
  
  # Run the first bag of models
  for (i in seq_len(bagSize)){
    cat(
      paste0(
        "Initial run of xgb.cv with ",
        dtBest[include==TRUE, .N],
        " feature(s): ",
        i,
        " of ",
        bagSize,
        "\n"
      )
    )
    
    # Run xgb.cv
    xgbCV <- internalXgb.cv(testData = ! is.null(testSet)) 
  }
  
  # Fix maximize if not specified by user
  # If it is null that means user cannot have specified custom eval metric
  # Therefore find the name of the metric
  # and we will know if it's a minimised or maximised
  if (is.null(maximize)){
    # Find name of metric from evaluation log
    trainMetric <- names(xgbCV$evaluation_log)[2]
    trainMetric <- substr(trainMetric, 7, nchar(trainMetric))
    if (substr(trainMetric, 1, 3) == "auc"){
      maximize <- TRUE
    } else if (substr(trainMetric, 1, 3) == "map"){
      maximize <- TRUE
    } else if (substr(trainMetric, 1, 4) == "ndcg"){
      maximize <- TRUE
    } else{
      maximize <- FALSE
    }
  }
  rm(xgbCV)
  
  # Function returns the proportion of (x, y) pairs
  # where the y value is a better score than the x value
  # running the function with the inputs the opposite way around will be 1 - ans
  # lower value means x is better, higher means y is better
  checkPairwise <- function(x, y, maximize = FALSE){
    n <- length(x)
    m <- length(y)
    vec <- c(x, y)
    rtn <- (sum(frank(vec * (-1)^(maximize))[seq_along(x)]) - n * (n + 1)/2)/
      (n * m)
    return(rtn)
  }
  
  # Initialise variable to end loop
  finished <- FALSE
  
  # Extract best scores
  bestScores <- dt_modelDetails[, test_mean]
  bestScoresPlus <- dt_modelDetails[, test_mean + test_std * (-1) ^ (maximize)]
  
  # Start stage 2 loop
  while (! finished){
    
    # Copy best settings ready to update for current test
    dtCurrent <- copy(dtBest)
    
    # Get feature to test and some test details
    test_feature <- dtTestTracker[testCount, Feature]
    test_include <- dtTestTracker[
      testCount,
      ifelse(
        is.na(include),
        ifelse(Feature %in% dtBest[include == TRUE, Feature], 0, 1),
        2 * include - 1
      )
    ]
    test_monotonicity <- dtTestTracker[testCount, monotonicity]
    test_simplify <- dtTestTracker[testCount, simplify]
    
    # Update settings and print details to console
    
    if (test_include != 0){
      # Update settings
      dtCurrent[Feature == test_feature, include := test_include == 1]
      
      # Print to console
      cat(paste0(
        "Test ", testCount, " of a maximum of ", nrow(dtTestTracker), "\n"
      ))
      cat(paste0(
        ifelse(test_include == 1, "Adding ", "Removing "), test_feature, "\n"
      ))
    } else{
      # Print to console
      cat(paste0(
        "Test ", testCount, " of a maximum of ", nrow(dtTestTracker), "\n"
      ))
      cat(paste0(
        ifelse(
          dtTestTracker[testCount, monotonicity != 0],
          "Adding ",
          "Removing "
        ),
        "monotonicity to/from ",
        test_feature,
        "\n"
      ))
    }
    if (! is.na(test_monotonicity)){
      dtCurrent[
        Feature == test_feature,
        monotonicity := test_monotonicity
      ]
    }
    
    if (dtCurrent[, sum(include)] == 0){
      cat("Skipping test since no features left\n")
      
    } else if (dtCurrent[, sum(include)] > maxColsPerModel){
      cat("Skipping test since max features has been reached\n")
      
    } else{
      # Setup data
      if (test_include == 1){
        # Get the extra column and add to the design matrix
        extraCol <- internalSetupdata(test_feature)
        currentDataMat <- cbind(bestDataMat, extraCol)
        # Reorder so it is easy to replicate
        currentDataMat <- currentDataMat[
          ,
          intersect(colFeats, colnames(currentDataMat))
        ]
        if (! is.null(testSet)){
          extraCol <- internalSetupdata(test_feature, testData = TRUE)
          currentDataMatTest <- cbind(bestDataMatTest, extraCol)
          # Reorder so it is easy to replicate
          currentDataMatTest <- currentDataMatTest[
            ,
            intersect(colFeats, colnames(currentDataMat))
          ]
        }
      } else if (test_include == -1){
        # Drop column
        currentDataMat <- bestDataMat[
          , 
          -which(test_feature == colnames(bestDataMat)),
          drop = FALSE
        ]
        if (! is.null(testSet)){
          currentDataMatTest <- bestDataMatTest[
            , 
            -which(test_feature == colnames(bestDataMatTest)),
            drop = FALSE
          ]
        }
      } else{
        # Data remains the same
        currentDataMat <- bestDataMat
        if (! is.null(testSet)){
          currentDataMatTest <- bestDataMatTest
        }
      }
      
      # Update parameters with current monotonicity constraints
      monotonicityObject <- dtCurrent$monotonicity
      names(monotonicityObject) <- dtCurrent$Feature
      params$monotone_constraints <- xgbMonotone(
        cols = colnames(currentDataMat),
        increasing = intersect(
          colnames(currentDataMat),
          names(monotonicityObject[monotonicityObject == 1])),
        decreasing = intersect(
          colnames(currentDataMat),
          names(monotonicityObject[monotonicityObject ==-1]))
      )
      
      
      # Setup xgbData ready for modelling
      xgbData <- xgb.DMatrix(data = currentDataMat, info = info)
      if (! is.null(testSet)){
        xgbDataTest <- xgb.DMatrix(data = currentDataMatTest, info = infoTest)
      }
      
      # Run bag of models
      for (i in seq_len(bagSize)){
        cat(
          paste0(
            "Running xgb.cv with ",
            dtCurrent[, sum(include)],
            " feature(s): ",
            i,
            " of ",
            bagSize,
            "\n"
          )
        )
        
        # Run xgb.cv
        internalXgb.cv(testData = ! is.null(testSet))
      }
      
      # Extract new scores
      matchRows <- sapply(
        seq_len(nrow(dt_modelDetails)),
        function(i){
          setequal(
            dt_modelDetails[i, feats[[1]]],
            dtCurrent[include == TRUE, Feature]
          ) & setequal(
            dt_modelDetails[i, featsInc[[1]]],
            dtCurrent[include == TRUE & monotonicity == 1, Feature]
          ) & setequal(
            dt_modelDetails[i, featsDec[[1]]],
            dtCurrent[include == TRUE & monotonicity == -1, Feature]
          )
        }
      )
      
      currentScores <- dt_modelDetails[matchRows, test_mean]
      currentScoresPlus <- dt_modelDetails[
        matchRows,
        test_mean + test_std * (-1) ^ (maximize)
      ]
      
      if (test_simplify == 0){
        incFeatureScore <- currentScores
        incFeatureScorePlus <- currentScoresPlus
        excFeatureScore <- bestScores
        excFeatureScorePlus <- bestScoresPlus
      } else{
        incFeatureScore <- bestScores
        incFeatureScorePlus <- bestScoresPlus
        excFeatureScore <- currentScores
        excFeatureScorePlus <- currentScoresPlus
      }
      
      # Test metrics
      dt_testSummaryToAppend <- data.table(
        testNum = testCount,
        feature = test_feature,
        include = test_include,
        monotonicity = monotonicityObject[
          names(monotonicityObject) == test_feature
        ],
        otherFeatures = list(
          setdiff(dtCurrent[include == TRUE, Feature], test_feature)
        ),
        otherFeaturesInc = list(
          setdiff(
            dtCurrent[include == TRUE & monotonicity == 1, Feature],
            test_feature
          )
        ),
        otherFeaturesDec = list(
          setdiff(
            dtCurrent[include == TRUE & monotonicity == -1, Feature],
            test_feature
          )
        ),
        scoreExc = mean(excFeatureScore),
        scoreInc = mean(incFeatureScore),
        scorePlus1SDExc = mean(excFeatureScorePlus),
        scorePlus1SDInc = mean(incFeatureScorePlus),
        propImproved = checkPairwise(
          excFeatureScore, incFeatureScore, maximize
        ),
        propPlus1SDImproved = checkPairwise(
          excFeatureScorePlus, incFeatureScorePlus, maximize
        )
      )
      
      # Check 1 - average score improves when including variable being tested
      if (maximize){
        check1 <- dt_testSummaryToAppend[, scoreInc > scoreExc]
      } else{
        check1 <- dt_testSummaryToAppend[, scoreInc < scoreExc]
      }
      
      # Check 2 - average score + std improves
      if (maximize){
        check2 <- dt_testSummaryToAppend[, scorePlus1SDInc > scorePlus1SDExc]
      } else{
        check2 <- dt_testSummaryToAppend[, scorePlus1SDInc < scorePlus1SDExc]
      }
      
      # Check 3 - prop of including beating excluding is better than cutoff
      # (lower is better)
      check3 <- dt_testSummaryToAppend[, propImproved > cutoff]
      
      # Check 4 - proportion of current + std beating best + std
      # is better than cutoff (lower is better)
      check4 <- dt_testSummaryToAppend[, propPlus1SDImproved > cutoff]
      
      # Check whether to include feature
      if (all(check1, check2, check3, check4)){
        testPassed <- test_simplify == 0
        dt_testSummaryToAppend[, includeFeature := TRUE]
      } else{
        testPassed <- test_simplify != 0
        dt_testSummaryToAppend[, includeFeature := FALSE]
      }
      if(verbose) cat("test results: \n", check1, check2, check3, check4, "\n")
      # Append test summary to test summary table
      dt_testSummary <- rbindlist(list(dt_testSummary, dt_testSummaryToAppend))
      
      # Save output
      if (! is.null(testSummaryCSV)){
        # Collapse features list to character
        dt_testSummaryToAppend[
          ,
          ':='(
            otherFeatures = paste0(otherFeatures[[1]], collapse = ', '),
            otherFeaturesInc = paste0(otherFeaturesInc[[1]], collapse = ', '),
            otherFeaturesDec = paste0(otherFeaturesDec[[1]], collapse = ', ')
          )
        ]
        
        # Write to disc
        write.table(
          dt_testSummaryToAppend,
          file = testSummaryCSV,
          append = TRUE,
          row.names = FALSE,
          col.names = FALSE,
          sep = ","
        )
      }
      
      # If test passed overwrite previous best with new best
      if (testPassed){
        dtBest <- dtCurrent
        bestDataMat <- currentDataMat
        if (! is.null(testSet)){
          bestDataMatTest <- currentDataMatTest
        }
        
        bestScores <- currentScores
        bestScoresPlus <- currentScoresPlus
        if (test_include != 0){
          cat(
            paste0(
              "Test passed! Updating feature set to ",
              ifelse(test_include == 1, "include ", "remove "),
              test_feature,
              "\n"
            )
          )
        } else{
          cat(
            paste0(
              "Test passed! Updating parameters to ",
              ifelse(test_monotonicity != 0, "include ", "remove "),
              "monotone constraint on ",
              test_feature,
              "\n"
            )
          )
        }
        
      } else{
        cat("Test failed\n")
      }
    }
    
    # Finish if we run out of features to test
    if (testCount >= nrow(dtTestTracker)){
      finished <- TRUE
      cat ("Tests completed\n")
    }
    
    # Increase test count (tells us which feature to test in this iteration)
    testCount <- testCount + 1
    
  }
  
  # Put together final list of best features
  finalFeatures <- dtBest[include == TRUE, Feature]
  finalFeatures <- finalFeatures[order(finalFeatures)]
  
  params$monotone_constraints <- dtBest$monotonicity
  names(params$monotone_constraints) <- dtBest$Feature
  
  # return----------
  
  # 
  
  return(
    list(
      bestFeatures    =  finalFeatures,
      testSummary     =  dt_testSummary,
      modelDetails    =  dt_modelDetails,
      params          =  params,
      monotonicInc    =  dtBest[monotonicity == 1 & include == TRUE, Feature],
      monotonicDec    =  dtBest[monotonicity == -1 & include == TRUE, Feature]
    )
  )
}