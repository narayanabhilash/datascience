#' Retrieve Feature Stats from xgboost Model
#'
#' @description For understanding features (single variables or interactions) in a xgboost, 
#' this function will create a output summarising key stats from all trees.
#' @usage GetFeatureInteractions(model, feature_names, maxInteractionDepth = 2, maxDeepening = -1)
#' @param model A xgboost model.  May have an issue if xgb.cv trained model used.
#' @param feature_names A character vector gives names for features. This should be the colnames of the matrix 
#' that is used for training xgboost model.
#' @param maxInteractionDepth This defines the max-way interaction to be assessed. 
#' By default, it summarises all possibile interactions  
#' @param maxDeepening This defines the max depth of each tree to summarise stats.
#' 
#' @details Based on Far0n's xgbfi code (c#), which is on MIT open source license, this R code is created to 
#' to follow the logic and results as much as possibile.
#' 
#' As there is no tree structure travelling package ready for a xgb.dump output (tree structure), 
#' the recursive method is used on xgb.model.dt.tree output (table structure).
#' 
#' The impact would be large RAM used and may not be efficient in terms of running time.
#' 
#' A balance of (running time and RAM restriction) vs (maxInteractionDepth, maxDeepening) needs to be considered.
#' 
#' @author Sixiang Hu at uk.rsagroup.com
#' @importFrom xgboost xgb.model.dt.tree
#' @importFrom data.table data.table rbindlist setnames
#' @export GetFeatureInteractions
#'
#' @examples
#' 
#' ## Not run:
#' data(agaricus.train, package='xgboost')
#' data(agaricus.test, package='xgboost')
#' 
#' data(agaricus.train, package='xgboost')
#' data(agaricus.test, package='xgboost')
#' 
#' dtrain <- xgb.DMatrix(agaricus.train$data, label = agaricus.train$label)
#' dtest <- xgb.DMatrix(agaricus.test$data, label = agaricus.test$label)
#' bst <- xgboost(data = dtrain, max_depth = 2, 
#' eta = 1, nthread = 2, nrounds = 2, objective = "binary:logistic")
#' 
#' #summarise interaction
#' rst <- GetFeatureInteractions(model=bst,feature_names=colnames(agaricus.train$data))
#' ## End(Not run)

GetFeatureInteractions <- function(model, feature_names=NULL, maxInteractionDepth = 2, maxDeepening = -1){
  
  if (!("xgb.Booster" %in% class(model))) stop("model provided must be a xgboost model.")
  
  ModelParser <- xgboost::xgb.model.dt.tree(feature_names = feature_names, model = model)
  setnames(ModelParser,"Quality","Gain")
  
  numTree <- max(ModelParser$Tree)-1
  
  xgbFeatureInteractions <- InitTreeInteraction()
  pb <- txtProgressBar(0,1,style=3)
  topEnv <- new.env()
  
  for(i in 0:numTree){
    
    treeFeatureInteractions <- InitTreeInteraction()
    currentInteraction <- ModelParser[0]
    assign("pathMemo", character(0), envir = topEnv)
    
    treeFeatureInteractions <- CollectFeatureInteractions(ModelParser[Tree == i], currentInteraction,
                                                          0,0,1,0,0,
                                                          i,"0-0",maxInteractionDepth,maxDeepening,
                                                          treeFeatureInteractions,topEnv)
    
    xgbFeatureInteractions <- rbindlist(list(xgbFeatureInteractions,treeFeatureInteractions),fill=TRUE)
    setTxtProgressBar(pb, i/numTree)
  }
  
  xgbFeatureInteractions <- xgbFeatureInteractions[,lapply(.SD,sum, na.rm=TRUE),by=Name,.SDcols=c("Gain","Cover","FScore","FScoreWeighted",
                                                                                                  "ExpectedGain","SumLeafCoversLeft","SumLeafCoversRight",
                                                                                                  "SumLeafValuesLeft","SumLeafValuesRight","TreeIndex",
                                                                                                  "TreeDepth")]  
  
  xgbFeatureInteractions[,`:=`(AverageFScoreWeighted = FScoreWeighted / FScore,
                               AverageGain = Gain / FScore,
                               AverageTreeIndex = TreeIndex / FScore,
                               AverageTreeDepth = TreeDepth / FScore)]
  
  return(xgbFeatureInteractions[])
}


InitTreeInteraction <- function(){
  treeFeatureInteractions <- data.table(Name = character(0)
                                        ,Depth = integer(0)
                                        ,Gain = numeric(0)
                                        ,Cover = numeric(0)
                                        ,FScore = numeric(0)
                                        ,FScoreWeighted = numeric(0)
                                        ,AverageFScoreWeighted = numeric(0)
                                        ,AverageGain = numeric(0)
                                        ,ExpectedGain = numeric(0)
                                        ,TreeDepth = integer(0)
                                        ,AverageTreeDepth = numeric(0)
                                        ,TreeIndex = integer(0)
                                        ,AverageTreeIndex = numeric(0)
                                        ,SumLeafCoversLeft=numeric(0)
                                        ,SumLeafCoversRight=numeric(0)
                                        ,SumLeafValuesLeft =numeric(0)
                                        ,SumLeafValuesRight =numeric(0)
                                        #,SplitValueHistogram ## Sixiang: Out of scope atm
  )
  return(treeFeatureInteractions)
}

FeatureInteraction <- function(interaction, gain, cover, pathProbability, depth, treeIndex, fScore = 1){
  
  Name <- paste0(interaction,collapse = "|")
  Depth <- length(interaction) - 1
  Gain <- gain
  Cover <- cover
  FScore <- fScore
  FScoreWeighted <- pathProbability
  AverageFScoreWeighted <- FScoreWeighted / FScore
  AverageGain <- Gain / FScore
  ExpectedGain <- Gain * pathProbability
  TreeDepth <- depth
  AverageTreeDepth <- TreeDepth / FScore
  TreeIndex <- treeIndex
  AverageTreeIndex <- treeIndex / FScore
  
  return(data.table(Name,Depth,Gain,Cover, FScore, FScoreWeighted,
                    AverageFScoreWeighted,AverageGain,ExpectedGain,
                    TreeIndex,TreeDepth,AverageTreeIndex,AverageTreeDepth)
  )
}

CollectFeatureInteractions <- function(ModelParser, currentInteraction,
                                       currentGain, currentCover, pathProbability, depth, deepening,
                                       treeIndex, NodeIndex, maxInteractionDepth=2,maxDeepening = -1,
                                       treeFeatureInteractions,topEnv){
  
  tree.Data        <- ModelParser[ID == NodeIndex]
  
  if(tree.Data$Feature=="Leaf" || nrow(tree.Data) == 0) return(treeFeatureInteractions)
  
  tree.left.Data   <- ModelParser[ID == tree.Data$Yes]
  tree.right.Data  <- ModelParser[ID == tree.Data$No]
  
  currentInteraction <- rbind(currentInteraction,tree.Data)
  currentGain  <- currentGain + tree.Data$Gain
  currentCover <- currentCover + tree.Data$Cover
  
  pathProbabilityLeft  <- pathProbability * (tree.left.Data$Cover  / tree.Data$Cover)
  pathProbabilityRight <- pathProbability * (tree.right.Data$Cover / tree.Data$Cover)
  
  fi <- FeatureInteraction(currentInteraction$Feature, currentGain, currentCover, pathProbability, depth, treeIndex, 1)
  
  if (depth < maxDeepening || maxDeepening < 0)
  {
    newInteractionLeft <- ModelParser[0]
    newInteractionRight <- newInteractionLeft
    
    treeFeatureInteractions <- CollectFeatureInteractions(ModelParser , newInteractionLeft ,
                                                          0, 0, pathProbabilityLeft , depth + 1, deepening + 1, 
                                                          treeIndex, tree.Data$Yes, maxInteractionDepth, maxDeepening,
                                                          treeFeatureInteractions,topEnv)
    
    treeFeatureInteractions <- CollectFeatureInteractions(ModelParser, newInteractionRight,
                                                          0, 0, pathProbabilityRight, depth + 1, deepening + 1, 
                                                          treeIndex, tree.Data$No, maxInteractionDepth, maxDeepening,
                                                          treeFeatureInteractions,topEnv)
  }
  
  path <- paste0(currentInteraction$Node[order(currentInteraction$Feature)],collapse = "-")
  
  if (! (fi$Name %in% treeFeatureInteractions$Name)){
    treeFeatureInteractions <- rbindlist(list(treeFeatureInteractions,fi),fill=TRUE);
    assign("pathMemo",c(get('pathMemo', envir=topEnv),path),envir = topEnv)
  }
  else{    
    if(path %in% get('pathMemo', envir=topEnv)) return(treeFeatureInteractions)
    
    assign("pathMemo",c(get('pathMemo', envir=topEnv),path),envir = topEnv)
    
    treeFeatureInteractions[Name==fi$Name,"Gain":=Gain+currentGain]
    treeFeatureInteractions[Name==fi$Name,"Cover":=Cover+currentCover]
    treeFeatureInteractions[Name==fi$Name,"FScore":=FScore+1]
    treeFeatureInteractions[Name==fi$Name,"FScoreWeighted":=FScoreWeighted+pathProbability]
    treeFeatureInteractions[Name==fi$Name,"AverageFScoreWeighted":=FScoreWeighted / FScore]
    treeFeatureInteractions[Name==fi$Name,"AverageGain":=Gain / FScore]
    treeFeatureInteractions[Name==fi$Name,"ExpectedGain":=ExpectedGain+currentGain * pathProbability]
    treeFeatureInteractions[Name==fi$Name,"TreeDepth":=TreeDepth+depth]
    treeFeatureInteractions[Name==fi$Name,"AverageTreeDepth":=TreeDepth / FScore]
    treeFeatureInteractions[Name==fi$Name,"TreeIndex":=TreeIndex+treeIndex]
    treeFeatureInteractions[Name==fi$Name,"AverageTreeIndex":=TreeIndex / FScore]
  }
  
  if (nrow(currentInteraction) - 1 == maxInteractionDepth) return(treeFeatureInteractions)
  
  currentInteractionLeft  <- currentInteraction
  currentInteractionRight <- currentInteraction
  
  if (is.na(tree.left.Data$Feature) && deepening == 0){
    treeFeatureInteractions[Name==fi$Name,"SumLeafValuesLeft":=SumLeafValuesLeft+tree.left.Data$Gain]
    treeFeatureInteractions[Name==fi$Name,"SumLeafCoversLeft":=SumLeafCoversLeft+tree.left.Data$Cover]
  }
  
  if (is.na(tree.right.Data$Feature) && deepening == 0) {
    treeFeatureInteractions[Name==fi$Name,"SumLeafValuesRight":=SumLeafValuesRight+tree.right.Data$Gain]
    treeFeatureInteractions[Name==fi$Name,"SumLeafCoversRight":=SumLeafCoversRight+tree.right.Data$Cover]
  }
  
  treeFeatureInteractions <- CollectFeatureInteractions(ModelParser , currentInteractionLeft, 
                                                        currentGain, currentCover, pathProbabilityLeft, depth + 1, deepening,
                                                        treeIndex, tree.Data$Yes, maxInteractionDepth, maxDeepening,
                                                        treeFeatureInteractions,topEnv)
  treeFeatureInteractions <- CollectFeatureInteractions(ModelParser, currentInteractionRight,
                                                        currentGain, currentCover, pathProbabilityRight, depth + 1, deepening,
                                                        treeIndex, tree.Data$No, maxInteractionDepth, maxDeepening,
                                                        treeFeatureInteractions,topEnv)
  
  return(treeFeatureInteractions[])
}