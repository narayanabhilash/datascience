#####  postcodeValid  #####
#' Function to check if a UK postcode is valid.
#' @description Returns true is a postcode is 
#' @usage postcodeValid(x,
#'               forceSpace=FALSE)
#' @param x A character vector to check against.
#' @param forceSpace If TRUE, the postcode must include the middle space to be valid.
#' Otherwise the space may be missing and the function will return TRUE if the postcode is otherwise valid. Default is FALSE.
#' @return A logical vector of TRUE of FALSE.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export

postcodeValid <- function(x, forceSpace=FALSE){
  if (forceSpace){
    checkPattern <- "^([A-Za-z][A-Ha-hK-Yk-y]?[0-9][A-Za-z0-9]? [0-9][A-Za-z]{2}|[Gg][Ii][Rr] 0[Aa]{2})$"
  } else{
    checkPattern <- "^([A-Za-z][A-Ha-hK-Yk-y]?[0-9][A-Za-z0-9]? ?[0-9][A-Za-z]{2}|[Gg][Ii][Rr] ?0[Aa]{2})$"
  }
  grepl(checkPattern, x)
}


#####  postcodeSectorValid  #####
#' Function to check if a UK postcode is valid.
#' @description Returns true is a postcode is 
#' @usage postcodeSectorValid(x,
#'               forceSpace=FALSE)
#' @param x A character vector to check against.
#' @param forceSpace If TRUE, the postcode must include the middle space to be valid.
#' Otherwise the space may be missing and the function will return TRUE if the postcode is otherwise valid. Default is FALSE.
#' @return A logical vector of TRUE of FALSE.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export

postcodeSectorValid <- function(x, forceSpace=FALSE){
  if (forceSpace){
    checkPattern <- "^([A-Za-z][A-Ha-hK-Yk-y]?[0-9][A-Za-z0-9]? [0-9]|[Gg][Ii][Rr] 0)$"
  } else{
    checkPattern <- "^([A-Za-z][A-Ha-hK-Yk-y]?[0-9][A-Za-z0-9]? ?[0-9]|[Gg][Ii][Rr] ?0)$"
  }
  grepl(checkPattern, x)
}