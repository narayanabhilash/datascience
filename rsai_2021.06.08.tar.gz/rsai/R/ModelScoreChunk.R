#' Score a model against a CSV file in chunks
#' 
#' @description This function scores a model against a CSV file, but doing it in chunks of a
#' specified size, rather than all at once. This means that the memory
#' consumption will be much lower and allows for scoring of data sets too large
#' to fit into memory.
#' 
#' \code{scoreAgainstCSV} is a (both S3 and S4) generic function, with specific
#' methods defined for \code{model} of class \code{gbm} and \code{expression}.
#' The \code{gbm} package is only required if that particular method is
#' used.\cr If \code{model} is an expression, then this can be used to provide
#' some SAS-data-step-like functionality without taking up a great deal of
#' memory space.\cr The default model will attempt to make use of the methods
#' of \code{predict}, but there is no guarantee it will work for a particular
#' class of model. In particular you may run into issues of factor mis-coding,
#' which you can solve by adding a block of code similar to that found in the
#' \code{.gbm} method.
#' 
#' @aliases scoreAgainstCSV scoreAgainstCSV.gbm scoreAgainstCSV.expression
#' scoreAgainstCSV.gbm scoreAgainstCSV-methods scoreAgainstCSV,ANY-method
#' scoreAgainstCSV,gbm-method scoreAgainstCSV,expression-method
#' @usage scoreAgainstCSV(model, fin, fout, inside = TRUE, predNames = 
#' paste0(substitute(model), "Preds"), chunkSize = 1000L, verbose = TRUE,
#' checkNames = TRUE, colClasses = NA,dataMap = data.table(col = character(),
#' oldval = character(), newval = character()), ...)
#' @param model The model object to score against. Different methods will be
#' dispatched depending on the class of \code{model}.
#' @param fin The input file. Can either be a quoted filename, or a connection
#' which is open for reading but not for writing. It needs to have column names
#' @param fout The output file. Can either be a quoted filename, or a
#' connection which is open for writing. If the empty string (""),
#' function returns predictions as an object in R (currently for default method only).
#' @param inside Logical. Evaluate expressions "inside" the input data frame
#' (using \code{\link{within}}), or in the environment of the function? Only
#' used if \code{model} is of class "expression" or a subclass.
#' @param predNames The name(s) to give to the new column(s) of predictions.
#' Defaults to the name of the model object, with "Preds" on the end. Note that
#' \code{predNames} must be specified explicitly if \code{scoreAgainstCSV} is
#' applied to an \code{EMBglm} object model.
#' @param chunkSize Number of rows per chunk. More will mean more memory usage,
#' but may be faster in some situations and reduces computation overhead.
#' @param verbose Logical. If TRUE, a message is printed after each chunk
#' scored.
#' @param checkNames Logical. Passed on to \code{check.names} argument in
#' \code{read.csv} when reading in files.
#' @param colClasses Logical. Passed on to \code{colClasses} argument in
#' \code{read.csv} when reading in files.  It may be necessary to set this to
#' `character` to avoid issues with reading in numeric (or mostly numeric) data
#' which contain leading zeroes.
#' @param dataMap Optional data.table. 
#' If specified, \code{dataMap} must contain 3 columns "col", 
#' "oldval" and "newval". Prior to running any predictions, for each row in \code{dataMap}, 
#' any data in \code{col} equal to \code{oldval} is set to \code{newval}.
#' @param \dots Any further arguments to pass to \code{predict}. For example,
#' if scoring data against a non-multiplicative EMBglm object, pass the type here. 
#' @details \code{scoreAgainstCSV} is a (both S3 and S4) generic function, 
#' with specific methods defined for \code{model} of class \code{gbm} and 
#' \code{expression}. The \code{gbm} package is only required if that particular
#'  method is used.\cr
#' If \code{model} is an expression, then this can be used to provide some 
#' SAS-data-step-like functionality without taking up a great deal of memory 
#' space.\cr
#' The default model will attempt to make use of the methods of \code{predict},
#'  but there is no guarantee it will work for a particular class of model. 
#'  In particular you may run into issues of factor mis-coding, which you can 
#'  solve by adding a block of code similar to that found in the \code{.gbm} 
#'  method.

#' @return NULL, invisibly (or a data table if fout is the empty string).
#' @note Error messages from \code{read.csv} are suppressed, so you might like
#' to check your file is readable before using this function. Other errors
#' (such as in \code{predict}) will report normally. \cr
#' @author James Lawrence
#' @seealso \code{\link{predict}}, \code{\link{predict.EMBglm}}
#' @export
#' @examples
#' 
#' ## simulate some data
#' df1 <- data.frame(x1=factor(sample(letters,1000,replace=TRUE)),x2=factor(sample(letters,1000,replace=TRUE)),x3=rnorm(1000))
#' df1$y <- with(df1,rnorm(1000) + as.integer(x1)/26 + (as.integer(x2)-as.integer(x1))/2000 + x3^2)
#' ## fit a GBM and a GLM
#' require(gbm)
#' gbm1 <- gbm(y ~ ., data=df1, n.trees=500L,shrinkage=0.01,interaction.depth=4L,verbose=TRUE)
#' glm1 <- glm(y ~ ., data=df1)
#' ## write the data to a file
#' write.csv(df1,file="testCSV.csv",row.names=FALSE)
#' ## now score the GBM and GLM
#' ## big chunk (1000 rows)
#' scoreAgainstCSV(gbm1,fin="testCSV.csv",fout="testCSV2.csv",n.trees=500L)
#' ## smaller chunks (100 rows)
#' scoreAgainstCSV(gbm1,fin="testCSV.csv",fout="testCSV3.csv",chunkSize=100L,n.trees=500L)
#' scoreAgainstCSV(glm1,fin="testCSV.csv",fout="testCSV4.csv",chunkSize=100L)
#' ## check the results are the same regardless of chunk size
#' identical(read.csv("testCSV2.csv"),read.csv("testCSV3.csv"))
#' ## clean up
#' unlink("testCSV.csv")
#' unlink("testCSV2.csv")
#' unlink("testCSV3.csv")
#' unlink("testCSV4.csv")
#' 
scoreAgainstCSV <-
  function(
    model,
    fin,
    fout = "",
    inside = TRUE,
    predNames = paste0(substitute(model), "Preds"),
    chunkSize = 1000L,
    verbose = TRUE,
    checkNames = TRUE,
    colClasses = NA,
    dataMap = data.table(
      col = character(),
      oldval = character(),
      newval = character()),
    ...) {
    
    
    if (is(fin, "connection")) {
      if (isOpen(fin, "w") ||
          !isOpen(fin, "r"))
        stop("'fin' must be open for reading and not open for writing")
    }
    if (is(fout, "connection")) {
      if (!isOpen(fout, "w"))
        stop("'fout' must be open for writing")
    }
    if (is.character(fin)) {
      fin <- file(fin, open = "r")
      on.exit(close(fin), add = TRUE)
    }
    if (is.character(fout)) {
      if (nchar(fout)) {
        fout <- file(fout, open = "w")
        on.exit(close(fout), add = TRUE)
      }
      
    }
    if(fin == fout) stop ("fin and fout must be different")
    UseMethod("scoreAgainstCSV")
  }



scoreAgainstCSVS4Generic <-
  function(model,
           fin,
           fout,
           inside = TRUE,
           predNames = paste0(substitute(model), "Preds"),
           chunkSize = 1000L,
           verbose = TRUE,
           checkNames = TRUE,
           colClasses = NA,
           dataMap = data.table(col = character(),
                                oldval = character(),
                                newval = character()),
           ...) {
    if (is(fin, "connection")) {
      if (isOpen(fin, "w") ||
          !isOpen(fin, "r"))
        stop("'fin' must be open for reading and not open for writing")
    }
    if (is(fout, "connection")) {
      if (!isOpen(fout, "w"))
        stop("'fout' must be open for writing")
    }
    if (is.character(fin)) {
      fin <- file(fin, open = "r")
      on.exit(close(fin), add = TRUE)
    }
    if (is.character(fout)) {
      if (nchar(fout)) {
        fout <- file(fout, open = "w")
        on.exit(close(fout), add = TRUE)
      }
    }
    standardGeneric("scoreAgainstCSV")
  }


scoreAgainstCSV.default <-
  function(
    model,
    fin,fout,inside=TRUE,
    predNames=paste0(substitute(model),"Preds"),
    chunkSize=1000L,verbose=TRUE,
    checkNames = TRUE, colClasses = NA,
    dataMap = data.table(col = character(),
    oldval = character(),
    newval = character()),
           ...) {
    cat ("starting the default method\n")
    if (!(nchar(fout))) df.out <- data.table() # null data table
    df.in <- try(read.csv(
      fin,
      stringsAsFactors=FALSE,
      nrow=chunkSize,
      check.names=checkNames,
      colClasses=colClasses,
      header = TRUE # this must be the case if you're going to score it...
      ),
      silent=TRUE)
    if (inherits(df.in, "try-error")){
      cat("file did not read in!. Returning NULL. Check you have set colClasses up appropriately." )  
      return(invisible(NULL))
      }
    df.names <- colnames(df.in)
    # modify df.in if dataMap has any values to it:
    
    if (!is.data.table (dataMap))
      stop ("dataMap must be a data table")
    if (! identical(colnames(dataMap) ,c("col", "oldval", "newval")))
      stop ("invalid column names for dataMap")
    if (nrow (dataMap) > 0) {
      for (i in 1:nrow (dataMap)) {
        Column <- dataMap$col[i]
        Old <- dataMap$oldval[i]
        New <- dataMap$newval[i]
        if (!(Column %in% colnames(df.in)))
          stop ("value ",
                Column,
                " in dataMap$col not found in columns of df.in")
        if (class (df.in[[Column]]) %in% c ("factor","ordered")) levels (df.in[[Column]])<- c(levels (df.in[[Column]]), New )
        if (is.na (Old))
          df.in[[Column]][is.na ( df.in[[Column]])] <- New
            else
              df.in[[Column]] [df.in[[Column]] == Old] <- New
      }}
    if(nchar(fout)){
        df.out <- cbind(df.in, predict(model, df.in, ...))
      names(df.out) <- c(df.names, predNames)
      write.csv(df.out, fout, row.names = FALSE)
    }  else {
         df.out <- data.table(predict(model, df.in, ...))
         
         names(df.out) <- predNames
      }
  
      n <- nrow(df.out)
      if (verbose)
        cat("scored", n, "rows\n")
      while (TRUE) {
        df.in <- try(read.csv(
          fin,
          stringsAsFactors=FALSE,
          nrow=chunkSize,
          check.names=checkNames,
          colClasses=colClasses,
          header = FALSE
          ),silent=TRUE)
        if(inherits(df.in,"try-error")) {
          if (nchar(fout)) return(invisible(NULL))
          return(df.out)}
        names(df.in) <- df.names
        if(nchar(fout)){
        df.out <- cbind(df.in, predict(model, df.in, ...))
        
        names(df.out) <- c(df.names, predNames)
        names(df.out) <- NULL
        write.csv(df.out[, ], fout, row.names = FALSE)
        }  else {
          names(df.in) <- df.names
          temp <- data.table(predict(model, df.in, ...))
          names(temp) <- predNames
          df.out <- rbind (df.out, temp) 
          rm(temp)
            
        }
        n <- n + nrow(df.in)
        if (verbose)
          cat("scored", n, "rows\n")
      }
      if(!(nchar(fout))) return (df.out)
    }

scoreAgainstCSV.expression <- function(model,fin,fout,inside=TRUE,
                                       predNames=paste0(substitute(model),"Preds"),
                                       chunkSize=1000L,verbose=TRUE,
                                       checkNames = TRUE, colClasses = NA,...){
	df.in <- try(read.csv(
	  fin, stringsAsFactors = FALSE, nrow = chunkSize,
	  check.names = checkNames, colClasses = colClasses, header = TRUE
	), silent = TRUE)
	if (inherits(df.in, "try-error"))
	  return(invisible(NULL))
	df.names <- colnames(df.in)
	if(inside) df.out <- within(df.in,eval(model))
	if(!inside) eval(model)
	write.csv(df.out,fout,row.names=FALSE)
	n <- nrow(df.out)
	if(verbose) cat("scored",n,"rows\n")
	while(TRUE){
		df.in <- try(read.csv(
		  fin,stringsAsFactors=FALSE,header=FALSE,nrow=chunkSize,
		  check.names=checkNames,colClasses=colClasses),silent=TRUE)
		if(inherits(df.in,"try-error")) return(invisible(NULL))
		names(df.in) <- df.names
		if(inside) df.out <- within(df.in,eval(model))
		if(!inside) eval(model)
		names(df.out) <- NULL
		write.csv(df.out[,],fout,row.names=FALSE)
		n <- n + nrow(df.out)
		if(verbose) cat("scored",n,"rows\n")		
	}
}

scoreAgainstCSV.gbm <- function(
  model, fin, fout, inside = TRUE, predNames = paste0(substitute(model), "Preds"),
  chunkSize = 1000L, verbose = TRUE,
  checkNames = TRUE, colClasses = NA, ...) {
  
	df.in <- try(read.csv(fin,stringsAsFactors=FALSE,nrow=chunkSize, header = TRUE,
	                      check.names=checkNames,colClasses=colClasses),silent=TRUE)
	if(inherits(df.in,"try-error")) return(invisible(NULL))
	for (v in names(df.in)){
		j <- match(v,model$var.names)
		vl <- model$var.levels[[j]]
		if(class(model$var.levels[[j]])=="character") df.in[[v]] <- factor(df.in[[v]],levels=vl) else df.in[[v]] <- as.numeric(df.in[[v]])
	}
	df.names <- colnames(df.in)
	df.out <- cbind(df.in,predict(model,df.in,...))
	names(df.out) <- c(df.names,predNames)
	write.csv(df.out,fout,row.names=FALSE)
	n <- nrow(df.out)
	if(verbose) cat("scored",n,"rows\n")
	while(TRUE){
		df.in <- try(read.csv(fin,stringsAsFactors=FALSE,header=FALSE,nrow=chunkSize,check.names=checkNames,colClasses=colClasses),silent=TRUE)
		if(inherits(df.in,"try-error")) {
		  if (nchar(fout)) return(invisible(NULL))
		  return(df.out)}
		names(df.in) <- df.names
		for (v in names(df.in)){
			j <- match(v,model$var.names)
			vl <- model$var.levels[[j]]
			if(class(model$var.levels[[j]])=="character") df.in[[v]] <- factor(df.in[[v]],levels=vl) else df.in[[v]] <- as.numeric(df.in[[v]])
		}
		df.out <- cbind(df.in,predict(model,df.in,...))
		names(df.out) <- c(df.names,predNames)
		names(df.out) <- NULL
		write.csv(df.out[,],fout,row.names=FALSE)
		n <- n + nrow(df.out)
		if(verbose) cat("scored",n,"rows\n")		
	}
}

## S4 variants
## can't be used without calling setOldClass("gbm")

setOldClass("gbm")
setGeneric("scoreAgainstCSV",signature=c("model"),def=scoreAgainstCSVS4Generic)
setMethod("scoreAgainstCSV",signature=signature(model="ANY"),scoreAgainstCSV.default)
setMethod("scoreAgainstCSV",signature=signature(model="expression"),scoreAgainstCSV.expression)
setMethod("scoreAgainstCSV",signature=signature(model="gbm"),scoreAgainstCSV.gbm)
