#####################################################
# Simple summary table
#####################################################

#' Create a simple summary table
#' 
#' @description Run function against data to return a data table with
#' simple summary statistics.
#' @usage simpleSummary(data)
#' @param data A data set
#' @export
#' @author Edwin Graham

simpleSummary <- function(data){
  data.table(
    feature = names(data),
    index = seq_along(data),
    numeric = sapply(data, is.numeric),
    class = sapply(data, function(x) class(x)[1]),
    unique = sapply(data, function(x) length(unique(x))),
    missing = sapply(data, function(x) sum(is.na(x))),
    mode = sapply(data, function(x) getMode(x, na.rm = TRUE)),
    min = sapply(data, function(x){
      if (is.numeric(x)) min(x, na.rm = TRUE) else NA
    }),
    mean = sapply(data, function(x){
      if (is.numeric(x)) mean(x, na.rm = TRUE) else NA
    }),
    median = sapply(data, function(x){
      if (is.numeric(x)) median(x, na.rm = TRUE) else NA
    }),
    sd = sapply(data, function(x){
      if (is.numeric(x)) sd(x, na.rm = TRUE) else NA
    }),
    max = sapply(data, function(x){
      if (is.numeric(x)) max(x, na.rm = TRUE) else NA
    })
  )
}