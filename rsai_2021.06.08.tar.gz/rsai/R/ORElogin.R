#' **DEFUNCT** Log in to a remote Exadata session
#' 
#' @description \code{ORElogin} is a wrapper for the \code{ore.connect} function, so that
#' you don't have to remember the defaults. It is also handy for including in
#' distributable code, so you don't have to share your password with others.
#' 
#' When called, \code{ORElogin} produces a tcl/tk widget with three fields
#' corresponding to the user name, datastore to connect to and password. The
#' first two have dynamic memory allocated to them and should remember previous
#' input; the third does not for security reasons. The username and division to
#' log in to are stored in the options \code{ore.name} and \code{ore.division}
#' respectively; these can be modified (and defaults set) using
#' \code{\link{options}} if desired.
#' @usage ORElogin(wait=FALSE)
#' @param wait logical. If \code{TRUE}, the login window remains active until a
#' successful connection is made or the window is closed (this is useful if you
#' are calling this function as part of script, to give you time to enter your
#' credentials before the rest of the script executes). If \code{FALSE} (the
#' default), code execution continues immediately once the window is
#' initialised.
#' @details When called, \code{ORElogin} produces a tcl/tk widget with three 
#' fields corresponding to the user name, datastore to connect to and password. 
#' The first two have dynamic memory allocated to them and should remember 
#' previous input; the third does not for security reasons.
#' The username and division to log in to are stored in the options 
#' \code{ore.name} and \code{ore.division} respectively; these can be modified 
#' (and defaults set) using \code{\link{options}} if desired.

#' @return NULL, although a message will be echoed to the terminal on a
#' successful connection.
#' @note % can't use links here, since ORE might not be available. At time of
#' writing, the session timeout is something like 30 minutes. Bear this in mind
#' when connecting, particularly returning after some time away.
#' \code{ore.is.connected} is not a reliable way of testing if your connection
#' will accept input.\cr \code{ORElogin} requires the \code{ORE} package. This
#' is not listed as a formal dependency of the \code{rsai} library to allow use
#' of other functionality without having to install \code{ORE}.
#' 
#' @author James Lawrence
#' @export
#' @examples
#' 
#' ## no examples listed, since this function is likely to become defunct soon!
#' 
ORElogin <- function(wait=FALSE){
##	require(ORE)
##	require(OREcommon)

.Defunct()

#	require(tcltk)
#	tt <- tktoplevel()
#	OREun <- tclVar("RSA_F#")
#	OREct <- tclVar("ALDB1")
#	label.widget.un <- tklabel(tt, text = "username")
#	un.widget <- tkentry(tt,textvariable=OREun)
#	if(!is.null(options("ore.name")$ore.name)) tclvalue(OREun) <- as.character(options("ore.name"))
#	label.widget.ct <- tklabel(tt, text = "connect to")
#	ct.widget <- tkentry(tt,textvariable=OREct)
#	if(!is.null(options("ore.division")$ore.division)) tclvalue(OREct) <- as.character(options("ore.division"))
#	label.widget.pw <- tklabel(tt, text = "password") 
#	pw.widget <- tkentry(tt,show="^")
#	button.widget <- tkbutton(tt, text = "connect",
#		command = oc <- function(){OREbase::ore.connect(
#			user=as.character(tkget(un.widget)),
#			sid=as.character(tkget(ct.widget)),
#			host="lwex02db3p01",
#			password=as.character(tkget(pw.widget)),
#			port=1521,
#			all=TRUE)
#			switch(as.character(OREbase::ore.is.connected()),"TRUE"=cat("success!\n"),"FALSE"=cat("failed!\n"))
#			options(ore.name=as.character(tkget(un.widget)))
#			options(ore.division=as.character(tkget(ct.widget)))
#			if(OREbase::ore.is.connected()) tkdestroy(tt)
#		}
#	)
#	tkbind(pw.widget, "<Return>",oc)
#	tkpack(label.widget.un,un.widget,label.widget.ct,ct.widget,label.widget.pw,pw.widget,button.widget) -> t1
#	if(wait) tkwait.window(tt)
}

#ore.top <- function() ore.doEval(function() system("/usr/bin/top -b -n1 -ugrid",intern=TRUE))
