#####  niceBin  #####
#' Function to bin numeric vectors into between maxLevs/2 and maxLevs intervals with "nice" round numbers as mid-points, and returns an ordered factor of the same length.
#' @description This function takes a vector, bins it into between maxLevs/2 and maxLevs intervals with "nice" round numbers as mid-points, and returns an ordered factor of the same length. The factor levels are set as the mid-points of the ranges used for binning.
#' @usage niceBin(x, maxLevs=255L, addNA=FALSE)
#' @param x A numerical vector
#' @param maxLevs The maximum number of levels allowable in the return factor
#' @param addNA If TRUE the returned factor has an NA level (useful for printing/plotting)
#' @return Ordered factor of the same length as the input vector
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #niceBin(rnorm(50))
#' @export

niceBin <- function(x, maxLevs=255L, addNA=FALSE){
  if(addNA) maxLevs <- maxLevs-1 # Create space for an NA level
  if(maxLevs<2) stop("maxLevs must be greater than 1, and greater than 2 if addNA is TRUE")
  if(all(is.na(x))){
    fac <- factor(x)
    if(addNA) fac <- addNA(fac)
    return(fac)
  }
  l <- min(x, na.rm = TRUE) # lowest
  h <- max(x, na.rm = TRUE) # highest
  if(identical(l, h)){
    fac <- factor(x)
    if(addNA) fac <- addNA(fac)
    return(fac)
  } 
  r <- h - l # range
  o <- c(1, 2, 2.5, 3, 4, 5, 6, 8, 10) # options for steps
  s <- r/(maxLevs - 1) # minimum size of step required
  step <- NULL # initialise step
  # For integers, ensure number of levels is as low as possible capturing all variation
  if(is.integer(x)){
    int <- TRUE
  } else if(any(is.na(as.integer(x[which(!is.na(x))])))) {
    int <- FALSE # protects against integer overflow
  } else if(all(x[which(!is.na(x))]==as.integer(x[which(!is.na(x))]))){
    int <- TRUE
  } else int <- FALSE
  if(int) {
    GCD <- gcd(x) # Greatest common denominator for x
    tens <- floor(log10(GCD)) # units of first sig.fig of GCD
    o_ <- unique(do.call(c, lapply(seq(0, tens), function(i) o*10^i)))
    o_ <- o_[order(-o_)]
    o_ <- o_[which(o_!=2.5)]
    possStep <- o_[which(sapply(o_, function(x) !GCD%%x))[1]] # Possible step size based on GCD
    if(possStep>s) step <- possStep
  }
  if(is.null(step)){
    tens_r <- floor(log10(r)) # units of first sig.fig of range
    tens_s <- floor(log10(s)) # units of first sig.fig of min step size
    o_ <- unique(do.call(c, lapply(seq(tens_s, tens_r), function(i) o*10^i)))
    o_ <- o_[order(-o_)]
    if(int) o_ <- o_[which(o_!=2.5)]
    step <- min(o_[which(o_ >= s)])
    if(int) step <- max(step, 1)
  }
  firstBreak <- ceiling(l/step) - 0.5
  if(firstBreak < l/step) firstBreak <- firstBreak + 1
  lastBreak <- floor(h/step) + 0.5
  if(lastBreak > h/step) lastBreak <- lastBreak - 1
  breaks <- seq(firstBreak, lastBreak) * step # breaks for splitting x
  midpoints <- seq(firstBreak - 0.5, lastBreak + 0.5) * step # mid-points of splits
  fac <- cut(x, breaks = c(-1/0, breaks, 1/0)) # Split x using breaks
  levels(fac) <- midpoints # level names are midpoints of splits
  fac <- ordered(fac, levels = levels(fac)) # apply ordering
  if(addNA) fac <- addNA(fac)
  return(fac)
}





