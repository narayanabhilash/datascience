#####  plotResponseByCol  #####
#' Function to plot a column by a response variable
#' @description This function takes a factor or numeric column (if numeric it will be binned) and plots it against
#' a response column (average by bin) with columns of exposure / weight / count.
#' @usage plotResponseByCol(
#' data,
#' col,
#' colOrder = NULL,
#' response,
#' predCols=NULL,
#' exposure=NULL,
#' weight=NULL,
#' maxLevs=255,
#' title=NULL,
#' na = NULL,
#' xAxisName=NULL,
#' barAxisName=NULL,
#' lineAxisName=NULL,
#' Palette=NULL,
#' Thickness = NULL,
#' maxYaxisBar = NULL,
#' ...)
#' @param data A data frame.
#' @param col The name of the column defining the x-axis.
#' @param colOrder Optional argument to order the columns. This can be: the name of a column in \code{data}
#' (in which case the plotted data are sorted consistently with their match to this column),
#' "weight" or "response" (to reorder by these), or a character vector of length >1 (in which case _only_ those columns display.) 
#' @param response The name of the column defining the observed response variable.
#' @param predCols Optional. A character vector of column names. The columns should contain model predictions.
#' @param exposure Optional column name defining exposure. For claim severity it would define claim count.
#' @param weight Optional column name (or names) defining weights where the weights are unrelated to exposure.
#' If more than one weight column selected then weights are shown as stacked bars.
#' This can be used to show how the distributions of other factors varies by the x-axis column.
#' @param maxLevs Maximum number of levels to plot.
#' @param title Optional chart title.
#' @param na Optional numeric value to treat as NA (or named list thereof).
#' @param xAxisName Optional x-axis title.
#' @param barAxisName Optional y-axis title for the bar columns.
#' @param lineAxisName Optional y-axis title for the line columns.
#' @param Palette Optional colour palette. This is applied to the bars first, then the lines.
#' @param Thickness Optional line width parameter. 
#' @param maxYaxisBar Optional plotting argument to hard specify the maximal Y axis bar value.
#' @param \dots Optional parameters to be passed through to plot_ly function
#' e.g. width=910 to set the chart width.
#' @return A plotly plot object
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export
#' @examples
#' data("UKTheftFreq")
#' plotResponseByCol(
#' UKTheftFreq,
#' col = "year",
#' colOrder = as.character(2013:2016),
#' response = "numClaims",
#' predCols = "currentModel",
#' exposure = "exposure",
#' weight = "weight",
#' title = "Actual vs Expected claim Frequency by Year")
#'  

plotResponseByCol <- function 
(
  data,
  col,
  colOrder = NULL,
  response,
  predCols = NULL,
  exposure = NULL,
  weight = NULL,
  maxLevs = 255,
  title = NULL,
  na = NULL,
  xAxisName = NULL,
  barAxisName = NULL,
  lineAxisName = NULL,
  Palette = NULL,
  Thickness = NULL,
  maxYaxisBar = NULL,
  ...
) 
{
  
  
  ###############################################################
  # Validation checks
  if(!is.data.frame(data)) stop("data must be a data frame")
  if(!is.data.table(data)) data <- data.table(data) else data <- copy(data)
  if(length(response)!=1) stop("response should be one column")
  if(length(col)!=1) stop("col should be one column")
  if(!is.null(exposure)) if(length(exposure)!=1) stop("exposure should be one column")
  #if(!is.null(weight)) if(length(weight)!=1) stop("weight should be one column")
  if(!(all(weight %in% names(data)))) stop("one or more weight columns are not in the data set")
  if(anyDuplicated(c(response, exposure, weight, predCols))) stop("Columns duplicated.")
  if(any(c("weight", "response") %in% predCols)) stop("No predCols can be named: 'weight' or 'response'")
  

# column order ------------------------------------------------------------
  
  if (is.list(colOrder)){
    if (col %in% names (colOrder)) colOrder <- colOrder[[col]] else colOrder <- NULL
  }
  
  # blame Tom for this bit...
  colOrder3 <- NULL
  if(length(colOrder) > 1){
    colOrder3 <- copy(colOrder)
    colOrder <- NULL
  }
  
  colOrder2 = colOrder
  if(!is.null(colOrder)){
      if (!(colOrder %in% c("response", "weight", names(data)))) 
        stop("colOrder should be 'response', 'weight' or a column name")
  if (colOrder %in% c("response", "weight")) colOrder2 = NULL
    }
  
  # Filter data
  data <- data[,
               unique(c(response, exposure, weight, predCols, col, colOrder2)),
               with=FALSE]
  
  # Ensure columns are unique
  originalCol <- col
  if(col %in% c(response, exposure, weight, predCols)){
    newNames <- make.names(c(response, exposure, weight, predCols, col), unique=TRUE)
    col <- newNames[length(newNames)]
    names(data) <- newNames
  }
  
  # Deal with missing weight
  if(is.null(weight)){
    data[, weight := 1]
    weight <- "weight"
  }
  
  # Adjust for exposure
  if(!is.null(exposure)){
    set(data, j=response, value=data[[response]]/data[[exposure]])
    for (wts in weight){
      set(data, j = wts, value = data[[wts]] * data[[exposure]])
    } # could use data table syntax for this?? 
    set(data, j=exposure, value=NULL)
  }
  # Bin col and/or adjust for missing
  if(is.numeric(data[[col]])){
    if (is.list(na)) na <- na[[col]]
    data[get(col) == na, eval(col):= NA]
    set(data, j=col, value=niceBin(data[[col]], maxLevs, anyNA(data[[col]])))
  } else if(is.factor(data[[col]])){
    if(anyNA(data[[col]])) set(data, j=col, value=base::addNA(data[[col]]))
  } else {
    if (any(c("POSIXct", "Date") %in% class (data[[col]]))) {
      temp <- niceBin(as.double(data[[col]]), maxLevs, anyNA(data[[col]]))
      data[[col]] <- data[[col]][match(temp, temp)]
    } else stop("Must specify a factor or numeric column.")
  }
  setnames(data, c(response, col), c("response", "col"))
  
  # Summarise for plot
  # create a single weight column
  Weights <- weight
  if (length(Weights) > 1){
    data[, weightSum :=  rowSums(.SD), .SDcols = Weights]
    setnames(data, "weightSum", "weight")
  } else {
    setnames(data, weight, "weight")
    Weights <- "weight"
  }
  summary <- data[, c(.(weight=sum(weight)), lapply(.SD, function(x) weighted.mean(x, weight))),
                  keyby = "col", 
                  .SDcols = c("response", predCols)]
  # multiple Weights:
  if (length(Weights) > 1){
    weightSum <- data[, lapply(.SD, sum), keyby = "col", 
                      .SDcols = Weights] 
    summary <- weightSum[summary]
  }
  if(nrow(summary) > maxLevs){
    setkey(summary, weight)
    summary[seq(1, nrow(summary)-maxLevs+1), newCol := "Other"]
    summary[seq(nrow(summary)-maxLevs+2, nrow(summary)), newCol := as.character(col)]
    if(length(Weights) > 1) temp <- summary[, lapply(.SD, sum), keyby = "newCol", .SDcols = Weights]
    summary <- summary[, c(.(weight=sum(weight)), lapply(.SD, function(x) weighted.mean(x, weight))),
                       keyby = "newCol", 
                       .SDcols = c("response", predCols)]
    summary[, newCol := factor(newCol, exclude=NULL)]
    setnames(summary, "newCol", "col")
    if (length(Weights) > 1) summary <- temp[summary]
  }
  setkeyv(summary, "col")

  # Order summary...
  if (!is.null(colOrder)) {
    ordName = "colOrder2"
    while (ordName %in% names(summary)) {
      ordName <- paste0(ordName, "x")
    }
    if (colOrder %in% names(summary)) {
      summary[[ordName]] <- summary[[colOrder]] 
      } else {
      summary[[ordName]] <-
        as.factor(data[[colOrder2]][match(summary$col, data$col)])
    }
    setkeyv(summary, "col")
    # I really really don't understand why I can't use colOrder2 in a key here.
    # but it does. not. work.
      summary <- summary[order(summary[[ordName]],
                               decreasing = (colOrder == "weight"))]
  }
  # Order summary...
  if (!(is.null(colOrder3))){
    summary <- summary [as.character(col) %in% colOrder3]
    temp <- match(as.character(summary$col), colOrder3)
    summary <- summary[order(temp)]
  }
  
  summary$display <- as.character(summary$col)
  summary[is.na(display), display := "NA"]
  summary[, display := factor(display, levels=summary$display)]
  setnames(summary, "display", col)
  
  if(is.null(xAxisName)) xAxisName <- originalCol
  return(
    barLinePlot(
      summary, factorCol = col, barCols = Weights,
      stacked = (length(Weights) > 1),
      lineCols = c("response", predCols),
      title = title, xAxisName = xAxisName,
      barAxisName = barAxisName,
      lineAxisName = lineAxisName,
      maxYaxisBar = maxYaxisBar,
      Palette = Palette, Thickness = Thickness, ...))
}
