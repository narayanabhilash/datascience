#####  plotEvalLog  #####
#' Function to plot the evaluation log for an xgb.cv.synchronous object.
#' @description Plot the evaluation log for an xgb.cv.synchronous object (output from xgb.cv()).
#' @usage plotEvalLog(cv, legendPosition="topright")
#' @param cv An xgb.cv.synchronous object or a list containing an evalution log table.
#' @param legendPosition Position of the legend, e.g. "topleft".
#' @return A plot.
#' @note You can also call this on xgb.train objects, if you've set a watchlist. 
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples # plotEvalLog(xgbCV)
#' @export

plotEvalLog <- function(cv, legendPosition="topright"){
  # Evaluation log columns to plot
  cols <- setdiff(grep("_std$", names(cv$evaluation_log), invert=TRUE, value=TRUE), "iter")
  
  # Range of plot
  minY <- min(sapply(cols, function(col) min(cv$evaluation_log[[col]])))
  maxY <- max(sapply(cols, function(col) max(cv$evaluation_log[[col]])))
  range <- maxY-minY
  units <- 10^floor(log(range, base=10))
  minY <- units*floor(minY/units)
  maxY <- units*ceiling(maxY/units)
  
  # Create empty plot with the right scale
  plot(1, type="n", xlab="Num Trees", ylab="Evaluation metric", xlim=c(0, nrow(cv$evaluation_log)), ylim=c(minY, maxY))
  # Plot each of the columns in the evaluation log
  for(i in 1:length(cols)){
    lines(cv$evaluation_log[[cols[i]]], col=i)
  }
  # Best iteration
  abline(v=cv$best_iteration, lty=2)
  # Legend
  legend(legendPosition, legend=cols, col=1:length(cols), lty=1, cex=0.8)
}

#####  plot.xgb.cv.synchronous  #####
#' Function to plot the evaluation log for an xgb.cv.synchronous object.
#' @description Plot the evaluation log for an xgb.cv.synchronous object (output from xgb.cv().)
#' @param cv An xgb.cv.synchronous object or a list containing an evalution log table.
#' @param legendPosition Position of the legend, e.g. "topleft".
#' @return A plot.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples # plot(xgbCV)
#' @export

plot.xgb.cv.synchronous <- plotEvalLog