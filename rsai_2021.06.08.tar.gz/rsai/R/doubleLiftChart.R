
#' Double lift chart of candidate models
#' @description \code{doubleLiftChart} produces a plotly double lift chart (or the table behind it) of two models,
#'  showing how well the models fit to unseen data. The data is split into bins
#' according to the relative predictions (as a ratio) of the two models.
#' @usage doubleLiftChart(
#' dataset,
#' Response,
#' model_1,
#' model_2,
#' nbins = 10,
#' Exposure = NULL,
#' Weight = NULL,
#' model_1Name = NULL,
#' model_2Name = NULL,
#' ResponseName = NULL,
#' offset_model = NULL,
#' calibrate = FALSE,
#' family = NULL,
#' tweedieP = NULL,
#' chart = TRUE,
#' ExBand = F,
#' ...)
#' @param dataset data frame containing model predictions and outcomes 
#' @param Response Response column in dataset
#' @param model_1 model_1 column in dataset
#' @param model_2 model_2 column in dataset
#' @param nbins number of bins into which the data are divided
#' @param Exposure Optional exposure column in dataset.
#' The response will be divided by exposure and rows will be weighted by exposure.
#' @param Weight Optional weight column in dataset (if null, assumed unweighted).
#' This is used to weight rows with no effect on response/
#' @param model_1Name name given to model 1 in chart (defaults to \code{model_1})
#' @param model_2Name name given to model 2 in chart (defaults to \code{model_2})
#' @param ResponseName name given to response in chart (defaults to \code{Response})
#' @param offset_model Offset column in dataset.
#' The offset is assumed to be multiplicative if used.
#' Both sets of model predictions will be multiplied by values from this column if used.
#' @param calibrate if TRUE, re-bases both sets of predictions
#' (I.E. refits the intercept for both models.) You must supply a \code{family} to do this.
#' @param family Used only if \code{calibrate=TRUE}. Must be one of: Normal, Bernoulli, Poisson, Gamma, Tweedie.
#' @param tweedieP Tweedie power parameter. Used only if \code{calibrate=TRUE} and \code{family="Tweedie"}.
#' Must be between 1 and 2.
#' @param chart if TRUE, produces a \code{plotly} chart rather than a data table
#' @param ... further arguments passed to barLinePlot.
#' @param ExBand if TRUE, bands data with equal exposure rather than equal row count.
#' @import data.table 
#' @export
doubleLiftChart <- function(
  dataset,
  Response,
  model_1,
  model_2,
  nbins = 10,
  Exposure = NULL,
  Weight = NULL,
  model_1Name = NULL,
  model_2Name = NULL,
  ResponseName = NULL,
  offset_model = NULL,
  calibrate = FALSE,
  family = NULL,
  tweedieP = NULL,
  chart = TRUE,
  ExBand = F,
  ...
){
  

# Sort out chart name NULLS# ---------------------------------------------------------
  if(is.null(model_1Name)) model_1Name <- model_1
  if(is.null(model_2Name)) model_2Name <- model_2
  if(is.null(ResponseName)) ResponseName <- Response
  
  if(!(all(c(Response, model_1, model_2, Weight, Exposure, offset_model) %in% names(dataset)))){
    stop("column names provided are not all in dataset")
  }
  
  if(!is.data.frame(dataset)) stop("dataset must be a data frame")
  if(!is.data.table(dataset)) dataset <- data.table(dataset)
  
  LiftDataTable <- dataset[, c(Response, model_1, model_2, Weight, Exposure, offset_model), with=FALSE]
  
  setnames(LiftDataTable, c(Response, model_1, model_2), c('Response', 'model_1', 'model_2'))

  if(is.null(Weight)) LiftDataTable[, Weight := 1] else setnames(LiftDataTable, Weight, "Weight")
  if(is.null(Exposure)) LiftDataTable[, Exposure := 1] else setnames(LiftDataTable, Exposure, "Exposure")
  if(is.null(offset_model)) LiftDataTable[, offset_model := 1] else setnames(LiftDataTable, offset_model, "offset_model")
   
  if(anyNA(LiftDataTable)) stop("NAs detected in data or implied: remove or fix")
  
  LiftDataTable[,':='(Response = Response/Exposure,
                      Weight = Exposure*Weight,
                      model_1 = model_1*offset_model,
                      model_2 = model_2*offset_model)]
  
  ### REBASE / CALIBRATE
  if(calibrate){
    if(is.null(family)){
      stop("family must be one of: Normal, Bernoulli, Poisson, Gamma, Tweedie when calibrate=TRUE.")
    } else if(!(family %in% c("Normal", "Bernoulli", "Poisson", "Gamma", "Tweedie"))){
      stop("family must be one of: Normal, Bernoulli, Poisson, Gamma, Tweedie when calibrate=TRUE.")
    }
    
    if(family=="Tweedie"){
      if(is.null(tweedieP)){
        stop("If family is Tweedie then tweedieP must be between 1 and 2.")
      } else if(tweedieP<1 | tweedieP>2){
        stop("If family is Tweedie then tweedieP must be between 1 and 2.")
      }
    }
    
    LiftDataTable[, ':=' (
      model_1 = rebasePreds(Response, model_1, family=family, w=Weight, p=tweedieP),
      model_2 = rebasePreds(Response, model_2, family=family, w=Weight, p=tweedieP))]
    
  }
 
   

  LiftDataTable[,':='(ModelRatio = model_2 / model_1)]
  if (ExBand){
  # Change to work off of Exposure rather than .N (i.e. Row Count)
  LiftDataTable <- LiftDataTable[order(ModelRatio)]
  LiftDataTable[, ':='(ModelRatioBin = ceiling(nbins * cumsum(Weight)/sum(Weight)))]
  } else {
  LiftDataTable[,':='(ModelRatioBin = ceiling(nbins *frank(model_2 / model_1)/.N))]
  }
  
  
  LiftDataSum <- LiftDataTable[, .(
    Response = weighted.mean(Response, Weight),
    model_1 = weighted.mean(model_1, Weight),
    model_2 = weighted.mean(model_2, Weight),
    Weight = sum(Weight)),
    keyby = ModelRatioBin]
  
  setnames(LiftDataSum, c("Response", "model_1", "model_2"), c(ResponseName, model_1Name, model_2Name))
  
  if (chart) {
    barLinePlot(LiftDataSum,
                factorCol = "ModelRatioBin",
                barCols = "Weight",
                lineCols = c(ResponseName, model_1Name, model_2Name),  
                ...)
    
  } else return (LiftDataSum)
}
