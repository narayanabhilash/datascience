# numEncode
# facEncode
# encoderNames
# validateEncoder
# factorEncoder

#####  numEncode  #####
#' Encode a numeric into a numeric matrix.
#' @description Function that takes a vector and applies any missing value treatment and, if necessary, converts to numeric.
#' Returns a single column matrix, either sparse or dense.
#' @usage numEncode(
#'  x,
#'  colName = "x",
#'  NA_treatment = "fix",
#'  NA_value = 2.14E+9,
#'  sparse = FALSE
#')
#' @param x A vector to encode.
#' @param colName The column name. This will be used to create the column name of the resulting matrix.
#' @param NA_treatment What to do with missing values. Options are: pass (default), zero, addNA, drop or fail.
#' \describe{
#'   \item{pass}{NAs are passed through and returned as NAs in the final matrix.}
#'   \item{fix}{The NA is replaced by the \code{NA_value}}
#'   \item{drop}{Rows containing NAs are dropped.}
#'   \item{fail}{The function stops with an error message (useful as a catch if you are expecting no NAs.)}
#' }
#' @return A numeric matrix with named columns - either a standard dense matrix or a sparse matrix of class dgCMatrix.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom Matrix sparse.model.matrix Matrix
#' @importFrom data.table data.table
#' @examples
#' # set.seed(1984L)
#' # mat <- numEncode(
#' #   sample(c(1:100, NA), 2000, replace=TRUE),
#' # colName = "Column",
#' #  NA_treatment = "fix",
#' #  NA_value = 9999
#' # )
#' # head(mat)
#' @export

numEncode <- function(
  x,
  colName = "x",
  NA_treatment = "fix",
  NA_value = 2.14E+9,
  sparse = FALSE
){
  
  # Deal with non-numeric vectors
  if ("Date" %in% class(x)){
    x <- as.integer(x)
    colName <- paste0(colName, "~Date")
  } else if ("POSIXct" %in% class(x)){
    x <- as.double(x)
    colName <- paste0(colName, "~POSIXct")
  } else if (is.logical(x)){
    x <- as.integer(x)
    colName <- paste0(colName, "~logical")
  } else if (!is.numeric(x)){
    x <- tryCatch({
      as.numeric(x)
    }, warning = function(w) {
      stop("")
    }, error = function(e) {
      stop(paste0(colName, " cannot be coerced to numeric."))
    })
    warning(paste0(colName, " was coerced to numeric."))
  }
  
  # Apply NA action
  if (NA_treatment == "fail"){
    if(anyNA(x)) stop(
      paste0(colName, " contains missing values which is not allowed with a 'fail' NA action.")
    )
    
  } else if (NA_treatment == "drop"){
    x <- x[!is.na(x)]
    
  } else if (NA_treatment == "fix"){
    if (!is.numeric(NA_value)){
      stop("NA_value must be numeric")
    }
    if (length(NA_value) != 1){
      stop("NA_value must be length 1")
    }
    if (is.na(NA_value)){
      stop("NA_value must not be NA")
    }
    if (! is.finite(NA_value)){
      stop("NA_value must be finite")
    }
    if (is.integer(x)){
      if (is.integer(NA_value) == NA_value){
        NA_value <- as.integer(NA_value)
      }
    }
    x[which(is.na(x))] <- NA_value
    
  } else if (NA_treatment != "pass"){
    stop("NA_treatment should be one of 'fix', 'drop', 'fail' or 'pass'.")
  }
  
  # Create matrix
  if (sparse){
    require(Matrix)
    mat <- Matrix(x, sparse = TRUE)
  } else{
    mat <- matrix(x)
  } 
  
  # Set column names
  colnames(mat) <- colName
  
  # return
  return(mat)
}



#####  encoderNames  #####
encoderNames <- function(){
  c("oneHot", "numeric", "ordered", "binary", "circular")
}



#####  validateEncoder  #####
validateEncoder <- function(x){
  if (is.character(x)){
    if (x %in% encoderNames()){
      return(TRUE)
    }
    return(FALSE)
  }
  if (is.function(x)){
    if (length(formals(x)) < 3){
      return(FALSE)
    } 
    if (all(names(formals(x)[1:3]) == c("x", "trainMode", "sparse"))){
      return(TRUE)
    }
  }
  return(FALSE)
}



#####  facEncode  #####
#' Encode a factor into a numeric matrix.
#' @description Function that takes a factor and applies an encoding to a sparse or dense matrix.
#' Supported encodings include: one-hot, numeric, binary, ordered and circular.
#' Returns either a sparse or dense matrix.
#' @usage facEncode(
#'  x,
#'  factorName = "x",
#'  encoder = "oneHot",
#'  NA_treatment = "fix",
#'  sparse = FALSE
#')
#' @param x A factor vector to encode.
#' @param factorName The factor name. This will effect the column names of the resulting matrix.
#' @param encoder The encoder to use. Must be one of: oneHot (default), numeric, ordered, binary or circular.
#' \describe{
#'   \item{oneHot}{Each level of the factor will have its own column containing 1 or 0 depending on the value for that row.}
#'   \item{numeric}{The function \code{as.integer} is simply applied to the factor.}
#'   \item{ordered}{The factor is assumed in the same order as the \code{as.integer} function would put it in.
#'   A binary column is encoded for each possible split-point. This will result in n-1 columns for an n-level factor.
#'   I.E. the columns of a resulting matrix will be: as.integer(x) >= 2; as.integer(x) >= 3; ... ; as.integer(x) >= n}
#'   \item{binary}{This first encodes the factor as an integer (again uses \code{as.integer} and subtracts 1 so levels start at 0.) 
#'   Then the integer is converted to binary. The binary numbers are then split into columns, so the first column represents 2^0, then 2^1, etc.}
#'   \item{circular}{Assumes the factor describes something that is ordered and "wraps around", for example days of the week
#'   This will result in a two column encoding where one column is \code{sin((as.integer(x)-1)*2*pi/length(levels(x)))}
#'   and the other is \code{cos((as.integer(x)-1)*2*pi/length(levels(x)))}.}
#' }
#' @param sparse Specify TRUE (default) to return a sparse matrix or FALSE to return a dense matrix.
#' @param NA_treatment What to do with missing values. Options are: pass (default), zero, addNA, drop or fail.
#' \describe{
#'   \item{pass}{NAs are passed through and returned as NAs in the final matrix.}
#'   \item{fix}{A new NA level is added before the encoding is applied for all encodings
#'   except circular where the NA rows are set to zero for both columns.}
#'   \item{zero}{If encoder is set to oneHot, the final encoding will not include a column for NAs,
#'   so any NA values will be encoded as a zero vector..
#'   This is unless the factor explicitly has an NA level (which can be set using \code{addNA}).
#'   For any other encoder, the NA_treatment will be identical to "fix".}
#'   \item{drop}{Rows containing NAs are dropped.}
#'   \item{fail}{The function stops with an error message (useful as a catch if you are expecting no NAs.)}
#' }
#' @return A numeric matrix with named columns - either a standard dense matrix or a sparse matrix of class dgCMatrix.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom Matrix sparse.model.matrix Matrix
#' @importFrom data.table data.table
#' @examples
#' # # Create some dummy data
#' facEncode(
#'   factor(c("A", "B", "C")),
#'   factorName = "x",
#'   encoder = "oneHot",
#'   sparse = FALSE,
#'   NA_treatment = "pass"
#' )
#' # head(mat)
#' @export

facEncode <- function(
  x,
  factorName = "x",
  encoder = "oneHot",
  NA_treatment = "fix",
  sparse = FALSE
){
  # x must be a factor
  if (!is.factor(x)) stop("x must be a factor")
  
  # Validate factorName
  if (!is.character(factorName)){
    stop("factorName must be a character vector")
  }
  if (length(factorName) != 1){
    stop("factorName must be a character vector of length 1")
  }
  
  # Validate encoders
  validEncoders <- c("oneHot", "numeric", "ordered", "binary", "circular")
  if (!is.character(encoder)){
    stop("encoder must be a character vector")
  }
  if (length(encoder) != 1){
    stop("encoder must be a character vector of length 1")
  }
  if (!encoder %in% validEncoders){
    stop(paste0("encoder must be one of: ", paste0(validEncoders, collapse=", "), "."))
  }
  
  # Validate NA_treatment
  validNAActions <- c("pass", "fix", "drop", "fail", "zero")
  if (!is.character(NA_treatment)){
    stop("NA_treatment must be a character vector")
  }
  if (length(NA_treatment) != 1){
    stop("NA_treatment must be a character vector of length 1")
  }
  if (!NA_treatment %in% validNAActions){
    stop(paste0("NA_treatment must be one of: ", paste0(validNAActions, collapse=", "), "."))
  }
  
  # sparse
  if (!is.logical(sparse)){
    stop("sparse must be logical")
  }
  if (length(sparse) != 1){
    stop("sparse must be a logical vector of length 1")
  }
  if (is.na(sparse)){
    stop("sparse must be TRUE or FALSE")
  }
  if (sparse) require(Matrix)
  
  # Find the current global na.action option and store
  current.na.action <- options('na.action')
  
  # Find which elements, if any, are NAs
  whichNA <- which(is.na(x))
  
  # Set up to perform the required na.action
  if (NA_treatment == "zero" & encoder != "oneHot"){
    NA_treatment <- "fix"
  } else if (NA_treatment == "zero"){
    options('na.action' = "na.pass")
  }
  
  if (NA_treatment == "fix"){
      x <- addNA(x)
  } else if (length(whichNA)==0){
    NA_treatment <- "none"
  }
  
  if (NA_treatment == "fail"){
    stop("data contains NAs which is not allowed under the specified NA_treatment")
  } else if (NA_treatment == "drop"){
    x <- x[-whichNA]
  } else if (NA_treatment == "pass"){
    options('na.action' = "na.pass") # Set the global na.action option to pass, as required
  }
  
  # Number of levels
  nLevs <- length(levels(x))
  
  ##### ENCODINGS ##### 
  #### OneHot ####
  if (encoder == "oneHot"){
    if (sparse){
      mat <- sparse.model.matrix(~ . + 0, data = data.frame(x)) # sparse one-hot encoding
      if (NA_treatment == "pass"){
        mat[whichNA, ] <- NA
      }
    } else{
      mat <- model.matrix(~ . + 0, data = data.frame(x)) # dense one-hot encoding
      if (NA_treatment == "zero"){
        mat[is.na(mat)] <- 0
      }
    }
    colnames(mat) <- paste0(factorName, "~is~", levels(x))
    
    #### numeric ####
  } else if (encoder == "numeric"){
    x <- as.integer(x)
    if (sparse){
      mat <- Matrix(x, sparse = TRUE)
    } else {
      mat <- matrix(x)
    }
    colnames(mat) <- paste0(factorName, "~numeric")
    
    #### ordered ####
  } else if (encoder == "ordered"){
    if (length(x) == 0){
      mat <- matrix(numeric(0), ncol = nLevs - 1)
    } else(
      mat <- sapply(
        seq(2, nLevs),
        function(i){
          1*(as.integer(x) >= i)
        }
      )
    )
    if (sparse){
      mat <- Matrix(mat, sparse = TRUE)
    }
    colnames(mat) <- paste0(factorName, "~ordered~", seq(2, nLevs))
    
    #### binary ####
  } else if (encoder == "binary"){
    mat <- matrix(
      as.integer(intToBits(as.integer(x)-1)),
      ncol = 32,
      nrow = length(x),
      byrow = TRUE
    )
    mat[which(mat[, 32] == 1), ] <- NA
    mat <- mat[, 1:ceiling(log(nLevs)/log(2))]
    if (sparse){
      mat <- Matrix(mat, sparse = TRUE)
    }
    colnames(mat) <- paste0(factorName, "~binary~", seq(0, ncol(mat)-1))
    
    #### circular ####
  } else if (encoder == "circular"){
    # circular encoding
    circlePoints <- length(which(! is.na(levels(x))))
    x_ <- (as.integer(x)-1)/circlePoints
    mat <- matrix(c(sin(x_*2*pi), cos(x_*2*pi)), ncol = 2)
    mat[which(is.na(as.character(x))), ] <- 0

    if (sparse){
      mat <- Matrix(mat, sparse = TRUE)
    }
    colnames(mat) <- paste0(factorName, "~circular", circlePoints, "~", c("sin", "cos"))
  }
  ########## 
  
  # Set global na.action option back to whatever it was at the start
  options('na.action' = current.na.action$na.action)
  
  # Return the matrix
  return(mat)
}


#####  factorEncoder  #####
#' Encode all factors in a data frame to numeric columns and return a numeric matrix.
#' @description Function that takes a data frame with numeric and factor columns and applies encodings 
#' to each of the factors.
#' Returns a numeric matrix.
#' @usage factorEncoder(
#'  data,
#'  defaultEncoding       =  "oneHot",
#'  encodingExceptions    =  NULL,
#'  NA_treatment          =  "fix",
#'  NA_exceptions         =  NULL,
#'  NA_default            =  2.14E+9,
#'  NA_defaultExceptions  =  NULL,
#'  sparse                =  NULL,
#'  denseThreshold        =  0.5,
#'  addAttributes         =  TRUE,
#'  trainMode             =  FALSE
#' )
#' @param data A data frame containing only numeric or factor columns.
#' @param defaultEncoding The default encoder to apply to factor columns.
#' Must be one of: oneHot (default), numeric, ordered, binary or circular.
#' \describe{
#'   \item{oneHot}{Each level of the factor will have its own column containing 1 or 0 
#'  depending on the value for that row.}
#'   \item{numeric}{The function \code{as.integer} is simply applied to the factor.}
#'   \item{ordered}{The factor is assumed in the same order as the \code{as.integer} function would put it in.
#'   A binary column is encoded for each possible split-point. This will result in n-1 columns for an n-level factor.
#'   I.E. the columns of a resulting matrix will be: as.integer(x) >= 2; as.integer(x) >= 3; ... ; as.integer(x) >= n}
#'   \item{binary}{This first encodes the factor as an integer (again uses \code{as.integer}
#'   and subtracts 1 so levels start at 0.) Then the integer is converted to binary.
#'   The binary numbers are then split into columns, so the first column represents 2^0, then 2^1, etc.}
#'   \item{circular}{Assumes the factor describes something that is order and "wraps around", 
#'  for example days of the week. This will result in a two column encoding where one column is
#'  \code{sin((as.integer(x)-1)*2*pi/length(levels(x)))} and the other is
#'  \code{cos((as.integer(x)-1)*2*pi/length(levels(x)))}.}
#' }
#' @param encodingExceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are factor columns in the data and the values are all valid encoders
#' (currently: oneHot (default), numeric, ordered, binary or circular),
#' OR a named list where each name is a valid encoder and each element is a character vector of factor columns
#' in the data. The function will apply the specified encoder to the factors named here
#' and the default encoder to all other factors.
#' @param NA_treatment What to do with missing values. Options are: pass (default), zero, addNA, drop or fail.
#' \describe{
#'   \item{pass}{NAs are passed through and returned as NAs in the final matrix.}
#'   \item{zero}{Rows with NAs are set to all zeros in the final matrix, whatever the encoding}
#'   \item{addNA}{A new NA level is added for all factors except those with "circular" encoding which
#'   have their NAs set to zero}
#'   \item{drop}{Rows containing NAs are dropped.}
#'   \item{fail}{The function stops with an error message (useful as a catch if you are expecting no NAs.)}
#' }
#' @param NA_exceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are factor columns in the data and the values are all valid NA actions, 
#' (currently: pass (default), zero, addNA, drop or fail),
#' OR a named list where each name is a valid NA action and each element is a character vector of factor columns
#' in the data. The function will apply the specified NA action to the factors named here
#' and the default NA action to all other factors.
#' @param NA_default value to which numeric NAs are set by default when the \code{NA_treatment} is set to "fix".
#' @param NA_defaultExceptions Optional named numeric vector where the names are numeric variables and the values are the values to set the NAs to.
#' This will override the default for the variables specified.
#' @param sparse Optional argument. Specify TRUE to return a sparse matrix or FALSE to return a dense matrix.
#' This overrides the default behaviour which chooses which type of matrix to return dynamically
#' (see \code{denseThreshold} argument.)
#' @param denseThreshold Number between 0 and 1. If the ratio of number of columns in the input data to the number
#' of columns in the output is greater than this threshold the function will return a dense matrix. 
#' Otherwise it will return a sparse matrix. Default value is 0.5.
#' This behaviour can be overridden by setting the \code{sparse} argument to TRUE or FALSE. 
#' @param addAttributes TRUE (default) or FALSE. If TRUE, this will add the following attributes to the
#' returned matrix:
#' @param trainMode TRUE or FALSE (default). Only has an effect if \code{encodingExceptions} is used and at least one of
#' the encoders is a function (for example if using target value encoding).
#' This is used as the second argument for the encoder function.
#' \describe{
#'   \item{factorLevels}{The original levels of all the factors}
#'   \item{encoders}{The encoders of all the factors}
#'   \item{NAActions}{The NA action used for each of the factors}
#' }
#' @return A numeric matrix with named columns - either a standard dense matrix or a sparse matrix of class dgCMatrix.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom Matrix sparse.model.matrix Matrix
#' @importFrom data.table data.table
#' @examples
#' # # Create some dummy data
#' # n <- 1000
#' # dt <- data.table(x=factor(sample(LETTERS, n, replace=TRUE)),
#' #                  y=rnorm(n),
#' #                  z=factor(sample(letters[1:16], n, replace=TRUE)))
#' # dt[1, x := NA]
#' # dt[2, y := NA]
#' # dt[3, z := NA]
#' # 
#' # # Return a dense matrix
#' # mat <- factorEncoder(dt,
#' #                      sparse=FALSE,
#' #                      encodingExceptions=c(z="binary"))
#' # head(mat)
#' # 
#' # # Default behavior returns a sparse matrix
#' # # Example with NA rows dropped
#' # mat <- factorEncoder(dt,
#' #                      encodingExceptions=list(binary="z"),
#' #                      NA_treatment="drop")
#' # head(mat)
#' @export

factorEncoder <- function(
  data,
  defaultEncoding       =  "oneHot",
  encodingExceptions    =  NULL,
  NA_treatment          =  "fix",
  NA_exceptions         =  NULL,
  NA_default            =  2.14E+9,
  NA_defaultExceptions  =  NULL,
  sparse                =  NULL,
  denseThreshold        =  0.5,
  addAttributes         =  TRUE,
  trainMode             =  FALSE
){

  # Validate data
  if (!is.data.frame(data)) stop("data must be a data frame")
  if (!is.data.table(data)) data <- data.table(data)
  
  # Check for tildes
  if (length(grep("~", names(data))) > 0) stop(
    "It's a really *really* bad idea to use tildes (~) in your column names!!"
  )
  
  if (length(defaultEncoding) != 1){
    stop("defaultEncoding is not valid")
  }
  if (! validateEncoder(defaultEncoding)){
    stop("defaultEncoding is not valid")
  }

  # Validate NA_treatment
  if (!is.character(NA_treatment)){
    stop("NA_treatment must be a character vector")
  }
  if (length(NA_treatment) != 1){
    stop("NA_treatment must be a character vector of length 1")
  }
  
  # Validate NA_default
  if (!is.numeric(NA_default)){
    stop("NA_default must be numeric")
  }
  if (length(NA_default) != 1){
    stop("NA_default must be a numeric vector of length one")
  }
  if (is.na(NA_default)){
    stop("NA_default cannot be missing")
  }
  if (! is.finite(NA_default)){
    stop("NA_default must be finite")
  }
  
  # Validate addAttributes
  if (!is.logical(addAttributes)) stop("addAttributes must be logical")
  if (length(addAttributes) != 1) stop("addAttributes must be length 1")
  if (is.na(addAttributes)) stop("addAttributes cannot be NA")
  
  # Find factor columns
  factorCols <- which(sapply(data, is.factor))
  
  # Set up encoders
  encoders <- lapply(
    seq_along(factorCols),
    function(x) defaultEncoding
  )
  names(encoders) <- names(factorCols)
  
  # Number of levels for factors
  nLevs <- sapply(names(factorCols), function(x) length(levels(data[[x]])))
  
  # Factors with only 2 levels
  encoders[which(nLevs < 3)] <- "numeric"
  
  # Apply encodingExceptions
  if (!is.null(encodingExceptions)){
    # Check that it has names
    if (is.null(names(encodingExceptions))){
      stop("encodingExceptions must be named")
    }
    if (anyDuplicated(names(encodingExceptions))){
      stop("encodingExceptions names must be unique")
    }
    # Encoding exceptions is a list
    if (is.list(encodingExceptions)){
      if (
        all(
          sapply(
            encodingExceptions,
            function(x){
              if (length(x) == 1){
                validateEncoder(x)
              } else FALSE
            }
          )
        ) &
        all(names(encodingExceptions) %in% names(factorCols))
      ){
        # encodingExceptions is in the format we want which is a
        # named list where the names are factors from the data and
        # each list entry is an encoder
      } else if (all(sapply(encodingExceptions, is.character))){
        if (
          all(sapply(names(encodingExceptions), validateEncoder)) &
          all(sapply(
            encodingExceptions,
            function(x) all(x %in% names(factorCols))
          ))){
          # encodingExceptions is a named list where names are encoders
          # and the entries are character vectors of column names
          encodingExceptions <- as.list(namedList2Vec(encodingExceptions))
        } else{
          stop("Format of encodingExceptions not recognised.")
        }
        # encodingExceptions is not a list
      } else{
        stop("Format of encodingExceptions not recognised.")
      }
    } else if (!is.character(encodingExceptions)){
      stop("Format of encodingExceptions not recognised.")
      # encodingExceptions is a character
    } else if (
      all(sapply(encodingExceptions, validateEncoder)) &
      all(names(encodingExceptions) %in% names(factorCols))
    ){
      encodingExceptions <- as.list(encodingExceptions)
    } else{
      stop("Format of encodingExceptions not recognised.")
    }
    
    # encodingExceptions is now a valid character vector
    # Use to update encoders
    encoders[match(names(encodingExceptions), names(factorCols))] <- encodingExceptions
  }
  
  # Set up NA actions
  NAActions <- rep(NA_treatment, ncol(data))
  names(NAActions) <- names(data)
  
  # Apply NA_exceptions
  if (!is.null(NA_exceptions)){
    if (is.list(NA_exceptions)){
      # Convert NA_exceptions to character vector
      NA_exceptions <- namedList2Vec(NA_exceptions)
      # NA_exceptions is not a list
    } else if (!is.character(NA_exceptions)){
      stop("NA_exceptions should be a named list or named character vector.")
      # NA_exceptions is a character
    } else{
      if (is.null(names(NA_exceptions))){
        stop("If NA_exceptions is a character vector, it should be a named.")
      }
      if (anyDuplicated(names(NA_exceptions))){
        stop("NA_exceptions contains a duplicated column name.")
      }
    }
    if (!all(names(NA_exceptions) %in% names(data))){
      stop("NA_exceptions contains column names that don't exist in the input data.")
    }
    
    # NA_exceptions is now a valid character vector
    # Use to update NAActions
    NAActions[match(names(NA_exceptions), names(data))] <- NA_exceptions
  }
  
  # Set up NA default
  NA_default <- rep(NA_default, ncol(data))
  names(NA_default) <- names(data)
  
  # Apply NA default exceptions
  if (!is.null(NA_defaultExceptions)){
    if (!is.numeric(NA_defaultExceptions)){
      stop("NA_defaultExceptions should be a numeric vector.")
    } 
    if (is.null(names(NA_defaultExceptions))){
      stop("NA_defaultExceptions must be a named numeric vector.")
    }
    if (anyDuplicated(names(NA_defaultExceptions))){
      stop("NA_defaultExceptions contains a duplicated column name.")
    }

    if (!all(names(NA_defaultExceptions) %in% names(data))){
      stop("NA_defaultExceptions contains column names that don't exist in the input data.")
    }

    # Use to update encoders
    NA_default[match(names(NA_defaultExceptions), names(data))] <- NA_defaultExceptions
  }
  
  # Apply the NA drop action
  if (any(NAActions == "drop")){
    dropCols <- names(NAActions)[which(NAActions=="drop")]
    data <- data[which(rowSums(is.na(data[, dropCols, with=FALSE])) == 0)]
  }
  
  # Train mode
  if (! is.logical(trainMode)){
    stop("trainMode must be logical")
  }
  if (length(trainMode) != 1){
    stop("trainModel should be length 1")
  }
  
  # Now create functions to transform each column
  createFunctionList <- function(trainMode){
    functionList <- lapply(
      seq(1, ncol(data)),
      function(i){
        colName <- names(data)[i]
        if (i %in% factorCols){
          if (is.character(encoders[[colName]])){
            return(
              function(x, sparse){
                facEncode(
                  x,
                  factorName = colName,
                  encoder = encoders[[colName]],
                  NA_treatment = NAActions[i],
                  sparse = sparse
                )
              }
            )
          } else{
            return(
              function(x, sparse){
                if (NAActions[i] == "fail"){
                  if (anyNA(x)){
                    stop("Missing values found which are not allowed under 'fail' NA action.")
                  }
                }
                mat <- encoders[[colName]](x, trainMode, sparse)
                if (NAActions[i] == "pass"){
                  if (anyNA(x)){
                    mat[which(is.na(x)), ] <- NA
                  }
                } 
                return(mat)
              }
            )
          }
        } else{
          return(
            function(x, sparse){
              numEncode(
                x,
                colName = colName,
                NA_treatment = NAActions[i],
                NA_value = NA_default[i],
                sparse = sparse
              )
            }
          )
        }
      }
    )
  }
  
  # Calculate the number of additional columns we are adding to the data by our encodings
  numCols <- ncol(
    do.call(
      cbind,
      lapply(
        seq(1, ncol(data)),
        function(i){
          createFunctionList(FALSE)[[i]](data[0][[colnames(data)[i]]], sparse=FALSE)
        }
      )
    )
  )
  
  # Check sparse is logical
  if (!is.null(sparse)){
    if (!is.logical(sparse)) stop("sparse must be logical")
    if (length(sparse) != 1) stop("sparse must be length 1")
  } else{
    # Dense matrix if the ratio of columns in the original data to columns in the new data is above threshold
    # Otherwise return a sparse matrix
    if(ncol(data)/numCols > denseThreshold){
      sparse <- FALSE
    } else{
      sparse <- TRUE
    } 
  }
  
  # Apply encodings and create return matrix
  returnMat <- do.call(
    cbind,
    lapply(
      seq(1, ncol(data)),
      function(i){
        createFunctionList(trainMode)[[i]](data[[colnames(data)[i]]], sparse = sparse)
      }
    )
  )

  # addAttributes
  if (addAttributes){
    # NAActions
    attr(returnMat, "NAActions") <- NAActions[names(factorCols)]
    
    # factorLevels
    factorLevels <- lapply(names(factorCols), function(x) levels(data[[x]]))
    names(factorLevels) <- names(factorCols)
    attr(returnMat, "factorLevels") <- factorLevels
    
    # facEncodingTbls
    facEncodingTbls <- lapply(
      factorCols,
      function(i){
        levels <- levels(data[[colnames(data)[i]]])
        if (anyNA(levels)){
          tbl <- data.table(
            factor = addNA(factor(levels, levels=levels))
          )
        } else{
          tbl <- data.table(
            factor = factor(levels, levels=levels)
          )
          if (NAActions[[colnames(data)[i]]] == "fix"){
            tbl <- rbind(
              tbl,
              data.table(factor=NA)
            )
          }
        }
        tbl <- cbind(
          tbl,
          createFunctionList(FALSE)[[i]](tbl[, factor], sparse = FALSE)
        )
        setnames(tbl, "factor", colnames(data)[i])
        return(tbl)
      }
    )
    names(facEncodingTbls) <- names(factorCols)
   
    attr(returnMat, "facEncodingTbls") <- facEncodingTbls
  }
  
  # Make column names unique
  colnames(returnMat) <- make.unique(colnames(returnMat))
  
  # Return the final matrix
  return(returnMat)
}
