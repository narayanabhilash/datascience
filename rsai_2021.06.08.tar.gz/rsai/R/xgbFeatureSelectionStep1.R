
#  FUNCTION  ##############################################################

# Stage one ---------------------------------------------------------------

#' Initial pass through potential input variables
#' @description Run through a large selection of potential input variables in various combinations
#' with the aim of selecting those which have significant impacts on a model of the target variable.
#' This informs an optimal starting point for an exhaustive filter.
#' @param data training data
#'
#' @param exVars potential input variables (without encodings)
#' @param response name of the response variable
#'  
#' @param alwaysInclude names of any input features you wish to include in all of your candidate models.
#' @param exposure Argument passed directly to `xgbSetupdata2`
#' @param sampleWeight Argument passed directly to `xgbSetupdata2`
#' @param offset_model Argument passed directly to `xgbSetupdata2`
#' @param link Argument passed directly to `xgbSetupdata2`
#' @param defaultEncoding Argument passed directly to `xgbSetupdata2`
#' @param encodingExceptions Argument passed directly to `xgbSetupdata2`
#' @param NA_treatment Argument passed directly to `xgbSetupdata2`
#' @param NA_exceptions Argument passed directly to `xgbSetupdata2`
#' @param NA_default Argument passed directly to `xgbSetupdata2`
#' @param NA_defaultExceptions Argument passed directly to `xgbSetupdata2`
#' @param sparse Argument passed directly to `xgbSetupdata2`
#' @param trainMode Argument passed directly to `xgbSetupdata2`
#' @param orderedAsNum Argument passed directly to `xgbSetupdata2`
#' @param filterCols Argument passed directly to `xgbSetupdata2`
#' @param initialRuns Number of times each potential input feature is included in a candidate model
#' @param maxColsPerModel Maximum number of input features to include in a candidate model
#' @param monotonicInc names of input features assumed always to be monotonic increasing...
#' @param monotonicDec ... or decreasing
#' @param initialSeed random seed for repeatability
#' @param featureImportanceCSV output file name (and path) for feature importance table
#' @param modelDetailsCSV output file name (and path) for model details
#' @param params Argument passed directly through to \code{\link{xgb.cv}}
#' with the following exceptions:
#' \describe{
#'   \item{tree_method defaults}{If \code{tree_method} and \code{max_bin} are
#'   not explicitly included in \code{params}, they will be set to
#'   \code{tree_method = "hist"} and \code{max_bin = 64}, essentially changing
#'   the default method to increase speed.
#'   }
#'   \item{Monotone constraints}{\code{monotone_constraints} will be ignored
#'   but you can still use the monotonic constraint feature of \code{xgboost}
#'   by using the \code{monotonicInc} and \code{monotonicDec} arguments.
#'   }
#'   \item{Interaction constraints}{\code{interaction_constraints} will be
#'   ignored and is not currently supported in this routine.
#'   }
#' }
#' @param nrounds Argument passed directly to `xgb.cv`
#' @param nfold Argument passed directly to `xgb.cv`
#' @param metrics Argument passed directly to `xgb.cv`
#' @param obj Argument passed directly to `xgb.cv`
#' @param feval Argument passed directly to `xgb.cv`
#' @param stratified Argument passed directly to `xgb.cv`
#' @param folds Argument passed directly to `xgb.cv` (Therefore if specified, this is a _list_)
#' @param train_folds Argument passed directly to `xgb.cv`
#' @param early_stopping_rounds Argument passed directly to `xgb.cv`
#' @param maximize Argument passed directly to `xgb.cv`
#' @param correlationRows Maximum number of rows used to calculate approximate rank correlation of feature and response
#' (numeric features only.)
#' @return an amalgamated table of feature importances (using mean and maximum of absolute shap value)
#' for each feature / model / fold, plus rank correlation of sample response (suggests monotonicity).
#' correlations only returned if `folds`` are explicitly specified
#' @note An input feature (e.g. "Manufacturer~is~Toyota") may differ from an input variable (e.g. "Manufacturer".) 
#' @export

xgbFSStep1 <- function(
  # Fundamental arguments
  data,
  exVars,
  response,
  alwaysInclude = c(), # starting point
  
  # Arguments passed directly to xgbSetupdata2
  exposure               =  NULL,
  sampleWeight           =  NULL,
  offset_model           =  NULL,
  link                   =  log,
  defaultEncoding        =  "oneHot",
  encodingExceptions     =  NULL,
  NA_treatment           =  "fix",
  NA_exceptions          =  NULL,
  NA_default             =  2.14E+9,
  NA_defaultExceptions   =  NULL,
  sparse                 =  TRUE,
  trainMode              =  NULL,
  orderedAsNum           =  TRUE,
  filterCols             =  character(0),
  
  # Arguments controlling feature inclusion and saving
  initialRuns            =  1,
  maxColsPerModel        =  50, # does this work with null? if so default that
  monotonicInc           =  NULL,
  monotonicDec           =  NULL,
  initialSeed            =  1984L,
  featureImportanceCSV   =  NULL,
  modelDetailsCSV        =  NULL,
  
  # Arguments passed directly to xgb.cv
  params                 =  list(),
  nrounds                =  500, 
  nfold                  =  NULL,
  metrics                =  list(),
  obj                    =  NULL,
  feval                  =  NULL,
  stratified             =  TRUE,
  folds                  =  NULL,
  train_folds            =  NULL,
  early_stopping_rounds  =  NULL,
  maximize               =  NULL,
  
  # for correlation
  correlationRows        =  1000L
){
  
  ## Validate arguments that aren't validated as an argument to another function call
  # initialSeed
  if (! (is.numeric(initialSeed) &
         is.vector(initialSeed) &
         length(initialSeed) == 1)){
    stop("initialSeed should be an integer")
  } else if (! is.integer(initialSeed)){
    initialSeed <- as.integer(initialSeed)
  }
  
  # set alwaysFilter
  alwaysFilter <- filterCols
  
# Find the list of feature columns
colFeats <- xgbSetupdata2_colnames(
  data,
  exVars              =  exVars,
  defaultEncoding     =  defaultEncoding,
  encodingExceptions  =  encodingExceptions,
  NA_treatment        =  "fix",
  NA_exceptions       =  NULL,
  orderedAsNum        =  TRUE,
  filterCols          =  alwaysFilter
)

# Fix always include cols
alwaysInclude <- intersect(alwaysInclude, colFeats)

# Number of models per run
numModelsPerRun <- ceiling(
  (length(colFeats) - length(alwaysInclude)) / (maxColsPerModel - length(alwaysInclude)))

# Set base score where no offset exists 
if (! "base_score" %in% names(params)){
  if (is.null(offset_model)){
    if (is.null(sampleWeight)){
      if (is.null(exposure)){
        base_score <- mean(data[[response]])
      } else{
        base_score <- weighted.mean(data[[response]]/data[[exposure]], data[[exposure]])
      }
    } else{
      if (is.null(exposure)){
        weighted.mean(data[[response]], data[[sampleWeight]])
      } else{
        weighted.mean(data[[response]]/data[[exposure]], data[[exposure]] * data[[sampleWeight]])
      }
    }
  } else{
    if (link(1) == 0){
      params$base_score <- 1
    } else if (link(0) == 0){
      params$base_score <- 0
    } else{
      params$base_score <- 0.5
    }
  }
}

# Default tree_method to 'hist' with max_bin = 64 for speed
if (is.null(params$tree_method)){
  params$tree_method <- "hist"
}
if (params$tree_method == "hist"){
  if (is.null(params$max_bin)){
    params$max_bin <- 64
  }
} 

# Fix monotonicity constraints
params$monotone_constraints <- suppressWarnings( # neat!
  xgbMonotone(
    cols = colFeats,
    increasing = monotonicInc,
    decreasing = monotonicDec
  )
) 
# Function to split features into chunks
randomChunk <- function(x, n){
  split(x, factor(((rank(sample(runif(length(x)))) - 1) %% n) + 1))
}

# Set a seed
set.seed(initialSeed)

# sample of fold numbers for approximate correlation ----------------------
foldSample  <- NULL
if(!(is.null(folds))) 
  foldSample <- lapply(folds, function (x) {
    if (length(x) <= correlationRows)
      return(seq_along(x))
    sort(sample(seq_along(x), correlationRows, replace = FALSE))
}
)  # possibly could improve using sample weight but it'll probably do

# Set a seed
set.seed(initialSeed)

# Initialise feature importance table
dt_featureImportance <- data.table(
  Feature = character(0),
  meanShap = numeric(0),
  maxShap = numeric(0),
  monoShap = numeric (0),
  j = integer(0),
  i = integer(0),
  foldNo = integer(0)
) # shap this here... want good ordering....

# Write CSV
if (! is.null(featureImportanceCSV)){ #could fwrite but later want appending
  write.csv(dt_featureImportance, file = featureImportanceCSV, row.names = FALSE)
}

# Initialise model count
iter <- 0L

# Initialise model details table
dt_modelDetails <- data.table(
  feats = vector(mode = "list", length = 0),
  seed = integer(0),
  bestIteration = integer(0),
  train_mean = numeric(0),
  train_std = numeric(0),
  test_mean = numeric(0),
  test_std = numeric(0)
)

# Write CSV
if (! is.null(modelDetailsCSV)){
  write.csv(dt_modelDetails, file = modelDetailsCSV, row.names = FALSE)
}

# Internal function for running xgb.cv and outputting results
internalModelBuild <- function(feats){
  # Which original explanatory variables are required
  exVarsInnerLoop <- unique(names(colFeats[which(colFeats %in% feats)])) # the features we need
  
  # Build the data
  xgbData <- suppressWarnings(
    xgbSetupdata2(
      data,
      response              =  response,
      explanatory_vars      =  exVarsInnerLoop,
      exposure              =  exposure,
      sampleWeight          =  sampleWeight,
      offset_model          =  offset_model,
      link                  =  link,
      defaultEncoding       =  defaultEncoding,
      encodingExceptions    =  encodingExceptions,
      NA_treatment          =  NA_treatment,
      NA_exceptions         =  NA_exceptions,
      NA_default            =  NA_default,
      NA_defaultExceptions  =  NA_defaultExceptions,
      sparse                =  sparse,
      orderedAsNum          =  orderedAsNum,
      filterCols            =  c(
        alwaysFilter,
        setdiff(colFeats[which(names(colFeats) %in% exVarsInnerLoop)], feats)
      )
    )
  )
  
  # Features included in xgbData in the order we have created them
  feats <- colnames(xgbData[[1]])
  assign("feats", feats, envir = parent.frame())
  
  # Update model count
  assign("iter", iter + 1, envir = parent.frame())
  
  # Set a seed
  set.seed(initialSeed + iter)
  
  # Call to xgb.cv
  xgbCV <- xgb.cv(
    params                 =  params,
    data                   =  xgbData[[1]],
    nrounds                =  nrounds,
    prediction             =  TRUE,
    folds                  =  folds,
    verbose                =  TRUE,
    print_every_n          =  nrounds,
    early_stopping_rounds  =  early_stopping_rounds,
    #base_score             =  base_score, ## it's in params already
    callbacks              =  list(cb.cv.predict(save_models = TRUE))
  )
  
  # Create data table of unique details
  dt_modelDetailsToAppend <- cbind(
    data.table(
      feats = list(feats),
      seed = initialSeed + iter
    ),
    xgbCV$evaluation_log[iter == xgbCV$best_iteration]
  )
  
  # Append to master table
  assign(
    "dt_modelDetails",
    rbindlist(
      list(
        dt_modelDetails,
        dt_modelDetailsToAppend
      ),
      use.names = FALSE
    ),
    envir = parent.frame()
  )
  
  dt_modelDetailsToAppend[, feats := paste0(feats[[1]], collapse = ', ')]
  
  # Save output
  if (! is.null(modelDetailsCSV)){
    write.table(
      dt_modelDetailsToAppend,
      file = modelDetailsCSV,
      append = TRUE,
      row.names = FALSE,
      col.names = FALSE,
      sep = ","
    )
  }
  gc()
  # return
  return(list(data = xgbData[[1]], xgbCV = xgbCV))
}

# correlation cantrip:-------------
corP <- function (x,y) { 
  if (!(is.numeric(x) && is.numeric(y))) return (0) #doesn't do dates
  if (all(is.na(x)) || all(is.na(y))) return (0)
  if (is.na(var(x, na.rm = T))) return (0)
  if (is.na(var(y, na.rm = T))) return (0)
  if (var(x, na.rm = T) && var(y, na.rm = T))
    return (cor(x, y, use = "complete.obs", method = "pearson"))
  0
}

# Start of outer loop
cat("Step 1 - building initial feature importance list\n")
for (j in seq_len(initialRuns)){
  cat(paste0("Starting run ", j, " of ", initialRuns, "\n"))
  
  ##? if j > 1 add to the always include?
  
  # Setup indices for each model in inner loop
  outerLoopFeats <- randomChunk(setdiff(colFeats, alwaysInclude), numModelsPerRun)
  
  # Start of inner loop
  for (i in seq_len(numModelsPerRun)){
    cat(paste0("For run ", j, ", building model ", i, " of ", numModelsPerRun, "\n"))
    
    # Run xgb.cv
    xgbCV <- internalModelBuild(c(alwaysInclude, outerLoopFeats[[i]]))   # make cv call more silent?
    
    # Find the feature importance for each submodel
    ls_featureImportance <- lapply(
      xgbCV$models,
      xgb.importance,
      trees = seq(0, xgbCV$best_iteration - 1),
      feature_names = feats
    )
    
    # extract shapley importances and correlations for each fold and feature
    ls_featureImportance <- lapply(
      seq_along(folds),
      function (k){
        shapL <- createShapValues(
          xgbCV$xgbCV$models[[k]],
          xgbCV$data[folds[[k]], ],
          numTrees = NULL,
          report = FALSE,
          factorLength = 200,
          Attributes = attributes(xgbCV$data), 
          # Have Dimnames but it's ok, dimension is missing
          Combine = FALSE)
        
        dt_ = data.table(
          Feature = names(shapL$meanAbsShap), 
          meanShap = shapL$meanAbsShap,
          maxShap = shapL$maxShap[names(shapL$meanAbsShap)],
          monoShap = 0,
          j = j, i = i, foldNo = k
        )     
        for (nm in dt_$Feature){
          if(nm %in% names(data) && !(is.null(foldSample))) 
            dt_[
              Feature == nm,
              monoShap := corP(
                shapL$shapValues[[nm]][foldSample[[k]]],
                data[[nm]][folds[[k]][foldSample[[k]]]])]
        } 
        # NOTE: This step will fail if you don't use the whole of data to make the folds
        
        return(dt_)
      }
    )
    
    
    # Combine into single data table
    dt_featureImportanceToAppend <- rbindlist(ls_featureImportance)
    # setkey?
    
    # Save to disk
    if (! is.null(featureImportanceCSV)){
      write.table(
        dt_featureImportanceToAppend,
        file = featureImportanceCSV,
        append = TRUE,
        row.names = FALSE,
        col.names = FALSE,
        sep = ","
      )
    }
    
    # Append rows to the feature importance table
    dt_featureImportance <- rbindlist(
      list(dt_featureImportance, dt_featureImportanceToAppend))
    
    # Exit inner loop
  }
  
  # Exit outer loop
}

 dt_featureImportance
}

# Stage two ---------------------------------------------------------------

# Stage 2 might end up being a new function
# dt_featureImportance and dt_modelDetails are the output from stage 1
# First transform dt_featureImportance into inputs for stage 2

# Summarised feature importance data to get ordered 


#' Process output from feature selection Step 1
#' 
#' @description This function takes the feature importance output from `xgbFSStep1`
#' and returns the input features required for the starting point for featurewise 
#' feature selection via `xgbFeatureSelection`.
#' 
#' @param dt_featureImportance feature importance table from `xgbFSStep1`
#' @param alwaysInclude vector of features to always include, if required
#' @param minFeatures minimum number of features to return in the starting point
#' @param maxFeatures maximum number of features to return in the starting point
#' @param meanThreshold threshold for a mean absolute shap value to be included
#' @param maxThreshold threshold for a maximum absolute shap value to be included
#' @param minThreshold mean shap threshold for a feature not to be returned at all
#' @param monotonicInc monotonic increasing input features
#' @param monotonicDec monotonic decreasing input features
#' @param monoThreshold rank correlation threshold (absolute) for unspecified features
#' to be set as monotonic in future fitting. No impact if set above 1.
#' @return a list of feature-specific inputs for `xgbFeatureSelection` 
#' i.e.  startingFeats, importances, monotonicInc and monotonicDec 
#' @export
#'
xgbFSStep2 <- function(
  dt_featureImportance,
  alwaysInclude          =  c(),
  minFeatures            =  5L,
  maxFeatures            =  100L,
  meanThreshold          =  0.05,
  maxThreshold           =  0.25,
  minThreshold           =  0,
  monotonicInc           =  NULL,
  monotonicDec           =  NULL,
  monoThreshold          =  1
) {
  
  dtFeatImpSummary <- dt_featureImportance[
  ,
  .( 
    meanShap = mean(meanShap),
    maxShap = mean(maxShap),
    monoShap = mean(monoShap)
    ),
  by = .(Feature)
  ][meanShap > minThreshold | Feature %in% alwaysInclude]
  
  # so you can use half if you want to by cunning use of the arguments
  # but thresholds are the expected behaviour
  dtFeatImpSummary[Feature %in% alwaysInclude, include := TRUE]
  dtFeatImpSummary[is.na(include), include := FALSE]
  dtFeatImpSummary[include == TRUE, pass := TRUE]
  dtFeatImpSummary[meanShap >= meanThreshold, pass := TRUE]
  if (maxThreshold > 0)
    dtFeatImpSummary[maxShap >= maxThreshold, pass := TRUE]
  dtFeatImpSummary[is.na(pass), pass := FALSE]
  
  setorder(dtFeatImpSummary, -include, -pass, -meanShap) # was in wrong order before>> confused now
  
  # augment mono:=---------------
  
  monotonicInc <- setdiff(
    c(
      monotonicInc, dtFeatImpSummary[monoShap >= monoThreshold]$Feature),
    monotonicDec)
  monotonicDec <- setdiff(
    c(
      monotonicDec, dtFeatImpSummary[monoShap <= (-1 * monoThreshold)]$Feature),
    monotonicInc)
  
  monotonicInc <- unique(monotonicInc)
  monotonicDec <- unique(monotonicDec)
  
  # in the unfortunate event that we have very few features...
  
  if (minFeatures > nrow(dtFeatImpSummary)){
    message(
      "fewer than specified minimum features exceed the minimum threshold:
      \n returning just these")
    startingFeats <- rep(TRUE, nrow(dtFeatImpSummary))
    names(startingFeats) <- dtFeatImpSummary$Feature[nrow(dtFeatImpSummary):1]

  } else {
  #otherwise...
  
    if (maxFeatures) {
      numberOfFeatures <-
        median(c(maxFeatures, minFeatures, sum(dtFeatImpSummary$pass)))
      dtFeatImpSummary[, include := FALSE]
      dtFeatImpSummary[1:numberOfFeatures, include := TRUE]
    } else {
      dtFeatImpSummary[1:minFeatures, include := TRUE]
      numberOfFeatures <- sum(dtFeatImpSummary$include)
    }
    
    # now return an order of testing based on the distance to the boundary point...
    dtFeatImpSummary[, testOrder := abs(numberOfFeatures + 0.4 - .I)]
    startingFeats <- dtFeatImpSummary$include
    names(startingFeats) <- dtFeatImpSummary$Feature
    startingFeats <- startingFeats[order(dtFeatImpSummary$testOrder)]
    dtFeatImpSummary[, testOrder := NULL]
  }
  return (list(
    startingFeats = startingFeats,
    importances = dtFeatImpSummary[, c("Feature", "meanShap", "maxShap", "monoShap"), with = F],
    monotonicInc = monotonicInc,
    monotonicDec = monotonicDec))
}

