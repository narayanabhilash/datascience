

# extract IDs of nodes from description file ------------------------------


geth2oIDs <- function(descriptions) {
  sapply(seq_along(descriptions), function (x)
    as.integer(gsub("(.* has id )([0-9]+)(.*)", "\\2", descriptions[x]))
  )
}

# get features used to split parent and child nodes -----------------------

geth2oNodes <- function(n, descriptions, IDs, features){
  
  nodeText <- descriptions[n]
  # get node _split_ and child _splits_.
  
  ParentIndex <- n
  #if not a split:
  if(!(grepl("left node \\(|.*Left child node \\(", nodeText))) return(c(NA, NA, NA))
  
  LeftIndex  <- as.integer(gsub("(.* left node \\(|.*Left child node \\()([0-9]+)(.*)", "\\2", nodeText))
  LeftIndex <- match(LeftIndex, IDs)
  RightIndex <- as.integer(gsub("(.* right node \\(|.*Right child node \\()([0-9]+)(.*)", "\\2", nodeText))
  RightIndex <- match(RightIndex, IDs)
  return (features[c(ParentIndex, LeftIndex, RightIndex)])
}

# xgbfr but for h2o looks like this. 
# just going to do depth 1 interactions.


#' xgbFR for h2o.gbm model
#' @description this function returns feature and interaction importance for 
#' an h2o.gbm model.
#' This is likely to be temporary so only a simple function is used.
#' For importance,
#' Gain and FScore simply record h2o's gain calculation
#' For depth 1 interaction, they record a count of the number of times that
#' a pair of features appear in consecutive tree splits.
#' @param h2omodel an h2o.gbm model
#' @param top.k number of interactions / features to return
#'
#' @return a list of the feature and interaction importances,
#' consistent in format with xgbfR
#' @export

h2ofR <- function(
  h2omodel,
 top.k = 100L
 ) {
  # importances come free:
  table1 <- as.data.table(h2omodel@model$variable_importances[, 1:2])
  table1 <- table1[1:min(top.k, nrow(table1))]
  colnames(table1) <- c ("Feature", "Gain")
  table1[, FScore := Gain]
  
  # interactions must be counted
  intList <- list()
  for (treenum in 1:h2omodel@model$model_summary$number_of_trees) {
    # get the consecutive features as a list:
    tree <- h2o.getModelTree(h2omodel, treenum)
    IDs <- geth2oIDs(tree@descriptions)
    parentkids <- lapply(
      seq_along(tree@features),
      FUN = function(x)
        geth2oNodes(x, tree@descriptions, IDs, tree@features)
    )
    # add to a running total:
    for (pk in parentkids) {
      if (!is.na(pk[2])) {
        pk1 <- paste(sort(pk[c(1, 2)]), collapse =  "|")
        if (!(pk1 %in% names(intList)))
          intList[[pk1]] <- 0
        intList[[pk1]] <- 1 + intList[[pk1]]
      }
      if (!is.na(pk[3])) {
        pk2 <- paste(sort(pk[c(1, 3)]), collapse =  "|")
        if (!(pk2 %in% names(intList)))
          intList[[pk2]] <- 0
        intList[[pk2]] <- 1 + intList[[pk2]]
      }
    }
  }
  # then convert intList to a sorted table:
  table2 <-
    data.table(
      Feature = names(intList),
      Gain = unlist(intList),
      FScore = unlist(intList)
    )
  setorder(table2,-Gain)
  if (nrow(table2) > top.k)
    table2 <- table2[1:top.k]
  
  return(list(table1, table2))
}