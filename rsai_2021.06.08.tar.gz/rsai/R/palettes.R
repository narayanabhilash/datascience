
#' RSA Palette
#'
#' @return The RSA colour palette.
#' @export
#'
#' @examples
#' print(rsaPalette())
rsaPalette <- function () {
  return(
    c(
      "#C4C0C2",
      "#5C1280",
      "#28A1C6",
      "#4A226E",
      "#4D4B4C",
      "#38174F",
      "#847F82",
      "#D2548E"
    )
  )
}

#' RSA Charting colour Palette
#'
#' @return A charting palette made up of RSA colours plus extra for charting
#' @export
#'
#' @examples 
#' print(chartPalette())
chartPalette <- function () {
  return(
    c(
      "#5C1280",
      "#D2548E",
      "#28A1C6",
      "#C4C0C2",
      "#38174F",
      "#8CB234",
      "#0072AE",
      "#CB5E57",
      "#DFAF47" ,
      "#3C3C3C"
    ))
}