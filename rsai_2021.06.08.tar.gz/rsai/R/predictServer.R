setClass("predictServer",representation(
	name="character",
	host="character",
	port="integer",
	model="ANY", ## anything for which predict() works
	proc="logical",
	procfn="function"
),prototype=prototype(
	name="some model or other",
	host=Sys.info()["nodename"],
	port=6011L,
	proc=FALSE,
	procfn=function(data) data
)) -> predictServer

setClass("predictClient",representation(
	host="character",
	port="integer"
),prototype=prototype(
	host=Sys.info()["nodename"],
	port=6011L
)) -> predictClient



#' method for \code{predict} for class \code{predictClient}
#' 
#' @description method for \code{predict} for class \code{predictClient}.
#' 
#' @usage \method{predict}{predictClient}(object, newdata)
#' @param object An object of class \code{"predictClient"}
#' @param newdata A data frame.
#' @return Depends on the server. Usually a data frame.
#' @author James Lawrence
#' @export
#' @examples
#' 
#' ## none yet!
#' 
predict.predictClient <- function(object,newdata){
	c1 <- socketConnection(host=object@host,port=object@port,blocking=TRUE)
	on.exit(close(c1))
	writeLines(as.character(n <- nrow(newdata)),c1)
	cat(n," rows to predict\n")
	write.csv(newdata,c1,row.names=FALSE)
	readLines(c1,n=1) -> objid
	cat("predicting using model",objid,"\n")
	preds <- read.csv(c1,nrows=n)
	return(preds)
}



#' Serve model predictions to a client
#' 
#' @description Starts a server socket connection, listens for input, computes predictions
#' and returns those to the client.
#' 
#' %% ~~ If necessary, more details than the description above ~~
#' @usage initialisePredictServer(x, ...)
#' @param x A \code{predictServer} object, usually created by calling
#' \code{predictServer}.
#' @param \dots Further arguments to \code{predict}.
#' @return NULL, though a few lines of info are echoed to the terminal as the
#' scoring progresses.
#' @author James Lawrence
#' @seealso \code{\link{predict}}, in particular
#' \code{\link{predict.predictClient}}.
#' @export
#' @examples
#' 
#' ## none yet!
#' 
initialisePredictServer <- function(x,...){
	c1 <- socketConnection(host=x@host,port=x@port,blocking=TRUE,server=TRUE)
	on.exit(close(c1))
	done <- FALSE
	readLines(c1,n=1L) -> n
	if(identical(n,"close")){
		done <- TRUE
		return(0)
	} else n <- as.integer(n[1])
	if(is.na(n) || n <= 0){
		stop("bad number of lines\n")
	} else cat(n,"rows expected\n")
	read.csv(c1,nrows=n) -> df.tmp
	cat("data received\n")
	if(x@proc){
		df.tmp <- x@procfn(df.tmp)
		cat("data processed\n")
	} else cat("no processing done\n")
	preds <- data.frame(Y=predict(x@model,df.tmp))
	writeLines(x@name,c1)
	write.csv(preds,file=c1,row.names=FALSE)
	cat("predictions sent\n")
}
