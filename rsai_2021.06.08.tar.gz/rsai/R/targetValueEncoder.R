#####  targetValueEncoder  #####
#' Perform target value encoding for factor data
#' @description Create an encoding for a factor based on a mean or weighted mean of the target value.
#' Supports the use of cross-folds and includes some regularising parameters to prevent overfit.
#' This function returns a new function, and it's this new function that produces encoded matrices based on factor value.
#' You can use the returned function to create matrix encodings on new data.
#' The returned function will itself return a one-column matrix and will have the following arguments:
#' \describe{
#'   \item{\code{x}}{A new factor vector with the same levels as before to encode into a matrix.}
#'   \item{\code{trainMode}}{If TRUE and if \code{x} matches the data used to create the encoder
#' then the out-of-fold or leave-one-out values will be returned. Useful for training models to avoid leakage.
#' If FALSE uses a consistent encoding across levels. Useful for scoring models on new data.}
#'   \item{\code{sparse}}{TRUE or FALSE. IF TRUE, returns a sparse matrix, if FALSE returns a dense matrix.}
#' }
#' @usage targetValueEncoder(
#'  x,
#'  target,
#'  foldId = NULL,
#'  weight = NULL,
#'  minWeight = 0,
#'  smoothing = 2,
#'  noise = 0,
#'  colName = NULL,
#'  seed = 1984L,
#'  timeFolds = FALSE
#')
#' @param x A factor vector. We are encoding this factor using the target.
#' @param target A numeric vector representing the target being predicted.
#' @param foldId Optional parameter. A vector representing cross-folds
#' or a list where each element corresponds to a fold and is a vector of row numbers.
#' When specified the encoding will only use information from the target for rows which are out-of-fold.
#' If not used, the returned encoder function will do "leave-one-out" target value encoding when in trainMode.
#' @param weight Optional parameter. Weights for each row.
#' Very useful when doing Poisson regression where the target would be frequency
#' (events per exposure) and the weights will be the exposure.
#' @param minWeight Optional parameter which defaults to 0.
#' Factor levels with a total weight lower than this cut-off, they will all be grouped together and treated as a single group.
#' If this super-group is still below the cut-off weight, it will be given the overall average.
#' @param smoothing Optional parameter which defaults to 2.
#' Increasing the smoothing moves the results towards the overall mean.
#' The higher the smoothing parameter the more weight is given to the overall mean
#' and the less weight to the observed mean per factor level.
#' Values should range from 0 upwards.
#' @param noise Optional parameter. A number between 0 and 1. Noise is added by randomly swapping target rows.
#' No rows are swapped for 0 and all rows for 1 (so 100 percent noise and no signal.)
#' Useful for regularisation to prevent overfitting.
#' @param colName Parameter that affects the column name for the one-column matrix that is returned by the encoding function.
#' @param seed A random seed which only affects any added noise.
#' Has no effect (and does not reset the random seed) when noise is set to zero. Default is 1984.
#' @param timeFolds Should we treat the folds as time periods for which no information is
#' allowed to leak forward. In this case, "out-of-fold" means _earlier_ folds. The first fold will
#' get a training set mean returned for all levels.
#' @return A new function that can be used to apply a target value encoding on this factor for new data.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table
#' @importFrom Matrix Matrix
#' @examples 
#' # # For replicability
#' # set.seed(999)
#' # 
#' # # Size of training data
#' # n <- 20000
#' # 
#' # # Create dummy training data
#' # dt_train <- data.table(
#' #   factor = factor(sample(LETTERS, n, replace=TRUE), levels=LETTERS),
#' #   foldId = seq(1, n) %% 5
#' # )
#' # dt_train[, target := rpois(n, (50 + as.integer(factor)) / 20)]
#' # 
#' # # Create test data with one-row per factor level
#' # dt_test <- data.table(
#' #   factor = factor(LETTERS, levels=LETTERS)
#' # )
#' # 
#' # # Create encoding function based on training data
#' # myEncoder <- targetValueEncoder(
#' #   x          =  dt_train[, factor],
#' #   target     =  dt_train[, target],
#' #   foldId     =  dt_train[, foldId],
#' #   smoothing  =  20
#' # )
#' # 
#' # # Apply function to training data in train mode, and test data in test mode
#' # dt_train[, TVE := myEncoder(factor, trainMode = TRUE)]
#' # dt_test[, TVE := myEncoder(factor, trainMode = FALSE)]
#' @export

targetValueEncoder <- function(
  x,
  target,
  foldId = NULL,
  weight = NULL,
  minWeight = 0,
  smoothing = 2,
  noise = 0,
  colName = NULL,
  seed = 1984L,
  timeFolds = FALSE
){
  # Validation for target and x
  if (! is.factor(x)){
    stop("x must be a factor")
  }
  if (! is.numeric(target)){
    stop("target must be numeric")
  }
  lenX <- length(x)
  if (lenX == 0){
    stop("x must have greater than zero length")
  }
  
  if (lenX != length(target)){
    stop("target and x must have the same length")
  }
  
  # Validate weight or set to all 1s
  if (is.null(weight)){
    weight <- rep(1, lenX)
  } else{
    if (! is.numeric(weight)){
      stop("weight must be numeric")
    }
    if (length(weight) != lenX){
      stop("weight must be the same as the target and x")
    }
    if (anyNA(weight)){
      warning("weight contains NAs, these have been set to zero")
      weight[is.na(weight)] <- 0
    }
    if (any(weight < 0)){
      stop("Negative weights are not allowed")
    }
  }
  
  # Put all together in a data table
  dt <- data.table(
    target = target,
    x = x,
    weight = weight,
    rowNum = seq_along(x)
  )
  
  # Get overall totals for weight and target
  totalWeight <- dt[, sum(weight)]
  if (totalWeight == 0){
    stop("The total weight in the data is zero.")
  }
  totalTarget <- dt[, sum(weight * target)]
  
  # Tidy
  rm(target, x, weight)
  
  # Fix missing target
  if (dt[, anyNA(target)]){
    warning("Some target values are NA - these will be ignored")
    dt[anyNA(target), ':=' (target = 0, weight = 0)]
  }
  
  # Fix missing x
  dt[, x := addNA(x)]
  
  # Get the levels
  levels <- levels(dt[, x])
  
  # Combine levels that don't meet cut-off
  weightSummary <- dt[, .(sumWeight = sum(weight)), by = .(x)]
  otherLevel <- paste0(rep("X", max(c(1, nchar(levels)), na.rm = TRUE) + 1), collapse = "")
  dt[, grouped_x := ifelse(
    x %in% weightSummary[sumWeight < minWeight, x],
    otherLevel,
    as.character(x)
  )]
  
  # Does the combined level have enough weight to be included itself?
  otherBelowWeightLimit <- dt[grouped_x == otherLevel, sum(weight)] < minWeight
  
  # FoldId
  if (! is.null(foldId)){
    # If list, set as vector
    if (is.list(foldId)){
      foldId <- folds_ListToVec(foldId)
    }
    if (timeFolds){
      if (! is.numeric(foldId)){
        stop("For time folds, the folds must be given as numeric values")
      }
      if (anyNA(foldId)){
        stop("For time folds, foldId must not contain any NAs")
      }
    }
    # Validate
    if (length(foldId) != nrow(dt)){
      stop("foldId must be the same length as the target and x")
    }
    # Set in data
    dt[, foldId := foldId]
    
    # Tidy
    rm(foldId)
    
    # Vector of folds
    folds <- unique(dt$foldId)
    
    # Check for unique values
    if (length(folds) == 1){
      warning("Only one fold. Performing 'leave-one-out' target value encoding")
      folds <- numeric(0)
      foldId <- NULL
      
    } else if (length(folds) > 20){
      cat(paste0("Creating a TV encoder using ", length(folds), " folds.\n"))
    }
  } else{
    folds <- numeric(0)
  }
  
  # Add random noise by randomly re-ordering a proportion of the target rows
  if (noise > 0){
    set.seed(seed)
    flipRows <- sample(seq(1, nrow(dt)), round(nrow(dt) * noise))
    dt[flipRows, target := sample(dt[flipRows, target])]
  }
  
  # Function to generate smoothed weighted averages by level
  getTargetValues <- function(dt){
    # Total values
    overallWeight <- dt[, sum(weight)]
    overallSumTarget <- dt[, sum(target * weight)]
    
    # Summary by level
    targetSummary <- dt[
      ,
      .(sumWeight = sum(weight) + smoothing,
        sumTarget = sum(target * weight) + smoothing * (overallSumTarget / overallWeight)
      ),
      keyby = .(x = grouped_x)
    ]
    
    # Add in any levels that were below weight cut-off
    allLevels <- data.table(x = levels)
    
    setkey(allLevels, x)
    setkey(targetSummary, x)
    
    targetSummary <- merge(targetSummary, allLevels, all = TRUE)
    
    # If any levels were grouped into a new level
    if (otherLevel %in% targetSummary$x){
      
      # If new level is still below weight cut-off, replace with overalls
      if (otherBelowWeightLimit){
        targetSummary[
          x == otherLevel,
          ':='(
            sumWeight = overallWeight,
            sumTarget = overallSumTarget
          )
        ]
      }
      
      # Any missings are given the same as the "other" level
      targetSummary[
        is.na(sumWeight),
        ':='(
          sumWeight = targetSummary[x == otherLevel, sumWeight],
          sumTarget = targetSummary[x == otherLevel, sumTarget]
        )
      ]
      
      # Drop other level
      targetSummary <- targetSummary[is.na(x) | x != otherLevel]
      
    } else{
      
      # Fix levels with zero weight
      targetSummary[
        is.na(sumWeight),
        ':='(
          sumWeight = overallWeight,
          sumTarget = overallSumTarget
        )
      ]
    }
    
    # Set x back to factor
    targetSummary[, x := addNA(factor(x, levels = levels[which(!is.na(levels))]))]
    
    # set key
    setkey(targetSummary, x)
    
    # Return
    return(targetSummary)
  }
  
  # Run function for full data set
  targetSummary <- getTargetValues(dt)
  
  # Next step depends on folds or no folds
  if (is.null(folds)){
    # Drop grouped_x
    dt[, grouped_x := NULL]
    
    # Merge data with summary
    setkey(dt, x)
    dt <- merge(dt, targetSummary, all.x = TRUE)
    
    # Re-order
    setkey(dt, rowNum)
    
    # Create Leave-one-out target value encoding
    dt[
      ,
      targetValue := ifelse(
        sumWeight == weight,
        sumTarget / sumWeight,
        (sumTarget - target) / (sumWeight - weight)
      )
    ]
    
  } else{
    
    if (! timeFolds){
      
      # Create out-of-fold smoothed weighted averages
      targetSummaryByFold <- rbindlist(
        lapply(
          folds,
          function(i){
            if (is.na(i)){
              tbl <- getTargetValues(dt[! is.na(foldId)])
            } else{
              tbl <- getTargetValues(dt[foldId != i | is.na(foldId)])
            }
            tbl[, foldId := i]
            return(tbl)
          }
        )
      )
      
    } else{
      # Create out-of-fold smoothed weighted averages
      targetSummaryByFold <- rbindlist(
        lapply(
          folds,
          function(i){
            tbl <- getTargetValues(dt[foldId < i])
            tbl[, foldId := i]
            return(tbl)
          }
        )
      )
    }
    
    if (targetSummaryByFold[, max(as.integer(x), na.rm=TRUE) > length(levels(x))]){
      targetSummaryByFold[as.integer(x) > length(levels(x)), x := NA]
    }
    targetSummaryByFold[, x := addNA(x)]
    
    # Fix the first timeFold
    targetSummaryByFold[
      sumWeight==0,
      ':='(
        sumWeight = totalWeight,
        sumTarget = totalTarget
      )
    ]
    
    # Drop unnecessary columns
    dt[, c("grouped_x", "target", "weight") := NULL]
    
    # Merge back onto data
    setkey(targetSummaryByFold, x, foldId)
    setkey(dt, x, foldId)
    dt <- merge(dt, targetSummaryByFold, all.x = TRUE)
    
    # re-order
    setkey(dt, rowNum)
    
    # Create target value encoding
    dt[, targetValue := sumTarget / sumWeight]
  }
  
  # Objects required for final function
  trainingValues <- dt[, targetValue]
  original_x <- dt[, x]
  
  # Remove data table
  rm(dt)
  
  # Create target Value lookup for new data
  targetSummary[
    ,
    ':='(
      targetValue = sumTarget / sumWeight,
      sumTarget = NULL,
      sumWeight = NULL
    )
  ]
  
  targetSummaryByFold[
    ,
    ':='(
      targetValue = sumTarget / sumWeight,
      sumTarget = NULL,
      sumWeight = NULL
    )
  ]
  
  # Build function to return as new encoder
  returnFunction <- function(
    x,
    trainMode = FALSE,
    sparse = FALSE,
    foldId = NULL
  ){
    # Validation
    if (! is.factor(x)){
      stop("x must be a factor")
    }
    
    # Add NA level to x
    x <- addNA(x)
    
    # Train mode, return original values for training
    if (trainMode){
      if (is.null(foldId)){
        if (! identical(x, original_x)){
          stop("x must match original x")
        }
        
        # Create a matrix
        if (sparse){
          mat <- Matrix(
            trainingValues,
            sparse = TRUE
          )
          
        } else{
          mat <- matrix(trainingValues)
        }
      } else{
        if (length(folds) == 0){
          stop("foldId specified when encoder was built using leave-one-out")
        }
        if (length(foldId) != length(x)){
          stop("foldId must be the same length as x")
        }
        if (length(setdiff(unique(foldId), folds)) > 0){
          stop("foldId contains folds not used when creating encoder")
        }
        if (! identical(levels(original_x), levels(x))){
          stop("x must have same levels as original x")
        }
        
        # Merge input data with target value, by fold
        require(data.table)
        dt <- data.table(
          x = x,
          foldId = foldId
        )
        dt[, rowNum := .I]
        setkey(dt, x, foldId)
        dt <- merge(dt, targetSummaryByFold, all.x=TRUE)
        setkey(dt, rowNum)
        
        # Create a matrix
        if (sparse){
          mat <- Matrix(
            dt[, targetValue],
            sparse = TRUE
          )
          
        } else{
          mat <- matrix(dt[, targetValue])
        }
      }
      
    } else{
      # Test mode
      if (! identical(levels(original_x), levels(x))){
        stop("x must have same levels as original x")
      }
      
      # Find matching rows for lookup table
      rows <- match(x, targetSummary$x)
      
      # Create a matrix
      if (sparse){
        mat <- Matrix(
          targetSummary[rows, targetValue],
          sparse = TRUE
        )
        
      } else {
        mat <- matrix(
          targetSummary[rows, targetValue]
        )
      }
    }
    
    # Set column name
    if (! is.null(colName)){
      colnames(mat) <- paste0(colName, "~TVEncoder")
    }
    
    return(mat)
  }
  
  # Return encoder function
  return(returnFunction)
}