#'  Summarise a large file for districting or AvE analysis
#'
#' @description Reads a data set in chunks, then summarises rows by a specified input field (or formula thereof).
#' Data is read in chunks to minimise memory usage. This enables more rapid modelling downstream.
#' A multiplicative model form is assumed.
#'
#' A running commentary is printed to the console, showing how many rows have
#' been read in.
#'
#' @aliases chunkSummarise 
#' @usage
#' chunkSummarise(infile,
#' chunkSize = 50000L,
#' perils = "",
#' responseCol = "Response",
#' offsetCol = NA,
#' summaryCol = NA,
#' sFormula = NULL,
#' exposureCol = NA,
#' yearCol = NA,
#' currentModel = NA,
#' weightCol = NA,
#' rNAval = 0,
#' rDefaultVal = NA, 
#' nlines = NULL,
#' tweedieCols = FALSE,
#' tweediePower = 1.5,
#' ...)
#' @param infile Filename of the input. Note this must be a filename only, not
#' an active connection as might be created by \code{\link{file}} and similar.
#' @param chunkSize Number of rows to read in at once. More will be quicker up
#' to a point, but will use more memory.
#' @param perils the name(s) you wish to give your perils 
#' If \code{seed} is held constant and different integer values of
#' \code{sampleNo} are selected, distinct sets of rows not meeting
#' \code{responseKeepCondition} will be kept. \code{sampleNo} takes a list of
#' integers between 1 and 1/\code{sampleProb} , and the default value will
#' produce a downsample consistent with previous versions. \cr If more than one
#' value is specified, \code{downsampleNonClaims} creates multiple files and
#' appends the values of \code{sampleNo} onto the specified \code{outfile}.
#' @param responseCol The column name(s) containing your response(s). Must be 
#' the same length as `perils`, or a simgle value (as must the arguments following)
#' @param offsetCol Your offset(s), ie the ground state for your model
#' as an expected response per unit exposure. An offset of 1 is assumed by default
#' @param summaryCol Column(s) you wish to summarise by (eg postcode).
#' @param sFormula Optional argument to override summaryCol with a formulaic statement.
#' For example this would enable you to summarise by postcode sector from full 
#' postcode data.
#' @param exposureCol Exposure (or for example, for severity, claim count).
#' @param yearCol Exposure year column name
#' @param currentModel Optional for an existing model, assumed to be per unit exposure.
#' @param weightCol Optional weights column
#' @param rNAval any \code{NA} values in the response columns will be set to this.
#' @param rDefaultVal values of the response to _ignore_ when summarising,
#' for example default reserves when severity modelling.
#' @param nlines Number of lines in the original data set, if known (for speed)
#' @param tweedieCols Additional columns produced for modelling using a tweedie
#' distribution for burning cost.
#' @param tweediePower dispersive constant for tweedie. Default is 1.5 which is 
#' usually required for poisson/gamma.
#' @param \dots Other arguments to \code{\link{read.csv}} eg \code{check.names}.
#' @return a summarised table or named list thereof, containing columns of the data
#' summarised by the chosen factor, as follows:
#' 
#' `Response` (Total), `Expected` (Total expected response according to the offset model),
#' `weightedExposure` (Total Weighted Exposure), `weightdOffset` (weighted average by weighted exposure),
#' `CurrentModel` (weighted average current model per unit exposure,),
#' `Years` (years which had an exposure), `ClaimYears` (years which had a claim, with duplication as required), `respPerExposure`
#' (weighted average response per unit exposure), and `currentExpected` (Total expected response
#' according to the current model).  Plus weighted A/E columns, and tweedie weight, if selected.
#' 
#' 
#' A running commentary is printed to the console, showing how many rows have been read in
#' @author Tom Bratcher
#' @seealso \code{\link{read.csv}}, \code{\link{Vectorize}},
#' @export
#' @importFrom R.utils countLines
#' @examples
#' data("UKTheftFreq")
#' 
#' # Create a factor with lots of levels:
#' UKTheftFreq$location <- factor(apply(
#'   UKTheftFreq[,.(coordinate_x, coordinate_y)], 1, 
#'   function (x) paste0 (round(x / 20000) ,collapse = "&")))
#' 
#' # write it out:
#' fwrite(UKTheftFreq, file = "uktheft.csv")
#' 
#' Test <- chunkSummarise(
#'   infile = "uktheft.csv",
#'   chunkSize = 4000L,
#'   perils = "Example",
#'   sFormula = "gsub('&','!',location)",
#'   summaryCol = "location",
#'   exposureCol = "exposure",
#'   responseCol = "numClaims", 
#'   weightCol = "weight",
#'   offsetCol = "offset",
#'   currentModel = "currentModel",
#'   nlines = 69433
#' )
#' unlink ("uktheft.csv")
#' 
chunkSummarise <- function(
  infile,
  chunkSize = 50000L,
  perils = "",
  responseCol = "Response",
  offsetCol = NA,
  summaryCol = NA,
  sFormula = NULL,
  exposureCol = NA,
  yearCol = NA,
  currentModel = NA,
  weightCol = NA,
  rNAval = 0,
  rDefaultVal = NA,
  nlines = NULL,
  tweedieCols = FALSE,
  tweediePower = 1.5,
  ...)
  {


# error checking ----------------------------------------------------------

    if (is(infile, "connection"))
      stop("'infile' should be a file name, not an actual connection")

    # rows in each chunk:
    if (missing(nlines)) {
      cat("'nlines' not specified. Counting lines...\n")
      
      nlines <- R.utils::countLines(infile) - 1
      cat("found", nlines, "lines\n")
    }
    
    cvec <-
      c(rep(chunkSize, nlines %/% chunkSize), nlines %% chunkSize)
    if (cvec[length(cvec)] == 0L)
      cvec <- cvec[-length(cvec)]
    tableHeader <- colnames(read.csv(infile, nrows = 1, ...))
    
    # check we have anything we've specified: 
    
    for (nm in setdiff(unique(c(
        responseCol,
        offsetCol,
        summaryCol,
        exposureCol,
        yearCol,
        currentModel,
        weightCol)), NA)){
      if (!(nm %in% tableHeader)) stop (
        "'", nm, "' is an expected column name in the arguments but not in infile. Note spaces are removed by read.csv"
      )
    } 

    # if multicolumns: 
    PerilCount <- length(perils)
    
    if (PerilCount > 1){
      if (length(sFormula)) {
        if (length(sFormula) == 1) sFormula <- rep(sFormula, PerilCount) 
        if (length(sFormula) != PerilCount) stop ("Specify the same number of summary formulae as perils, or just 1")
      } else {
        if (is.na(summaryCol)) stop ("One of summaryCol or sFormula need to be specified")
      }
       if (length(responseCol) != PerilCount) stop ("Specify the same number of perils and responses")
       if (length(offsetCol) == 1) offsetCol <- rep(offsetCol, PerilCount) 
       if (length(offsetCol) != PerilCount) stop ("Specify the same number of offsets as perils, or just 1")
       if (length(exposureCol) == 1) exposureCol <- rep(exposureCol, PerilCount) 
       if (length(exposureCol) != PerilCount) stop ("Specify the same number of exposure columns as perils, or just 1")
       if (length(summaryCol) == 1) summaryCol <- rep(summaryCol, PerilCount) 
       if (length(summaryCol) != PerilCount) stop ("Specify the same number of summary columns as perils, or just 1")
       if (length(currentModel) == 1) currentModel <- rep(currentModel, PerilCount) 
       if (length(currentModel) != PerilCount) stop ("Specify the same number of current models as perils, or just 1")
       if (length(weightCol) == 1) weightCol <- rep(weightCol, PerilCount) 
       if (length(weightCol) != PerilCount) stop ("Specify the same number of weight columns as perils, or just 1")
       if (length(rNAval) == 1) rNAval <- rep(rNAval, PerilCount) 
       if (length(rNAval) != PerilCount) stop ("Specify the same number of response NA values as perils, or just 1")
       if (length(rDefaultVal) == 1) rDefaultVal <- rep(rDefaultVal, PerilCount) 
       if (length(rDefaultVal) != PerilCount) stop ("Specify the same number of response Default values as perils, or just 1")
    } # Year is always the same...
    

    fin <- gzfile(infile, "rt")
    on.exit({
      close(fin)
           })
    
        n2 <- 0
       header <- TRUE # is this the first one?

    Output <- list()   
    for (n in cvec) {
     
      df.tmp <- as.data.table(
        read.csv(
          fin,
          nrows = n,
          header = header,
          stringsAsFactors = FALSE,
          ... # think about col classes here, but generally fine.
        ))
      
      colnames(df.tmp) <- tableHeader
     
      #  don't think we need:...
      # if ((!is.null(DD)))
      #   applyDataDictionary (DD, df.tmp) -> df.tmp
      cat("read", n2 <- n2 + n, "rows,\n")
      
      input <- list()
      OutputChunk <- list()
      summCol <- c()
      for (i in 1: PerilCount){
      
      if (length(sFormula)) {
      summCol[i] <- paste0("summary",i)
      while (summCol[i] %in% tableHeader) summCol[i] <- paste0(summCol[i], "x")
      df.tmp[, eval(summCol[i]) := eval(parse(text = sFormula[i]))]
      } else summCol[i] <- summaryCol[i]
      
      
      input[[i]] <- data.table(
        exposure = df.tmp[[exposureCol[i]]],
        response = df.tmp[[responseCol[i]]],
        wtCol = df.tmp[[weightCol[i]]],
        offsetCol = df.tmp[[offsetCol[i]]],
        currentModel = df.tmp[[currentModel[i]]],
        summariseBy = df.tmp[[summCol[i]]],
        Year = df.tmp[[yearCol]]
      )
      # rm (df.tmp) ## might be many of these...
      
      for (nm in c("exposure", "wtCol", "offsetCol", "currentModel", "Year")){
        if(!(nm %in% names (input[[i]]))) input[[i]][[nm]]<- 1
      }
      
      # fix NA/ defaults:
      
      input[[i]][is.na(response), response:= rNAval[i]]
      if (is.numeric(rDefaultVal[i])) input[[i]] <- input[[i]][response != rDefaultVal[i]]
      
      # produce the summary:
      input[[i]][, `:=` (
        freqwt = wtCol * exposure,
        tweedwt = wtCol * exposure * offsetCol ^ (2-tweediePower),
        Expoffwt = offsetCol * exposure * wtCol,
        clmFreq = response / offsetCol)
        ]
    
      OutputChunk[[i]] <- input[[i]][
        freqwt > 0, # ie offset and exposure are positive...
        .(
          Response         = sum(response * wtCol),
          Expected         = sum(offsetCol * freqwt),
          weightedExposure = sum(freqwt),
          weightedOffset   = sum(offsetCol * freqwt),
          currentModel     = sum(currentModel * freqwt),
          tweedieWt        = sum(tweedwt),
          tweedCurrent     = sum(currentModel / offsetCol * tweedwt),
          tweedResponse    = sum(response / offsetCol / exposure * tweedwt),
          Years = .(sort(as.integer(unique(paste(Year))))), # years with exposure
          ClaimYears = .(sort(as.integer(unique(paste(rep(Year,(response > 0))))))) # years with claim
          ), 
        keyby = .(summariseBy)] # might want to create summariseBy on the fly...
      # eg postcode sector
      OutputChunk[[i]][is.na(ClaimYears), ClaimYears := c()]
      # add to what we had, and resume:
      if (header){
        Output[[i]] <- OutputChunk[[i]]
      } else{ 
        Output[[i]] <- rbind(Output[[i]], OutputChunk[[i]])
        setkey(Output[[i]], summariseBy)
        temp <- Output[[i]][,.(Years, ClaimYears, summariseBy)]
        Output[[i]][, `:=`(Years = NULL, ClaimYears = NULL)]
        
        Output[[i]] <- Output[[i]][
          ,
          lapply(.SD, sum),        
          by = .(summariseBy) # but not for years...           
          ] 

        temp <- temp[,.(
          Years = .(sort(unique(unlist(Years)))),
          ClaimYears = .(sort(unlist(ClaimYears)))
          ),
          keyby = .(summariseBy)]
        
        Output[[i]]<- merge(Output[[i]], temp)
        rm(temp)
      } 
      
      }
      header <- FALSE
    }
       
       # when we've done all the chunks,
       # ultimate divisors...
    
    for (i in 1:PerilCount){
       
       Output[[i]][, `:=`(
         weightedOffset = weightedOffset / weightedExposure,
         respPerExposure = Response / weightedExposure,
         currentModel = currentModel / weightedExposure,
         tweedResponse = tweedResponse / tweedieWt,
         tweedCurrent = tweedCurrent / tweedieWt
       )]
       
       Output[[i]][, currentExpected := currentModel * weightedExposure]   
       setkey(Output[[i]], summariseBy) # should be the original name, if exists...
       
       if (!(tweedieCols)){
         Output[[i]][, `:=`( tweedResponse = NULL, tweedieWt = NULL, tweedCurrent = NULL)]
       }
       
       if (nchar(perils[i])){
       Names <- setdiff (names (Output[[i]]), "summariseBy")
       setnames(Output[[i]], Names, paste(Names, perils[i], sep = "."))
       }
       
       if (is.null(sFormula))setnames(Output[[i]], "summariseBy", summaryCol[i])
    
    }    
    # if list length 1 unlist it, else name it:
    if (PerilCount >1){
      names (Output) <- perils
      return (Output) 
      }
    return (Output[[1]]) 
  }

