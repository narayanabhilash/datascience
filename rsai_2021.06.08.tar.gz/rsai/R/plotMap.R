#####  plotMap  #####
#' Function to plot a numeric column of data that varies by location on a map.
#' @description Function that takes a data frame with x, y, and z values to plot a colour scale map.
#' @usage plotMap(
#' data,
#'   column=NULL,
#'   x_coord="x_coord",
#'   y_coord="y_coord",
#'   colourScale="percentile",
#'   minVal=NULL,
#'   maxVal=NULL,
#'   percentileValues=NULL,
#'   palette = c("darkblue", "lightblue", "springgreen", "yellow", "orange", "red"),
#'   opacity = 0.5,
#'   main = NULL,
#'   asp = 1,
#'   pch = ".",
#'   ...
#' )
#' @param data A data frame
#' @param column The column containing the value to be plotted. If left NULL, function will plot just black dots.
#' @param x_coord The column containing x-coordinates for the plot 
#' @param y_coord The column containing y-coordinates for the plot 
#' @param colourScale One of 'percentile' (default), 'linear', or 'log'. If percentile then the values being plotted map to the colours in 'palette' based on their percentiles. If log or linear then they are mapped to colours on a standard log or linear scale.
#' @param minVal If colour scale is log or linear, this fixes the value that maps to the first colour. Values below are trimmed.
#' @param maxVal If colour scale is log or linear, this fixes the value that maps to the last colour. Values above are trimmed.
#' @param percentileValues If colour scale is percentile, this changes the mapping to colours so that it is based on the percentile values of *this* vector rather than of the column values being plotted. This is useful for plotting a subset of a larger data set with the same colour scale.
#' @param palette A vector of colours going from the colour representing low values to the colour representing high. Default goes from dark blue (low), through green, yellow and orange to red (high.)
#' @param opacity Value between 0 and 1. A value of 1 means points plotted are totally opaque and 0 totally transparent. Overplotting can be an issue if opacity is too high.
#' @param main The chart title (otherwise defaults to 'Chart of <column>').
#' @param asp Aspect ratio which defaults to 1 since it is assumed we are plotting a map with co-ordinates where an a/r of 1 is appropriate
#' @param pch Plotting symbol which maps to the 'pch' parameter in the plot function. Default is "."
#' @param ... Other parameters passed through to the plot function (can be used for subtitle, axis headings etc.)
#' @return Ordered factor of the same length as the input vector
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # # Create dummy data to plot
#' # n <- 10000
#' # mapData <- data.frame(coordinate_x=2*runif(n),
#' #                       coordinate_y=runif(n))
#' # mapData$value <- mapData$coordinate_x^2-mapData$coordinate_y
#' # 
#' # # Layout plot area
#' # layout(matrix(c(1,1,2,3), ncol = 2, byrow = TRUE))
#' # 
#' # # Plot the full "map"
#' # plotMap(data=mapData,
#' #         column="value",
#' #         x_coord="coordinate_x",
#' #         y_coord="coordinate_y",
#' #         colourScale="percentile",
#' #         opacity=1,
#' #         pch=1,
#' #         main="Full plot of mapData")
#' # 
#' # # Plot the right-hand side of the map only without fixing percentileValues.
#' # # Colours should rescale.
#' # plotMap(data=mapData[which(mapData$coordinate_x>1), ],
#' #         column="value",
#' #         x_coord="coordinate_x",
#' #         y_coord="coordinate_y",
#' #         colourScale="percentile",
#' #         opacity=1,
#' #         pch=1,
#' #         main="Right-hand side only, no use of percentileValues")
#' # 
#' # # Plot the right-hand side of the map only using percentileValues.
#' # # Colours should share the same scale as the first.
#' # plotMap(data=mapData[which(mapData$coordinate_x>1), ],
#' #         column="value",
#' #         x_coord="coordinate_x",
#' #         y_coord="coordinate_y",
#' #         colourScale="percentile",
#' #         percentileValues=mapData$value,
#' #         opacity=1,
#' #         pch=1,
#' #         main="Right-hand side using percentileValues")
#' @export

plotMap <- function(data,
                    column=NULL,
                    x_coord = "x_coord",
                    y_coord = "y_coord",
                    colourScale="percentile",
                    minVal=NULL,
                    maxVal=NULL,
                    percentileValues=NULL,
                    palette = c("darkblue", "lightblue", "springgreen", "yellow", "orange", "red"),
                    opacity = 0.5,
                    main = NULL,
                    asp = 1,
                    pch = ".",
                    ...){
  
  if (!is.data.table(data)) data <- data.table(data)
  
  # Get title
  if (is.null(main)){
    if (is.null(column)){
      main <- "Map"
    }
    main <- paste0("Map of ", column)
  }
  
  # Get X and Y coords
  if (!(x_coord %in% names (data))){
    temp <- grep("^x|x$|^long|^east", names(data), value=TRUE, ignore.case = TRUE)
    if (length(temp)==0) stop("X coordinate not found") else {
      x_coord <- temp[1]
      warning(paste0("X coordinate not found: using ", temp[1], "\n"))
    }
  }   
  if (!(y_coord %in% names (data))){
    temp <- grep("^y|y$|^lat|^north", names(data), value=TRUE, ignore.case = TRUE)
    if (length(temp)==0) stop("Y coordinate not found") else {
      y_coord <- temp[1]
      warning(paste0("Y coordinate not found: using ", temp[1], "\n"))
    }
  }
  
  # Create function to map number between 0 and 1 to a colour
  colFunc <- colorRamp(palette)
  
  # Filter data to remove NAs
  if (! is.null(column)) data <- data[which(!is.na(data[[column]]))]
  if(colourScale=="log") data <- data[which(data[[column]]>0)]
  
  # Get x, y, and z
  x <- data[[x_coord]]
  y <- data[[y_coord]]
  if (! is.null(column)) z <- data[[column]]
  
  # Create colurs
  if (! is.null(column)){
    if(colourScale=="log"){
      z <- log(z)
      if(!is.null(minVal)) minVal <- log(minVal)
      if(!is.null(maxVal)) maxVal <- log(maxVal)
    }
    
    if(colourScale=="percentile"){
      if(is.null(percentileValues)){
        calcPercentile <- ecdf(z)
      } else calcPercentile <- ecdf(percentileValues)
      z <- calcPercentile(z)
    } else if(colourScale %in% c("log", "linear")){
      # Change values to be between 0 and 1 for colFunc
      # Trim and rescale using minVal and maxVal
      if(is.null(minVal)){
        minVal <- min(z)
      } else{
        if(minVal > min(z)){
          warning("Some values are lower than 'minVal'. These will be trimmed before plotting.")
          z <- pmax(z, minVal)
        }
      }
      if(is.null(maxVal)){
        maxVal <- max(z)
      } else{
        if(maxVal < max(z)){
          warning("Some values are higher than 'maxVal'. These will be trimmed before plotting.")
          z <- pmin(z, maxVal)
        }
      }
      if(minVal >= maxVal) stop("minVal is not strictly less than maxVal")
      z <- (z - minVal)/(maxVal - minVal)
    } else stop("colourScale must be one of 'percentile', 'linear', or 'log'")
    
    # Vector of colours to plot
    colours <- rgb(colFunc(z),
                   alpha = as.integer(opacity * 256),
                   maxColorValue = 256)
  }
  
  # Plot
  if (! is.null(column)){
    plot(
      x,
      y,
      pch = pch,
      col = colours,
      asp = asp,
      main = main,
      xlab = x_coord,
      ylab = y_coord,
      ...
    )
  } else{
    plot(
      x,
      y,
      pch = pch,
      asp = asp,
      main = main,
      xlab = x_coord,
      ylab = y_coord,
      ...
    )
  }
}