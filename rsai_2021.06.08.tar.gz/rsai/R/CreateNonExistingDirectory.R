#' Create Directory when it doesn't exist
#'
#' Function to check whether location exists when writing a file and create the location if it doesn't exist
#'
#' @param fnv_FileLoc string. String giving the file and location you wish to write to.
#' @return \code{fnv_FileLoc} so that this function can be used in fwrite call.
#' @examples
#' # .fn_CreateNonExistingDirectory(fnv_FileLoc)

.fn_CreateNonExistingDirectory <- function (fnv_FileLoc)
{
  # Check if directories are defined in the name
  directory <- grep("(/|\\\\)", fnv_FileLoc)
  if (length(directory) == 0){
    return(fnv_FileLoc)
  }

  # Extract directory portion of fnv_FileLoc, strip trailing "/"
  directory <- gsub("^(.*)(/|\\\\)(.*)$", "\\1", fnv_FileLoc)
  while (substr(directory, nchar(directory), nchar(directory)) %in% c("\\","/")){
    directory <- substr(directory, 1, nchar(directory) - 1)
    if (nchar(directory) == 0){
      stop("Error in .fn_CreateNonExistingDirectory - attempting to create a blank directory")
    }
  }

  # Create directory if it doesn't exist
  if (file.exists(directory)){
    return(fnv_FileLoc)
  } else {
    dir.create(directory, recursive = TRUE)
    message("The directory ", directory, " was created")
    return(fnv_FileLoc)
  }
}
