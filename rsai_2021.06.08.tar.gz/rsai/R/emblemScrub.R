#' Select numbers from string vectors with pattern
#' 
#' @description Select numbers from string vectors with pattern
#' @param data string vector
#' @export
band <- function (data) { data<- as.numeric(gsub("([0-9.]+)[ ]*[-][ ]*[-0-9.]+","\\1",data))}



#' Function to clean and reformat banded data fields
#' 
#' @description \code{EMBscrub} processes duration and other banded data fields as might be
#' used by EMBlem files, turning them into equivalent numeric data.
#' 
#' Specifically, the processing should be equivalent to the processing of
#' numeric fields which is part of the UK P&P transformation project, with
#' duration data in years being converted into months and representative
#' figures being taken from banded data. (See notes below for known
#' exceptions.)
#' 
#' @aliases EMBscrub emblemScrub
#' @param data A list or data column.
#' @param noFlag If TRUE then before any other processing, all data containing
#' the word "no" are coerced to zero.
#' @param intFlag If TRUE then returns an integer rather than a numeric (which
#' may then round your data unexpectedly).
#' @return Processed data column.
#' @note The following won't be converted to numeric strings as might be
#' expected (so you will need to do this by hand if you really want to:) -
#' "Unknown" gets converted to \code{NA} rather than 9999 \cr
#' - "1 Month" gets converted to 1 rather than 0 \cr
#' - ABI classification codes (eg "A15") would be converted to \code{NA}.
#' @author Tom Bratcher
#' @seealso \code{\link{readEMBlem}}, for reading in EMBlem files.
#' @export
#' @examples
#' 
#' 
#' Dirtydata <- list ("4-5 Months",
#'                    "2-3 Years", 
#'                    "0 - 50", 
#'                    "50-100", 
#'                    "No accident", 
#'                    "31 and above", 
#'                    "125 and above", 
#'                    "5+", 
#'                    "Unknown")
#' EMBscrub(Dirtydata)
#' EMBscrub(Dirtydata,noFlag = TRUE,intFlag = TRUE)
#' 
EMBscrub <- function (data, noFlag = FALSE, intFlag=FALSE) {
  # does "no" mean zero?
  if (noFlag) data[grep("\\bno\\b", data, ignore.case = TRUE)] <- 0L
  
  # get rid of plusses:
  data <- gsub("([0-9]*)+[ ]*[+]","\\1", data)
  bandflag <- grep("[0-9]+[ ]*[-][ ]*[-0-9.]+", data)  
  plusflag <- grep(" and above", data, ignore.case = TRUE) # add 1 if it's over 100
  yearflag <- grep("year", data, ignore.case = TRUE)
 
  data <- gsub("[ ]*and above","", data, ignore.case = TRUE)
  data <- band (gsub ("([0-9]+)( )*([A-z]+)", "\\1",data)) # this doesn't then fix "colon banded" data. this is fine
  if (intFlag) data <- as.integer(data)
  over0 <- which (data > 0)
  over100 <- which (data > 100)
  if(length(yearflag)) data[yearflag] <- 12 * data[yearflag]
  data[intersect(bandflag, over0)] <- data[intersect(bandflag, over0)] + 1
  data[intersect(plusflag, over100)] <- data[intersect(plusflag, over100)] + 1
  
  return(data)
}


