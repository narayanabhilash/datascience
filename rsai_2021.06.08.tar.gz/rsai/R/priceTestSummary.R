#' Padding characters in front of string
#' @description  Padding characters in front of string
#' @param x string vector
#' @param n number of string to feep as a format
#' @param add characters to pad
#' @export
strpad <- function(x,n,add=" "){
	x <- strtrim(x,n)
	while (nchar(x) < n) x <- paste0(x,add)
	return(x)
}

#Sixiang: as defined in CBA.R
# logit <- function(x) log(x/(1-x))
# invlogit <- function(x) 1 - 1 / (1 + exp(x))



#' Analyse a Price Test
#' 
#' @description  This function will summarise conversion by price test factor given output
#' from a price test. It will also return an estimate of the elasticity of the
#' population tested.
#' @usage priceTestSummary(quotes, PTF, sales) 
#' @details A summary of the price test is echoed to the terminal. This includes one row
#' for each price test band, showing quotes, sales and conversion.\cr Two plots
#' are also created: a bar chart showing the number of quotes in each price
#' test band and a line graph showing the actual and modelled conversion by
#' price test factor.
#' 
#' @param quotes Numeric vector of the number of quotes in each price test
#' band.
#' @param PTF Numeric vector of the price test factor applied to each band.
#' @param sales Numeric vector of the number of sales in each band.
#' @return A numeric vector of length one, the estimated elasticity.
#' @author James Lawrence
#' @references The formula for the elasticity as a function of the coefficients
#' of the conversion GLM was derived by Edwin Graham.
#' @export
#' @examples
#' 
#' ## example: suppose we ran a price test
#' ## with 100k quotes each at +/- 2% price
#' ## and 800k quotes at normal price
#' ## we got 600,4000 and 400 sales respectively
#' ## at PTF 0.98 1.00 and 1.02
#' priceTestSummary(
#' 	PTF=c(0.98,1.00,1.02),
#' 	quotes=c(100000,800000,100000),
#' 	sales=c(600,4000,400)
#' )
#' 
priceTestSummary <- function(quotes,PTF,sales){
	if(length(PTF) != length(quotes)) stop("'quotes' and 'PTF' must have the same length")
	if(length(PTF) != length(sales)) stop("'sales' and 'PTF' must have the same length")
	if(any(sales > quotes)) stop("'sales' can't be more than 'quotes'")
	conv <- sales / quotes
	par(mfrow=c(1,2))
	plot(PTF,quotes,type="h",lwd=5,ylab="number of quotes",main="Price test structure")
	plot(PTF,conv*100,xlab="PTF",ylab="conversion %",type="l",main="Conversion by PTF")
	legend("topright",col=c("black","red"),lwd=1,legend=c("actual","predicted"))
	#segments(PTF,0,PTF,quotes,lwd=5)
	cat("Price test summary\nPTF     quotes     sales      conversion\n")
	for(i in seq_along(PTF)){
		cat(strpad(PTF[i],7),strpad(quotes[i],10),strpad(sales[i],10),strpad(conv[i],7),"\n")
	}
	conv.glm <- glm(conv ~ PTF,family="binomial",weights=quotes)
	ela <- (1 - invlogit(conv.glm$coef[1] + conv.glm$coef[2]))*conv.glm$coef[2]
	PTF2 <- data.frame(PTF=seq(min(PTF),max(PTF),length=100))
	lines(PTF2$PTF,predict(conv.glm,PTF2,type="response")*100,col="red")
	cat("estimated elasticity:",ela,"\n")
	return(invisible(unname(ela)))
}
