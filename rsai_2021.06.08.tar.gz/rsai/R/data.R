#' Claims Frequency data for theft claims for a UK motor portfolio 
#'
#' A dataset containing claims frequency data for theft claims for a UK motor portfolio.
#' This dataset can be used to create a location-based model of theft frequency.
#' Each row represents a period of exposure to theft risk for a specific policy.
#' There may be multiple rows per policy but the column to identify policies has been removed.
#' We have 22 postcode features and predictions from an "offset" model where the
#' effect of all location-based features has been removed. For an example of how to use this data set, see:
#' \url{
#'   https://teams.rsa-ins.com/sites/6625f3d4/Data%20Science%20Docs/bestPracticeGBM201904.nb.html
#' }
#'
#' @format A data frame with 69,433 rows and 31 variables:
#' \describe{
#'   \item{exposure}{The time period of exposure to theft risk associated with this row of data, in years.
#'   This will always be less than or equal to 1.}
#'   \item{numClaims}{Observed number of theft claims in this time period.}
#'   \item{weight}{Row-weighting. Rows associated with policies with no claims were sampled with a 5:1 ratio.
#'   Use this column to weight any analysis in order to account for the sampling.}
#'   \item{offset}{The predictions for a baseline theft frequency model that does not take location into account.
#'   Note that this is the expected *frequency* of claims across 1 unit (a year) of exposure,
#'   and not the expected *number* of claims for each row.}
#'   \item{currentModel}{The predictions for a benchmark model built on the same data.
#'   This model uses both location and non-location based features and is a GLM.
#'   Again, this number is a *frequency* per exposure period, not the expected number of claims.}
#'   \item{year}{Calendar year of exposure period.}
#'   \item{coordinate_x}{East/West location using the British National Grid coordinate reference system.}
#'   \item{coordinate_y}{North/South location using the British National Grid coordinate reference system.}
#'   \item{foldId}{A random grouping of rows by postcode sector that can be used to split the data into training and validation sets.}
#'   \item{D20_Country}{Postcode based modelling feature.}
#'   \item{cts_tft_sev_score}{Postcode based modelling feature.}
#'   \item{Unemployed_16_24}{Postcode based modelling feature.}
#'   \item{ccj_2004}{Postcode based modelling feature.}
#'   \item{Density}{Postcode based modelling feature.}
#'   \item{Long_Term_Unemployed_v1}{Postcode based modelling feature.}
#'   \item{F45PCMOSAICUKFACTORBSCORE}{Postcode based modelling feature.}
#'   \item{F45PCMOSAICUKFACTORCSCORE}{Postcode based modelling feature.}
#'   \item{Social_Grade_DE}{Postcode based modelling feature.}
#'   \item{Rented_from_Council}{Postcode based modelling feature.}
#'   \item{P_AFFLUENCE_AVG}{Postcode based modelling feature.}
#'   \item{ACQ_hhld_03km_bnd}{Postcode based modelling feature.}
#'   \item{ACQ_hhld_05km_bnd}{Postcode based modelling feature.}
#'   \item{ACQ_hhld_10km_bnd}{Postcode based modelling feature.}
#'   \item{ACQ_hhld_bnd}{Postcode based modelling feature.}
#'   \item{GRA_crime_032009}{Postcode based modelling feature.}
#'   \item{Dist.01}{Postcode based modelling feature.}
#'   \item{Dist.04}{Postcode based modelling feature.}
#'   \item{EV.09.Accident.count.within.3km.by.sector}{Postcode based modelling feature.}
#'   \item{motorway.20000}{Postcode based modelling feature.}
#'   \item{HPIINDEX}{Postcode based modelling feature.}
#'   \item{majorHousingType}{Postcode based modelling feature.}
#' }

"UKTheftFreq"