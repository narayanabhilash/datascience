# xgbSetupdata2
# xgbSetupdata2_colnames


#####################################################
# Code to generate generic xgboost ready matrices from data tables
#####################################################

#' Format a data frame ready for modelling using \code{xgboost} 
#' 
#' @description xgbSetupdata2 reads in a data frame or data table and outputs a list of 
#' one or more matrices with for use by algorithms such as xgboost.
#' @usage xgbSetupdata2(
#'  dt_Data,
#'  response              =  NULL,
#'  explanatory_vars      =  NULL,
#'  exposure              =  NULL,
#'  sampleWeight          =  NULL,
#'  offset_model          =  NULL,
#'  rowIndicesList        =  NULL,
#'  link                  =  log,
#'  defaultEncoding       =  "oneHot",
#'  encodingExceptions    =  NULL,
#'  NA_treatment          =  "fix",
#'  NA_exceptions         =  NULL,
#'  NA_default            =  2.14E+9,
#'  NA_defaultExceptions  =  NULL,
#'  sparse                =  TRUE,
#'  justMatrices          =  FALSE,
#'  trainMode             =  NULL,
#'  orderedAsNum          =  TRUE,
#'  filterCols            =  character(0)
#')
#' @param dt_Data The input data frame or data table.
#' @param response The name of the response column in dt_Data. If you are modelling claim frequency this should be claim count.
#' \strong{Do not} adjust the claim counts by exposure to create a claim frequency response, as the function does this for you.
#' Likewise for claim severity or burn cost models, the response column should be total loss \emph{not} loss per claim, or loss per exposure.
#' NAs are not allowed.
#' @param explanatory_vars character vector OR list of character vectors. 
#' If this is a list, you can vary the explanatory variables in each of the DMatrices produced but there must be a 1:1 mapping.
#' This is useful, for example, if you have a column with a different name in your validation data than your training data.
#' If not specified, all columns are used other than those sepecified as response, sampleWeight, offset_model and exposure.
#' If there are any NAs in these columns they will be treated as per the \code{NA_treatment} parameter.
#' @param exposure Optional name of column containing exposure periods. Useful for frequency and burn cost modelling.
#' For severity modelling with data containg some rows with more than one claim,
#' you should supply this parameter with the name of your claim count column.
#' Must contain non-negative values. NAs are not allowed.
#' @param sampleWeight Optional name of column to be used for weights in the model,
#' for example if the data is sampled using varying sampling ratios
#' and you need to up-weight certain rows where sampling was applied.
#' NB this should be weight \emph{over and above} the effect of exposure periods.
#' NAs will be set to zero and corresponding rows will be zero-weighted in xgboost modelling.
#' @param offset_model Optional name of column to be used as an offset model.
#' \code{xgboost} will model from this as a starting point.
#' \strong{Do not} apply the link function to this offset as the function applies it for you. NAs or values that produce
#' NAs when applying the link function are not allowed.
#' @param rowIndicesList optional list of integer vectors representing row numbers.
#' If this list is named the output list will also be named using the names from here.
#' \code{xgbSetupdata2} returns a list of matrix objects consistent with the data in these rows.
#' @param link a function to apply to any offset specified before setting the base margin. Default is log.
#' \emph{Note that if this is set to log (which it is by default) you should \emph{not} apply the log-link yourself
#' if using the offset_model parameter}
#' Set to:
#' \describe{
#'   \item{\code{identity}}{For linear models}
#'   \item{\code{logit}}{For binary classification.}
#'   \item{\code{log} (default)}{For frequency, severity and burn cost models.}
#' }
#' @param defaultEncoding The default encoder to apply to unordered factor columns.
#' Must be one of: oneHot (default), numeric, binary, circular or ordered.
#' Ordered factors will be numeric encoded unless there are encoding exceptions set, or \code{orderedAsNum} is FALSE.
#' \describe{
#'   \item{oneHot}{Each level of the factor will have its own column containing 1 or 0 depending on the value for that row.}
#'   \item{numeric}{The function \code{as.integer} is simply applied to the factor.}
#'   \item{binary}{This first encodes the factor as an integer (again uses \code{as.integer} and subtracts 1 so levels start at 0.) 
#'   Then the integer is converted to binary.
#'   The binary numbers are then split into columns, so the first column represents 2^0, then 2^1, etc.}
#'   \item{ordered}{The factor is assumed in the same order as the \code{as.integer} function would put it in.
#'   A binary column is encoded for each possible split-point. This will result in n-1 columns for an n-level factor.
#'   I.E. the columns of a resulting matrix will be: as.integer(x) < 2; as.integer(x) < 3; ... ; as.integer(x) < n}
#'   \item{circular}{The factor is encoded into two columns in a "clock-face" pattern that assumes the factor levels
#'   represent things that are ordered and repeat, like days of the week or months in the year.}
#' }
#' @param encodingExceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are factor columns in the data
#' table and the values are all valid encoders (currently: oneHot, numeric, binary),
#' OR a named list where each name is a valid encoder
#' and each element is a character vector of factor columns in the data. 
#' The function will apply the specified encoder to the factors named here and the default encoder to all other factors.
#' It is also possible to apply your own custom encoder using a function. To do this, \code{encodingExceptions}
#' should be a named list where each name is a factor and each entry is either a character name of a valid encoder as above
#' OR a custom function.
#' These functions must have three arguments: \code{x}, the factor vector to encode;
#' \code{trainMode} whether to return the training encoding or to apply the encoding on new data in test mode
#' (target value encoding will have different "out-of-fold" encoding for training data than new data);
#' \code{sparse}, whether to return a sparse matrix rather than a dense matrix.
#' The \code{targetValueEncoder} function creates custom encoding functions in the right form.
#' @param NA_treatment One of "fix" (default), "drop", "fail". What to do with missing values (NAs.)
#' This only applies to the explanatory_vars. If the response, exposure or offset model have missing values
#' the function will fail. If the sampleWeight column contains missing values they will be replaced with zeros
#' with a warning message.
#' \describe{
#'   \item{fix}{The function will replace any NAs and how it does so will depend on the arguments
#'   \code{NA_exceptions}, \code{NA_default} and \code{NA_defaultExceptions}.}
#'   \item{drop}{The function will drop any rows containing NAs}
#'   \item{fail}{Any NAs will trigger an error message. useful as a catch if you are expecting no NAs.}
#' }
#' @param NA_exceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are of explanatory variables in the data and the values the NA_treatment to apply
#' OR a named list where each name is an NA_treatment and the list elements are character vectors with the names of explanatory variables.
#' @param NA_default value to which numeric NAs are set by default when the \code{NA_treatment} is set to "fix".
#' @param NA_defaultExceptions Optional named numeric vector where the names are numeric variables and the values
#' are the values to set the NAs to.
#' This will override the default for the variables specified.
#' @param sparse if TRUE (default), the returned matrices will be a sparse representation, if FALSE they will be dense. 
#' @param justMatrices if TRUE returns matrices rather than xgb.Dmatrix objects. This can be useful if you wish to extract your data.
#' @param trainMode When using custom encoding function this must be specified. This can be a named list of logicals or a named
#' logical vector. It must be the same length as the rowIndicesList. Each entry corresponds to one of the matrices to return.
#' Training data should be set with \code{trainMode = TRUE}, and test or validation data with \code{trainMode = FALSE}.
#' This will determine how to encode factors that have a custom encoder (for example, target value encoding) where
#' training data has a different "out-of-fold" encoding than the test data.
#' @param orderedAsNum if TRUE (default) ordered factors will be encoded numerically unless any encoding exceptions have been set.
#' Otherwise, if FALSE, ordered factors are treated the same as unordered factors.
#' @param filterCols character vector of feature names to drop - for example if you have a factor column
#' called "FuelType" with three levels: "Petrol", "Diesel", "Hybrid" and "Electric", if using one-hot encoding
#' the function will create the features: "FuelType~is~Petrol", "FuelType~is~Diesel", "FuelType~is~Hybrid" and "FuelType~is~Electric".
#' If you only want the first three of these, you can set \code{filterCols} to "FuelType~is~Electric". The feature
#' will then not be included in the output.
#' @return a list of xgb.Dmatrix objects.
#' @note If using one-hot encoding, sparse encoding is the default. This was historically recommended for memory usage reasons.
#' However, if you wish to build a model to be extracted to another format,
#' we would recommend dense encoding due to the way \code{xgboost} treats zeroes. 
#' @importFrom xgboost xgb.DMatrix
#' @importFrom Matrix sparse.model.matrix
#' @importFrom data.table data.table
#' @examples 
#' # library(rsai)
#' # # Setup dummy data
#' # n <- 1000
#' # dt_Data <- data.table(
#' #   x1        =  rnorm(n),
#' #   x2        =  sample(letters, n, TRUE),
#' #   x3        =  rnorm(n),
#' #   u         =  exp(rnorm(n)),
#' #   exposure  =  runif(n)
#' # )
#' # dt_Data[, target := rpois(n, exposure * u * exp(0.1 * x1 + 0.2 * (x2 %in% letters[1:10]) - 0.1 * x3))]
#' # dt_Data[, x2 := factor(x2)]
#' # 
#' # # Create the list of xgbDMatrices
#' # xgbDList <- xgbSetupdata2(
#' #   dt_Data,
#' #   response          =  "target",
#' #   explanatory_vars  =  c("x1", "x2", "x3"),
#' #   NA_treatment      =  "fix",
#' #   NA_default        =  1e10,
#' #   exposure          =  "exposure",
#' #   offset_model      =  "u",
#' #   link              =  log,
#' #   defaultEncoding   =  "oneHot"
#' # )
#' @export
#' @author Edwin Graham, Tom Bratcher & Nigel Carpenter

xgbSetupdata2 <- function(
  dt_Data,
  response              =  NULL,
  explanatory_vars      =  NULL,
  exposure              =  NULL,
  sampleWeight          =  NULL,
  offset_model          =  NULL,
  rowIndicesList        =  NULL,
  link                  =  log,
  defaultEncoding       =  "oneHot",
  encodingExceptions    =  NULL,
  NA_treatment          =  "fix",
  NA_exceptions         =  NULL,
  NA_default            =  2.14E+9,
  NA_defaultExceptions  =  NULL,
  sparse                =  TRUE,
  justMatrices          =  FALSE,
  trainMode             =  NULL,
  orderedAsNum          =  TRUE,
  filterCols            =  character(0)
){
  
  #####################
  
  # Check input data is a data table
  if (!("data.table" %in% class(dt_Data))){
    if (!("data.frame" %in% class(dt_Data))){
      stop("dt_Data must be a data.frame")
    } else {
      dt_Data <- data.table(dt_Data) # convert data frame to data table
    }
  }
  
  # Validate rowIndicesList
  # We want rowIndicesList to be a list with rows indices for each matrix we are returning
  if (is.null(rowIndicesList)){
    rowIndicesList <- list(seq_len(nrow(dt_Data)))
  } else {
    if (!is.list(rowIndicesList)){
      stop("rowIndicesList must be a list")
    }
    if (!all(sapply(rowIndicesList, is.integer))){
      stop("rowIndicesList must contain integer vectors")
    }
    if (suppressWarnings(max(unlist(rowIndicesList))) > nrow(dt_Data)){
      stop("Row indices specified in rowIndicesList are out of bounds")
    } 
    if (suppressWarnings(min(unlist(rowIndicesList))) < 1){
      stop("Row indices specified in rowIndicesList are out of bounds")
    }
  }
  
  # Number of xgbDMatrices to return
  nXgbMats <- length(rowIndicesList)
  if (nXgbMats == 0){
    stop("rowIndicesList must be a list of length >= 1")
  }
  
  # Validate explanatory_vars
  if (is.null(explanatory_vars)){
    
    # Create empty list to populate with column names
    explanatory_vars <- vector(mode = "list", length = nXgbMats)
    
    # Populate list with column names, all in data set except response, exposure, weight and offset
    for (i in seq(1, nXgbMats)){
      explanatory_vars[[i]] <- setdiff(
        colnames(dt_Data),
        c(response, exposure, sampleWeight, offset_model)
      )
    }
    
    # Number of variables
    nVars <- length(explanatory_vars[[1]])
    if (nVars < 1){
      stop("There must be at least one explanatory variable")
    }
    
    # Find class of variables provided
    varTypes <- lapply(
      explanatory_vars,
      function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]])
    )
    
  } else {
    # explanatory_vars is a character vector of column names to use
    if (is.character(explanatory_vars)){
      # Convert to a list (one for each return matrix)
      explanatory_vars <- lapply(
        seq(1, nXgbMats),
        function(i) explanatory_vars
      )
      
      # Number of variables
      nVars <- length(explanatory_vars[[1]])
      if(nVars < 1){
        stop("There must be at least one explanatory variable")
      }
      
      # Find class of variables provided
      varTypes <- lapply(
        explanatory_vars,
        function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]])
      )
      
    } else{
      # explanatory_vars is a list of column names to use
      if (is.list(explanatory_vars)){
        
        # Check length is same as number of matrices to return
        if (length(explanatory_vars) != nXgbMats){
          stop("explanatory_vars must be list of the same length as rowIndicesList")
        }
        
        # Check that list contains character vectors
        if (!all(sapply(explanatory_vars, is.character))){
          stop("explanatory_vars must be a character vector or list of character vectors")
        }
        
        # Number of variables
        nVars <- length(explanatory_vars[[1]])
        if (nVars < 1){
          stop("There must be at least one explanatory variable")
        }
        
        # Find class of variables provided
        varTypes <- lapply(
          explanatory_vars,
          function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]])
        )
        
        # More than one matrix to return so check that variables match up
        if (nXgbMats > 1){
          
          # Check length of list of explanatory variables is consistent
          if (!all(sapply(explanatory_vars, length) == nVars)){
            stop("explanatory_vars must contain character vectors of the same length")
          }
          
          # Check corresponding variable types is consistent
          if (!all(
            sapply(
              seq(1, nVars),
              function(i) all(
                sapply(
                  seq(2, nXgbMats),
                  function(j) varTypes[[j]][[i]] == varTypes[[1]][[i]]
                )
              )
            )
          )){
            stop(paste0(
              "When using different explanatory variables for each xgbDMatrix,",
              " there must be a 1:1 mapping between the sets of variables.",
              " Corresponding columns must be of the same class."
            ))
          }
          
          # Find corresponding factors and check they have the same length of levels
          factorIndex <- which(varTypes[[1]]=="factor")
          if (length(factorIndex) > 0){
            factorVars <- lapply(
              explanatory_vars,
              function(x) x[factorIndex]
            )
            factorLevs <- lapply(
              factorVars,
              function(x) sapply(
                x,
                function(y) levels(dt_Data[[y]])
              )
            )
            factorLevLengths <- lapply(
              factorLevs,
              function(x) sapply(x, length)
            )
            
            if (!all(
              sapply(
                seq(1, length(factorIndex)),
                function(i) all(
                  sapply(
                    seq(2, nXgbMats),
                    function(j) factorLevLengths[[j]][[i]] == factorLevLengths[[1]][[i]])
                )
              )
            )){
              stop(paste0(
                "When using different explanatory variables for each xgbDMatrix,",
                " there must be a 1:1 mapping between the sets of variables.",
                " Corresponding factor columns must have the same number of levels."
              ))
            }
            
            # Check corresponding factors have the same level names
            if (!all(
              sapply(
                seq(1, length(factorIndex)),
                function(i) all(
                  sapply(
                    seq(2, nXgbMats),
                    function(j) all(factorLevs[[j]][[i]] == factorLevs[[1]][[i]])
                  )
                )
              )
            )){
              stop(paste0(
                "When using different explanatory variables for each xgbDMatrix,",
                "there must be a 1:1 mapping between the sets of variables. ",
                "Corresponding factor columns must have exactly the same levels."
              ))
            }
            
            # Check variables that are set to exist across more than one output matrix line up
            if (any(
              sapply(
                unique(unlist(explanatory_vars)),
                function(x){
                  length(
                    unique(
                      do.call(
                        c,
                        lapply(
                          explanatory_vars,
                          function(y){
                            which(x==y)
                          }
                        )
                      )
                    )
                  ) > 1
                }
              )
            )){
              stop(paste0(
                "At least one explanatory variable is set to be included in more than one output matrix,",
                " but in a different position. This is almost certainly an error!",
                " If you have a use case for allowing this, then let the Data Science team know about it."
              ))
            }
          }
        }
        
        # Otherwise if explanatory_vars is not a character vector or a list...
      } else stop("explanatory_vars must be a character vector or list of character vectors")
    }
  }

  # Check for columns listed in more than one place
  if (any(unlist(explanatory_vars) %in% c(exposure, response, sampleWeight, offset_model))){
    stop(paste0(
      "At least one column is listed in the explanatory_vars and also in one of the other arguments",
      " (response, exposure, sampleWeight or offset_model)."
    ))
  }
  
  if (anyDuplicated(c(exposure, response, sampleWeight, offset_model))){
    stop(
      "At least one column is listed in more than one argument (response, exposure, sampleWeight or offset_model.)"
    )
  }
  
  # Validate link function
  if(!is.function(link)) stop("link must be a valid function.")
  
  # Trim data to required factors. This also serves as a test that all factors specified in
  # explanatory_vars, sampleWeight, exposure, offset_model and response are valid column names
  dt_Data <- dt_Data[
    ,
    c(unique(unlist(explanatory_vars)), sampleWeight, exposure, offset_model, response),
    with = FALSE
  ]
  
  # Validate filterCols
  if (! is.character(filterCols)){
    stop("filterCols must be a character")
  }
  
  # Validate NA_treatment
  if (!is.character(NA_treatment)){
    stop("NA_treatment must be a character")
  }
  if (length(NA_treatment) != 1){
    stop("NA_treatment must be a character vector of length one")
  }
  if (! NA_treatment %in% c("fix", "drop", "fail")){
    stop("NA_treatment must be one of fix, drop or fail")
  }
  
  # Setup NA_treatments for all explanatory vars
  exVars <- unique(unlist(explanatory_vars))
  NA_treatments <- rep(NA_treatment, length(exVars))
  names(NA_treatments) <- exVars
  
  # Validate NA_exceptions
  if (! is.null(NA_exceptions)){
    if (is.list(NA_exceptions)){
      NA_exceptions <- namedList2Vec(NA_exceptions)
    } else if (is.character(NA_exceptions)){
      if (is.null(names(NA_exceptions))){
        stop("If NA_exceptions is a character vector it must be a named")
      }
      if (anyDuplicated(names(NA_exceptions))){
        stop("NA_exceptions must have unique names")
      }
    } else{
      stop("NA_exceptions must be either a list or a character vector")
    }
    # Check treatments are valid
    if (! all(NA_exceptions %in% c("fix", "drop", "fail"))){
      stop("NA_exceptions contains an invalid NA treatment.")
    }
    # Check NA_exceptions has valid variable names
    if (length(setdiff(names(NA_exceptions), names(NA_treatments))) > 0){
      stop("NA_exceptions refers to variables that are not specified in explanatory_vars")
    }
    # Update NA_treatments with exceptions
    NA_treatments[match(names(NA_exceptions), names(NA_treatments))] <- NA_exceptions
  }
  
  # Create NA_exceptionsList
  NA_exceptionsList <- lapply(
    explanatory_vars,
    function(x){
      NA_treatments[match(x, names(NA_treatments))]
    }
  )
  
  # Check NA_treatments are consistent across associated variables
  if (! is.null(NA_exceptions)){
    if (nXgbMats > 1){
      for (i in seq(2, nXgbMats)){
        if (! all(NA_exceptionsList[[i]] == NA_exceptionsList[[1]])){
          stop("NA treatments must be consistent across associated variables")
        }
      }
    }
  }
  
  # Find which rows need to be dropped
  dropCols <- names(NA_treatments)[which(NA_treatments == "drop")]
  if (length(dropCols) > 0){
    dropRows <- which(rowSums(is.na(dt_Data[, dropCols, with=FALSE])) > 0)
    
    # Adjust rowIndicesList accordingly and drop rows
    if (length(dropRows) > 0){
      # Fix rowIndicesList
      rowIndicesList <- lapply(
        rowIndicesList,
        function(x){
          rows <- rep(0, nrow(dt_Data))
          rows[x] <- 1
          rows <- rows[-dropRows]
          return(which(rows==1))
        }
      )
      
      # drop rows from table
      dt_Data <- dt_Data[-dropRows]
    }
    
    # Already performed drop action so remove from exception list
    NA_exceptionsList <- lapply(
      NA_exceptionsList,
      function(x){
        x[x != "drop"]
      }
    )
  }
  
  # Validate NA_default
  if (!is.numeric(NA_default)){
    stop("NA_default must be numeric")
  }
  if (length(NA_default) != 1){
    stop("NA_default must be a numeric vector of length one")
  }
  
  # Setup NA_values for all explanatory vars
  NA_values <- rep(NA_default, length(exVars))
  names(NA_values) <- exVars
  
  # Validate NA_defaultExceptions
  if (! is.null(NA_defaultExceptions)){
    if (! is.numeric(NA_defaultExceptions)){
      stop("NA_defaultExceptions must be a numeric vector")
    }
    if (is.null(names(NA_defaultExceptions))){
      stop("NA_defaultExceptions must be a named numeric vector")
    }
    if (anyDuplicated(names(NA_defaultExceptions))){
      stop("NA_defaultExceptions must have unique names")
    }
    # Check NA_exceptions has valid variable names
    if (length(setdiff(names(NA_defaultExceptions), names(NA_values))) > 0){
      stop("NA_exceptions refers to variables that are not specified in explanatory_vars")
    }
    # Update NA_values with exceptions
    NA_values[match(names(NA_defaultExceptions), names(NA_values))] <- NA_defaultExceptions
  }
  
  # Create NA_valuesList for use later
  NA_valuesList <- lapply(
    explanatory_vars,
    function(x){
      NA_values[match(x, names(NA_values))]
    }
  )
  
  # Check NA replacement values are consistent across associated variables
  if (! is.null(NA_defaultExceptions)){
    if (nXgbMats > 1){
      for (i in seq(2, nXgbMats)){
        if (! all(NA_valuesList[[i]] == NA_valuesList[[1]])){
          stop("NA replacement values must be consistent across associated variables")
        }
      }
    }
  }
  
  # Setup encoding for all explanatory vars
  encodings <- rep(defaultEncoding, length(exVars))
  names(encodings) <- exVars
  
  # Find the ordered factors and set to numeric encoding
  if (orderedAsNum){
    # Find ordered factors
    orderedFacs <- sapply(
      exVars,
      function(x){
        is.ordered(dt_Data[[x]])
      }
    )
    # Set to numeric
    encodings[which(orderedFacs)] <- "numeric"
  }
  
  # Validate encodingExceptions
  if (! is.null(encodingExceptions)){
    
    if (is.null(names(encodingExceptions))){
      stop("encodingExceptions must be named")
    }
    if (anyDuplicated(names(encodingExceptions))){
      stop("encodingExceptions names must be unique")
    }
    # Encoding exceptions is a list
    if (is.list(encodingExceptions)){
      if (
        all(
          sapply(
            encodingExceptions,
            function(x){
              if (length(x) == 1){
                validateEncoder(x)
              } else FALSE
            }
          )
        ) &
        all(names(encodingExceptions) %in% names(encodings))
      ){
        # encodingExceptions is in the format we want which is a
        # named list where the names are factors from the data and
        # each list entry is an encoder
      } else if (all(sapply(encodingExceptions, is.character))){
        if (
          all(sapply(names(encodingExceptions), validateEncoder)) &
          all(sapply(
            encodingExceptions,
            function(x) all(x %in% names(encodings))
          ))){
          # encodingExceptions is a named list where names are encoders
          # and the entries are character vectors of column names
          encodingExceptions <- as.list(namedList2Vec(encodingExceptions))
        } else{
          stop("Format of encodingExceptions not recognised.")
        }
        # encodingExceptions is not a list
      } else{
        stop("Format of encodingExceptions not recognised.")
      }
    } else if (!is.character(encodingExceptions)){
      stop("Format of encodingExceptions not recognised.")
      # encodingExceptions is a character
    } else if (
      all(sapply(encodingExceptions, validateEncoder)) &
      all(names(encodingExceptions) %in% names(encodings))
    ){
      encodingExceptions <- as.list(encodingExceptions)
    } else{
      stop("Format of encodingExceptions not recognised.")
    }
    
    # Update encodings with exceptions
    encodings[match(names(encodingExceptions), names(encodings))] <- encodingExceptions
  }
  
  # Use of custom encodings
  customEncodings <- any(sapply(encodings, is.function))
  if (customEncodings){
    if (is.null(trainMode)){
      stop("When using custom encodings, trainMode must be explicitly specified.")
    }
    if (is.logical(trainMode)){
      trainMode <- as.list(trainMode)
    }
    if (! is.list(trainMode)){
      stop("trainMode must be logical or a list of logicals")
    }
    if (! all(sapply(trainMode, is.logical))){
      stop("trainMode must be logical or a list of logicals")
    }
    if (! all(sapply(trainMode, function(x) length(x) == 1))){
      stop("trainMode must be logical or a list of logicals of length 1")
    }
    if (length(trainMode) != nXgbMats){
      stop("trainMode must be explicitly set for each of the return matrices")
    }
    if (! is.null(names(trainMode))){
      if (! setequal(names(trainMode), names(rowIndicesList))){
        stop("Names of trainMode are inconsistent with names of rowIndicesList")
      }
      trainMode <- lapply(
        names(rowIndicesList),
        function(x){
          trainMode[[x]]
        }
      )
    }
    names(trainMode) <- names(rowIndicesList)
  } else{
    trainMode <- lapply(rowIndicesList, function(x) FALSE)
  }
  
  # Create NA_exceptionsList
  encodingsList <- lapply(
    explanatory_vars,
    function(x){
      encodings[match(x, names(encodings))]
    }
  )
  
  # Check encodings are consistent across associated variables
  if (! is.null(encodingExceptions)){
    if (nXgbMats > 1){
      for (i in seq(2, nXgbMats)){
        if (! all(identical(encodingsList[[i]], encodingsList[[1]]))){
          stop("Encodings must be consistent across associated variables")
        }
      }
    }
  }
  
  # Drop encodings for non-factors
  facVars <- names(which(sapply(
    exVars,
    function(x) is.factor(dt_Data[[x]])
  )))
  
  encodingsList <- lapply(
    encodingsList,
    function(x){
      x[which(names(x) %in% facVars)]
    }
  )
  
  # response
  if (! is.null(response)){
      # Check response is numeric or logical
    if (is.logical(dt_Data[[response]])){
      set(dt_Data, j=response, value=as.integer(dt_Data[[response]]))
    } else if (! is.numeric(dt_Data[[response]])){
      stop("response is not numeric")
    }
    # Check response for NAs
    if (anyNA(dt_Data[[response]])){
      useResponse <- sapply(
        rowIndicesList,
        function(x){
          ! anyNA(dt_Data[x][[response]])
        }
      )
      if (! any(useResponse)){
        stop("response column contains NAs")
      }
      for (i in which(!useResponse)){
        cat(paste0("Response contains NAs for matrix ", i, " and will not be used.\n"))
      }
    } else{
      useResponse <- rep(TRUE, nXgbMats)
    }
    # Check response is finite
    if (any(is.infinite(dt_Data[[response]]))){
      stop("response contains infinite values")
    }
  } else{
    useResponse <- rep(FALSE, nXgbMats)
  }
  
  # base margin
  if (is.null(offset_model)){
    useBaseMargin <- FALSE
  } else {
    useBaseMargin <- TRUE
    if (! is.numeric(dt_Data[[offset_model]])){
      stop("offset_model must be numeric")
    }
    if (anyNA(dt_Data[[offset_model]])){
      stop("offset_model contains NAs")
    }
    if (any(is.infinite(dt_Data[[offset_model]]))){
      stop("offset_model contains non finite values")
    }
    base_margin <- link(dt_Data[[offset_model]]) # must apply link function to offset model
    if (anyNA(base_margin) | any(is.infinite(base_margin))){
      stop("offset_model contains values that are incompatible with the choice of link function.")
    }
  }
  
  # weight
  if (is.null(exposure)){
    if (is.null(sampleWeight)){
      useWeight <- FALSE
    } else {
      useWeight <- TRUE
      if (is.logical(dt_Data[[sampleWeight]])){
        set(dt_Data, j=sampleWeight, value=as.integer(dt_Data[[sampleWeight]]))
      } else if (! is.numeric(dt_Data[[sampleWeight]])){
        stop("sampleWeight must be numeric")
      }
      if (any(is.infinite(dt_Data[[sampleWeight]]))){
        stop("sampleWeight contains non-finite values")
      }
      if (anyNA(dt_Data[[sampleWeight]])){
        warning("sampleWeight has NA values which have been replaced with zeros.")
        set(dt_Data, i=which(is.na(dt_Data[[sampleWeight]])), j=sampleWeight, value=0)
      }
      weight <- dt_Data[[sampleWeight]]
    }
  } else{
    
    # Validate exposure column
    if (! is.numeric(dt_Data[[exposure]])){
      stop("exposure must be numeric")
    }
    if (anyNA(dt_Data[[exposure]])){
      stop("exposure column contains NAs")
    }
    if (any(dt_Data[[exposure]]<0)){
      stop("exposure column contains negative values")
    }
    if (any(is.infinite(dt_Data[[exposure]]<0))){
      stop("exposure column contains non-finite values")
    }
    if (any(dt_Data[[exposure]]==0)){
      zeroExposureFlag <- TRUE
    } else {
      zeroExposureFlag <- FALSE
    } 
    
    # Adjust target by exposure
    if (!is.null(response)){
      set(dt_Data, j=response, value=dt_Data[[response]]/dt_Data[[exposure]])
      if (zeroExposureFlag){
        # Zeros allowed in exposure column, except where response is greater than zero
        if (any(!is.finite(dt_Data[[response]]))){
          stop("Row with zero exposure and non-zero response detected.")
        }
        set(dt_Data, i=which(is.na(dt_Data[[response]])), j=response, value=0)
      }
    }
    useWeight <- TRUE
    if (is.null(sampleWeight)){
      weight <- dt_Data[[exposure]]
    } else{
      if (is.logical(dt_Data[[sampleWeight]])){
        set(dt_Data, j=sampleWeight, value=as.integer(dt_Data[[sampleWeight]]))
      } else if (! is.numeric(dt_Data[[sampleWeight]])){
        stop("sampleWeight must be numeric")
      }
      if (any(is.infinite(dt_Data[[sampleWeight]]))){
        stop("sampleWeight contains non-finite values")
      }
      if (anyNA(dt_Data[[sampleWeight]])){
        warning("sampleWeight has NA values which have been replaced with zeros.")
        set(dt_Data, i=which(is.na(dt_Data[[sampleWeight]])), j=sampleWeight, value=0)
      }
      weight <- dt_Data[[sampleWeight]]*dt_Data[[exposure]]
    }
  }
  
  # Use factorEncoder for each output matrix to create the data
  matrixList <- lapply(
    seq(1, nXgbMats),
    function(i){
      mat <- factorEncoder(
        dt_Data[
          rowIndicesList[[i]],
          explanatory_vars[[i]],
          with = FALSE
        ],
        defaultEncoding       =  "numeric",
        encodingExceptions    =  encodingsList[[i]],
        NA_treatment          =  "pass",
        NA_exceptions         =  NA_exceptionsList[[i]],
        NA_default            =  0,
        NA_defaultExceptions  =  NA_valuesList[[i]],
        sparse                =  sparse,
        addAttributes         =  TRUE,
        trainMode             =  trainMode[[i]]
      )
    }
  )
  
  
  ### Filter columns ###
  if (length(filterCols) > 0){
    
    # Find columns to drop
    colsToDrop <- unique(
      unlist(
        lapply(
          matrixList,
          function(x){
            which(colnames(x) %in% filterCols)
          }
        )
      )
    )
    
    # Columns that didn't exist
    colsForWarning <- setdiff(
      filterCols,
      unique(
        unlist(
          lapply(
            matrixList,
            function(x){
              colnames(x)[colsToDrop]
            }
          )
        )
      ) 
    )
    if (length(colsForWarning) > 0){
      warning(
        paste0(
          "The following feature names were included in filterCols but don't exist: ",
          paste0(colsForWarning, collapse = ", ")
        )
      )
    }

    # Drop columns
    if (length(colsToDrop) > 0){
      matrixList <- lapply(
        matrixList,
        function(x){
          y <- x[, -colsToDrop, drop = FALSE]
          if ("facEncodingTbls" %in% names(attributes(x)))
            for (nm2 in names(attr(x, "facEncodingTbls"))) {
              attr(y, "facEncodingTbls")[[nm2]] <- suppressWarnings(
                attr(x, "facEncodingTbls")[[nm2]][, -filterCols, with = FALSE])
            }
          attr(y, "NAActions") <- attr(x, "NAActions")
          attr(y, "factorLevels") <- attr(x, "factorLevels")
          return(y)
        }
      )
    }
  }

  ### Now Start building the list of xgbDMatrices ### 
  # For each return matrix create the xgb.DMatrix object
  returnList <- lapply(seq(1, nXgbMats), function(i){
    if (justMatrices) return(matrixList[[i]])
    xgbMat <- xgb.DMatrix(data = matrixList[[i]])
    # factorLevels
    attr(xgbMat, "factorLevels") <- attributes(matrixList[[i]])$factorLevels
    # facEncodingTbls
    attr(xgbMat, "facEncodingTbls") <- attributes(matrixList[[i]])$facEncodingTbls
    # NAActions
    attr(xgbMat, "NAActions") <- attributes(matrixList[[i]])$NAActions
    return(xgbMat)
  })

  # Add the label if we are using one
  if (!is.null(response)){
    for (i in seq(1, nXgbMats)){
      if (!(justMatrices)){
        if (useResponse[i]){
          setinfo(
            returnList[[i]],
            "label",
            dt_Data[[response]][rowIndicesList[[i]]]
          )
        }
      }
    }
  }
  
  # Add the weight if we are using one
  if (useWeight){
    for (i in seq(1, nXgbMats)){
      if (!(justMatrices)){
        setinfo(
          returnList[[i]],
          "weight",
          weight[rowIndicesList[[i]]]
        )
      }
    }
  }
  
  # Add the base margin if we are using one
  if (useBaseMargin){
    for (i in seq(1, nXgbMats)){
      if (!(justMatrices)){
        setinfo(
          returnList[[i]],
          "base_margin",
          base_margin[rowIndicesList[[i]]]
        )
      }
    }
    
    # Add a note in the console recommending the use of base_score
    cat("Note that base_margin is being used.\n")
    if (link(0.5) != 0){
      cat("When training we recommend explicitly setting the 'base_score' parameter ")
      if (link(1) == 0){
        cat("to 1.\n")
      } else if (link(0) == 0){
        cat("to 0.\n")
      } else cat("to an appropriate value.\nThis should be the value that maps to zero when applying the link function.\n")
    }
  }
  
  # Use names from input list
  names(returnList) <- names(rowIndicesList)
  
  # Return output
  return(returnList)
}


#####################################################
# xgbSetupdata2_colnames
#####################################################

#' Quickly get the column names from the one of the output matrices of a call to xgbSetupdata2
#' 
#' @description xgbSetupdata2_colnames returns the column names from an output matrix from a call to xgbSetupdata2
#' without having to actually process the data.
#' @usage xgbSetupdata2_colnames(
#'  dt_Data,
#'  exVars              =  NULL,
#'  defaultEncoding     =  "oneHot",
#'  encodingExceptions  =  NULL,
#'  NA_treatment        =  "fix",
#'  NA_exceptions       =  NULL,
#'  orderedAsNum        =  TRUE,
#'  filterCols          =  character(0)
#')
#' @param dt_Data The input data frame or data table.
#' @param exVars character vector of explanatory features for the call to \code{xgbSetupdata2}.
#' Must be a subset of column names of the input data.
#' @param defaultEncoding The default encoder to apply to unordered factor columns.
#' Must be one of: oneHot (default), numeric, binary, circular or ordered.
#' Ordered factors will be numeric encoded unless there are encoding exceptions set, or \code{orderedAsNum} is FALSE.
#' \describe{
#'   \item{oneHot}{Each level of the factor will have its own column containing 1 or 0 depending on the value for that row.}
#'   \item{numeric}{The function \code{as.integer} is simply applied to the factor.}
#'   \item{binary}{This first encodes the factor as an integer (again uses \code{as.integer} and subtracts 1 so levels start at 0.) 
#'   Then the integer is converted to binary.
#'   The binary numbers are then split into columns, so the first column represents 2^0, then 2^1, etc.}
#'   \item{ordered}{The factor is assumed in the same order as the \code{as.integer} function would put it in.
#'   A binary column is encoded for each possible split-point. This will result in n-1 columns for an n-level factor.
#'   I.E. the columns of a resulting matrix will be: as.integer(x) < 2; as.integer(x) < 3; ... ; as.integer(x) < n}
#'   \item{circular}{The factor is encoded into two columns in a "clock-face" pattern that assumes the factor levels
#'   represent things that are ordered and repeat, like days of the week or months in the year.}
#' }
#' @param encodingExceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are factor columns in the data
#' table and the values are all valid encoders (currently: oneHot, numeric, binary),
#' OR a named list where each name is a valid encoder
#' and each element is a character vector of factor columns in the data. 
#' The function will apply the specified encoder to the factors named here and the default encoder to all other factors.
#' It is also possible to apply your own custom encoder using a function. To do this, \code{encodingExceptions}
#' should be a named list where each name is a factor and each entry is either a character name of a valid encoder as above
#' OR a custom function.
#' These functions must have three arguments: \code{x}, the factor vector to encode;
#' @param NA_treatment One of "fix" (default), "drop", "fail". What to do with missing values (NAs.)
#' \describe{
#'   \item{fix}{The function will replace any NAs and how it does so will depend on the arguments
#'   \code{NA_exceptions}, \code{NA_default} and \code{NA_defaultExceptions}.}
#'   \item{drop}{The function will drop any rows containing NAs}
#'   \item{fail}{Any NAs will trigger an error message. useful as a catch if you are expecting no NAs.}
#' }
#' @param NA_exceptions Optional argument. If specified it must contain EITHER a named character vector
#' where the names are of explanatory variables in the data and the values the NA_treatment to apply
#' OR a named list where each name is an NA_treatment and the list elements are character vectors with the names of explanatory variables.
#' @param orderedAsNum if TRUE (default) ordered factors will be encoded numerically unless any encoding exceptions have been set.
#' Otherwise, if FALSE, ordered factors are treated the same as unordered factors.
#' @param filterCols character vector of feature names to drop - for example if you have a factor column
#' called "FuelType" with three levels: "Petrol", "Diesel", "Hybrid" and "Electric", if using one-hot encoding
#' the function will create the features: "FuelType-is-Petrol", "FuelType-is-Diesel", "FuelType-is-Hybrid" and "FuelType-is-Electric".
#' If you only want the first three of these, you can set \code{filterCols} to \code{"FuelType-is-Electric"}. The feature
#' will then not be included in the output.
#' @return a character vector
#' @note If using one-hot encoding, sparse encoding is the default. This was historically recommended for memory usage reasons.
#' However, if you wish to build a model to be extracted to another format,
#' we would recommend dense encoding due to the way \code{xgboost} treats zeroes. 
#' @importFrom xgboost xgb.DMatrix
#' @importFrom Matrix sparse.model.matrix
#' @importFrom data.table data.table
#' @examples 
#' # library(rsai)
#' # # Setup dummy data
#' # n <- 1000
#' # dt_Data <- data.table(
#' #   x1        =  rnorm(n),
#' #   x2        =  sample(letters, n, TRUE),
#' #   x3        =  rnorm(n),
#' #   u         =  exp(rnorm(n)),
#' #   exposure  =  runif(n)
#' # )
#' # dt_Data[, target := rpois(n, exposure * u * exp(0.1 * x1 + 0.2 * (x2 %in% letters[1:10]) - 0.1 * x3))]
#' # dt_Data[, x2 := factor(x2)]
#' # 
#' # # xgbSetupdata2_colnames
#' # (
#' #   expectedColNames <- xgbSetupdata2_colnames(
#' #     dt_Data,
#' #     exVars              =  c("x1", "x2", "x3"),
#' #     defaultEncoding     =  "oneHot",
#' #     NA_treatment        =  "fix"
#' #   )
#' # )
#' # 
#' # # Create the list of xgbDMatrices
#' # xgbDList <- xgbSetupdata2_col(
#' #   dt_Data,
#' #   response          =  "target",
#' #   explanatory_vars  =  c("x1", "x2", "x3"),
#' #   NA_treatment      =  "fix",
#' #   NA_default        =  1e10,
#' #   exposure          =  "exposure",
#' #   offset_model      =  "u",
#' #   link              =  log,
#' #   defaultEncoding   =  "oneHot"
#' # )
#' # 
#' # # check names match
#' # identical(
#' #   expectedColNames,
#' #   colnames(xgbDList[[1]])
#' # )
#' @export
#' @author Edwin Graham


xgbSetupdata2_colnames <- function(
  dt_Data,
  exVars              =  NULL,
  defaultEncoding     =  "oneHot",
  encodingExceptions  =  NULL,
  NA_treatment        =  "fix",
  NA_exceptions       =  NULL,
  orderedAsNum        =  TRUE,
  filterCols          =  character(0)
){
  
  #####################
  
  # Check input data is a data table
  if (!("data.table" %in% class(dt_Data))){
    if (!("data.frame" %in% class(dt_Data))){
      stop("dt_Data must be a data.frame")
    } else {
      dt_Data <- data.table(dt_Data) # convert data frame to data table
    }
  }
  
  # Drop all rows - we don't need them!
  dt_Data <- dt_Data[0]
  
  # Check exVars
  if (is.null(exVars)){
    exVars <- names(dt_Data)
  }
  if (! is.character(exVars)) stop("exVars must be a character vector")
  if (! all(exVars %in% names(dt_Data))){
    stop("exVars should be columns of dt_Data")
  }
  
  # Setup NA_treatments before applying exceptions
  if (! (is.character(NA_treatment) & length(NA_treatment) == 1)){
    stop("NA_treatments should be a character of length 1")
  }
  NA_treatments <- rep(NA_treatment, length(exVars))
  names(NA_treatments) <- exVars
  
  # Validate NA_exceptions
  if (! is.null(NA_exceptions)){
    if (is.list(NA_exceptions)){
      NA_exceptions <- namedList2Vec(NA_exceptions)
    } else if (is.character(NA_exceptions)){
      if (is.null(names(NA_exceptions))){
        stop("If NA_exceptions is a character vector it must be a named")
      }
      if (anyDuplicated(names(NA_exceptions))){
        stop("NA_exceptions must have unique names")
      }
    } else{
      stop("NA_exceptions must be either a list or a character vector")
    }
    # Check NA_exceptions has valid variable names
    if (length(setdiff(names(NA_exceptions), names(NA_treatments))) > 0){
      stop("NA_exceptions refers to variables that are not specified in explanatory_vars")
    }
    # Update NA_treatments with exceptions
    NA_treatments[match(names(NA_exceptions), names(NA_treatments))] <- NA_exceptions
  }
  
  # Setup encoding for all explanatory vars
  encodings <- rep(defaultEncoding, length(exVars))
  names(encodings) <- exVars
  
  # Find the ordered factors and set to numeric encoding
  if (orderedAsNum){
    # Find ordered factors
    orderedFacs <- sapply(
      exVars,
      function(x){
        is.ordered(dt_Data[[x]])
      }
    )
    # Set to numeric
    encodings[which(orderedFacs)] <- "numeric"
  }
  
  # Validate encodingExceptions
  if (! is.null(encodingExceptions)){
    
    if (is.null(names(encodingExceptions))){
      stop("encodingExceptions must be named")
    }
    if (anyDuplicated(names(encodingExceptions))){
      stop("encodingExceptions names must be unique")
    }
    # Encoding exceptions is a list
    if (is.list(encodingExceptions)){
      if (
        all(
          sapply(
            encodingExceptions,
            function(x){
              if (length(x) == 1){
                validateEncoder(x)
              } else FALSE
            }
          )
        ) &
        all(names(encodingExceptions) %in% names(encodings))
      ){
        # encodingExceptions is in the format we want which is a
        # named list where the names are factors from the data and
        # each list entry is an encoder
      } else if (all(sapply(encodingExceptions, is.character))){
        if (
          all(sapply(names(encodingExceptions), validateEncoder)) &
          all(sapply(
            encodingExceptions,
            function(x) all(x %in% names(encodings))
          ))){
          # encodingExceptions is a named list where names are encoders
          # and the entries are character vectors of column names
          encodingExceptions <- as.list(namedList2Vec(encodingExceptions))
        } else{
          stop("Format of encodingExceptions not recognised.")
        }
        # encodingExceptions is not a list
      } else{
        stop("Format of encodingExceptions not recognised.")
      }
    } else if (!is.character(encodingExceptions)){
      stop("Format of encodingExceptions not recognised.")
      # encodingExceptions is a character
    } else if (
      all(sapply(encodingExceptions, validateEncoder)) &
      all(names(encodingExceptions) %in% names(encodings))
    ){
      encodingExceptions <- as.list(encodingExceptions)
    } else{
      stop("Format of encodingExceptions not recognised.")
    }
    
    # Update encodings with exceptions
    encodings[match(names(encodingExceptions), names(encodings))] <- encodingExceptions
  }
  
  # Use of custom encodings
  customEncodings <- any(sapply(encodings, is.function))
  
  # Get the column names
  colNameList <- lapply(
    exVars,
    function(x){
      if ("Date" %in% class(dt_Data[[x]])){
        return(paste0(x, "~Date"))
      } else if ("POSIXct" %in% class(dt_Data[[x]])){
        return(paste0(x, "~POSIXct"))
      } else if (is.logical(dt_Data[[x]])){
        return(paste0(x, "~logical"))
      } else if (! is.factor(dt_Data[[x]])){
        return(x)
      } else if (is.character(encodings[[x]])){
        if (encodings[[x]] == "oneHot"){
          if (NA_treatments[[x]] == "fix"){
            set(dt_Data, j = x, value = addNA(dt_Data[[x]]))
          }
          return(paste0(x, "~is~", levels(dt_Data[[x]])))
        } else if (encodings[[x]] == "numeric"){
          return(paste0(x, "~numeric"))
        } else if (encodings[[x]] == "ordered"){
          if (NA_treatments[[x]] == "fix"){
            set(dt_Data, j = x, value = addNA(dt_Data[[x]]))
          }
          return(paste0(x, "~ordered~", seq(2, length(levels(dt_Data[[x]])))))
        } else if (encodings[[x]] == "binary"){
          if (NA_treatments[[x]] == "fix"){
            set(dt_Data, j = x, value = addNA(dt_Data[[x]]))
          }
          return(paste0(x, "~binary~", seq(0, ceiling(log(length(levels(dt_Data[[x]])))/log(2)) - 1)))
        } else if (encodings[[x]] == "circular"){
          return(paste0(x, "~circular", length(levels(dt_Data[[x]])), "~", c("sin", "cos")))
        }
      } else{
        if (NA_treatments[[x]] == "fix"){
          set(dt_Data, j = x, value = addNA(dt_Data[[x]]))
        }
        return(colnames(encodings[[x]](dt_Data[[x]])))
      }
    }
  )
  
  # Filter out columns to be filtered
  colNameList <- lapply(
    colNameList,
    function(x) setdiff(x, filterCols)
  )
  
  # Set names of list elements to corresponding feature columns
  names(colNameList) <- exVars
  
  # Create list of the same structure just with names of corresponding feature columns
  nameList <- lapply(
    exVars,
    function(x) rep(x, length(colNameList[[x]]))
  )
  
  # Create the final character vector to return
  # Vector contains the names of the design matrix columns
  rtnChar <- unlist(colNameList)
  # The names of the vector are the corresponding original feature columns
  names(rtnChar) <- unlist(nameList)
  
  # Return
  return(rtnChar)
}
