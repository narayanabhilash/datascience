#####  weighted.median  #####
#' Function to calculate weighted median.
#' @description This function calculates a median for weighted data.
#' @usage weighted.median(x, w, na.rm=FALSE)
#' @param x an object containing the values whose weighted median is to be computed.
#' @param w a numerical vector of weights the same length as x giving the weights to use for elements of x. Negative or zero weighted values are ignored.
#' @param na.rm a logical value indicating whether NA values in x should be stripped before the computation proceeds. Note than an NA value in w will cause the function to return NA regardless of this parameter.
#' @return a length-one numeric vector.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # weighted.median(rnorm(100), runif(100))
#' @export

weighted.median <- function(x, w, na.rm=FALSE){
  n <- length(x)
  if (length(w) != n) stop("x and w are not the same length")
  
  if (anyNA(x)){
    if (na.rm){
      m <- which(is.na(x))
      x <- x[-m]
      w <- w[-m]
      n <- n - length(m)
    } else return(NA_real_)
  } 

  if (anyNA(w)) return(NA_real_)
  
  o <- order(x)
  x <- x[o]
  w <- pmax(w, 0)[o]
  
  b <- cumsum(w)/sum(w)
  
  return(mean(x[which(b>=0.5 & c(0, b[-n])<=0.5)]))
}


