
#' Function for comparing model fit

#' @description Reads in model predictions and outcomes and returns goodness-of-fit metrics consistent
#' with those calculated in the xgb.cv and xgb.train routines in the \code{xgboost} package. 
#' This allows comparison of models to be readily made on "public" test data consistent with holdout data. 
#'
#' @usage modelMetric(obs,
#'             pred,
#'             exposure = NULL,
#'             weights = NULL,
#'             calibrate = FALSE,
#'             measure = "poisson",
#'             tweedie = 1.5,
#'             cutoff = 0.5)
#' @param obs A vector of observed outcomes (E.G. total claim cost or claim count)
#' @param pred A vector of predictions for (obs / exposure).
#' For example, for a frequency model this will be predicted annual claims frequency.
#' For claims severity this will be predicted average claim cost.
#' For burning cost this will be predicted annual burning cost.
#' @param exposure Vector of exposures eg length of at-risk period for frequency model/burning cost model
#' or number of claims for a severity model. 
#' @param weights Vector of weights \emph{over and above exposure.} For example, downsampling weight if using downsampling.
#' @param calibrate If true, \code{pred} is adjusted by a uniform proportion or constant as appropriate to coincide with obs.
#' In other words the predictions are rebased (by re-fitting the intercept) to better fit the observed values.
#' This is useful if you are testing a model by measuring goodness of fit against a different time period or have built a model using a capped
#' or modified response variable. For complete consistency with xgb.train, calibrate would be set equal to \code{FALSE}.
#' Use \code{calibrate=TRUE} to compare models in cases where you care more about differentiating risk well than
#' getting the base level exactly right.
#' @param measure Metric to return. Can be "poisson", "gamma", "tweedie", "binary-logistic", "RMSE", "MAE", "AUC" or "error".
#' Negative log-liklihood for poisson, gamma, tweedie and binary-logistic. error returns classification error.
#' Log-liklihood for gamma and tweedie is calculated assuming psi (shape parameter) = 1.
#' @param tweedie Dispersion parameter if \code{measure} = "tweedie"
#' @param cutoff Only used if \code{measure} = "error". Cutoff for positive v negative examples. Should be between 0 and 1.
#' @return Numeric value for goodness of fit. 
#' @export

modelMetric <-
  function(obs,
           pred,
           exposure = NULL,
           weights = NULL,
           calibrate = FALSE,
           measure = "poisson",
           tweedie = 1.5,
           cutoff = 0.5){
    
    # Check weights
    if(!is.null(weights)) if(length(weights) != length(obs)) stop("weights are the wrong length")
    
    # Check preds
    if(length(obs) != length(pred)) stop("pred is the wrong length")
    
    # poisson
    # gamma
    # tweedie
    # binary-logistic
    # RMSE
    # MAE
    # AUC
    # error
    
    ########### POISSON SECTION  ########### 
    if(measure == "poisson"){
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate){
        pred <- rebasePreds(obs, pred, family="Poisson", w=weights)
      }
      
      # Evaluation metric
      metric <- "poisson-nloglik"
      
      
      ########### GAMMA SECTION   ###########   
    } else if(measure == "gamma"){
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate){
        pred <- rebasePreds(obs, pred, family="Gamma", w=weights)
      }
      
      # Evaluation metric
      metric <- "gamma-nloglik"
      
      
      ########### TWEEDIE SECTION  ########### 
    } else if(measure == "tweedie"){
      
      # Check tweedie power parameter
      if(tweedie<=1 | tweedie>=2) stop("tweedie should be between 1 and 2")
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate){
        pred <- rebasePreds(obs, pred, family="Tweedie", w=weights, p=tweedie)
      }
      
      # Evaluation metric
      metric <- "tweedie-nloglik"
      
      
      ########### BINARY SECTION   ###########  
    } else if(measure == "binary-logistic"){
      
      # Exposure
      if(!is.null(exposure)) warning(paste0("Exposures ignored for ", measure, "."))
      
      # Rebase predictions
      if(calibrate){
        pred <- rebasePreds(obs, pred, family="Bernoulli", w=weights)
      }
      
      # Evaluation metric
      metric <- "logloss"
      
      
      ########### RMSE SECTION     ########### 
    } else if(measure == "RMSE"){
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate){
        pred <- rebasePreds(obs, pred, family="Normal", w=weights)
      }
      
      # Evaluation metric
      metric <- "rmse"
      
      
      ########### MAE SECTION      ###########  
    } else if(measure == "MAE"){
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate){
        if(is.null(weights)){
          diff <- median(pred-obs)
        } else{
          diff <- weighted.median(pred-obs, weights)
        }
        pred <- pred-diff
      }
      
      # Evaluation metric
      metric <- "mae"
      
      
      ########### AUC SECTION      ###########  
    } else if(measure == "AUC"){
      
      # Adjust for exposure
      if(!is.null(exposure)){
        # Check length
        if(length(exposure) != length(obs)) stop("exposures are the wrong length")
        # Adjust observations
        obs <- obs / exposure
        # Adjust weight
        if(!is.null(weights)) weights <- weights * exposure else weights <- exposure
      }
      
      # Rebase predictions
      if(calibrate) warning(paste0("No calibration performed for ", measure, "."))
      
      # Evaluation metric
      metric <- "auc"
      
      
      ########### ERROR SECTION    ########### 
    } else if(measure == "error"){
      
      # Exposure
      if(!is.null(exposure)) warning(paste0("Exposures ignored for ", measure, "."))
      
      # Rebase predictions
      if(calibrate) warning(paste0("No calibration performed for ", measure, "."))
      
      # Evaluation metric
      metric <- paste0("error@", cutoff)
      
      
    } else stop("measure should be one of: poisson, gamma, tweedie, binary-logistic, RMSE, MAE, AUC, error.")
    
    
    # Calculate evaluation metric
    value <- evalMetric(obs, pred, metric, w=weights, p=tweedie)
    
    # Output model metric
    return(value)

  }
