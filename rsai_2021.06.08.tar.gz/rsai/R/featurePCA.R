##### featurePCA #####
#' Function to create new features using PCA
#' @description This function takes numeric column data and creates a data table of new principal component features 
#' along with summary analytical output.
#' @usage featurePCA(data,features,theme=NULL,dist=NULL,center=TRUE,scale = TRUE)
#' @param data  a data table of original data
#' @param features a list of columns to be used as inputs to the PCA - these must be free of missing values
#' @param theme a label to prefix the theme of the new principal component features e.g. theftHazard
#' @param dist a label to suffix the geographical resolution of the column input data  e.g. postcode or 5km
#' @param center set to TRUE to apply centering
#' @param scale set to TRUE to apply scaling
#' @return  A list of objects including a data table of scores and loadings of the new features as well as plot objects
#' @author Russell Green (russell.green@uk.rsagroup.com)
#' @export
#' @examples
#' data("UKTheftFreq")
#' featurePCA(UKTheftFreq,
#' features = c ("Rented_from_Council", "Social_Grade_DE", "HPIINDEX"),
#' theme = "theftHazard",
#' dist = "postcode",
#' center = TRUE,
#' scale = TRUE)
#'

featurePCA <- function(
  data,  # original dataset
  features,  # features to be pca'd
  theme = NULL, 
  dist = NULL,
  center = TRUE,
  scale = TRUE ) { 
  
  ###############################################################
  # Validation checks
  if(!is.data.table(data)) stop("data must be a data table")
  if(length(features) <=2) stop("Character vector of features should have a minimum of 3 columns")
  if(anyDuplicated(features)) stop("Columns duplicated.")
 
  if( is.null(theme)) { 
    theme <- paste0(deparse(substitute(data)))
    message('The "theme" to prefix the new features was set by default to the data table name [', theme, '] 
             You can specify "theme" in the function call \n')
    } else { }
  
  if( is.null(dist)) { 
    dist <- "z"
    message('The "dist" to suffix the new features was set by default to unknown distance [.z] 
             You can specify "dist" in the function call \n\n')
   } else { }
  
 

  
  # apply PCA using prcomp ( from stats package)
  
  temp_PCA <- prcomp(data[,features, with = FALSE], center = center, scale. = scale) 
  
  # bind new PCA features to raw data key
  temp_newPCAFeatures <-  as.data.table (temp_PCA$x)
  temp_newPCAFeatures [, rowNo:=.I]
  
  # make PCA featurenames informative
  setnames(x = temp_newPCAFeatures, 
           old = names(temp_newPCAFeatures)[1:length(features)],
           new = paste0( theme, "_", names(temp_newPCAFeatures)[1:length(features)], ".", dist)) 
  
  # summary indicating the proportion of variance explained
  pr_var <- temp_PCA$sdev ^ 2
  prop_varex <- pr_var / sum(pr_var)
  
  plt_var <-
    plot_ly(data = data.table( x =1:length(features) , y = prop_varex[1:length(features)]),
            x = ~x, y = ~y ,
            type = 'bar') %>%
    layout(title = "Plot of variance explained for each component" ,
           xaxis = list(title = paste0("Principal Components for ", theme),
                        showline=TRUE,
                        mirror = TRUE),
           yaxis = list(title = "Variance explained",
                        tickformat = "%",
                        showline=TRUE,
                        mirror = TRUE))
  
  plt_varSum <-
    plot_ly(data = data.table( x =1:length(features) , y = cumsum(prop_varex[1:length(features)])),
            x = ~x, y = ~y ,
            type = 'scatter',
            mode = 'lines+markers') %>%
    layout(title = "Plot of cumulative variance explained" ,
           xaxis = list(title = paste0("Principal Components for ", theme),
                        showline=TRUE,
                        mirror = TRUE),
           yaxis = list(title = "cumulative variance",
                        tickformat = "%",
                        showline=TRUE,
                        mirror = TRUE))
  
  # binding all the scores together
  return(list(newFeatures = temp_newPCAFeatures,
              pcLoadings = temp_PCA$rotation,
              PCA = temp_PCA,
              plt_var = plt_var,
              plt_varSum = plt_varSum,
              dist = dist,
              theme = theme
              ))
  
 
  
}
