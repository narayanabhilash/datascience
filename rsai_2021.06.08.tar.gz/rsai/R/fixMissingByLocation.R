#####  fixMissingByLocation  #####
#' Function to fix missing values in a data set by location.
#' @description Function to fix missing values in a data set with location coordinates by selecting the nearest non-missing value from the the rest of the data.
#' The function converts the location data to UTM to calculate distance.
#' @usage fixMissingByLocation(
#' data,
#' x_coord,
#' y_coord,
#' colsToFix,
#' rowsToFix = NULL,
#' rowsForFix = NULL,
#' Transform = TRUE,
#' CRS_in = "+init=EPSG:4326",
#' UTMZone = 30)
#' @param data A data frame or data table.
#' @param x_coord The column in the data representing East/West location. By default the function assumes this will be Longitude.
#' @param y_coord The column in the data representing North/South location. By default the function assumes this will be Latitide.
#' @param colsToFix The name of any columns with missing data to be fixed.
#' @param rowsToFix Optional. If left missing then the function will attempt to fix any row with a missing value for each of the columns to fix.
#' If you wish to only fix a subset, then you can specify those rows as an integer vector here.
#' @param rowsForFix Optional. If left missing the function will use any row with a non-missing value to impute the rows with missing values.
#' If only a subset of the data is trustworth enough to be used for missing data imputation, you can specify the rows as an integer vector here.
#' @param Transform Optional. Do you want to transform your x and y coordinate data before imputation?
#' you are only likely to need to do this if your current data is Longitude/ Latitude
#' @param CRS_in Optional. This is a character that can be interpreted as a Coordinate Reference System (E.G. "+init=EPSG:4326" which is the default).
#' This determines how the x_coord and y_coord arguments are interpreted. The default assumes Longitude and Latitude. 
#' @param UTMZone Optional. The UTM Zone number of the location data. Default is 30 which is the UK. Switch to 29 for Ireland or 33 for Sweden.
#' @return A data frame or data table.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export

fixMissingByLocation <- function(
  data,
  x_coord,
  y_coord,
  colsToFix,
  rowsToFix = NULL,
  rowsForFix = NULL,
  Transform = TRUE,
  CRS_in = "+init=EPSG:4326",
  UTMZone = 30) {
  
  ###### Validation ######
  
  # Check data
  if (! is.data.frame(data)){
    stop("data must be a data frame")
  }
  if (! is.data.table(data)){
    df <- TRUE
    data <- data.table(data)
  } else df <- FALSE
  
  # Check x_coord
  if (! is.null(x_coord)){
    if (! is.vector(x_coord)) stop("x_coord must be a character vector")
    if (! is.character(x_coord)) stop("x_coord must be a character vector")
    if (! length(x_coord) == 1) stop("x_coord must be length one")
    if (! x_coord %in% names(data)) stop(paste0(x_coord, " is not a column in the specified data"))
    if (! is.numeric(data[[x_coord]])) stop("x_coord column must be numeric")
  }
  
  # Check y_coord
  if (! is.null(y_coord)){
    if (! is.vector(y_coord)) stop("y_coord must be a character vector")
    if (! is.character(y_coord)) stop("y_coord must be a character vector")
    if (! length(y_coord) == 1) stop("y_coord must be length one")
    if (! y_coord %in% names(data)) stop(paste0(y_coord, " is not a column in the specified data"))
    if (! is.numeric(data[[y_coord]])) stop("y_coord column must be numeric")
  }
  
  # Check colsToFix
  if (! is.vector(colsToFix)) stop("colsToFix must be a character vector")
  if (! is.character(colsToFix)) stop("colsToFix must be a character vector")
  if (length(setdiff(colsToFix, names(data))) > 0){
    stop(paste0("All colsToFix must exist in data (missing: ", paste0(setdiff(colsToFix, names(data)), collapse=", "), ")"))
  }
  
  # Check rowsToFix
  if (! is.null(rowsToFix)){
    if (! is.vector(rowsToFix)) stop("rowsToFix must be an integer vector")
    if (! is.integer(rowsToFix)) stop("rowsToFix must be an integer vector")
    if (length(rowsToFix) == 0){
      cat("Note: No rows to fix. Returning original data set.\n")
      return(data)
    }
    if (min(rowsToFix) < 1L | max(rowsToFix) > nrow(data)) stop("At least one row to fix is out of range")
  }
  
  # Check rowsForFix
  if (! is.null(rowsForFix)){
    if (! is.vector(rowsForFix)) stop("rowsForFix must be an integer vector")
    if (! is.integer(rowsForFix)) stop("rowsForFix must be an integer vector")
    if (length(rowsForFix) == 0){
      cat("Note: No rows for fix. Returning original data set.\n")
      return(data)
    }
    if (min(rowsForFix) < 1L | max(rowsForFix) > nrow(data)) stop("At least one row for fix is out of range")
  }
  
  # Check for duplicated column names
  if (anyDuplicated(c(colsToFix, x_coord, y_coord))) stop("Duplicated column detected in input arguments.")
  
  # Check UTMZone
  if (! is.vector(UTMZone)) stop("UTMZone must be a vector")
  if (length(UTMZone) != 1) stop("UTMZone must be of length one")
  if (! as.character(UTMZone) %in% as.character(1:60)) stop("UTMZone should be from 1 to 60. UK=30. Sweden=32.")
  
  # Check CRS_in
  CRSCheck <- try(CRS(CRS_in, doCheckCRSArgs=TRUE))
  if ("try-error" %in% class(CRSCheck)) stop("CRS_in is not a valid coordinate reference system.")
  
  ###### Validation ######
  
  # Take copy of data in case we accidently alter the input data
  data_ <- copy(data)
  
  # Run through each column in turn
  for (col in colsToFix){ # could speed this up because most cols will be the same...
    
    # Find the rows to fix
    if (is.null(rowsToFix)){
      colRowsToFix <- which(is.na(data[[col]]))
    } else{
      colRowsToFix <- intersect(rowsToFix, which(is.na(data[[col]])))
    }
    
    if (length(colRowsToFix) > 0){
      # Find the rows for fix
      if (is.null(rowsForFix)){
        colRowsForFix <- which(! is.na(data[[col]]))
      } else{
        colRowsForFix <- intersect(rowsForFix, which(! is.na(data[[col]])))
      }
      
      if (length(colRowsForFix) > 0){
        # Table where the column contains missing values
        tblMissing <- data[colRowsToFix, c(x_coord, y_coord, col), with=FALSE]
        # Table where the column contains non-missing values
        tblNonMissing <- data[colRowsForFix, c(x_coord, y_coord, col), with=FALSE]
        
        # Convert tables to spatial points data frame objects
        
        spdfMissing <- SpatialPointsDataFrame(
          coords = tblMissing[, c(x_coord, y_coord), with = FALSE],
          data = tblMissing[, col, with = FALSE],
          proj4string = CRS(CRS_in))
        
        if (Transform){
        spdfMissing <- spTransform(
          spdfMissing,
          CRSobj=CRS(paste0(
            "+proj=utm +zone=", UTMZone, " +north +ellps=WGS84")
            )
          )
        }
        
        spdfNonmissing <- SpatialPointsDataFrame(
          coords = tblNonMissing[, c(x_coord, y_coord), with=FALSE],
          data = tblNonMissing[, col, with = FALSE],
          
          proj4string = CRS(CRS_in))
        if (Transform){
        
            spdfNonmissing <- spTransform(
            spdfNonmissing, 
            CRSobj=CRS(paste0(
              "+proj=utm +zone=", UTMZone, " +north +ellps=WGS84")
            )
          )
        }
        # ppp - point pattern from package spatstat - required to pass into nncross
        ppp_PCD_missing <- suppressWarnings(ppp(
          spdfMissing@coords[, 1], 
          spdfMissing@coords[, 2],
          window = owin(
            c(min(spdfMissing@coords[, 1]), max(spdfMissing@coords[, 1])),
            c(min(spdfMissing@coords[, 2]), max(spdfMissing@coords[, 2])
            ))))
        
        ppp_PCD_nonMissing <- suppressWarnings(ppp(
          spdfNonmissing@coords[, 1],
          spdfNonmissing@coords[, 2],
          window = owin(
            c(min(spdfNonmissing@coords[, 1]), max(spdfNonmissing@coords[, 1])),
            c(min(spdfNonmissing@coords[, 2]), max(spdfNonmissing@coords[, 2])
                                                   ))))
        
        
        # nncross distance to nearest neighbour and ID of that neighbour
        N <- nncross(ppp_PCD_missing, ppp_PCD_nonMissing)
        
        # Where column is missing update column in location data table with value from nearest non-missing neighbour
        set(data_, i=colRowsToFix, j=col, value=tblNonMissing[[col]][N$which])
        
      } else{
        warning(paste0("For ", col, " there are no non-missing rows to use for imputation."))
      }
    }
  }
  
  # Return to data frame only if original data was not a data table
  if (df) data_ <- as.data.frame(data_)
  
  # Return fixed data table
  return(data_)
  
}