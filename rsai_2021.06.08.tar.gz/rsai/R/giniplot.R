
#' Calculate gini coefficients and plot the curves
#' @description  The function is designed to show Gini curves for comparable
#' model predictions on a test data set.
#' @usage giniPlot(
#' dt_test,
#' modelCols,
#' modelNames,
#' Response,
#' nbins = 100, 
#' exposureCol = NULL,
#' Title = "Gini comparison chart",
#' xTitle = "Proportion of predictions",
#' yTitle = "Proportion actual",
#' chart = TRUE,
#' output_dir = NULL,
#' Palette = rsaPalette()[c(2,3,6,8,4)]
#' )
#' @param dt_test  test dataset - a data frame or data table
#' @param modelCols names of model prediction colums in `dt_test`.
#' Where relevant these are expected to be per exposure rates
#' @param modelNames corresponding names to display in the chart
#' @param Response name of the column of dt_test containing response data
#' @param nbins number of bins (data points) of predicted intensity to plot.
#' this should be lower than 1 / x, where x is the maximum 
#' proportion of weighted exposure for a particular row in the dataset
#' @param exposureCol name of the exposure column, or NULL
#' @param weightCol name of the weight column, or NULL
#' @param chart logical: return the chart (true) or the data 
#' @param Title chart title text
#' @param xTitle x axis title text
#' @param yTitle y axis title text
#' @param outDir if not NULL, the chart is saved to this directory. 
#' @param Palette colour palette
#'
#' @return a plotly chart, or a list of summarised data for plotting, plus values
#' @export
#'
#' @examples
#' 
#' data("UKTheftFreq")
#'# build a simple model
#'xgbData <- xgbSetupdata2(
#'  dt_Data = UKTheftFreq,
#'  response = "numClaims",
#'  explanatory_vars = colnames(UKTheftFreq)[10:31],
#'  exposure = "exposure",
#'  sampleWeight = "weight",
#'  offset_model = "offset",
#'  rowIndicesList = list(
#'    train = which(UKTheftFreq$foldId < 5),
#'    test = which(UKTheftFreq$foldId ==5))
#')
#'
#'simpleModel <- xgb.train(
#'  params = list(
#'    objective = "count:poisson",
#'    max_depth = 2L,
#'    min.child.weight = 20,
#'    eta = 0.2,
#'    gamma = 0.2
#'  ),
#'  data  = xgbData$train,
#'  nrounds = 50
#')

#'UKTheftFreq[foldId == 5, simplemodel := predict(simpleModel, xgbData$test)]
#'giniPlot(
#'  UKTheftFreq,
#'  modelCols =  c("simplemodel", "offset"),
#'  modelNames = c("Simple model", "Offset"),
#'  Response     = "numClaims",
#'  exposureCol  = "exposure",
#'  weightCol    = "weight"
#')

giniPlot <- function(
  dt_test,
  modelCols,
  modelNames,
  Response,
  nbins = 100, 
  exposureCol = NULL,
  weightCol = NULL,
  chart = TRUE,
  Title = "Gini comparison chart",
  xTitle = "Proportion of predictions",
  yTitle = "Proportion actual",
  output_dir = NULL,
  Palette = rsaPalette()[c(2,3,6,8,4)]
  )
{

# error checking ----------------------------------------------------------
  
  for (nm in modelCols){
    if (!(nm %in% colnames(dt_test))) stop (
      nm, " not found in dt_test")
    if(any(is.na(dt_test[, get(nm)]))){
      warning ("removing rows with NA values for ", nm)
      dt_test <- dt_test[!is.na(get(nm))]
    }
    
  }
  
  if (is.null(exposureCol)) {
    exposures <- rep(1, nrow(dt_test))
  } else 
  {
    if (!(exposureCol %in% names(dt_test))) stop (
      "exposureCol not found in dt_test")
    exposures <- dt_test[, get(exposureCol)]
  }
  
  if (is.null(weightCol)) {
    weights <- rep(1, nrow(dt_test))
  } else 
  {
    if (!(weightCol %in% names(dt_test))) stop (
      "weightCol not found in dt_test")
    weights <- dt_test[, get(weightCol)]
  }  
  
  if (!(all(c(Response) %in% colnames(dt_test)))) stop (
    "Response column not found in dt_test")
 
# function ----------------------------------------------------------------
  setDT(dt_test)
  
  dt_temp <- copy(dt_test[
    ,
    c(Response, modelCols),
    with = F
    ])
  dt_temp[, t_exposure := exposures * weights]
  dt_temp <- dt_temp[!(is.na(t_exposure))]
  dt_temp <- dt_temp[t_exposure > 0]
  totalResponse <- sum(dt_temp[, get(Response) * weights])
  totalExposure <- sum(dt_temp[, t_exposure])
  if(nbins == 0) nbins <- nrow(dt_test)
  # set empty outputs:
  dt_out <- data.table(
    binNumber = 0:nbins,
    X_default = (0:nbins) / nbins,
    Y_default = (0:nbins) / nbins)
  ginis <- list()
  if (chart){
    fig <- plot_ly(
    dt_out,
    x = ~X_default,
    y = ~Y_default,
    type = 'scatter',
    mode = 'lines',
    name = "Default",
    line = list(dash = "dot", color = "#333333", width = 0.4)
    )
  fig <- fig %>% layout(
    title = Title,
    xaxis = list(title = xTitle),
    yaxis = list(title = yTitle))
  
  }
  # loop over models, adding data:
  
  for (i in seq_along(modelCols)){
    #print(i)
    nm <- modelCols[i]
    dt_temp[, t_sorter:= - 1 * get(nm)]
    setkey(dt_temp, t_sorter)
    if (nbins < nrow(dt_test)){
      dt_temp[, cum_exposure := pmin(
        nbins, 1 + trunc(cumsum(t_exposure) / totalExposure * nbins))]
    } else{
      dt_temp[, cum_exposure := cumsum(t_exposure) / totalExposure]
    }
    
    # cumulative sum using trapezium method:
    dt_gini <- dt_temp[
      , 
      .(
        a = sum(t_exposure)/ totalExposure,
        b = sum(get(Response)) / totalResponse
        ),
      keyby = .(cum_exposure)]
    dt_gini2 <- rbind(data.table (cum_exposure = 0L, a = 0, b = 0 ), dt_gini)
    dt_gini <- rbind(dt_gini, data.table(cum_exposure = 1L + nbins, a = 0, b = 0))
    dt_gini_trap <- data.table(
      bin = dt_gini$cum_exposure,
      a = (dt_gini$a + dt_gini2$a) / 2,
      b = (dt_gini$b + dt_gini2$b) / 2)
    
    # gini coefficient is:
    ginis[nm] <- sum(dt_gini$a * cumsum(dt_gini_trap$b))
    dt_out[, eval(paste0("X_",i)) := cumsum(dt_gini2$a)]
    dt_out[, eval(paste0("Y_",i)) := cumsum(dt_gini2$b)]
    # now have to plot them 
    if (chart){
      fig <- fig %>% add_trace(
      x = dt_out[[paste0("X_",i)]],
      y = dt_out[[paste0("Y_",i)]],
      name = paste0(modelNames[i]," : \nGini = ", round(ginis[[nm]], 3)),
      mode = 'lines',
      line = list(
        width = 2, 
        dash = "line",
        color = Palette[i])
      ) 
    }
  }
  
  
  if (chart) {
    if(!(is.null(output_dir))) saveWidget(
      fig,
      paste0(
        normalizePath(output_dir), 
        "\\gini",
        gsub("[^0-9]","",Sys.time()),
        ".html"
        )
      )
    return (fig)  } 
  return (list(chartdata = dt_out, GiniScores = ginis))
  
}





