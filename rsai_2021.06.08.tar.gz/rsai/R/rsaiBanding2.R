# functions to calculate an optimal binning based on weighted losses applied to vector "binOn" and then applied to "toBin".

# start with a function which it uses which we subsequently use again on a new data set...

#' Produce an optimal binning of a numeric data set
#' 
#' @description some model fitting routines require numeric data to be binned or are speeded up by it.
#' \code{rsaiBand} takes a data set with optional weighting and a loss power function, and returns
#' the upper limits of a defined numeric binning designed to minimise loss
#' (as defined by abs(value - estimated value) ^ loss power).
#'
#' @usage rsaiBand (binOn, bins = 100L, lossPower = 1, wts = 1, rounding =4L)
#'
#' @param binOn input data used to create the binning
#' @param bins number of bins produced. 
#' @param lossPower exponent of the loss function - usually set to 1 (minimise absolute error)
#' or 2 (minimise squared error) but can be any strictly positive value.
#' @param wts optional weights. if supplied, must be the same length as \code{binon}
#' (the function maintains consistency between \code{wts} and \code{binon} when removing any NAs)
#' @param rounding band limits are rounded to this many dps.  
#'
#' @return upper limits of the bins. (The last of these will be the maximal value of code{binon} but this
#' is largely irrelevant if using the binning on a new dataset.) These can then be applied to a new dataset 
#' using the rsai function \code{applyBin}.
#' @export
#' @examples
#' set.seed (57627890L)
#' tempData <- rgamma(20000, shape =4, rate = 0.01) # a deliberately skew dataset
#' tempBands <- rsaiBand (tempData, bins = 50, lossPower = 2, rounding = 0)
#' tempBands
#' table (applyBin (toBin = tempData, bands = tempBands))
#' rm (tempData)
#' rm (tempBands)

rsaiBand <- function (binOn, bins = 100L, lossPower = 1, wts = 1, rounding =4L){
 
  #1. Eine kleine errorcheck
  rounding <- as.integer(rounding)
  bins <- as.integer (bins) 
  if (length (wts)==1) wts <- rep (1, length (binOn))
  if (!(length (wts)== length(binOn))) stop ("wts should be a constant or a vector the same length as binOn")
  if (!( is.numeric (binOn) &  is.numeric (lossPower) & is.numeric(wts))) stop (
    "One or more variables not of the correct class")
  if (lossPower <= 0) stop ("lossPower should be strictly positive")
  if (bins <= 1) stop ("need at least 2 bins")  
  
  
  #2. scrub NA values from bin data, maintaining consistency...
  wts <- wts [!is.na (binOn)] 
  binOn <- binOn [!is.na(binOn)]
  wts[is.na(wts)]<- 0

  mn = min (binOn)
  mx = max (binOn)
  Fx <- ecdf (binOn)
  Top = (1:bins)/bins
  Bottom = Top -1/bins
  stepecdf <- Fx (mn+Top*(mx-mn))-  Fx (mn+Bottom*(mx-mn))
  
  #3. define subfunctions
  
  # loss from estimate used:
  lossFn <- function (estimates, weights = wts){ sum (weights *(abs(binOn - estimates))^ lossPower)  }
  
  # define estimates from banding: feeds into lossFn
  estFn <- function (band) { if (lossPower>1.5) return (mean (band)) else return (median (band)) }
  
  # get bin number of data from banding:
 # lLims <- function (bands) { 1+ pmin (ecdf(round (cumsum (bands) + mn, rounding))(binOn)*length (bands), length(bands)-1) }
  lLims <- function (bands) {pmin (length (bands), 1+ sapply (binOn, FUN = function (x) sum (x> round(mn+ cumsum(bands), rounding))))}
  # so get a function which gives loss function of banding from the banding:
  
  lossFunction <- function( bands ){
    array <- data.table (data = binOn, band  = lLims(bands))
    estimates <- aggregate (data ~ band, array, estFn)
    return (lossFn( estimates = estimates$data [match (array$band, estimates$band)]))
  }
  
  # 4. derive a banding which is intermediate:
  
  ## this is the change from the original banding function. That used a different interpolation. this calculates an approximate "density function"
  ## at n points (n = number of bins -1 ) and calculates bin placings based on that. where power = 1, the density function = the actual distribution density:
  ## when power = 0 it's uniform.
  
  deriveBand <- function (power) {
    ecdfi <- stepecdf^power
    ecdfi<- ecdfi/ sum(ecdfi)
    xFx <- cumsum (ecdfi)
    return ((mx-mn)* (approx (y = Top, x = xFx, xout = Top,yleft =0, yright =1)$y -approx (y = Top, x = xFx, xout = Bottom, yleft =0, yright =1)$y))}  
  
  
  #search for optimum power

  MIN = 0
  MAX = 1
  gap =T
  diff = 1
  losses <- data.table( values = 0, loss = lossFunction(deriveBand(0)))
  while (abs (MAX - MIN) >0.01 & gap ){
  #repeat()
  
 array <- MIN +((MAX - MIN) /4*(0:4))
  for (i in 1:5) {
    if(! (array[i] %in% losses$values)) losses<- rbind (losses, data.table(values = array[i], loss= lossFunction(deriveBand(array[i]))))}
  setkey(losses, loss)
  MAX = max(losses$values[1],losses$values[2],losses$values[3])
  MIN=  min(losses$values[1],losses$values[2],losses$values[3])
  #cat ("max=", max, "\n")
  diff2 = MAX - MIN
  gap = (diff>diff2)
  diff = diff2                                                                                      
  }
  #print (losses)
  #cat (max,min,gap)
  
    bestband <- deriveBand(losses$values[1])
    return  ( unname( round (mn+cumsum(bestband), rounding))) # returns upper limits of bands (the last of which is irrelevant!)
  
    
    
}

# function 2: like lLims but want to apply a known banding to a new data set. 

#' Assign numeric data to one of n predefined bins
#'
#' @param toBin Data to be binned
#' @param bands Upper limits of bands (the last of which is essentially irrelevant for the binning, but is required to produce the correct number of bins)
#' @return the appropriate bin number. Note behaviour at bin boundaries: values equal to a boundary are assigned to the lower bin.  
#' @export
#' @examples
#' applyBin (c(4,4.5,5,5.5), bands = 1:6)
#' applyBin (c(4,4.5,5,5.5), bands = 0:5)
applyBin <- function (toBin, bands) pmin (length (bands), 1+ sapply (toBin, FUN = function (x) {sum (x>bands)}))

