#' Function to Detect Model Degradation
#' 
#' @description A simple way of detecting model degradation. Comparing the actual values
#' against the predicted values. Then determining after however many steps of
#' time degradation occurs. Finally you may alter the error to whatever you
#' deem appropriate.
#' 
#' For this to work you must have already built a model from some training data
#' and used it to predict the results of test data. \code{detectExtrema} will
#' simply notify you as to which point in time the model degrades based on a
#' preset error.
#' @usage detectExtrema(actual.data, predicted.data, error=0.1)
#' @param predicted.data The vector containing the predicted data scores.
#' @param actual.data The vector containing the actual data scores.
#' @param error The error level you would like to test at. A non-negative
#' numerical value.
#' @details For this to work you must have already built a model from some training 
#' data and used it to predict the results of test data. \code{detectExtrema} will simply notify
#' you as to which point in time the model degrades based on a preset error.  

#' @return How many steps of time along the data provided until the degradation
#' occurs.
#' @author James Bland
#' @importFrom data.table as.data.table transpose
#' @export
#' @examples
#' 
#' #    require(zoo)
#' #    vec1 <- seq(from = 10, to = 15, by=0.01)
#' #    vec2 <- rep(10, 501)
#' #    detectExtrema(vec1, vec2, 0.3)
#' 
detectExtrema <- function(actual.data, predicted.data, error=0.1) {
  if(length(actual.data) <= 5){stop("'actual.data' should have length more than 5.")}
  if(length(actual.data) != length(predicted.data)){stop("'actual.data' should have the same length as 'predicted.data'")}
  if(length(error) > 1 || error < 0) stop("'error' should be a single value, at least 0")
  z <- rbind(as.integer(3:(length(actual.data) -2)), zoo::rollmean(actual.data, 5))
  z <- as.data.frame(z)
  z <- data.table::as.data.table(data.table::transpose(z))
  names(z)[1] = "V1"
  names(z)[2] = "V2"
  w <- rbind(as.integer(3:(length(predicted.data) - 2)), zoo::rollmean(predicted.data, 5))
  w <- as.data.frame(w)
  w <- data.table::as.data.table(data.table::transpose(w))
  names(w)[1] = "V1"
  names(w)[2] = "V2"
  count=0
  for(i in 3:(length(actual.data)-2)) {
    wzdiff <- w[w$V1==i,]$V2 - z[z$V1==i,]$V2
    if (abs(wzdiff) < ((error/2) * z[z$V1==i,]$V2)) next
    else{
      count <- count+1
      if(count==1) break
    }
    print(i)
    break
  }
  print(i)
}
