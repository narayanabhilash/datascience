#####  monthDiff  #####
#' Difference in months between two dates
#' @description Number of whole months elapsed from date1 to date2.
#' @usage monthDiff(date1, date2)
#' @param date1 date
#' @param date2 date
#' @return An integer
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #monthDiff(date1=as.Date(c("1984-06-24", "1988-08-16")), date2=as.Date("2017-10-03"))
#' @export

monthDiff <- function(date1, date2){
  d1 <- as.POSIXlt(date1)
  d2 <- as.POSIXlt(date2)
  return(12*(d2$year-d1$year)+(d2$mon-d1$mon)-(d2$mday<d1$mday))
}


#####  yearDiff  #####
#' Difference in years between two dates
#' @description Number of whole years elapsed from date1 to date2.
#' @usage yearDiff(date1, date2)
#' @param date1 date
#' @param date2 date
#' @return An integer
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #yearDiff(date1=as.Date(c("1984-06-24", "1988-08-16")), date2=as.Date("2017-10-03"))
#' @export

yearDiff <- function(date1, date2){
  return(floor(monthDiff(date1, date2)/12))
}