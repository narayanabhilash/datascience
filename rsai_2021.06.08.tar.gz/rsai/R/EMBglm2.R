# EMBglm functions. Contains:
## validate.EMBglm
## as.EMBglm
## plot.EMBglm
## predict.EMBglm
## fixAliasTables
## reorderEMBglm
## EMBmodelMerge
## standardiseEMBglm
## rebaseEMBglm
## logitEMBglm
## delogitEMBglm
## summary.EMBglm

#####  validate.EMBglm  #####
#' Function to check whether an object is a valid EMBglm class.
#' @description The function takes an R object and checks that it is a valid EMBglm class. If it isn't the function returns an error message.
#' @usage validate.EMBglm(object)
#' @param object The object to validate.
#' @return Does not return a value if validity rules are all passed.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' # validate.EMBglm(EMBglmTbl)
#' @export

validate.EMBglm <- function(object){
  # Check for non-empty data table
  if (!("data.table" %in% class(object))) stop("Must be a data.table")
  if (!("data.frame" %in% class(object))) stop("Must be a data.frame")
  if (nrow(object) < 1) stop("Must have at least one row")
  
  # Check column names
  if (any(duplicated(names(object)))) stop("No duplicated column names")
  FacCols <- colnames(object)[substr(colnames(object), 1, 6) == "Factor"]
  LevCols <- colnames(object)[substr(colnames(object), 1, 5) == "Level"]
  nFac <- length(FacCols)
  nLev <- length(LevCols)
  if (nFac != nLev) stop("There must be the same number of Level columns as Factor columns")
  if (nFac==0) stop ("No Factor columns in EMBglm")
  if (!identical(names(object)[seq(1, nFac*2)], c(paste0("Factor", seq(1, nFac)), paste0("Level", seq(1, nFac))))){
    stop("First columns in data table must be: Factor1, ..., FactorN, Level1, ..., LevelN")
  }
  ValCols <- colnames(object)[substr(colnames(object), 1, 5) == "Value"]
  ValColIndex <- which(colnames(object) %in% ValCols)
  nVal <- length(ValColIndex)
  if (nVal==0) stop ("No Value columns in EMBglm")
  
  # Check column contents
  if (!all(sapply(c(FacCols, LevCols), function(col) class(object[[col]])=="character"))){
    stop("All Factor and Level columns must be character")
  }
  if (!all(sapply(ValCols, function(col) class(object[[col]])=="numeric"))) stop("Value columns must be numeric")
  if (any(sapply(c(FacCols, LevCols, ValCols), function(col) anyNA(object[[col]])))) stop("NAs detected")
  if (any(sapply(c(FacCols, LevCols, ValCols), function(col) any(is.infinite(object[[col]]))))) stop("Non-finite values detected")

  # Check column order
  if (!identical(ValColIndex, seq(nFac*2+1, nFac*2+nVal))) stop("Value columns must be grouped together after Factor and Level columns")
  
  # Check structure is valid
  ratingTbls <- unique(object[, FacCols, with=FALSE])
  if (any(sapply(seq(1, nrow(ratingTbls)), function(i){
    facs <- as.character(ratingTbls[i])
    facs <- facs[which(facs != "")]
    any(duplicated(facs))
  }))) stop("Factors should not be repeated within a row (E.G. Factor1 and Factor2 cannot refer to the same factor)")
  
  # Check blank factor names only exist to the right of non-blank factors
  if (any(sapply(seq(1, nrow(ratingTbls)), function(i){
    facs <- as.character(ratingTbls[i])
    max(c(which(facs != ""), -Inf)) > min(c(which(facs == ""), Inf))
  }))) stop("Blank factors should always be to the right of non-blank factors")
  
  # Strip down for ease of checking
  object2 <- copy(object)[, c(FacCols, LevCols), with=FALSE]
  object2[, row := .I]
  
  # checkByTbl is the result of going through table by table checking various validity conditions
  checkByTbl <- sapply(seq(1, nrow(ratingTbls)), function(i){
    ratingTbl <- ratingTbls[i]
    setkeyv(ratingTbl, FacCols)
    setkeyv(object2, FacCols)
    filtered <- object2[ratingTbl]
    if (filtered[, sum(Factor1=="")] > 1) return(2)
    if (max(filtered$row) - min(filtered$row) + 1 != nrow(filtered)) return(3) # tables are jumbled up
    filtered <- filtered[, names(which(colSums(filtered != "") > 0)), with=FALSE] # remove blank cols
    filtered[, row := NULL]
    setkey(filtered, NULL)
    if (anyDuplicated(filtered) > 0) return(2) # non-unique levels
    LevCols2 <- colnames(filtered)[substr(colnames(filtered), 1, 5) == "Level"]
    if (length(LevCols2 > 1)){
      cartesianProdNum <- prod(sapply(LevCols2, function(col){
        length(unique(filtered[[col]]))
      }))
      if (cartesianProdNum != nrow(filtered)) return(1)
    }
    return(0)
  })
  if (max(checkByTbl) == 3) stop("Rows must be grouped together by rating table")
  if (max(checkByTbl) == 2) stop("Duplicate rows exist")
  if (max(checkByTbl) == 1) stop("Interactions must have a row for every combination of factor levels")
  
  # Check level names are consistent between tables for each factor
  ratingTbls[, tblNum := .I]
  setkeyv(ratingTbls, FacCols)
  object2 <- ratingTbls[object2]
  facCheck <- unique(rbindlist(lapply(seq(1, nFac), function(i) {
    data.table(Factor=object2[[FacCols[i]]], Level=object2[[LevCols[i]]], tblNum=object2[["tblNum"]])[Factor != ""]
  })))
  uniqueFactors <- unique(facCheck$Factor)
  checkByFactor <- sapply(uniqueFactors, function(x){
    filtered <- facCheck[Factor==x]
    if (length(unique(filtered$Level))*length(unique(filtered$tblNum)) != nrow(filtered)) return(1) # levels are inconsistent
    return(0)
  })
  if (max(checkByFactor) == 1) stop("Levels of rating factors must be consistent across different rating tables")
  
  # Check for alias tables
  if (any(duplicated(t(apply(as.matrix(ratingTbls[, FacCols, with=FALSE]), 1, function(vec) vec[order(vec)]))))){
    stop("Alias table detected")
  }
  
  # Check type is compatible, if it exists
  if (!is.null(attributes(object)$type)){
    type <- attributes(object)$type
    if (!is.character(type)) stop("The type attribute is invalid")
    if (length(type) != 1) stop("The type attribute is not valid")
    if (! type %in% c("Multiplicative", "Additive", "Logistic")){
      stop("The type attribute should be 'Multiplicative', 'Additive', or 'Logistic'")
    }
    
    # Check for out-of-range values
    if (type %in% c("Multiplicative", "Logistic")){
      if (any(sapply(ValCols, function(x){
        min(object[, x, with=FALSE]) <= 0
      }))) stop("Out-of-range values detected.")
    } else if (type == "Logistic"){
      if (any(sapply(ValCols, function(x){
        min(object[, x, with=FALSE]) >= 1
      }))) stop("Out-of-range values detected.")
    }
  }
}
#############################


#####  as.EMBglm  #####
#' Function to convert a data table into an EMBglm object.
#' @description The function takes a data.table object and returns an object of class EMBglm.
#' @usage as.EMBglm(x, type=NULL)
#' @param x The object to convert to EMBglm class.
#' @param type NULL by default. If set to 'Additive', or 'Logistic', the \code{predict} function will assume the model
#' is additive or logistic. Otherwise if NULL or set to 'Multiplicative' \code{predict} assumes a multiplicative model.
#' @return An EMBglm object.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' # EMBglmObj <- as.EMBglm(dtObj)
#' @export

as.EMBglm <- function(x, type=NULL){
  # Check if data frame / data table. Convert to data table if data frame.
  if (!"data.frame" %in% class(x)) stop("x must be a data frame")
  if (!"data.table" %in% class(x)) x <- data.table(x)
  
  # Fix NAs and ensure that all Factor and Level columns are character.
  FacCols <- names(x)[which(substr(colnames(x), 1, 6) == "Factor")]
  LevCols <- names(x)[which(substr(colnames(x), 1, 5) == "Level")]
  for (col in c(FacCols, LevCols)){
    set(x, j=col, value=ifelse(is.na(x[[col]]), "", as.character(x[[col]])))
  }
  
  # Add type attribute
  if (is.null(type)){
    I0 <- 1
  } else{
    attr(x, "type") <- type
    if (type == "Additive"){
      I0 <- 0
    } else if (type == "Logistic"){
      I0 <- 0.5
    } else{
      I0 <- 1
    }
  }

  # Fix NAs in Value columns and set to 1 with warning.
  ValCols <- names(x)[which(substr(colnames(x), 1, 5) == "Value")]
  for (col in ValCols){
    if (anyNA(x[[col]])){
      set(x, j = col, value=ifelse(is.na(x[[col]]), I0, x[[col]]))
      warning(paste0("NAs found in column: ", col, ". NAs set to 1."))
    }
  }
  
  # Check for validity then change class to EMBglm.
  validate.EMBglm(x)
  if ("EMBglm" %in% class(x)) return(x) else{
    class(x) <- c("EMBglm", class(x))
    invisible(alloc.col(x))
    return(x)
  }
}
#######################


#####  plot.EMBglm  #####
#' Function to plot one of the tables in an EMBglm object.
#' @description The function takes an EMBglm and produces a plotly bar-line chart of the requested table.
#' @usage plot.EMBglm(x,
#' factors=character(0),
#' barCols=character(0),
#' lineCols=NULL,
#' title=NULL,
#' xAxisName=NULL,
#' barAxisName=NULL,
#' lineAxisName=NULL,
#' ...)
#' @param x The EMBglm object to plot.
#' @param factors A character vector containing a factor or factors. These must correspond to a 'rating table' within the EMBglm object.
#' @param barCols A character vector with a set of columns to plot as bars.
#' @param lineCols A character vector with a set of columns to plot as lines.
#' @param title The plot title.
#' @param xAxisName The x-axis title.
#' @param barAxisName The y-axis title for columns plotted as bars.
#' @param lineAxisName The y-axis title for columns plotted as lines.
#' @param \dots Optional parameters to be passed through to plot_ly function e.g. width=910 to set the chart width.
#' @return A plotly chart.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @importFrom plotly plot_ly layout add_trace
#' @examples
#' # plot.EMBglm(EMBglm)
#' @export
plot.EMBglm <- function(x,
                        factors=character(0),
                        barCols=character(0),
                        lineCols=NULL,
                        title=NULL,
                        xAxisName=NULL,
                        barAxisName=NULL,
                        lineAxisName=NULL,
                        ...){
  
  # Ensure x is a valid EMBglm object
  validate.EMBglm(x)
  
  # Default lines
  if(is.null(lineCols)) lineCols <- colnames(x)[which(substr(colnames(x), 1, 5) == "Value")]
  
  # Column names
  nFacPlot <- length(factors)
  nFacX <- max(which(substr(colnames(x), 1, 6) == "Factor"))
  facCols <- paste0("Factor", seq(1, nFacX))
  levCols <- paste0("Level", seq(1, nFacX))
  
  x <- copy(x)[, c(facCols, levCols, barCols, lineCols), with=FALSE]
  tbls <- unique(x[, facCols, with=FALSE])
  factorsLong <- c(factors, rep("", nFacX-nFacPlot))
  
  # Look for rating tables that match
  tblMatch <- which(sapply(seq(1, nrow(tbls)), function(i){
    setequal(factorsLong, as.character(tbls[i]))
  }))
  if(length(tblMatch) != 1) stop("factors specified do not match a table within x")
  
  # Filtering the EMBglm object to the correct rows
  tbls <- tbls[tblMatch]
  setkeyv(tbls, names(tbls))
  setkeyv(x, names(tbls))
  x <- x[tbls]
  
  # Prepare for plot
  if(nFacPlot>0){
    if(nFacPlot>1){
      # Change the order of columns around to match those specified
      colOrder <- order(match(factorsLong, as.character(x[1, facCols, with=FALSE])))
      if(!identical(colOrder, seq(1, nFacX))) setnames(x, c(paste0("Factor", colOrder), paste0("Level", colOrder)), c(facCols, levCols))
      
      # change sort order
      for(i in seq(1, nFacX)){
        orderTbl <- data.table(unique(x[[paste0("Level", i)]]))
        orderTbl[, order := .I]
        setnames(orderTbl, names(orderTbl), paste0(c("Level", "Order"), i))
        setkeyv(orderTbl, paste0("Level", i))
        assign(paste0("orderTbl", i), orderTbl)
      }
      for(i in seq(1, nFacX)){
        setkeyv(x, paste0("Level", i))
        x <- get(paste0("orderTbl", i))[x]
      }
      setkeyv(x, paste0("Order", seq(nFacX, 1, by=-1)))
      
      # Paste together levels
      for(i in seq(1, nFacPlot)){
        if(i==1) Level <- x[["Level1"]] else Level <- paste0(Level, ".", x[[levCols[i]]])
      }
      x[, Level1 := Level]
    }
    
    if(is.null(xAxisName)) xAxisName <- paste0(factors, collapse = ":")
  }
  
  # Plot
  barLinePlot(dataForPlot=x,
              factorCol="Level1",
              barCols=barCols,
              lineCols=lineCols,
              title=title,
              xAxisName=xAxisName,
              barAxisName=barAxisName,
              lineAxisName=lineAxisName,
              ...)
}
#########################


#####  predict.EMBglm  #####
#' Score an EMB glm (or a modified one) in R
#' 
#' @description \code{predict.EMBglm} enables \code{predict} to score a \code{EMBglm} object
#' on a data frame. This can be called via the rsai function
#' \code{link{scoreAgainstCSV}} on very large files.
#' 
#' %% ~~ If necessary, more details than the description above ~~
#' 
#' @param object An EMBglm file (i.e. a data table with rows and columns
#' consistent with tabulated EMBlem model specification) containing
#' details of the model(s) to be scored.
#' @param newdata A data frame containing the data you want to score on.
#' @param auditrow If set to a vector of positive integers, the function will print out
#' the multipliers being successively applied to these particular rows of
#' \code{newdata} as ancillary output. (Note that if called via
#' \code{scoreAgainstCSV}, this will produce output for that row of each
#' \emph{chunk}.)
#' @param upperFlag If set to True, the function tries to match column names in
#' the data to factor names in the EMBglm file without being case sensitive.
#' @param NAstops If set to True, stop predictions on encountering any returned 
#' NA values (and return diagnostics).
#' @param type By default this is NULL. If specified, this must be one of 'Multiplicative', 'Additive' or 'Logistic'.
#' These determine the type of model scoring to perform. If NULL, this looks to see if the type attribute has been
#' set on the EMBglm object and uses that. If this is also NULL, the function assumes the model is multiplicative.
#' @return Returns a data table containing predictions corresponding to each of
#' the `Value` columns in \code{object}.
#' @note If you wish to use \code{scoreAgainstCSV} to evaluate an EMBglm file
#' you \emph{must} also specify \code{predNames}. \cr As is often the case when
#' processing files in chunks, you may experience difficulties if your data
#' contain leading zeroes.  These can be overcome by setting \code{colClasses}
#' = `character` in any call to \code{scoreAgainstCSV}. \cr The factor levels
#' in \code{object} need to correspond to the column names of \code{newdata}.
#' However, this match is not case sensitive, so you will need to modify your
#' objects if they have column names which differ only by case.
#' @note to call the function call 'predict' _not_ predict.EMBglm.
#' @note The function is expecting a multiplicative model:
#' for propensities see \code{\link{logitEMBglm}} for the workaround.
#' @author Tom Bratcher
#' @seealso \code{\link{scoreAgainstCSV}}
#' @importFrom data.table data.table as.data.table setkeyv haskey
#' @export
#' @references %% ~put references to the literature/web site here ~
#' @examples
#' 
#' 
#' modelFile <- data.table (Factor1 = c("",rep ("Age",10),rep("NCDYears",5))
#' ,Level1 = c("",31:40, 0:3,"4+" ), Value = c (0.02,1.5 - 0.1* (0:9), 1.5-0.2*(0:4) ) )
#' 
#' head(modelFile)
#' 
#' ## A very simple frequency model as a function of Age and NCD years;
#' ##0.02 represents the base value in the model.
#' ## For example the model would give 32-year-old with 3 years NCD an assumed claim frequency of
#' ##0.02 times 1.4 times 0.9. 
#' 
#' dt <- data.table (policyNo = 1:100, Age = sample (31:40,100,replace = TRUE),
#' NCDYears = sample (0:5,100, replace = TRUE))
#' ## note that the levels in the model file don't match up with the data file in all cases...
#' 
#' ##Scoring this directly:
#' preds <- predict(as.EMBglm(modelFile),newdata = dt, auditrow = 2, NAstops = FALSE)
#' ## Alternatively, using scoreAgainstCSV: 
#' #write.csv(dt,file="testCSV.csv",row.names=FALSE)
#' #scoreAgainstCSV(as.EMBglm(modelFile),fin="testCSV.csv",fout="testCSV2.csv",
#' #predNames = "FreqPred", verbose = TRUE, chunkSize=50L)
#' ## clean up
#' #unlink("testCSV.csv")
#' #unlink("testCSV2.csv")
#' rm(dt)
#' rm(preds)
#' 
predict.EMBglm <- function(
  object,
  newdata,
  auditrow = 0,
  upperFlag = FALSE,
  NAstops = TRUE,
  type = NULL
){
  
  validate.EMBglm(object)
  object <- copy(object)
  
  # Find type
  if (is.null(type)){
    if (is.null(attributes(object)$type)){
      type <- "Multiplicative"
    } else{
      type <- attributes(object)$type
    }
  } else{
    if (!(is.character(type) & length(type)==1)){
      stop("type must be character of length 1")
    }
    if (! type %in% c("Multiplicative", "Additive", "Logistic")){
      stop("type must be NULL or one of 'Multiplicative', 'Additive', 'Logistic'")
    }
  }
  
  # Turn logistic to multiplicative using logitEMBglm
  if (type == "Logistic") object <- logitEMBglm(object)

  if (max(auditrow) > nrow(newdata)) stop("auditrow exceeds newdata length")
  
  if (!(is.data.frame(newdata))) stop(
    "newdata must be a data frame or table")
  setDT(newdata)
  
  # Columns of object
  FacCols <- grep("Factor", colnames(object), value = TRUE)
  LevCols <- gsub("Factor", "Level", FacCols)
  valCols <- grep("Value", colnames(object), value = TRUE)
  
  # Check for out-of-range values
  if (type %in% c("Multiplicative", "Logistic")){
    if (any(sapply(valCols, function(x){
      min(object[, x, with=FALSE]) < 0
    }))) stop("Out-of-range values detected.")
  }
  if (type == "Logistic"){
    if (any(sapply(valCols, function(x){
      min(object[, x, with=FALSE]) > 1
    }))) stop("Out-of-range values detected.")
  }
  
  # Calculate number of factors and drop unneeded cols
  nFac <- length(FacCols)
  object <- object[, c(FacCols, LevCols, valCols), with=FALSE]
  
  # Everything to uppercase if upperFlag is TRUE
  if (upperFlag){
    origNames <- c(colnames(newdata))
    colnames(newdata) <- toupper(colnames(newdata))
    for (nm in FacCols){
      object[[nm]]<- toupper(object[[nm]])
    }
  }
  
  # Create list of rating tables
  ratingTbls <- unique(object[, FacCols, with=FALSE])
  setkeyv(object, FacCols)
  ratingTblList <- lapply(seq(1, nrow(ratingTbls)), function(i){
    facs <- ratingTbls[i]
    ways <- nFac - length(which(facs == ""))
    setkeyv(facs, FacCols)
    rtTbl <- object[facs]
    if(ways==0) rtTbl <- rtTbl[, valCols, with=FALSE] else{
      setnames(rtTbl, paste0("Level", seq(1, ways)), as.character(facs)[seq(1, ways)])
      setkeyv(rtTbl, as.character(facs)[seq(1, ways)])
      rtTbl <- rtTbl[, (FacCols):=NULL]
      if(ways < nFac) rtTbl <- rtTbl[, (paste0("Level", seq(ways+1, nFac))) := NULL]
    }
    setnames(rtTbl, valCols, paste0(i, "_", valCols))
    return(rtTbl)
  })
  
  # Check all factors exist
  uniqeFacs <- unique(unlist(lapply(FacCols, function(col){
    facs <- ratingTbls[[col]]
    return(facs[which(facs != "")])
  })))
  
  missingCols <- uniqeFacs[which(! uniqeFacs %in% names(newdata))]
  if (length(missingCols) > 0) stop(paste0("newdata missing columns: ", paste0(missingCols, collapse=", ")))
  
  # Trim data to required columns
  newdata <- copy(newdata)[, uniqeFacs, with=FALSE][, rowNumber := .I]
  facClasses <- sapply(uniqeFacs, function(fac) class(newdata[[fac]]))
  for (i in which(! facClasses %in% c("factor", "character"))){
    set(newdata, j=uniqeFacs[[i]], value=as.character(newdata[[uniqeFacs[[i]]]]))
  }
  
  # merge tables
  if (max(auditrow) > 0) cat(paste0("Details for auditrow(s): ", paste0(auditrow, collapse = ", "), "\n"))
  for (i in seq(1, length(ratingTblList))) {
    if (max(auditrow) > 0) cat(paste0("\n Table ", i, "\n"))
    tbl <- ratingTblList[[i]]
    if(!haskey(tbl)) {
      for(k in seq(1, ncol(tbl))) set(newdata, j = names(tbl)[k], value = as.numeric(tbl[1, ])[k])
    } else {
      setkeyv(newdata, key(tbl))
      newdata <- tbl[newdata]
    }
    if(max(auditrow) > 0) tblToPrint <- newdata[rowNumber %in% auditrow, c("rowNumber", key(ratingTblList[[i]]), paste0(i, "_", valCols)), with=FALSE]
    if(i==1) {
      setnames(newdata, paste0("1_", valCols), valCols)
    } else {
      for(k in seq_along(valCols)) {
        if (type == "Additive"){
          set(newdata, j=valCols[k], value=newdata[[valCols[k]]] + newdata[[paste0(i, "_", valCols[k])]])
        } else{
          set(newdata, j=valCols[k], value=newdata[[valCols[k]]] * newdata[[paste0(i, "_", valCols[k])]])
        }
        set(newdata, j=paste0(i, "_", valCols[k]), value=NULL)
      }
      # stop here if any NA values calculated:
      if (NAstops && any(sapply(newdata[, valCols, with=FALSE], is.nan))){
        stop(
          paste0("Stopping: NaN dectected. ",
          "This is likely due to a combination of 0 and 1 in different tables. ",
          "Note that an event cannot be both certain (probability 1) and impossible (probability 0) at the same time.")
        )
      }
      if (NAstops && any(is.na(newdata[, valCols, with=FALSE]))){
        stop(
          paste0(
            "Stopping: NAs returned for current table. Factors used: \n",
            paste0(
              key(ratingTblList[[i]]),
              collapse = "\n"
            ),
            "\nIf this is expected behaviour then set NAstops = FALSE."
          )
        )
      }
    }
    if(max(auditrow) > 0) {
      setnames(tblToPrint, paste0(i, "_", valCols), valCols)
      setkey(tblToPrint, rowNumber)
      print(tblToPrint)
    }
  }
  if(max(auditrow) > 0) {
    cat("\n Final results:\n")
    tblToPrint <- newdata[rowNumber %in% auditrow, c("rowNumber", valCols), with=FALSE]
    setkey(tblToPrint, rowNumber)
    print(tblToPrint)
  }
  
  # Re-order data and create predictions
  setkey(newdata, rowNumber)
  predictions <- as.matrix(newdata[, valCols, with=FALSE])
  
  # Put logistic results back from odds to probabilities
  if (type == "Logistic"){
    predictions <- ifelse(
      predictions == Inf,
      1,
      predictions / (1 + predictions)
    )
  }

  return(predictions)
}

#setGeneric("predict") ## probably need this, not sure
#setMethod("predict",signature = signature (object="EMBglm"),predict.EMBglm)
############################

#####  fixAliasTables  #####
#' Rearrange the factor order within tables in an EMBglm object
#' 
#' @description Given an EMBglm object, you can specify a list of tables with the factors
#' in the order that you want them. The function returns 
#' 
#' @param model An EMBglm object.
#' @param tables A list containing character vectors representing factors.
#' @return An object of class EMBglm
#' @export
#' @examples
#'modelFile <- data.table(
#'  Factor1 = c("", rep("NCDYears", 15)),
#'  Factor2 = c(rep("", 6), rep("Occupation", 10)),
#'  Level1 = c("", rep(c(0:3, "4+"), 3)),
#'  Level2 = c(rep("", 6), rep("Numismatist", 5), rep("Baker", 5)),
#'  Value =  c(0.02, 1.5 - 0.2 * (0:4), rep(1, 7), rep(0.9, 3))
#')
#'
#'print(modelFile)
#'
#'modelFile2 <- fixAliasTables(
#'  modelFile,
#'  list(
#'    c("Occupation", "NCDYears")
#'  )
#')
#'
#'print(modelFile2)

fixAliasTables <- function(
  model,
  tables
){
  # Check model is valid using as.EMBglm
  model <- as.EMBglm(model)
  
  # Check format of tables
  if (! is.list(tables)){
    stop("tables must be a list")
  }
  if (! all(sapply(tables, is.character))){
    stop("tables must be a list of character vectors")
  }
  
  # Number of factor columns in model
  nFac <- length(grep("Factor", colnames(model)))
  
  # Check tables has the right length
  if (any(sapply(tables, length) > nFac)){
    stop("At least one table has too many factors")
  }
  
  # Create data table of potential alias tables
  dtAlias <- unique(model[, paste0("Factor", seq_len(nFac)), with = FALSE])
  
  # Check that there are enough tables
  if (nrow(dtAlias) < length(tables)){
    stop("More tables specified than exist in model")
  }
  
  # Put potential aliases into a list
  aliases <- lapply(
    seq_len(nrow(dtAlias)),
    function(i){
      as.vector(as.matrix(dtAlias[i, ]))
    }
  )
  
  # Pad out tables list to nFac length
  tables <- lapply(
    tables,
    function(x){
      c(x, rep("", nFac - length(x)))
    }
  )
  
  # Find which table belongs with which alias
  tblMatch <- sapply(
    tables,
    function(x){
      which(
        sapply(
          aliases,
          function(y) setequal(x, y)
        )
      )
    }
  )
  
  # If there is at least one table without a match
  if (is.list(tblMatch)){
    stop("Matching table not found")
  }
  
  # If any are duplicated
  if (anyDuplicated(tblMatch)){
    stop("More than one table references the same alias table")
  }
  
  # Find columns of model that are not relevant
  FacCols <- paste0("Factor", seq_len(nFac))
  LevCols <- paste0("Level", seq_len(nFac))
  OtherCols <- colnames(model)[which(! colnames(model) %in% c(FacCols, LevCols))]
  
  # Construct return object
  newModel <- rbindlist(
    lapply(
      seq_along(aliases),
      function(i){
        tbl <- merge(model, dtAlias[i], by=FacCols)
        if (i %in% tblMatch){
          alias <- aliases[[i]]
          table <- tables[[which(tblMatch==i)]]
          reordering <- order(match(table, alias))
          if (! identical(reordering, seq_len(nFac))){
            setnames(
              tbl,
              c(FacCols, LevCols),
              c(paste0("Factor", reordering), paste0("Level", reordering))
            )
            setcolorder(tbl, c(FacCols, LevCols))
          }
        }
        return(tbl)
      }
    )
  )
  
  # Double check return object is valid
  newModel <- as.EMBglm(newModel)
  
  # Return
  return(newModel)
}
#########################


#####  reorderEMBglm  #####
#' Change the order of tables in an EMBglm object
#'
#' @description By specifying a new order, change the order of rating tables within an EBMglm object.
#' @param model An EMBglm object.
#' @param newIndex A vector of integers representing the location of the table in the original EMBglm object.
#' E.G. c(3, 1, 2) will move the third table in the original to the first position in the new object.
#' @return returns an EMBglm object.
#' @export
#' @examples
#' modelFile <- data.table(
#'   Factor1 = c(rep ("NCDYears",15), ""),
#'   Factor2 = c(rep("", 5), rep("Occupation", 10), ""),
#'   Level1 = c(rep(c(0:3, "4+"), 3), ""),
#'   Level2 = c(rep("", 5), rep("Numismatist", 5), rep("Baker", 5), ""),
#'   Value =  c(1.5 - 0.2 * (0:4), rep(1, 7), rep(0.9, 3), 0.02)
#' )
#' 
#' print(modelFile)
#' 
#' modelFile2 <- reorderEMBglm(
#'   modelFile,
#'   c(3, 1, 2)
#' )
#' 
#' print(modelFile2)

reorderEMBglm <- function(
  model,
  newIndex
){
  # Validate model
  validate.EMBglm(model)
  
  # Get factor columns and tables
  FacCols <- colnames(model)[substr(colnames(model), 1, 6) == "Factor"]
  tables <- unique(model[, FacCols, with=FALSE])
  
  # Validate newIndex
  if (! is.numeric(newIndex)){
    stop("newIndex must be numeric")
  }
  if (! all(newIndex %in% seq_len(nrow(tables)))){
    stop(paste0("newIndex must be an integer between 1 and ", nrow(tables)))
  }
  if (anyDuplicated(newIndex)){
    stop("Duplicates in newIndex")
  }
  
  # Fill newIndex
  newIndex <- c(newIndex, setdiff(seq_len(nrow(tables)), newIndex))
  
  # Find type of original model
  type <- attributes(model)$type
  
  # Build new version of model
  newModel <- as.EMBglm(
    rbindlist(
      lapply(
        newIndex,
        function(i){
          merge(model, tables[i], by=FacCols)
        }
      )
    ),
    type = type
  )
  
  # Return
  return(newModel)
}
#########################


#####  EMBmodelMerge  #####
#' Create a combined file from two EMB model specifications
#'
#' @description \code{EMBmodelMerge} will create an amalgamation of two or more model files in the format output by EMBlem.
#' This enables the user to create a composite file, which can then score new data on multiple models simultaneously
#' via \code{scoreAgainstCSV} or \code{predict}.
#' @param models A list of EMBglm objects to merge together.
#' @param names Either NULL (default) or a character vector the same length as models with names to be used as suffixes of columns to avoid naming conflicts.
#' @param upperFlag logical. If true, all of the values in 'factor columns' are converted to upper case. This can aid in matching.
#' @param standardise logical. If true, the rating tables are ordered first by interaction depth and then alphabetically
#' (Factor1, ..., FactorN),
#' if no facFile is specified or in the order from the facFile (again, Factor1, ..., FactorN) if one is specified.
#' Also, the order of factors within a rating table will be based first on the number of levels (lowest to highest),
#' and then the same order as the ordering of tables (alphabetically or the order from the facFile).
#' The rows in the tables will be ordered using an order as consistent as possible with the original models as possible if
#' no facFile is specified, or in the order from the facFile otherwise.
#' This ordering is applied by table (Level1, ..., LevelN).
#' If false, all orderings will be as consistent with the initial models as possible.
#' @param rebase logical. If true, a facFile must be specified. This will rebase the tables so that the predictions
#' are identical but any row with a base level will be set to the identity
#' (1 for multiplicative models, 0 for additive models, 0.5 for logistic models).
#' @param facFile Optional. An object of class EMBlemFacFile, EMBlemModel, or EMBlemModelMap.
#' If specified, and if standardise or rebase is true, this will be used to ensure consistency with the output,
#' and orders and rebasing will be based on the factors, levels and base levels in this object.
#' @param type the type attribute of the merged model file, if not already set in one of the original models. 
#' \code{EMBmodelMerge} will append these to the column names of any value columns which exist in both mod1 and mod2,
#' AND to any column which is just called "Value."
#'
#' @return returns an EMBglm object.
#' @export
#'
#' @examples
#' modelFile <- data.table (Factor1 = c("",rep ("Age",10),rep("NCDYears",5)),Level1 = c("",31:40, 0:3,"4+" ),
#'Value = c (0.02,1.5 - 0.1* (0:9), 1.5-0.2*(0:4) ) )
#'
#'modelFile2 <- data.table(Factor1 = c("", rep ("NCDYears",15)),
#'                         Factor2 =c (rep("",6),rep("Occupation",10)),
#'                         Level1 = c("",rep (c( 0:3,"4+" ),3)),
#'                         Level2 = c(rep("",6), rep ("Numismatist",5), rep( "Baker",5)),
#'                         Value =  c (0.02,1.5-0.2*(0:4), rep (1,7), rep (0.9,3)) )
#'
#'modMerge <- EMBmodelMerge(list(modelFile,modelFile2),names = c("Age", "Occupation"))
#'head (modMerge)
#'rm (modelFile)
#'rm (modelFile2)
#'rm (modMerge)
#'

EMBmodelMerge <- function(
  models,
  names = NULL,
  upperFlag = FALSE,
  standardise = FALSE,
  rebase = FALSE,
  facFile = NULL,
  type = NULL
){
  #### Validation
  # Models
  if (! is.list(models)){
    stop("models must be a list of EMBglms to merge")
  }
  if (length(models) < 1){
    stop("models must be a list with minimum length of 1")
  }
  # Put all to EMBglm class (also checks that they are valid EMBglm objects)
  models <- lapply(models, as.EMBglm)
  
  # Take local copies so we don't change anything in the global environment
  models <- lapply(models, copy)
  
  # Names
  if (is.null(names)){
    names <- paste0(".", seq_along(models))
  } else{
    if (! is.character(names)){
      stop("names must be a character vector")
    }
    if (length(names) != length(models)){
      stop("names must be the same length as models")
    }
    if (any(duplicated(names))){
      stop("names must be unique")
    }
  }
  
  # type
  # Find type if NULL
  if (is.null(type)){
    modelTypes <- unique(
      unlist(
        lapply(
          models,
          function(x){
            attributes(x)$type
          }
        )
      )
    )
    if (length(modelTypes) == 1){
      type <- modelTypes[[1]]
    } else{
      if (length(modelTypes) > 1){
        warning(
          paste0("You are merging models with inconsistent 'type' attributes.")
        )
      }
    }
    # Otherwise validate type argument
  } else{
    if (!(is.character(type) & length(type) == 1)){
      stop("type must be character of length 1")
    }
    if (! type %in% c("Multiplicative", "Additive", "Logistic")){
      stop("type must be NULL or one of 'Multiplicative', 'Additive', 'Logistic'")
    }
  }
  
  # upperFlag, standardise, rebase
  if (! all(sapply(list(upperFlag, standardise, rebase), is.logical))){
    stop("upperFlag, standardise and rebase must be logical")
  }
  if (! all(sapply(list(upperFlag, standardise, rebase), function(x) length(x) == 1))){
    stop("upperFlag, standardise and rebase must be length 1")
  }
  if (anyNA(c(upperFlag, standardise, rebase))){
    stop("upperFlag, standardise and rebase must not be missing")
  }
  
  
  #### Interaction depth
  # Find Interaction depth of each model
  nFacList <- sapply(
    models,
    function(x){
      length(grep("Factor", colnames(x)))
    }
  )
  # Overall interaction depth
  nFac <- max(nFacList)
  
  # Factor columns
  FacCols <- paste0("Factor", seq(1, nFac))
  # Level columns
  LevCols <- paste0("Level", seq(1, nFac))
  
  # Create blank columns so they have the same number of Factor and Level cols
  for (i in which(nFacList < nFac)){
    for (j in seq(nFacList[i] + 1, nFac)){
      set(models[[i]], j = paste0("Factor", j), value = "")
      set(models[[i]], j = paste0("Level", j), value = "")
    }
    setcolorder(models[[i]], c(FacCols, LevCols))
  }
  
  #### Upper flag
  # If upper flag is set, put all factors to upper case
  if (upperFlag){
    for (i in seq_along(models)){
      for (j in seq_len(nFacList[i])){
        set(
          models[[i]],
          j = paste0("Factor", j),
          value = toupper(models[[i]][[paste0("Factor", j)]])
        )
      }
    }
  }
  
  
  #### Column names
  # All other columns
  cols <- lapply(
    models,
    function(x){
      colnames(x)[which(!colnames(x) %in% c(FacCols, LevCols))]
    }
  )
  
  # Check for conflicts then change
  conflictNames <- unique(unlist(cols)[which(duplicated(unlist(cols)))])
  for (i in seq_along(models)){
    namesToChange <- cols[[i]][which(cols[[i]] %in% conflictNames)]
    if (length(namesToChange) > 0){
      setnames(models[[i]], namesToChange, paste0(namesToChange, names[[i]]))
    }
  }
  
  # Value columns
  ValCols <- lapply(
    models,
    function(x){
      grep("Value", colnames(x), value = TRUE)
    }
  )
  # Other columns
  otherCols <- lapply(
    seq_along(models),
    function(i){
      colnames(models[[i]])[which(!colnames(models[[i]]) %in% c(FacCols, LevCols, ValCols[[i]]))]
    }
  )
  # Temporarily change "Other" names to allow us to add new columns without clashing
  for (i in seq_along(models)){
    if (length(otherCols[[i]]) > 0){
      setnames(models[[i]], otherCols[[i]], paste0("Other", otherCols[[i]]))
    }
  }
  
  # Add row number as new column
  models <- lapply(models, function(x) x[, rowNum := .I])
  
  
  ### Rating tables
  # Find list of tables within each model
  tblDtList <- lapply(
    seq_along(models),
    function(i){
      unique(models[[i]][, paste0("Factor", seq_len(nFac)), with=FALSE])
    }
  )
  
  # Turn data.tables into a list of character vectors
  tblCharList <- lapply(
    tblDtList,
    function(x){
      lapply(
        seq_len(nrow(x)),
        function(i){
          as.vector(as.matrix(x[i, ]))
        }
      )
    }
  )
  
  # Drop characters of length zero
  tblCharList <- lapply(
    tblCharList,
    function(x){ 
      lapply(
        x, 
        function(y){
          y[which(y != "")]
        }
      )
    }
  )
  
  # Ways
  ways <- lapply(tblCharList, function(x) sapply(x, length))
  
  # Check ways is ascending
  waysDiff <- lapply(ways, diff)
  waysAscending <- sapply(waysDiff, function(x) all(x > 0))
  
  # Add in buffers to tblCharList
  tblCharListBuffered <- lapply(
    seq_along(tblCharList),
    function(i){
      if (waysAscending[i]){
        n <- c(1, which(waysDiff[[i]] > 0) + 1)
        w <- ways[[i]][n]
        ind <- c(seq_along(tblCharList[[i]]), n - 0.5, Inf)
        x <- c(tblCharList[[i]], lapply(c(w, max(w) + 1), list))
        return(x[order(ind)])
      } else {
        return(tblCharList[[i]])
      }
    }
  )
  
  # Tables for the return
  rtnTblCharList <- orderingListFunction(tblCharListBuffered)
  rtnTblCharList <- rtnTblCharList[which(! sapply(rtnTblCharList, is.list))]
  
  ### Factors and Levels
  # Unique factors across all
  factors <- unique(unlist(rtnTblCharList))
  
  # Levels for each factor
  levels <- lapply(
    factors,
    function(fac){
      orderingFunction(
        lapply(
          seq_along(models),
          function(i){
            nFac_ <- nFacList[i]
            dt <- rbindlist(
              lapply(
                seq_len(nFac_),
                function(j){
                  dt_ <- models[[i]][, c(paste0(c("Factor", "Level"), j), "rowNum"), with = FALSE]
                  setnames(dt_, names(dt_), c("Factor", "Level", "rowNum"))
                  dt_ <- dt_[Factor == fac]
                  dt_[, facNum := j]
                  return(dt_)
                }
              )
            )
            setkey(dt, rowNum, facNum)
            return(unique(dt[, Level]))
          }
        )
      )
    }
  )
  
  # Remove row number as new column
  models <- lapply(models, function(x) x[, rowNum := NULL])
  
  # Put levels into a data table
  dtLevels <- rbindlist(
    c(
      list(data.table(Factor = "", Level = "", levNum = 1)),
      lapply(
        seq_along(factors),
        function(i){
          dt <- data.table(
            Factor = factors[[i]],
            Level = levels[[i]]
          )
          dt[, levNum := .I]
          return(dt)
        }
      )
    )
  )
  
  
  ### Create skeleton return table
  # Put full set of return tables into a data table
  dtTables <- rbindlist(
    lapply(
      rtnTblCharList,
      function(x){
        mat <- matrix(rep("", nFac), nrow = 1)
        mat[seq_along(x)] <- x
        dt <- as.data.table(mat)
        setnames(dt, paste0("Factor", seq_len(nFac)))
        return(dt)
      }
    )
  )
  dtTables[, tblNum := .I]
  
  # Set key on levels table for merge
  setkey(dtLevels, Factor)
  
  # Create skeleton table
  dtFinal <- dtTables
  for (i in seq_len(nFac)){
    setkeyv(dtTables, paste0("Factor", i))
    dtFinal <- merge(
      dtFinal,
      dtLevels,
      by.x = paste0("Factor", i),
      by.y = "Factor",
      allow.cartesian = TRUE
    )
    setnames(dtFinal, c("Level", "levNum"), paste0(c("Level", "levNum"), i))
  }
  
  setkeyv(dtFinal, c("tblNum", paste0("levNum", seq_len(nFac))))
  setcolorder(dtFinal, c(paste0("Factor", seq_len(nFac)), paste0("Level", seq_len(nFac))))
  
  dtFinal[, rowNum := .I]
  dtFinal[, c("tblNum", paste0("levNum", seq_len(nFac))) := NULL]
  
  
  ### Fix alias tables
  # Fix the table list
  tblCharList <- lapply(
    tblCharList,
    function(x){
      lapply(
        x,
        function(y){
          ind <- which(
            sapply(
              rtnTblCharList,
              function(z){
                setequal(y, z)
              }
            )
          )
          return(rtnTblCharList[[ind]])
        }
      )
    }
  )
  
  # Fix the individual models
  models <- lapply(
    seq_along(models),
    function(i){
      fixAliasTables(models[[i]], tblCharList[[i]])
    }
  )
  
  ### Put flesh on skeleton
  # Merge on model by model
  for (i in seq_along(models)){
    dtFinal <- merge(
      dtFinal,
      models[[i]],
      by = c(FacCols, LevCols),
      all.x = TRUE
    )
  }
  
  # Reorder rows and columns
  setkey(dtFinal, rowNum)
  dtFinal[, rowNum := NULL]
  if (length(unlist(otherCols)) > 0){
    setnames(dtFinal, paste0("Other", unlist(otherCols)), unlist(otherCols))
  }
  setcolorder(dtFinal, c(FacCols, LevCols, unlist(ValCols), unlist(otherCols)))
  
  # Fix missing values
  if (is.null(type)){
    I0 <- 1
  } else{
    if (type == "Additive"){
      I0 <- 0
    } else if (type == "Logistic"){
      I0 <- 0.5
    } else{
      I0 <- 1
    }
  }
  
  for (col in unlist(ValCols)){
    if (anyNA(dtFinal[[col]])){
      set(dtFinal, j = col, value=ifelse(is.na(dtFinal[[col]]), I0, dtFinal[[col]]))
    }
  }
  
  # Convert to EMBglm with correct type
  dtFinal <- as.EMBglm(dtFinal, type=type)
  
  # Standardise or rebase if needed
  if (rebase){
    dtFinal <- rebaseEMBglm(dtFinal, facFile=facFile, type=type)
    if (! standardise){
      cat("Note: standardise = FALSE ignored since rebase = TRUE\n")
    }
  } else if (standardise){
    dtFinal <- standardiseEMBglm(dtFinal, facFile=facFile, type=type)
  }
  
  # return
  return(dtFinal)
}
###########################


#####  standardiseEMBglm  #####
#' Function to re-format a rating table object (object with class EMBglm.)
#' @description The function takes an object of class EMBglm (Emblem-style rating tables)
#' and reformats to a standard format (Intercept exists and is the first row, all 1-way tables exist for all factors used, etc.)
#' @usage standardiseEMBglm(EMBglm, facFile, type=NULL)
#' @param EMBglm An object of class EMBglm.
#' @param facFile Optional. An object of class EMBlemFacFile, EMBlemModel, or EMBlemModelMap.
#' If specified the function will ensure all levels and factors are consistent with the facFile.
#' @param type Set to "Additive", "Mutiplicative" or "Logistic".
#' If not set, defaults to the type attribute of the EMBglm object.
#' @return An object of class EMBglm which will produce identical predictions to the original.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set setcolorder
#' @examples
#' # standardiseEMBglm(myEMBglm, myFACfile)
#' @export

standardiseEMBglm <- function(EMBglm, facFile=NULL, type=NULL){
  
  # Validation
  if (! "EMBglm" %in% class(EMBglm)) stop("EMBglm must be of class EMBglm")
  validate.EMBglm(EMBglm)
  if (! is.null(facFile)){
    if ("EMBlemFacFile" %in% class(facFile)){
      facFile <- EMBlemFacFile(facFile)
    } else if ("EMBlemModel" %in% class(facFile)){
      facFile <- EMBlemFacFile(facFile@facFile)
    } else if ("EMBlemModelMap" %in% class(facFile)){
      facFile <- EMBlemFacFile(facFile@facFile)
    } else stop("facFile must be of class EMBlemFacFile, EMBlemModel or EMBlemModelMap.")
  }
  
  # Take copies to avoid changing anything in the parent environment
  EMBglm <- copy(EMBglm)
  if (! is.null(facFile)){
    facFile <- copy(facFile)
  }
  
  # Get the type attribute from the input EMBglm if argument set to NULL
  if (is.null(type)){
    if (! is.null(attributes(EMBglm)$type)){
      type <- attributes(EMBglm)$type
      origType <- type
    } else {
      type <- "Multiplicative"
      origType <- NULL
    }
  } else{
    # Otherwise Validate type argument
    if (!is.character(attributes(object)$type)) stop("The type attribute is invalid")
    if (length(attributes(object)$type) != 1) stop("The type attribute is not valid")
    if (! attributes(object)$type %in% c("Multiplicative", "Additive", "Logistic")){
      stop("The type attribute should be 'Multiplicative', 'Additive', or 'Logistic'")
    }
    origType <- type
  }
  
  # Identity
  if (type == "Multiplicative"){
    I0 <- 1
  } else if (type == "Additive"){
    I0 <- 0
  } else{
    I0 <- 0.5
  }
  
  # Find the value columns
  valCols <- grep("Value", colnames(EMBglm), value = TRUE)
  
  # Number of factor columns
  facCols <- colnames(EMBglm)[substr(colnames(EMBglm), 1, 6) == "Factor"]
  nFac <- length(facCols)
  
  # Other columns
  otherCols <- colnames(EMBglm)[which(! colnames(EMBglm) %in% c(valCols, paste0("Factor", seq(1, nFac)), paste0("Level", seq(1, nFac))))]
  if (length(otherCols) > 0){
    origOtherCols <- otherCols
    otherCols <- paste0("OtherCol", 1:length(otherCols))
    setnames(EMBglm, origOtherCols, otherCols)
  }
  levCols <- paste0("Level", seq(1, nFac))
  
  
  # Is there an intercept?
  interceptUsed <- EMBglm[, any(Factor1=="")]
  
  # If no intercept, add one
  if(! interceptUsed){
    icptRow <- data.table(Factor1="")
    if (nFac > 1){
      for (i in 2:nFac){
        set(icptRow, j=paste0("Factor", i), value="")
      }
    }
    for (i in 1:nFac){
      set(icptRow, j=paste0("Level", i), value="")
    }
    for (x in valCols){
      set(icptRow, j=x, value=I0)
    }
    EMBglm <- as.EMBglm(rbindlist(list(icptRow, EMBglm), fill=TRUE))
  }
  
  # Tables in EMBglm
  tables <- unique(EMBglm[, facCols, with=FALSE])
  tables[, ways := sapply(1:nrow(tables), function(i){
    nFac - length(which(tables[i] == ""))
  })]
  
  # Reduce EMBglm if max(ways) < nFac
  if (max(tables$ways) < nFac){
    nFac <- max(tables$ways)
    facCols <- paste0("Factor", 1:nFac)
    levCols <- paste0("Level", 1:nFac)
    EMBglm <- EMBglm[, c(facCols, levCols, valCols, otherCols), with=FALSE]
    tables <- tables[, c(facCols, "ways"), with=FALSE]
  }
  
  # Factors in EMBglm
  factors <- unique(rbindlist(lapply(seq(1, nFac), function(i){
    dt <- EMBglm[, paste0("Factor", i), with=FALSE]
    setnames(dt, "Factor")
    return(dt)
  })))
  factors <- factors[Factor != ""]
  
  # Factors in facFile
  if (! is.null(facFile)){
    factors2 <- data.table(Factor = names(facFile@factors))
    if (any(! factors$Factor %in% factors2$Factor)){
      stop("At least one factor in the EMBglm object is not contained in the facFile.")
    }
    # Get order
    factors2[, order := .I]
    setkey(factors, Factor)
    setkey(factors2, Factor)
    factors <- merge(factors, factors2)
  } else{
    factors[, order := .I]
  }
  setkey(factors, order)
  
  # Get EMBglm data into list as this make the next step easier
  setkeyv(EMBglm, facCols)
  EMBglmList <- lapply(1:nrow(tables), function(i){
    tbl <- tables[i, facCols, with=FALSE]
    setkeyv(tbl, facCols)
    return(EMBglm[tbl])
  })
  
  # Re-order factors within table
  for (i in 1:nrow(tables)){
    ways <- tables[i, ways]
    if (ways > 0){
      facs <- as.character(tables[i, facCols, with=FALSE])
      facs <- facs[1:ways]
      reorder <- 1:nFac
      reorder[1:ways] <- rank(match(facs, factors$Factor))
      if (any(reorder != 1:nFac)){
        setnames(EMBglmList[[i]], c(facCols, levCols), c(paste0("Factor", reorder), paste0("Level", reorder)))
        EMBglmList[[i]] <- EMBglmList[[i]][, c(facCols, levCols, valCols, otherCols), with=FALSE]
        for (j in 1:nFac){
          set(tables, i, j=paste0("Factor", reorder[j]), value=facs[j])
        }
      }
    }
  }
  # Recombine list back into data table and replace EMBglm
  EMBglm <- rbindlist(EMBglmList)
  
  # Levels in EMBglm
  levels <- unique(rbindlist(lapply(seq(1, nFac), function(i){
    dt <- EMBglm[, paste0(c("Factor", "Level"), i), with=FALSE]
    setnames(dt, c("Factor", "Level"))
    dt <- dt[Factor != ""]
    return(dt)
  })))
  levels[, order := 1:.N, by="Factor"]
  
  
  # Get levels from facFile and check all levels in EMBglm exist in facFile
  if (! is.null(facFile)){
    levels2 <- rbindlist(lapply(factors$Factor, function(x){
      dt <- data.table(Factor=x, Level=facFile@factors[[x]]@levels)
    }))
    levels2[, order2 := 1:.N, by="Factor"]
    
    setkey(levels, Factor, Level)
    setkey(levels2, Factor, Level)
    levels <- merge(levels, levels2, all.x=TRUE, all.y=TRUE)
    if (anyNA(levels$order2)) stop("At least one factor level in the EMBglm object is not contained in the facFile.")
    if (anyNA(levels$order)){
      warning(paste0("At least one factor level in the facFile is not in the EMBglm object.",
                     "\nThese will be added and given values the same as their base level."))
      ### This bit assumes EMBglmList is still a valid representation of EMBglm ###
      RowsWithNA <- which(is.na(levels$order))
      for (i in RowsWithNA){
        # Find factor and level name to add
        fac <- levels[i, Factor]
        lev <- levels[i, Level]
        # Find base level and check it's in the EMBglm levels
        baseLev <- facFile@factors[[fac]]@baseLevel
        if (is.na(levels[Factor==fac & Level==baseLev, order])){
          stop("The base level is missing for at least one Factor in the EMBglm.")
        }
        # Run through each table. Where the factor is in the table add rows.
        for (j in 1:nrow(tables)){
          facs <- as.character(tables[j, facCols, with=FALSE])
          if (fac %in% facs){
            k <- which(facs==fac)
            newRows <- EMBglmList[[j]][eval(parse(text=paste0("Level", k, "==baseLev")))]
            newRows[, eval(parse(text=paste0("Level", k, ":=lev")))]
            newRows[, c(otherCols) := NULL]
            EMBglmList[[j]] <- rbindlist(list(EMBglmList[[j]], newRows), fill=TRUE)
          }
        }
      }
      # Recombine list back into data table and replace EMBglm
      EMBglm <- rbindlist(EMBglmList)
    }
    # Put levels in the right order
    setkey(levels, Factor, order2, order)
    levels[, order := 1:.N, by="Factor"]
    levels[, order2 := NULL]
  }
  
  # Look for missing tables
  tblMat <- as.matrix(tables[, facCols, with=FALSE])
  tblList <- lapply(
    1:nrow(tblMat),
    function(i){
      x <- tblMat[i, ]
      return(unique(x[which(x != "")]))
    } 
  )
  
  # All tables that are needed
  requiredTbls <- 
    unique(
      do.call(
        c,
        lapply(
          tblList,
          function(x){
            ways <- length(x)
            if (ways > 1){
              return(do.call(c, lapply(1:ways, function(i) combn(x, i, simplify = FALSE))))
            } else{
              return(list(x))
            }
          }
        )
      )
    )
  # Missing tables
  missingTbls <- setdiff(requiredTbls, tblList)
  
  # Add missing tables
  ### This bit assumes EMBglmList is still a valid representation of EMBglm ###
  for (x in missingTbls){
    ways <- length(x) 
    levs <- vector(mode="list", length=nFac)
    for (i in 1:nFac){
      if (i <= ways){
        levs[[i]] <- levels[Factor==x[i], Level]
      } else levs[[i]] <- ""
    }
    newTbl <- data.table(expand.grid(levs))
    names(newTbl) <- levCols
    newTbl <- alloc.col(newTbl)
    for (i in 1:nFac){
      if (i <= length(x)){
        set(newTbl, j=facCols[i], value=x[i])
      } else{
        set(newTbl, j=facCols[i], value="")
      }
    }
    for (i in 1:length(valCols)){
      set(newTbl, j=valCols[i], value=I0)
    }
    newTbl <- newTbl[, c(facCols, levCols, valCols), with=FALSE]
    EMBglmList <- c(EMBglmList, list(copy(newTbl)))
    newTbl[1, ways := ways]
    tables <- rbindlist(list(tables, newTbl[1, c(facCols, "ways"), with=FALSE]))
  }
  # Recombine list back into data table and replace EMBglm
  EMBglm <- rbindlist(EMBglmList, fill=TRUE)
  
  # Set table order
  tables[, currentOrder := .I]
  setkey(factors, Factor)
  for (i in 1:nFac){
    setkeyv(tables, paste0("Factor", i))
    tables <- merge(tables, factors, by.x=key(tables), by.y="Factor", all.x=TRUE)
    setnames(tables, "order", paste0("order", i))
  }
  setkeyv(tables, c("ways", paste0("order", 1:nFac)))
  tables[, newOrder := .I]
  ### This bit assumes EMBglmList is still a valid representation of EMBglm ###
  if (any(tables[, currentOrder != newOrder])){
    EMBglmList2 <- lapply(1:nrow(tables), function(i){
      EMBglmList[[tables[i, currentOrder]]]
    })
    # Recombine list back into data table and replace EMBglm
    EMBglm <- rbindlist(EMBglmList2, fill=TRUE)
  }
  tables <- tables[, c(facCols, "ways"), with=FALSE]
  
  
  # Set row order within tables
  levels <- rbindlist(list(data.table(Factor="", Level="", order=1), levels))
  setkey(levels, Factor, Level)
  
  # Generate EMBglmList again in case things have changed
  setkeyv(EMBglm, facCols)
  EMBglmList <- lapply(1:nrow(tables), function(i){
    tbl <- tables[i, facCols, with=FALSE]
    setkeyv(tbl, facCols)
    return(EMBglm[tbl])
  })
  EMBglmList <- lapply(EMBglmList, function(x){
    for (i in 1:nFac){
      setkeyv(x, paste0(c("Factor", "Level"), i))
      x <- merge(x, levels, by.x=key(x), by.y=key(levels))
      setnames(x, "order", paste0("order", i))
    }
    setkeyv(x, paste0("order", 1:nFac))
    x <- x[, c(facCols, levCols, valCols, otherCols), with=FALSE]
    return(x)
  })
  # Recombine list back into data table and replace EMBglm
  EMBglm <- rbindlist(EMBglmList)
  
  # Rename other cols
  if (length(otherCols) > 0){
    setnames(EMBglm, otherCols, origOtherCols)
  }
  
  # Return
  return(as.EMBglm(EMBglm, type=origType))
  
}

###########################


#####  rebaseEMBglm  #####
#' Function to re-format a rating table object (object with class EMBglm.)
#' @description The function takes an object of class EMBglm (Emblem-style rating tables)
#' and reformats so that all base levels in all tables are re-based to 1. Needs a second object containing the base levels for each factor.
#' This can be an object of any of the following classes: EMBlemFacFile, EMBlemModel, EMBlemModelMap.
#' @usage rebaseEMBglm(EMBglm, facFile, type=NULL)
#' @param EMBglm An object of class EMBglm.
#' @param facFile An object of class EMBlemFacFile, EMBlemModel, or EMBlemModelMap
#' @param type If the model is additive or logistic, set type to either "Additive" or "Logistic" respectively.
#' (if not set, defaults to the type attribute of the EMBglm object, or mulitiplicative if not found.)
#' @return An object of class EMBglm where all base levels in all tables have relativity 1
#' (alternatively if this is an additive or logistic model, these will be 0 or 0.5 respectively).
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set setcolorder
#' @examples
#' # rebaseEMBglm(myEMBglm, myFACfile)
#' @export

rebaseEMBglm <- function(EMBglm, facFile, type=NULL){
  
  # Standardise to start
  EMBglm <- standardiseEMBglm(EMBglm, facFile, type)
  
  # Get type for use in the function and retain original argument
  origType <- type
  if (is.null(type)){
    if (! is.null(attributes(EMBglm)$type)){
      type <- attributes(EMBglm)$type
      origType <- type
    } else{
      type <- "Multiplicative"
    }
  }
  
  # Get facFile in right format
  if("EMBlemFacFile" %in% class(facFile)){
    facFile <- EMBlemFacFile(facFile)
  } else if("EMBlemModel" %in% class(facFile)){
    facFile <- EMBlemFacFile(facFile@facFile)
  } else if("EMBlemModelMap" %in% class(facFile)){
    facFile <- EMBlemFacFile(facFile@facFile)
  } else stop("facFile must be of class EMBlemFacFile, EMBlemModel or EMBlemModelMap.")
  
  # Divide and multiply function
  if (type == "Multiplicative"){
    multFunc <- function(x, y) x*y
    divFunc <- function(x, y) x/y
  } else if (type == "Additive"){
    multFunc <- function(x, y) x+y
    divFunc <- function(x, y) x-y
  } else{
    multFunc <- function(x, y){
      odds <- x * y / ((1-x) * (1-y))
      return(odds / (1 + odds))
    }
    divFunc <- function(x, y){
      odds <- (x * (1-y)) / (y * (1-x))
      return(odds / (1 + odds))
    }
  }
  
  # Find the value columns
  valCols <- grep("Value", colnames(EMBglm), value = TRUE)
  
  # Number of factor columns
  facCols <- colnames(EMBglm)[substr(colnames(EMBglm), 1, 6) == "Factor"]
  nFac <- length(facCols)
  
  # Other columns
  otherCols <- colnames(EMBglm)[which(! colnames(EMBglm) %in% c(valCols, paste0("Factor", seq(1, nFac)), paste0("Level", seq(1, nFac))))]
  if (length(otherCols) > 0){
    origOtherCols <- otherCols
    otherCols <- paste0("OtherCol", 1:length(otherCols))
    setnames(EMBglm, origOtherCols, otherCols)
  }
  levCols <- paste0("Level", seq(1, nFac))
  
  # Check for out-of-range values
  if (type %in% c("Multiplicative", "Logistic")){
    if (any(sapply(valCols, function(x){
      min(EMBglm[, x, with=FALSE]) <= 0
    }))) stop("Out-of-range values detected.")
  } else if (type == "Logistic"){
    if (any(sapply(valCols, function(x){
      min(EMBglm[, x, with=FALSE]) >= 1
    }))) stop("Out-of-range values detected.")
  }
  
  # Tables in EMBglm
  tables <- unique(EMBglm[, facCols, with=FALSE])
  tables[, tblOrder := .I]
  nTbl <- nrow(tables)
  
  # Factors in EMBglm
  factors <- unique(EMBglm[Factor1 != "", .(Factor=Factor1)])
  
  # Get baseLevels and order for factors from facFile
  set(factors, j="baseLevels", value=sapply(factors$Factor, function(x){
    facFile@factors[[x]]@baseLevel
  }))
  
  # Get EMBglm data into list as this make our life easier
  setkeyv(EMBglm, facCols)
  EMBglmList <- lapply(1:nrow(tables), function(i){
    tbl <- tables[i, facCols, with=FALSE]
    setkeyv(tbl, facCols)
    return(EMBglm[tbl])
  })
  
  # Put row order on each table
  EMBglmList <- lapply(EMBglmList, function(x){
    x[, rowOrder := .I]
    return(x)
  })
  
  # Order tables by factors so we can lookup by factor in the below loop
  setkeyv(tables, facCols)
  
  # Loop through by table starting at the bottom (the tables with highest interaction level)
  if (nTbl > 1){
    for (i in nTbl:2){
      facs <- as.character(tables[tblOrder==i, facCols, with=FALSE])
      ways <- length(which(facs != ""))
      # Loop through each factor in the table
      for (j in 1:ways){
        fac <- facs[j]
        baseLev <- factors[Factor==fac, baseLevels]
        # Re-order table
        setkeyv(EMBglmList[[i]], c(paste0("Level", j), "rowOrder"))
        # Find sub-table
        subFacs <- data.table(t(c(facs[facs != fac], "")))
        names(subFacs) <- facCols
        setkeyv(subFacs, facCols)
        subTbl <- tables[subFacs][, tblOrder]
        # Get matrix of baselevel values
        baseValueMat <- sapply(valCols, function(value){
          EMBglmList[[i]][eval(parse(text=paste0("Level", j, '=="', baseLev, '"'))), value, with=FALSE][[1]]
        })
        baseValueMat <- as.matrix(baseValueMat, ncol=length(valCols))
        # Loop through value columns moving multipliers from table to sub-table
        for (k in 1:length(valCols)){
          # Divide through in table
          set(EMBglmList[[i]], j=valCols[k], value=divFunc(EMBglmList[[i]][[valCols[k]]], baseValueMat[, k]))
          # Multiply through in sub-table
          set(EMBglmList[[subTbl]], j=valCols[k], value=multFunc(EMBglmList[[subTbl]][[valCols[k]]], baseValueMat[, k]))
        }
        # Put table back in the right order
        setkey(EMBglmList[[i]], rowOrder)
      }
    }
  }
  
  # Recombine list back into data table and replace EMBglm
  EMBglm <- as.EMBglm(rbindlist(EMBglmList), type=origType)[, rowOrder := NULL]
  
  # Rename other cols
  if (length(otherCols) > 0){
    setnames(EMBglm, otherCols, origOtherCols)
  }
  
  return(EMBglm)
}

############################

#####  logitEMBglm  #####
#' Function to preprocess EMBglm object built using logit link .
#' @description EMBglm functions have been written assuming a log link based model. The function takes an EMBglm object detailing a
#' logit - link model (ie binomial model) and preprocesses it to allow other EMBglm functions to work- removing the logit and replacing it with log.
#' the transformation between these is x <- x/(1-x) and its inverse is x <- x(1+x). 
#' @note this function is now largely deprecated as you can specify an
#' EMBglm object as having a logit link
#' @usage logitEMBglm(object)
#' @param object The object to process.
#' @note this function is now largely deprecated as you can specify an
#' EMBglm object as having a logit link
#' @return modified EMBglm object.
#' @author Tom Bratcher (tom.bratcher@)
#' @examples
#' 
#' ## Compare with example in \code {predict.EMBglm}:
#' 
#' modelFile <- data.table(
#' Factor1 = c("",rep ("Age",10),rep("NCDYears",5)),
#' Level1 = c("", 31:40, 0:3, "4+"),
#' Value = c(0.3, 0.6 - 0.02 * (0:9), 0.8 - 0.1 * (0:4)))
#' 
# ## A very simple binomial model as a function of Age and NCD years;
# '
#' dt <- data.table(
#'  policyNo = 1:100, Age = sample (31:40, 100, replace = TRUE),
#'  NCDYears = sample (0:5, 100, replace = TRUE))
#' preds <- predict(logitEMBglm(as.EMBglm(modelFile)),
#'  newdata = dt, NAstops = FALSE)
#' preds <- preds / (1+preds)
#' 
#' @export
#' 

logitEMBglm <- function (object){
  if (! ("EMBglm" %in% class(object))) stop("object must be of class EMBglm")
  
  for (nm in grep("^Value", names(object))) object[[nm]] <- object[[nm]]/(1 - object[[nm]])
  return(object)
}  


#####  delogitEMBglm  #####
#' Function to postprocess EMBglm object back into logit link form.
#' @description Inverse function for logitEMBglm
#' @usage delogitEMBglm(object)
#' @param object The object to process.
#' @return modified EMBglm object.
#' @author Tom Bratcher (tom.bratcher@)
#' @export
#' 

delogitEMBglm <- function (object){
  if (! ("EMBglm" %in% class(object))) stop("object must be of class EMBglm")
  
  for (nm in grep("^Value", names(object))) object[[nm]] <- object[[nm]]/(1 + object[[nm]])
  return(object)
}  


#####  summary.EMBglm  #####
#' Print details of EMBglm objects.
#' @description Function to print high level details of an EMBglm object to the console.
#' @usage summary.EMBglm(object)
#' @param object The object to process.
#' @return Returns NULL (prints to console only).
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export
#'

summary.EMBglm <- function(object){
  # Does object have class EMBglm
  rightClass <- "EMBglm" %in% class(object)
  
  # If object is not a data frame then return an error
  if (! is.data.frame(object)){
    stop(paste0(
      "Object must be a data.frame to be a valid EMBglm model.",
      if (rightClass){
        paste0("\nIn addition, your object is officially of class EMBglm despite failing the validation.",
               "\nThis could be highly problematic and I suggest something has gone very wrong!")
      }
    ))
  }
  
  # Check for validity
  if (! is.data.table(object)){
    tc <- try(validate.EMBglm(as.data.table(object)), silent=TRUE)
    if (! "try-error" %in% class(tc)){
      if (rightClass){
        warning(
          paste0("Your object is officially of class EMBglm and is a valid EMBglm object, except that it isn't a data.table.",
                 "\nThis could be very bad for a number of reasons!",
                 "\nUse code like:\n   object <- as.EMBglm(object)\n...to fix this.")
        )
      }
    }
  } else{
    tc <- try(validate.EMBglm(object), silent=TRUE)
  }
  
  # If not valid throw error
  if ("try-error" %in% class(tc)){
    stop(paste0(
      "Object is not a valid EMBglm model and fails validation with the following message:\n",
      tc[[1]],
      if (rightClass){
        paste0("In addition, your object is officially of class EMBglm despite failing the validation.",
               "\nThis could be highly problematic and I suggest something has gone very wrong!")
      }
    ))
  }
  
  if (! rightClass){
    warning(
      paste0("Your object is a valid EMBglm object, but not officially of class EMBglm.",
             "\nUse code like:\n   object <- as.EMBglm(object)\n...to fix this.")
    )
  }
  
  # take local copy to avoid changing the parent environment
  object <- copy(object)
  
  FacCols <- colnames(object)[substr(colnames(object), 1, 6) == "Factor"]
  valCols <- colnames(object)[substr(colnames(object), 1, 5) == "Value"]
  nFac <- length(FacCols)
  nVal <- length(valCols)
  ratingTbls <- unique(object[, FacCols, with=FALSE])
  type <- attributes(object)$type

 
  setkeyv(object, FacCols)
  ratingTblList <- lapply(seq(1, nrow(ratingTbls)), function(i){
    facs <- ratingTbls[i]
    ways <- nFac - length(which(facs == ""))
    setkeyv(facs, FacCols)
    rtTbl <- object[facs]
    if(ways==0) rtTbl <- rtTbl[, valCols, with=FALSE] else{
      setnames(rtTbl, paste0("Level", seq(1, ways)), as.character(facs)[seq(1, ways)])
      setkeyv(rtTbl, as.character(facs)[seq(1, ways)])
      rtTbl <- rtTbl[, (FacCols):=NULL]
      if(ways < nFac) rtTbl <- rtTbl[, (paste0("Level", seq(ways+1, nFac))) := NULL]
    }
    setnames(rtTbl, valCols, paste0(i, "_", valCols))
    return(rtTbl)
  })
  
  ways <- sapply(ratingTblList, function(x) length(key(x)))
  
  tbls <- sapply(ratingTblList, function(x) paste0(key(x), collapse=" * "))
  tbls[ways==0] <- "(Intercept)"
  tbls <- tbls[order(ways)]
  
  cat(
    paste0(
      "\nEMBglm object summary",
      "\n*********************",
      "\nNo. models: ", nVal,
      "\nType: ", if (is.null(type)) "NULL" else type,
      "\nNo. rating tables: ", length(ratingTblList),
      "\n",
      paste0(paste0("  ", tbls), collapse = "\n"),
      "\n"
    )
  )
  
}

###########################################

  