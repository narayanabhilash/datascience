#' Extract components of an address
#' 
#' @description \code{parseAddress} attempts to extract the flat number, house number, house
#' name and street from an address string.
#' 
#' The algorithm used by \code{parseAddress} is likely to change as the package
#' evolves, but currently the process is as follows:\cr First, if any string
#' begins with "Flat <number>", "Room <number>" or "Apartment <number>"
#' (including the abbreviations "Apt" and "Apt."), this is deemed to be the
#' flat number, and is assigned as such and stripped from the front.\cr Then,
#' if there is a number remaining in an element, the format is deemed to be
#' "<house name> <number> <street>".\cr If there is no number but either a
#' comma or the word "house" or "cottage", then the comma or word (and optional
#' space after) is deemed to separate the house name and street, and the number
#' is unknown.\cr Lastly if there is no other clue as to where the house name
#' ends and the street begins, the last two words are deemed to be the street
#' and anything before that is the house name.
#' @usage parseAddress(x)
#' @param x Character vector of raw address strings to process.
#' @return A list with four components, \code{flatNumber}, \code{Number},
#' \code{houseName} and \code{street} containing the extracted components of
#' \code{x}.
#' @note \code{parseAddress} is case-insensitive for matching purposes, but the
#' output will have the same case as the input.\cr "Number"s may not be
#' coercible to actual numeric vectors as they may contain non-numeric
#' characters, for example "221b" or "1-6" (or they may be absent entirely, a
#' NA value).
#' @details The algorithm used by \code{parseAddress} is likely to change as the 
#' package evolves, but currently the process is as follows:\cr
#' First, if any string begins with "Flat <number>", "Room <number>" or "Apartment
#'  <number>" (including the abbreviations "Apt" and "Apt."), this is deemed to 
#'  be the flat number, and is assigned as such and stripped from the front.\cr
#' Then, if there is a number remaining in an element, the format is deemed to 
#' be "<house name> <number> <street>".\cr
#' If there is no number but either a comma or the word "house" or "cottage", 
#' then the comma or word (and optional space after) is deemed to separate the 
#' house name and street, and the number is unknown.\cr
#' Lastly if there is no other clue as to where the house name ends and the 
#' street begins, the last two words are deemed to be the street and anything 
#' before that is the house name.

#' @author James Lawrence
#' @seealso \link{regex} for details on regular expression matching and
#' substitution, which underpins this function.
#' @export
#' @examples
#' 
#' ## these work well
#' x1 <- c(
#' 	"RSA Building, St. Mark's Court",
#' 	"RSA Building 1 St. Mark's Court",
#' 	"RSA Building Fenchurch Street",
#' 	"Flat 2 221b Baker Street",
#' 	"221b Baker Street"
#' )
#' ## these don't work so well
#' x2 <- c(
#' 	"RSA Building St. Mark's Court",
#' 	"15-18 The Walkie Talkie 30 Fenchurch Street"
#' )
#' parseAddress(x1)
#' parseAddress(x2)
#' 
parseAddress <- function(x){
	if(!is.character(x)) x <- as.character(x)
	Number <- character(n <- length(x))
	FlatNumber <- character(n)
	houseName <- character(n)
	street <- character(n)
	isAFlat <- grep("([Ff][Ll][Aa][Tt]|[Rr][Oo][Oo][Mm]|[Aa][Pp][Aa][Rr][Tt][Mm][Ee][Nn][Tt]|[Aa][Pp][Tt]\\.?) ?[0-9]+[0-9a-zA-Z]?",x)
	if(!identical(isAFlat,integer(0))){
		FlatNumber[isAFlat] <- gsub("([Ff][Ll][Aa][Tt]|[Rr][Oo][Oo][Mm]|[Aa][Pp][Aa][Rr][Tt][Mm][Ee][Nn][Tt]|[Aa][Pp][Tt]\\.?) *([0-9]+[0-9a-zA-Z]?).*","\\2",x[isAFlat])
		x[isAFlat] <- gsub("([Ff][Ll][Aa][Tt]|[Rr][Oo][Oo][Mm]|[Aa][Pp][Aa][Rr][Tt][Mm][Ee][Nn][Tt]|[Aa][Pp][Tt]\\.?) *[0-9]+[0-9a-zA-Z]?[, ](.*)","\\2",x[isAFlat])
	}
	hasNumber <- grep("[0-9]",x)
	Number[hasNumber] <- gsub(".*?([0-9\\/-]+[a-zA-Z]?).*","\\1",x[hasNumber])
	x[hasNumber] <- gsub("[0-9\\/-]+[a-zA-Z]?","#NUMBER#",x[hasNumber])
	street[hasNumber] <- gsub(".*#NUMBER#[ ,]*(.*)","\\1",x[hasNumber])
	houseName[hasNumber] <- gsub("(.*?)[ ,]*#NUMBER#.*","\\1",x[hasNumber])
	if(identical(hasNumber,integer(0)))ind2 <- seq_along(x) else ind2 <- -hasNumber
	Number[ind2] <- NA
	hasCommaNotNumber <- grep("[Hh][Oo][Uu][Ss][Ee]|[Cc][Oo][Tt][Tt][Aa][Gg][eE]|,",x[ind2])
	street[ind2][hasCommaNotNumber] <- gsub("(.*?)([Hh][Oo][Uu][Ss][Ee]|[Cc][Oo][Tt][Tt][Aa][Gg][eE]|,).*?([^, ][^,]*)","\\3",x[ind2][hasCommaNotNumber])
	houseName[ind2][hasCommaNotNumber] <- gsub("(.*?)([Hh][Oo][Uu][Ss][Ee]|[Cc][Oo][Tt][Tt][Aa][Gg][eE]|,).*[^, ][^,]*","\\1\\2",x[ind2][hasCommaNotNumber])
	if(identical(hasCommaNotNumber,integer(0))) ind3 <- ind2 else ind3 <- seq_along(x)[ind2][-hasCommaNotNumber]
	street[ind3] <- gsub(".* ([A-Za-z']* [A-Za-z']*)","\\1",x[ind3])
	houseName[ind3] <- gsub("(.*) [A-Za-z']* [A-Za-z']*","\\1",x[ind3])
	return(list(FlatNumber=FlatNumber,Number=Number,houseName=houseName,street=street))
}
