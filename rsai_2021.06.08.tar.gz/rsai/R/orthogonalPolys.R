#####  orthogonalPolys  #####
#' Function to convert a vector into a matrix of orthogonal polynomials of order n
#' @description This function takes a vector and, by default returns a matrix of polynomial coefficients which,
#' if applied would create normalised orthogonal polynomials of x up to a certain order.
#' By changing the 'returnPolys' parameter to TRUE, you can directly return the matrix of polynomials
#' @usage orthogonalPolys(x, order, weight=NULL, returnPolys=FALSE)
#' @param x A numerical vector
#' @param order An integer >= 1, the maximum polynomial order to go up to.
#' @param weight Optional weight vector
#' @param returnPolys If TRUE return a matrix of polynomials. If FALSE (default) return a matrix of coefficients that can be used to create orthogonal polynomials.
#' @return A matrix. Depending on the returnPolys parameter, either the polynomial matrix or a matrix of coefficents.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #orthogonalPolys(rnorm(1000), order=5)
#' @export

orthogonalPolys <- function(x, order, weight=NULL, returnPolys=FALSE){
  # Validation
  if(is.null(weight)) weight <- rep(1, length(x))
  if(length(x) != length(weight)) stop("'weight' must be the same length as 'x'")
  
  # Validation
  vec <- x[!is.na(x)]
  if(length(x) != length(vec)) warning("Missing values detected will be ignored/dropped in any output.")
  w <- weight[!is.na(x)]
  if(as.integer(order) != order) stop("'order' must be an integer")
  if(length(order) != 1) stop("'order' must be length 1.")
  if(order < 1) stop("'order' must less than or equal to 1.")
  if(length(vec) < order+1) stop("x is not long enough")
  
  # Mean and standard deviation for scaling (using weights)
  meanVec <- weighted.mean(vec, w)
  sdVec <- sqrt(sum(w * (vec - meanVec)^2)/ sum(w))
  
  # If order is more than 1
  if(order > 1){
    # Create matrix of polynomial powers of x
    mat <- sapply(seq(1, order), function(i) scale(vec, center=meanVec, scale=sdVec)^i)
    # Create dummy return matrix (diagonal/identity matrix)
    returnMatrix <- rbind(rep(0, order), diag(order))
    # For each power >= 2 use coefficients of linear model to fill in values in the return matrix
    for(i in seq(2, order)){
      model <- lm(mat[, i] ~ mat[, seq(1, i-1)], weights=w)
      meanRes <- weighted.mean(model$residuals, w)
      sdRes <- sqrt(sum(w * (model$residuals - meanRes)^2)/ sum(w))
      returnMatrix[1:(i+1), i] <- c(-coefficients(model), 1)/sdRes
    }
    # If we are returning the columns of polynomials rather than the coefficients, simply apply the matrix we just built
    if(returnPolys) {
      returnMatrix <- cbind(rep(1, nrow(mat)), mat) %*% returnMatrix
    # Otherwise we need to combine the matrix with a matrix which does the scaling
    } else{
      # Scaling matrix using mean and standard deviation
      scaleMatrix <- sapply(seq(1, order), function(i){
        c(sapply(seq(0, i), function(j) (choose(i, j)*(-meanVec)^(i-j))/sdVec^(i)), rep(0, order-i))
      })
      # Combine scaling and orthogonalising matrices
      returnMatrix <- cbind(c(1, rep(0, order)), scaleMatrix) %*% returnMatrix
      # Row names
      rownames(returnMatrix) <- c("1", "x", paste0("x^", seq(2, order)))
    }
  # If order is equal to 1
  } else{
    # Return matrix only needs to do scaling
    returnMatrix <- c(-meanVec/sdVec, 1/sdVec)
    if(returnPolys) {
      # If we are returning the columns of polynomials rather than the coefficients, simply apply the matrix we just built
      returnMatrix <- cbind(rep(1, length(x)), vec) %*% returnMatrix
    } else{
      # Make returnMatrix into 2-D matrix and give it row names
      dim(returnMatrix) <- c(2, 1)
      rownames(returnMatrix) <- c("1", "x")
    }
  }
  # Column names
  colnames(returnMatrix) <- paste0("OPoly(", seq(1, order), ")")
  return(returnMatrix)
}