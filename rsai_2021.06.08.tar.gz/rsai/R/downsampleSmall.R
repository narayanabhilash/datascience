#' Stratified sampling for a data frame based on values in a specified column.
#' @description Function to randomly sample down rows of a data table, but keeping all rows where a specified column
#' contains values greater than zero.
#' Result is a stratified sample where the stratification is based on values in the specified column.
#' @usage downsampleSmall(dt, col, sampleRate=0.5, weightCol="weight")
#' @param dt data table or data frame on which to perform sampling
#' @param col Column to stratify the sampling by.
#' Rows where the values of this column are greater than zero will not be sampled.
#' @param sampleRate Rate for sampling rows that don't meet the condition to be kept regardless. Should be between 0 and 1.
#' @param weightCol New column to create in the data containing weights
#' (1 for rows where \code{col} is greater than zero, and 1/sampleRate otherwise.) Set to NULL for no new column.
#' @import data.table 
#' @export


downsampleSmall <- function(dt, col, sampleRate=0.5, weightCol="weight"){
  # Check dt is a data.table
  if(!is.data.table(dt)){
    if(!is.data.frame(dt)) stop("dt must be a data frame")
    dt <- data.table(dt)
    df <- TRUE
  } else df <- FALSE
  
  # Rows not to sample
  rows1 <- which(dt[[col]]>0)
  
  # Set weight column to 1 where no sampling occurs
  if(!is.null(weightCol)) set(dt, i=rows1, j=weightCol, value=1)
  
  # Rows to sample
  n <- nrow(dt)
  if(length(rows1)>0) rows2 <- seq(1, n)[-rows1] else rows2 <- seq(1, nrow(dt))
  
  # Sample rows
  num <- min(max(round(length(rows2)*sampleRate), 1), length(rows2))
  rows2 <- sample(rows2, num, replace = FALSE)
  
  # Combine indices of rows we are keeping and put in original order
  rows <- c(rows1, rows2)
  rows <- rows[order(rows)]
  
  # Filter to only include rows we want
  dt <- dt[rows]
  
  # Set weight column to 1/sampleRate where sampling occurs 
  if(!is.null(weightCol)) set(dt, i=which(is.na(dt[[weightCol]])), j=weightCol, value=(n-length(rows1))/num)
  
  # Convert back to data frame if that was what was input
  if(df){
    dt <- data.frame(dt)
  }
  
  # return
  return(dt)
}