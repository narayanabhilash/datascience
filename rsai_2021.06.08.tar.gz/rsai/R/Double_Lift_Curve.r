### DoubleLiftCurve

#' Produces a double lift curve
#' @description \code{doubleLiftChart} Produces a plotly double lift chart of two models,
#' showing how well the predictions fit to observed. The data is split into bins
#' according to the relative predictions (as a ratio) of the two models.
#' @usage DoubleLiftCurve(Observed,
#'                 Expected_1,
#'                 Expected_2,
#'                 Exposure = NULL,
#'                 Weight = NULL,
#'                 Lower = 0.1,
#'                 Upper = 2,
#'                 Percent = 5,
#'                 Model_1 = "Model 1",
#'                 Model_2 = "Model 2",
#'                 Title = "Double Lift Chart",
#'                 ...)
#' @param Observed Vector of observed data
#' @param Expected_1 Vector of predictions for model 1
#' @param Expected_2 Vector of predictions for model 2
#' @param Exposure Optional vector of exposure periods.
#' Observed data will be divided through by the exposure and exposure will be used to weight results.
#' @param Weight Optional vector of weights.
#' @param Lower Lower cut-off for bandings
#' @param Upper Upper cut-off for bandings
#' @param Percent Width of bandings as a percent
#' @param Model_1 name given to model 1 in chart
#' @param Model_2 name given to model 2 in chart
#' @param Title Title of chart.
#' @param \dots Other parameters to pass through to \code{plot_ly}.
#' @import data.table 
#' @author Aravind Lakshminarayanan (Aravind.Lakshminarayanan@gcc.rsagroup.com)
#' @export

DoubleLiftCurve <- function(Observed, 
                            Expected_1,
                            Expected_2,
                            Exposure = NULL,
                            Weight = NULL,
                            Lower = 0.1,
                            Upper = 2,
                            Percent = 5, 
                            Model_1 = "Model 1",
                            Model_2 = "Model 2",
                            Title = "Double Lift Chart",
                            ...) {
  
  # merge all the necessary columns
  lift_curve_data <- data.table(Observed=Observed,
                                Expected_1 = Expected_1, 
                                Expected_2 = Expected_2)
  
  # Adjust by Exposure
  if(is.null(Exposure)){
    lift_curve_data$Exposure <- 1
  } else{
    lift_curve_data$Exposure <- Exposure
  }
  if(is.null(Weight)){
    lift_curve_data$Weight <- 1
  } else{
    lift_curve_data$Weight <- Weight
  }
  lift_curve_data$Observed <- lift_curve_data$Observed/lift_curve_data$Exposure
  lift_curve_data$Weight <- lift_curve_data$Weight*lift_curve_data$Exposure
  lift_curve_data$Exposure <- NULL
  
  # order by ascending of proportion values
  lift_curve_data$Proportion <- Expected_1/Expected_2
  lift_curve_data <- lift_curve_data[order(lift_curve_data$Proportion),]

  # calculate total weight and break into n bands
  lift_curve_data$Proportion_Banding <- (cut(lift_curve_data$Proportion, breaks = c(0,seq(Lower, Upper, by = Percent/100),Inf),right = FALSE))
  
  # calcualte weighted oberved and fitted for each band
  banded_table <- lift_curve_data[, .(Observed=weighted.mean(Observed, Weight),
                                      Fitted_Model_1=weighted.mean(Expected_1, Weight),
                                      Fitted_Model_2=weighted.mean(Expected_2, Weight),
                                      Weight=sum(Weight)),
                                  keyby=Proportion_Banding]
  
  m <- list(l=50, r=10, b=125, t=50)
  # plot the double lift curve
  p <- plot_ly(banded_table, x = banded_table$Proportion_Banding, y = banded_table$Weight, type = "bar", name = "Weight",
               marker = list(color = '#ffff00', line = list(color = 'rgb(0,0,0)', width = 0.5)),
               hoverinfo = "text",
               text = ~paste(Weight),
               ...) %>%
    add_trace(x = banded_table$Proportion_Banding, y = banded_table$Fitted_Model_1, type = "scatter", mode = "lines+markers", name = Model_1,
              yaxis = "y2",marker = list(color = '#0000FF'),line = list(color = '#0000FF'),
              hoverinfo = "text",
              text = ~paste(Fitted_Model_1)) %>%
    add_trace(x = banded_table$Proportion_Banding, y = banded_table$Fitted_Model_2, type = "scatter", mode = "lines+markers", name = Model_2,
              yaxis = "y2",marker = list(color = '#00FF00'),line = list(color = '#00FF00'),
              hoverinfo = "text",
              text = ~paste(Fitted_Model_2)) %>%
    add_trace(x = banded_table$Proportion_Banding, y = banded_table$Observed, type = "scatter", mode = "lines+markers", name = "Observed",
              yaxis = "y2",marker = list(color = '#FF00FF'),line = list(color = '#FF00FF'),
              hoverinfo = "text",
              text = ~paste(Observed)) %>%
    layout(title = Title,margin=m,
           xaxis = list(title = paste(Model_1,Model_2, sep="/"), autorange= TRUE, showline = TRUE), 
           yaxis = list(side = 'right', title = 'Weight', showgrid = TRUE, zeroline = FALSE),
           yaxis2 = list(side = 'left', overlaying = "y", title = 'Fitted Values', showgrid = FALSE, zeroline = FALSE)) %>%
    print(p)
  
}
