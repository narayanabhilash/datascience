
#' Sorting cantrip
#' @description `sort` can crash when confronted with non atomic data.
#' `SortA` just sorts on the first element.
#' @param x to sort
#'
#' @return sorted x
#' @author Tom Bratcher
#' @export
#' 
#' @examples
#' dt. <- c("apples", "pears", c ("bananas, carrots"))
#' sortA(dt.)
sortA <- function (x){
  x[order(sapply(x, function (y)y[[1]]))]
}