#####  EMBmodelToBeta  #####
#' Converting "squiggly" format to "beta" format
#'
#' \code{EMBmodelToBeta} converts a combined EMBglm object into separated "beta" formats which are exported ready for Earnix import.
#' @param EMBlemModel object. Your combined EMBglm model.
#' @param CSVLoc character, named. The location of the folder where you wish to store your CSV outputs.
#' @param XLSXLoc character, named. The location of the folder where you wish to store your XLSX outputs.
#' @param charLim numeric, named. Maximum factor length in Earnix (for cutting interaction names)- set "NA" for no limit.
#' @param keepCSV logical, named. Do you wish to keep the CSVs after conversion?
#' @param overWrite logical, named. Do you wish to overwrite CSVs if they already exist?
#' @param fnv_reorder logical, named. Reorder the model using \code{EMBmodelReorder}
#' @return Written outputs to CSVLoc and XLSXLoc respectively, alongside unmerged models in your R environment and VBS/VBA code in your project folder.
#' @keywords DGTools rsai CSV XLSX VBA VBS VBACSVtoXLSX VBSCSVtoXLSX EMBmodelToBeta CSVmodelToBeta
#' @export
#' @examples
#' #EMBmodelToBeta(allModels, CSVLoc = "../02_Output/My_CSV", XLSXLoc = "../02_Output/My_XLSX", keepCSV = TRUE)

EMBmodelToBeta <- function(EMBlemModel, ..., CSVLoc, XLSXLoc, charLim = 64, keepCSV = FALSE, overWrite = TRUE, fnv_reorder = FALSE) {

  ### Checking locations exist
  if(!dir.exists(CSVLoc)){
    dir.create(CSVLoc, recursive = TRUE)
  }
  if(!dir.exists(XLSXLoc)){
    dir.create(XLSXLoc, recursive = TRUE)
  }

  ### Reorder model
  if(fnv_reorder){
    EMBlemModel <- EMBmodelReorder(EMBlemModel, fnv_reorderNumeric = TRUE, fnv_reorderCharacter = TRUE)
  }

  ### EMBmodelUnmerge
  EMBmodelUnmerge(EMBlemModel)

  ### Changing digits for character conversion
  originalDigits <- getOption("digits")
  options(digits = 15)

  ### Looping through conversion for all models
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  for (EMBmdlName in Mdls) {

    # Taking a test copy (this is where we select the model we are doing "stuff" on)
    EMBmdl <- copy(get(EMBmdlName))

    # Sorting out base level
    baseLvl <- EMBmdl[Factor1 == "", Value]
    baseRow <- matrix(c("Base", "", baseLvl), nrow = 1, ncol = 3)
    baseMat <- rbind(rep("", 3), baseRow, rep("", 3), rep("", 3))

    # Creating lookups for noInt/Int2W (NOTE: DOES NOT ACCEPT 3-WAY INTERACTIONS)
    if (tryCatch(length(unique(EMBmdl[, (Factor3)])), error = function(e) 1 ) > 1) {
      EMBmdlNoInt <- EMBmdl[Factor1 != "" & Factor2 == "" & Factor3 == "", .(Factor1, Level1, Value)]
      EMBmdlInt2W <- EMBmdl[Factor2 != "" & Factor3 == "", .(Factor1, Factor2, Level1, Level2, Value)]
      EMBmdlInt3W <- EMBmdl[Factor3 != "", .(Factor1, Factor2, Factor3, Level1, Level2, Level3, Value)]
      intInd <- 3
    } else if (tryCatch(length(unique(EMBmdl[, (Factor2)])), error = function(e) 1 ) > 1) {
      EMBmdlNoInt <- EMBmdl[Factor1 != "" & Factor2 == "", .(Factor1, Level1, Value)]
      EMBmdlInt2W <- EMBmdl[Factor2 != "", .(Factor1, Factor2, Level1, Level2, Value)]
      intInd <- 2
    } else  {
      EMBmdlNoInt <- EMBmdl[Factor1 != "", .(Factor1, Level1, Value)]
      intInd <- 1
    }

    ### NoInt creation

    # As long as the NoInt matrix is not empty
    if (nrow(unique(EMBmdlNoInt[, .(Factor1)])) != 0) {

      # Loop for all simple factors that exist
      for (i in 1:nrow(unique(EMBmdlNoInt[, .(Factor1)]))) {

        # Assigning simple factor
        NoInt <- unique(EMBmdlNoInt[, Factor1])[i]

        # Creating our required format for the NoInt in question
        NoIntMat1 <- unname(as.matrix(EMBmdlNoInt[Factor1 == NoInt]))
        NoIntRow1 <- matrix(c("", NoInt, ""), nrow = 1, ncol = 3)
        NoIntMat2 <- cbind(rbind(NoIntRow1, NoIntMat1)[,-1], "")
        NoIntMat3 <- rbind(NoIntMat2[1,], rep("", 3), NoIntMat2)

        # Looping through our NoInts to create a combined matrix
        if (i == 1) {
          NoIntMatComb <- copy(NoIntMat3)
        } else {
          if (nrow(NoIntMat3) > nrow(NoIntMatComb)) {
            TmpMat <- rbind(NoIntMatComb,
                            matrix(rep("", ncol(NoIntMatComb) * (nrow(NoIntMat3) - nrow(NoIntMatComb))),
                                   nrow = (nrow(NoIntMat3) - nrow(NoIntMatComb)),
                                   ncol = ncol(NoIntMatComb)))
            NoIntMatComb <- cbind(TmpMat, NoIntMat3)
          } else if (nrow(NoIntMat3) < nrow(NoIntMatComb)) {
            TmpMat <- rbind(NoIntMat3,
                            matrix(rep("", ncol(NoIntMat3) * (nrow(NoIntMatComb) - nrow(NoIntMat3))),
                                   nrow = (nrow(NoIntMatComb) - nrow(NoIntMat3)),
                                   ncol = ncol(NoIntMat3)))
            NoIntMatComb <- cbind(NoIntMatComb, TmpMat)
          } else {
            NoIntMatComb <- cbind(NoIntMatComb, NoIntMat3)
          }
        }
      }

      # If the NoInt is empty, just initialise an empty character matrix
    } else NoIntMatComb <- matrix("", nrow = 0, ncol = 0)

    ### NoInt attachment

    # Attaching the NoInt matrix to our base matrix
    if (ncol(NoIntMatComb) > ncol(baseMat)) {
      TmpMat <- cbind(baseMat,
                      matrix(rep("", nrow(baseMat) * (ncol(NoIntMatComb) - ncol(baseMat))),
                             nrow = nrow(baseMat),
                             ncol = (ncol(NoIntMatComb) - ncol(baseMat))))
      baseNoIntMat <- rbind(TmpMat, NoIntMatComb)
    } else if (ncol(NoIntMatComb) < ncol(baseMat)) {
      TmpMat <- cbind(NoIntMatComb,
                      matrix(rep("", nrow(NoIntMatComb) * (ncol(baseMat) - ncol(NoIntMatComb))),
                             nrow = nrow(NoIntMatComb),
                             ncol = (ncol(baseMat) - ncol(NoIntMatComb))))
      baseNoIntMat <- rbind(baseMat, TmpMat)
    } else {
      baseNoIntMat <- rbind(baseMat, NoIntMatComb)
    }

    if (intInd == 1) {

      if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
        if (overWrite) {
          write.table(baseNoIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
        } else {
          cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
        }
      } else {
        write.table(baseNoIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
        cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
      }


    } else if (intInd > 1) {

      ### Int2W creation
      if (nrow(unique(EMBmdlInt2W[, .(Factor1, Factor2)])) != 0) {

        # Looping for all 2-way interactions that exist
        for (i in 1:nrow(unique(EMBmdlInt2W[, .(Factor1, Factor2)]))){

          # Assigning 2-way interaction
          Int2W <- unique(EMBmdlInt2W[, .(Factor1, Factor2)])[i]

          # Transforming this into our required format
          Int2WTab1 <- merge(EMBmdlInt2W, Int2W, by = c("Factor1", "Factor2"))
          Int2WMat1 <- matrix(Int2WTab1[,Value],
                              nrow = length(unique(Int2WTab1[,Level2])),
                              ncol = length(unique(Int2WTab1[,Level1])))
          Int2WMat2 <- cbind(unique(Int2WTab1[,Level2]), Int2WMat1)
          Int2WMat3 <- rbind(c("", unique(Int2WTab1[,Level1])),
                             Int2WMat2)
          Int2WMat4 <- rbind(c("", Int2W[,Factor1], rep("", ncol(Int2WMat3)-2)),
                             Int2WMat3)
          Int2WMat5 <- cbind(c("", "", Int2W[,Factor2], rep("", nrow(Int2WMat4)-3)),
                             Int2WMat4)
          Int2WMat6 <- rbind(rep("", ncol(Int2WMat5)),
                             Int2WMat5,
                             rep("", ncol(Int2WMat5)))
          if (is.na(charLim)) {
            Int2WMat7 <- rbind(c(paste0(Int2W[,Factor1], " * ", Int2W[,Factor2]), rep("", ncol(Int2WMat6)-1)),
                               Int2WMat6)
          } else {
            Int2WMat7 <- rbind(c(strtrim(paste0(Int2W[,Factor1], " * ", Int2W[,Factor2]), charLim), rep("", ncol(Int2WMat6)-1)),
                               Int2WMat6)
          }



          # Sticking all our 2-way interactions together
          if (i == 1) {
            Int2WMatComb <- copy(Int2WMat7)
          } else {
            if (ncol(Int2WMatComb) > ncol(Int2WMat7)) {
              TmpMat <- cbind(Int2WMat7, matrix(rep("", nrow(Int2WMat7)*(ncol(Int2WMatComb)-ncol(Int2WMat7))),
                                                nrow = nrow(Int2WMat7),
                                                ncol = (ncol(Int2WMatComb)-ncol(Int2WMat7))))
              Int2WMatComb <- rbind(Int2WMatComb, TmpMat)
            } else if (ncol(Int2WMatComb) < ncol(Int2WMat7)) {
              TmpMat <- cbind(Int2WMatComb, matrix(rep("", nrow = nrow(Int2WMatComb)*(ncol(Int2WMat7)-ncol(Int2WMatComb))),
                                                   nrow = nrow(Int2WMatComb),
                                                   ncol = (ncol(Int2WMat7)-ncol(Int2WMatComb))))
              Int2WMatComb <- rbind(TmpMat, Int2WMat7)
            } else {
              Int2WMatComb <- rbind(Int2WMatComb, Int2WMat7)
            }
          }

        }

      } else Int2WMatComb <- matrix("", nrow = 0, ncol = 0)

      ### Int2W attachment

      # Attaching the Int2W matrix to our baseNoInt matrix
      if (ncol(Int2WMatComb) > ncol(baseNoIntMat)) {
        TmpMat <- cbind(baseNoIntMat,
                        matrix(rep("", nrow(baseNoIntMat) * (ncol(Int2WMatComb) - ncol(baseNoIntMat))),
                               nrow =  nrow(baseNoIntMat),
                               ncol = (ncol(Int2WMatComb) - ncol(baseNoIntMat))))
        base2WIntMat <- rbind(TmpMat, Int2WMatComb)
      } else if (ncol(Int2WMatComb) < ncol(baseNoIntMat)) {
        TmpMat <- cbind(Int2WMatComb,
                        matrix(rep("", nrow(Int2WMatComb) * (ncol(baseNoIntMat) - ncol(Int2WMatComb))),
                               nrow = nrow(Int2WMatComb),
                               ncol = (ncol(baseNoIntMat) - ncol(Int2WMatComb))))
        base2WIntMat <- rbind(baseNoIntMat, TmpMat)
      } else {
        base2WIntMat <- rbind(baseNoIntMat, Int2WMatComb)
      }

      if (intInd == 2) {

        if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
          if (overWrite) {
            write.table(base2WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
            cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
          } else {
            cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
          }
        } else {
          write.table(base2WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
        }

      } else if (intInd > 2) {

        ### Int3W creation

        for (k in 1:nrow(unique(EMBmdlInt3W[, .(Factor1, Factor2, Factor3)]))) {

          # Assigning 3-way interaction
          Int3W <- unique(EMBmdlInt3W[, .(Factor1, Factor2, Factor3)])[k]

          # Transforming this into our required format
          Int3WTab1 <- merge(EMBmdlInt3W, Int3W, by = c("Factor1", "Factor2", "Factor3"))

          for (j in 1:nrow(unique(Int3WTab1[, .(Factor1, Factor2, Factor3, Level1)]))) {

            Int3WL1 <- unique(Int3WTab1[, .(Factor1, Factor2, Factor3, Level1)])[j]
            Int3WL1Tab1 <- merge(Int3WTab1, (Int3WL1[, .(Level1)]), by = c("Level1"))
            Int3WL1Mat1 <- matrix(Int3WL1Tab1[,Value],
                                  nrow = length(unique(Int3WL1Tab1[,Level3])),
                                  ncol = length(unique(Int3WL1Tab1[,Level2])))
            Int3WL1Mat2 <- cbind(unique(Int3WL1Tab1[,Level3]),
                                 Int3WL1Mat1,
                                 rep("", nrow(Int3WL1Mat1)))
            Int3WL1Mat3 <- rbind(c("", unique(Int3WL1Tab1[,Level2]), ""),
                                 Int3WL1Mat2)
            Int3WL1Mat4 <- rbind(c("", Int3WL1[,(Factor2)], rep("", ncol(Int3WL1Mat3)-2)),
                                 Int3WL1Mat3)
            Int3WL1Mat5 <- cbind(c("", "", Int3WL1[,(Factor3)], rep("", nrow(Int3WL1Mat4)-3)),
                                 Int3WL1Mat4)
            Int3WL1Mat6 <- rbind(rep("", ncol(Int3WL1Mat5)),
                                 Int3WL1Mat5,
                                 rep("", ncol(Int3WL1Mat5)))
            Int3WL1Mat7 <- rbind(c(paste0(Int3WL1[,Factor1], " = ", Int3WL1[,Level1]), rep("", ncol(Int3WL1Mat6)-1)),
                                 Int3WL1Mat6)

            if (j == 1) {
              Int3WL1MatComb <- Int3WL1Mat7
            } else {

              Int3WL1MatComb <- cbind(Int3WL1MatComb, Int3WL1Mat7)

            }

          }

          if (is.na(charLim)) {
            Int3WLMatComb <- rbind(c(paste0(Int3WL1[,Factor1], " * ",
                                            Int3WL1[,Factor2], " * ",
                                            Int3WL1[,Factor3]),
                                     rep("", ncol(Int3WL1MatComb)-1)),
                                   rep("", ncol(Int3WL1MatComb)),
                                   Int3WL1MatComb,
                                   rep("", ncol(Int3WL1MatComb)))
          } else {
            Int3WLMatComb <- rbind(c(strtrim(paste0(Int3WL1[,Factor1], " * ",
                                            Int3WL1[,Factor2], " * ",
                                            Int3WL1[,Factor3]),
                                     rep("", ncol(Int3WL1MatComb)-1)), charLim),
                                   rep("", ncol(Int3WL1MatComb)),
                                   Int3WL1MatComb,
                                   rep("", ncol(Int3WL1MatComb)))
          }

          if (k == 1) {
            Int3WMatComb <- Int3WLMatComb
          } else {
            if (ncol(Int3WMatComb) > ncol(Int3WLMatComb)) {
              TmpMat <- cbind(Int3WLMatComb, matrix(rep("", nrow(Int3WLMatComb)*(ncol(Int3WMatComb)-ncol(Int3WLMatComb))),
                                                    nrow = nrow(Int3WLMatComb),
                                                    ncol = (ncol(Int3WMatComb)-ncol(Int3WLMatComb))))
              Int3WMatComb <- rbind(Int3WMatComb, TmpMat)
            } else if (ncol(Int3WMatComb) < ncol(Int3WLMatComb)) {
              TmpMat <- cbind(Int3WMatComb, matrix(rep("", nrow = nrow(Int3WMatComb)*(ncol(Int3WLMatComb)-ncol(Int3WMatComb))),
                                                   nrow = nrow(Int3WMatComb),
                                                   ncol = (ncol(Int3WLMatComb)-ncol(Int3WMatComb))))
              Int3WMatComb <- rbind(TmpMat, Int3WLMatComb)
            } else {
              Int3WMatComb <- rbind(Int3WMatComb, Int3WLMatComb)
            }
          }

        }

        ### Int3W attachment

        # Attaching the Int3W matrix to our baseNoInt matrix
        if (ncol(Int3WMatComb) > ncol(base2WIntMat)) {
          TmpMat <- cbind(base2WIntMat,
                          matrix(rep("", nrow(base2WIntMat) * (ncol(Int3WMatComb) - ncol(base2WIntMat))),
                                 nrow =  nrow(base2WIntMat),
                                 ncol = (ncol(Int3WMatComb) - ncol(base2WIntMat))))
          base3WIntMat <- rbind(TmpMat, Int3WMatComb)
        } else if (ncol(Int3WMatComb) < ncol(base2WIntMat)) {
          TmpMat <- cbind(Int3WMatComb,
                          matrix(rep("", nrow(Int3WMatComb) * (ncol(base2WIntMat) - ncol(Int3WMatComb))),
                                 nrow = nrow(Int3WMatComb),
                                 ncol = (ncol(base2WIntMat) - ncol(Int3WMatComb))))
          base3WIntMat <- rbind(base2WIntMat, TmpMat)
        } else {
          base3WIntMat <- rbind(base2WIntMat, Int3WMatComb)
        }

        if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
          if (overWrite) {
            write.table(base3WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
            cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
          } else {
            cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
          }
        } else {
          write.table(base3WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
        }

      }

    }

  }

  ### Batch edit CSV to XLSX
  # VBACSVtoXLSX(CSVLoc = CSVLoc, XLSXLoc = XLSXLoc)
  VBSCSVtoXLSX(CSVLoc = CSVLoc, XLSXLoc = XLSXLoc, runCode = TRUE)

  ### Removing CSVs
  if (!(keepCSV)) {
    for (EMBmdlName in Mdls) {
      file.remove(paste0(CSVLoc, "/", EMBmdlName, ".csv"))
    }
    cat(noquote(paste0("CSVs in the folder '", CSVLoc ,"' have been deleted.\n")))
  }

  ### Resetting options
  options(digits = originalDigits)

}

#####  CSVmodelToBeta  #####
#' Converting "squiggly" format to "beta" format from CSV
#'
#' \code{CSVmodelToBeta} converts a folder of CSVs into separated "beta" formats which are exported ready for Earnix import. Note that the default for \code{fnv_sleepms} is to wait 10 seconds between each xlsx write, this is due to network constraints - when writing to C: drive there is not need to have any delay in writing.
#' @param inputLoc character, named. The location of the folder of your CSV inputs.
#' @param CSVLoc character, named. The location of the folder where you wish to store your CSV outputs.
#' @param XLSXLoc character, named. The location of the folder where you wish to store your XLSX outputs.
#' @param charLim numeric, named. Maximum factor length in Earnix (for cutting interaction names)- set "NA" for no limit.
#' @param keepCSV logical, named. Do you wish to keep the CSVs after conversion?
#' @param overWrite logical, named. Do you wish to overwrite CSVs if they already exist?
#' @param fnv_sleepms numeric. How long to sleep between writing each Excel file.
#' @param fnv_reorder logical, named. Reorder the model using \code{EMBmodelReorder}
#' @return Written outputs to CSVLoc and XLSXLoc respectively, alongside unmerged models in your R environment and VBS/VBA code in your project folder.
#' @keywords DGTools rsai CSV XLSX VBA VBS VBACSVtoXLSX VBSCSVtoXLSX EMBmodelToBeta CSVmodelToBeta
#' @export
#' @examples
#' #CSVmodelToBeta(inputLoc = "../00_Input/Models", CSVLoc = "../02_Output/My_CSV", XLSXLoc = "../02_Output/My_XLSX", keepCSV = TRUE, overWrite = FALSE)

CSVmodelToBeta <- function(..., inputLoc, CSVLoc, XLSXLoc, charLim = 64, keepCSV = FALSE, overWrite = TRUE, fnv_sleepms = 10000, fnv_reorder = FALSE) {

  ### Checking locations exist
  if(!dir.exists(CSVLoc)){
    dir.create(CSVLoc, recursive = TRUE)
  }
  if(!dir.exists(XLSXLoc)){
    dir.create(XLSXLoc, recursive = TRUE)
  }

  ### CSVmodelMerge
  CSVmodelMerge(inputLoc, EMBlemModel, upperFlag = FALSE, Value = FALSE)

  ### Reorder model
  if(fnv_reorder){
    EMBlemModel <- EMBmodelReorder(EMBlemModel, fnv_reorderNumeric = TRUE, fnv_reorderCharacter = TRUE)
  }

  ### EMBmodelUnmerge
  EMBmodelUnmerge(EMBlemModel)

  ### Changing digits for character conversion
  originalDigits <- getOption("digits")
  options(digits = 15)

  ### Looping through conversion for all models
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  for (EMBmdlName in Mdls) {

    # Taking a test copy (this is where we select the model we are doing "stuff" on)
    EMBmdl <- copy(get(EMBmdlName))

    # Sorting out base level
    baseLvl <- EMBmdl[Factor1 == "", Value]
    baseRow <- matrix(c("Base", "", baseLvl), nrow = 1, ncol = 3)
    baseMat <- rbind(rep("", 3), baseRow, rep("", 3), rep("", 3))

    # Creating lookups for noInt/Int2W (NOTE: DOES NOT ACCEPT 3-WAY INTERACTIONS)
    if (tryCatch(length(unique(EMBmdl[, (Factor3)])), error = function(e) 1 ) > 1) {
      EMBmdlNoInt <- EMBmdl[Factor1 != "" & Factor2 == "" & Factor3 == "", .(Factor1, Level1, Value)]
      EMBmdlInt2W <- EMBmdl[Factor2 != "" & Factor3 == "", .(Factor1, Factor2, Level1, Level2, Value)]
      EMBmdlInt3W <- EMBmdl[Factor3 != "", .(Factor1, Factor2, Factor3, Level1, Level2, Level3, Value)]
      intInd <- 3
    } else if (tryCatch(length(unique(EMBmdl[, (Factor2)])), error = function(e) 1 ) > 1) {
      EMBmdlNoInt <- EMBmdl[Factor1 != "" & Factor2 == "", .(Factor1, Level1, Value)]
      EMBmdlInt2W <- EMBmdl[Factor2 != "", .(Factor1, Factor2, Level1, Level2, Value)]
      intInd <- 2
    } else  {
      EMBmdlNoInt <- EMBmdl[Factor1 != "", .(Factor1, Level1, Value)]
      intInd <- 1
    }

    ### NoInt creation

    # As long as the NoInt matrix is not empty
    if (nrow(unique(EMBmdlNoInt[, .(Factor1)])) != 0) {

      # Loop for all simple factors that exist
      for (i in 1:nrow(unique(EMBmdlNoInt[, .(Factor1)]))) {

        # Assigning simple factor
        NoInt <- unique(EMBmdlNoInt[, Factor1])[i]

        # Creating our required format for the NoInt in question
        NoIntMat1 <- unname(as.matrix(EMBmdlNoInt[Factor1 == NoInt]))
        NoIntRow1 <- matrix(c("", NoInt, ""), nrow = 1, ncol = 3)
        NoIntMat2 <- cbind(rbind(NoIntRow1, NoIntMat1)[,-1], "")
        NoIntMat3 <- rbind(NoIntMat2[1,], rep("", 3), NoIntMat2)

        # Looping through our NoInts to create a combined matrix
        if (i == 1) {
          NoIntMatComb <- copy(NoIntMat3)
        } else {
          if (nrow(NoIntMat3) > nrow(NoIntMatComb)) {
            TmpMat <- rbind(NoIntMatComb,
                            matrix(rep("", ncol(NoIntMatComb) * (nrow(NoIntMat3) - nrow(NoIntMatComb))),
                                   nrow = (nrow(NoIntMat3) - nrow(NoIntMatComb)),
                                   ncol = ncol(NoIntMatComb)))
            NoIntMatComb <- cbind(TmpMat, NoIntMat3)
          } else if (nrow(NoIntMat3) < nrow(NoIntMatComb)) {
            TmpMat <- rbind(NoIntMat3,
                            matrix(rep("", ncol(NoIntMat3) * (nrow(NoIntMatComb) - nrow(NoIntMat3))),
                                   nrow = (nrow(NoIntMatComb) - nrow(NoIntMat3)),
                                   ncol = ncol(NoIntMat3)))
            NoIntMatComb <- cbind(NoIntMatComb, TmpMat)
          } else {
            NoIntMatComb <- cbind(NoIntMatComb, NoIntMat3)
          }
        }
      }

      # If the NoInt is empty, just initialise an empty character matrix
    } else NoIntMatComb <- matrix("", nrow = 0, ncol = 0)

    ### NoInt attachment

    # Attaching the NoInt matrix to our base matrix
    if (ncol(NoIntMatComb) > ncol(baseMat)) {
      TmpMat <- cbind(baseMat,
                      matrix(rep("", nrow(baseMat) * (ncol(NoIntMatComb) - ncol(baseMat))),
                             nrow = nrow(baseMat),
                             ncol = (ncol(NoIntMatComb) - ncol(baseMat))))
      baseNoIntMat <- rbind(TmpMat, NoIntMatComb)
    } else if (ncol(NoIntMatComb) < ncol(baseMat)) {
      TmpMat <- cbind(NoIntMatComb,
                      matrix(rep("", nrow(NoIntMatComb) * (ncol(baseMat) - ncol(NoIntMatComb))),
                             nrow = nrow(NoIntMatComb),
                             ncol = (ncol(baseMat) - ncol(NoIntMatComb))))
      baseNoIntMat <- rbind(baseMat, TmpMat)
    } else {
      baseNoIntMat <- rbind(baseMat, NoIntMatComb)
    }

    if (intInd == 1) {

      if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
        if (overWrite) {
          write.table(baseNoIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
        } else {
          cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
        }
      } else {
        write.table(baseNoIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
        cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
      }


    } else if (intInd > 1) {

      ### Int2W creation
      if (nrow(unique(EMBmdlInt2W[, .(Factor1, Factor2)])) != 0) {

        # Looping for all 2-way interactions that exist
        for (i in 1:nrow(unique(EMBmdlInt2W[, .(Factor1, Factor2)]))){

          # Assigning 2-way interaction
          Int2W <- unique(EMBmdlInt2W[, .(Factor1, Factor2)])[i]

          # Transforming this into our required format
          Int2WTab1 <- merge(EMBmdlInt2W, Int2W, by = c("Factor1", "Factor2"))
          Int2WMat1 <- matrix(Int2WTab1[,Value],
                              nrow = length(unique(Int2WTab1[,Level2])),
                              ncol = length(unique(Int2WTab1[,Level1])))
          Int2WMat2 <- cbind(unique(Int2WTab1[,Level2]), Int2WMat1)
          Int2WMat3 <- rbind(c("", unique(Int2WTab1[,Level1])),
                             Int2WMat2)
          Int2WMat4 <- rbind(c("", Int2W[,Factor1], rep("", ncol(Int2WMat3)-2)),
                             Int2WMat3)
          Int2WMat5 <- cbind(c("", "", Int2W[,Factor2], rep("", nrow(Int2WMat4)-3)),
                             Int2WMat4)
          Int2WMat6 <- rbind(rep("", ncol(Int2WMat5)),
                             Int2WMat5,
                             rep("", ncol(Int2WMat5)))
          if (is.na(charLim)) {
            Int2WMat7 <- rbind(c(paste0(Int2W[,Factor1], " * ", Int2W[,Factor2]), rep("", ncol(Int2WMat6)-1)),
                               Int2WMat6)
          } else {
            Int2WMat7 <- rbind(c(strtrim(paste0(Int2W[,Factor1], " * ", Int2W[,Factor2]), charLim), rep("", ncol(Int2WMat6)-1)),
                               Int2WMat6)
          }

          # Sticking all our 2-way interactions together
          if (i == 1) {
            Int2WMatComb <- copy(Int2WMat7)
          } else {
            if (ncol(Int2WMatComb) > ncol(Int2WMat7)) {
              TmpMat <- cbind(Int2WMat7, matrix(rep("", nrow(Int2WMat7)*(ncol(Int2WMatComb)-ncol(Int2WMat7))),
                                                nrow = nrow(Int2WMat7),
                                                ncol = (ncol(Int2WMatComb)-ncol(Int2WMat7))))
              Int2WMatComb <- rbind(Int2WMatComb, TmpMat)
            } else if (ncol(Int2WMatComb) < ncol(Int2WMat7)) {
              TmpMat <- cbind(Int2WMatComb, matrix(rep("", nrow = nrow(Int2WMatComb)*(ncol(Int2WMat7)-ncol(Int2WMatComb))),
                                                   nrow = nrow(Int2WMatComb),
                                                   ncol = (ncol(Int2WMat7)-ncol(Int2WMatComb))))
              Int2WMatComb <- rbind(TmpMat, Int2WMat7)
            } else {
              Int2WMatComb <- rbind(Int2WMatComb, Int2WMat7)
            }
          }

        }

      } else Int2WMatComb <- matrix("", nrow = 0, ncol = 0)

      ### Int2W attachment

      # Attaching the Int2W matrix to our baseNoInt matrix
      if (ncol(Int2WMatComb) > ncol(baseNoIntMat)) {
        TmpMat <- cbind(baseNoIntMat,
                        matrix(rep("", nrow(baseNoIntMat) * (ncol(Int2WMatComb) - ncol(baseNoIntMat))),
                               nrow =  nrow(baseNoIntMat),
                               ncol = (ncol(Int2WMatComb) - ncol(baseNoIntMat))))
        base2WIntMat <- rbind(TmpMat, Int2WMatComb)
      } else if (ncol(Int2WMatComb) < ncol(baseNoIntMat)) {
        TmpMat <- cbind(Int2WMatComb,
                        matrix(rep("", nrow(Int2WMatComb) * (ncol(baseNoIntMat) - ncol(Int2WMatComb))),
                               nrow = nrow(Int2WMatComb),
                               ncol = (ncol(baseNoIntMat) - ncol(Int2WMatComb))))
        base2WIntMat <- rbind(baseNoIntMat, TmpMat)
      } else {
        base2WIntMat <- rbind(baseNoIntMat, Int2WMatComb)
      }

      if (intInd == 2) {

        if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
          if (overWrite) {
            write.table(base2WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
            cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
          } else {
            cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
          }
        } else {
          write.table(base2WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
        }

      } else if (intInd > 2) {

        ### Int3W creation

        for (k in 1:nrow(unique(EMBmdlInt3W[, .(Factor1, Factor2, Factor3)]))) {

          # Assigning 3-way interaction
          Int3W <- unique(EMBmdlInt3W[, .(Factor1, Factor2, Factor3)])[k]

          # Transforming this into our required format
          Int3WTab1 <- merge(EMBmdlInt3W, Int3W, by = c("Factor1", "Factor2", "Factor3"))

          for (j in 1:nrow(unique(Int3WTab1[, .(Factor1, Factor2, Factor3, Level1)]))) {

            Int3WL1 <- unique(Int3WTab1[, .(Factor1, Factor2, Factor3, Level1)])[j]
            Int3WL1Tab1 <- merge(Int3WTab1, (Int3WL1[, .(Level1)]), by = c("Level1"))
            Int3WL1Mat1 <- matrix(Int3WL1Tab1[,Value],
                                  nrow = length(unique(Int3WL1Tab1[,Level3])),
                                  ncol = length(unique(Int3WL1Tab1[,Level2])))
            Int3WL1Mat2 <- cbind(unique(Int3WL1Tab1[,Level3]),
                                 Int3WL1Mat1,
                                 rep("", nrow(Int3WL1Mat1)))
            Int3WL1Mat3 <- rbind(c("", unique(Int3WL1Tab1[,Level2]), ""),
                                 Int3WL1Mat2)
            Int3WL1Mat4 <- rbind(c("", Int3WL1[,(Factor2)], rep("", ncol(Int3WL1Mat3)-2)),
                                 Int3WL1Mat3)
            Int3WL1Mat5 <- cbind(c("", "", Int3WL1[,(Factor3)], rep("", nrow(Int3WL1Mat4)-3)),
                                 Int3WL1Mat4)
            Int3WL1Mat6 <- rbind(rep("", ncol(Int3WL1Mat5)),
                                 Int3WL1Mat5,
                                 rep("", ncol(Int3WL1Mat5)))
            Int3WL1Mat7 <- rbind(c(paste0(Int3WL1[,Factor1], " = ", Int3WL1[,Level1]), rep("", ncol(Int3WL1Mat6)-1)),
                                 Int3WL1Mat6)

            if (j == 1) {
              Int3WL1MatComb <- Int3WL1Mat7
            } else {

              Int3WL1MatComb <- cbind(Int3WL1MatComb, Int3WL1Mat7)

            }

          }

          if (is.na(charLim)) {
            Int3WLMatComb <- rbind(c(paste0(Int3WL1[,Factor1], " * ",
                                            Int3WL1[,Factor2], " * ",
                                            Int3WL1[,Factor3]),
                                     rep("", ncol(Int3WL1MatComb)-1)),
                                   rep("", ncol(Int3WL1MatComb)),
                                   Int3WL1MatComb,
                                   rep("", ncol(Int3WL1MatComb)))
          } else {
            Int3WLMatComb <- rbind(c(strtrim(paste0(Int3WL1[,Factor1], " * ",
                                                    Int3WL1[,Factor2], " * ",
                                                    Int3WL1[,Factor3]), charLim),
                                     rep("", ncol(Int3WL1MatComb)-1)),
                                   rep("", ncol(Int3WL1MatComb)),
                                   Int3WL1MatComb,
                                   rep("", ncol(Int3WL1MatComb)))
          }

          if (k == 1) {
            Int3WMatComb <- Int3WLMatComb
          } else {
            if (ncol(Int3WMatComb) > ncol(Int3WLMatComb)) {
              TmpMat <- cbind(Int3WLMatComb, matrix(rep("", nrow(Int3WLMatComb)*(ncol(Int3WMatComb)-ncol(Int3WLMatComb))),
                                                    nrow = nrow(Int3WLMatComb),
                                                    ncol = (ncol(Int3WMatComb)-ncol(Int3WLMatComb))))
              Int3WMatComb <- rbind(Int3WMatComb, TmpMat)
            } else if (ncol(Int3WMatComb) < ncol(Int3WLMatComb)) {
              TmpMat <- cbind(Int3WMatComb, matrix(rep("", nrow = nrow(Int3WMatComb)*(ncol(Int3WLMatComb)-ncol(Int3WMatComb))),
                                                   nrow = nrow(Int3WMatComb),
                                                   ncol = (ncol(Int3WLMatComb)-ncol(Int3WMatComb))))
              Int3WMatComb <- rbind(TmpMat, Int3WLMatComb)
            } else {
              Int3WMatComb <- rbind(Int3WMatComb, Int3WLMatComb)
            }
          }

        }

        ### Int3W attachment

        # Attaching the Int3W matrix to our baseNoInt matrix
        if (ncol(Int3WMatComb) > ncol(base2WIntMat)) {
          TmpMat <- cbind(base2WIntMat,
                          matrix(rep("", nrow(base2WIntMat) * (ncol(Int3WMatComb) - ncol(base2WIntMat))),
                                 nrow =  nrow(base2WIntMat),
                                 ncol = (ncol(Int3WMatComb) - ncol(base2WIntMat))))
          base3WIntMat <- rbind(TmpMat, Int3WMatComb)
        } else if (ncol(Int3WMatComb) < ncol(base2WIntMat)) {
          TmpMat <- cbind(Int3WMatComb,
                          matrix(rep("", nrow(Int3WMatComb) * (ncol(base2WIntMat) - ncol(Int3WMatComb))),
                                 nrow = nrow(Int3WMatComb),
                                 ncol = (ncol(base2WIntMat) - ncol(Int3WMatComb))))
          base3WIntMat <- rbind(base2WIntMat, TmpMat)
        } else {
          base3WIntMat <- rbind(base2WIntMat, Int3WMatComb)
        }

        if (file.exists(paste0(CSVLoc, "/", EMBmdlName, ".csv"))) {
          if (overWrite) {
            write.table(base3WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
            cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV, overwriting the previous file.\n")))
          } else {
            cat(noquote(paste0(EMBmdlName, " already existed, so was not overwritten.\n")))
          }
        } else {
          write.table(base3WIntMat, paste0(CSVLoc, "/", EMBmdlName, ".csv"), sep = ",", col.names = F, row.names = F)
          cat(noquote(paste0(EMBmdlName, " with maximum of a ", intInd, "-way interaction has been output to CSV.\n")))
        }

      }

    }

  }

  ### Batch edit CSV to XLSX
  # VBACSVtoXLSX(CSVLoc = CSVLoc, XLSXLoc = XLSXLoc)
  VBSCSVtoXLSX(CSVLoc = CSVLoc, XLSXLoc = XLSXLoc, runCode = TRUE, fnv_sleepms = fnv_sleepms)

  ### Removing CSVs
  if (!(keepCSV)) {
    for (EMBmdlName in Mdls) {
      file.remove(paste0(CSVLoc, "/", EMBmdlName, ".csv"))
    }
    cat(noquote(paste0("CSVs in the folder '", CSVLoc ,"' have been deleted.\n")))
  }

  ### Resetting options
  options(digits = originalDigits)

}

