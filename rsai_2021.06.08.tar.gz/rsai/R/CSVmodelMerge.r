#####  CSVmodelMerge  #####
#' EMBmodelMerge together a Folder of CSV Emblem Models
#'
#' \code{CSVmodelMerge} allows you to quickly EMBmodelMerge together an entire folder.
#' @import data.table
#' @param Location character. The location of the folder where your CSV models are held.
#' @param Output object. What you wish the resultant EMBglm object to be called.
#' @param Value logical, named. Do you wish the models to have "Value" before their names?
#' @param upperFlag logical, named. See ?EMBmodelMerge.
#' @param reorder logical, named. See ?EMBmodelMerge.
#' @param ModelsToInclude Character vector. Names of files in \code{Location} that you wish to include.
#'  Defaults to include all csv files in \code{Location}.
#' @return Returns a EMBglm object featuring all CSVs in the specified folder.
#' @keywords DGTools rsai CSV EMBmodelMerge EMBglm
#' @export
#' @examples
#' #CSVmodelMerge("../my_Loc", allModels, upperFlag = TRUE, reorder = TRUE, ModelsToInclude = "all")

# A function to EMBmodelMerge from a folder
CSVmodelMerge <-
  function(Location,
           Output,
           ...,
           Value = TRUE,
           upperFlag = FALSE,
           reorder = FALSE,
           ModelsToInclude = "all") {

    # Take the names of all model files
    if (length(ModelsToInclude) > 1 || ModelsToInclude != "all"){
      CSVNames <- toupper(gsub( "\\.csv$", "",as.character(ModelsToInclude)))
    } else {
      CSVNames <- toupper( gsub( "\\.csv$", "",  grep( "\\.csv$", list.files(Location), value = TRUE ) ) )
    }

    CSVList <- vector("list", length(CSVNames))

    # Loop through all names and fread (caring for numeric errors etc)
    for (i in 1:length(CSVNames)) {
      temp <- fread(paste0(Location, "/", CSVNames[i], ".csv"), colClasses = "character")
      print(CSVNames[i])
      temp[, Value := as.numeric(Value)]
      if (sum(colSums(temp != "") != 0) < length(colnames(temp))){
        warning(paste0("File ", CSVNames[i], ".csv had missing columns"))
      }
      temp <- temp[,names(colSums(temp != ""))[colSums(temp != "") != 0], with = FALSE]
      CSVList[[i]] <- temp
    }

    # Combining the models
    EMBmodel <- EMBmodelMerge(CSVList, names = CSVNames, upperFlag = upperFlag, standardise = reorder)
    if (!Value) {
      setnames(EMBmodel, names(EMBmodel), gsub("Value", "", names(EMBmodel)))
    }
    assign(deparse(substitute(Output)), EMBmodel, envir = globalenv())

    # Creating verbose output
    txtOutput <- character()
    for (i in CSVNames) txtOutput <- paste0(txtOutput, i, "\n ")
    cat(noquote(paste0('The following models have been combined- stored in "', deparse(substitute(Output)), '":\n ', txtOutput, '\n')))

  }
