#####  VBACSVtoXLSX  #####
#' VBA for converting a folder of CSVs to XLSXs
#'
#' \code{VBACSVtoXLSX} creates a VBA script that can be copied into Excel which converts a specified folder of CSVs into XLSXs.
#' @param CSVLoc character, named. The location of the folder where your CSVs are stored.
#' @param XLSXLoc character, named. The location of the folder where your XLSXs are stored.
#' @return A VBA file in your project folder with code ready to run in excel.
#' @keywords DGTools rsai CSV XLSX VBA VBACSVtoXLSX VBSCSVtoXLSX
#' @export
#' @examples
#' #VBACSVtoXLSX(CSVLoc = "../02_Output/My_CSV", XLSXLoc = "../02_Output/My_XLSX")

VBACSVtoXLSX <- function(..., CSVLoc, XLSXLoc) {

  if (!dir.exists(CSVLoc)) {
    if (!dir.exists(XLSXLoc)) {
      cat("VBA: Both the CSVLoc and the XLSXLoc specified do not exist.")
    } else {
      cat("VBA: The CSVLoc specified does not exist.")
    }
  } else if (!dir.exists(XLSXLoc)) {
    cat("VBA: The XLSXLoc specified does not exist.")
  } else {

    fileConn <- file(paste0(CSVLoc, "CSVtoXLSX.vb"))
    writeLines(
      c('Sub CSVtoXLSX()',
        '',
        "'Define variables",
        'Dim CSVfolder As String',
        'Dim XlsFolder As String',
        'Dim fname As String',
        'Dim wBook As Workbook',
        '',
        "  'Optimize Macro Speed",
        '  Application.ScreenUpdating = False',
        '  Application.EnableEvents = False',
        '  Application.Calculation = xlCalculationManual',
        '',
        "  'Written in R",
        paste0(' CSVfolder = "', normalizePath(CSVLoc), '"'),
        paste0(' XlsFolder = "', normalizePath(XLSXLoc), '"'),
        '',
        "  'Looping through all CSVs in folder",
        '  fname = Dir(CSVfolder & "*.csv")',
        '  Do While fname <> ""',
        '     Set wBook = Workbooks.Open(CSVfolder & fname, Delimiter:=",")',
        '     wBook.SaveAs XlsFolder & Replace(fname, ".csv", ""), xlOpenXMLWorkbook',
        '     wBook.Close False',
        '     fname = Dir',
        '  Loop',
        '',
        "  'Reset Optimisation",
        '  Application.ScreenUpdating = True',
        '  Application.EnableEvents = True',
        '  Application.Calculation = xlCalculationAutomatic',
        '',
        'End Sub'),
      fileConn
    )
    close(fileConn)

  }

}

#####  VBSCSVtoXLSX  #####
#' VBS for converting a folder of CSVs to XLSXs
#'
#' \code{VBSCSVtoXLSX} creates a VBS script that can be run to convert a specified folder of CSVs into XLSXs.
#' @param CSVLoc named character. The location of the folder where your CSVs are stored.
#' @param XLSXLoc named character. The location of the folder where your XLSXs are stored.
#' @param fnv_sleepms integer. Time in millisecons to wait between writing each Excel file.
#' @param runCode logical. Do you wish to run the VBS immediately after creating (thus converting the folder)?
#' @return A VBS file in your project folder with code ready to run from console.
#' @keywords DGTools rsai CSV XLSX VBS VBACSVtoXLSX VBSCSVtoXLSX
#' @export
#' @examples
#' #VBSCSVtoXLSX(CSVLoc = "../02_Output/My_CSV", XLSXLoc = "../02_Output/My_XLSX", runCode = TRUE)

VBSCSVtoXLSX <- function(..., CSVLoc, XLSXLoc, fnv_sleepms = 0, runCode = TRUE) {

  if (!dir.exists(CSVLoc)) {
    if (!dir.exists(XLSXLoc)) {
      cat("VBS: Both the CSVLoc and the XLSXLoc specified do not exist.")
    } else {
      cat("VBS: The CSVLoc specified does not exist.")
    }
  } else if (!dir.exists(XLSXLoc)) {
    cat("VBS: The XLSXLoc specified does not exist.")
  } else {

    fileConn <- file(paste0(CSVLoc, "/../CSVtoXLSX.vbs"))
    writeLines(
      c(
        'Option Explicit  ',
        'Const vbNormal = 1  ',
        '',
        "Dim objXL, objWb ' Excel object variables",
        'Dim file, savename  ',
        'Dim myFolder, inputFolder, outputFolder, objFile  ',
        '',
        "' create an Excel object reference",
        'Set objXL = WScript.CreateObject ("Excel.Application")  ',
        '',
        'Dim objFSO  ',
        'Set objFSO = CreateObject("scripting.filesystemobject") ',

        '',
        "' Written in R",
        paste0('inputFolder = "', normalizePath(CSVLoc), '"  '),
        paste0('outputFolder = "', normalizePath(XLSXLoc), '" '),
        '',
        'Const fileExt = ".xlsx"  ',
        '',
        "' Setting input folder",
        'set myFolder = objFSO.getfolder(inputFolder)  ',
        '',
        'for each objFile in myFolder.Files  ',
        '  if LCase(objFSO.GetExtensionName(objFile)) = "csv" then',
        '  ',
        "    ' code to process csv files",
        '    savename = objFSO.BuildPath(outputFolder, objFSO.GetBaseName(objFile) & fileExt) ',
        '',
        "    ' Load the Excel file from the script's folder",
        '    Set objWb = objXL.WorkBooks.Open(objFile)  ',
        '',
        "    ' Turn off warning messages",
        '    objXL.DisplayAlerts = FALSE  ',
        '',
        "    ' xlsxWorkbookNormal",
        '    objWb.SaveAs savename, 51',
        '',
        "    ' Sleep for network to catch up",
        paste0('    WScript.Sleep ', fnv_sleepms),
        '',
        '  End If  ',
        'Next  ',
        '',
        'objWb.Close  ',
        'objXL.Quit  ',
        '',
        'Set objXL = Nothing  ',
        'Set objWB = Nothing  ',
        '',
        'Wscript.Echo "Conversion from CSV to XLSX complete."'
      ),
      fileConn
    )
    close(fileConn)

    if (runCode) shell(shQuote(normalizePath(paste0(CSVLoc, "/../CSVtoXLSX.vbs"))), "cscript", flag = "//nologo")

  }

}
