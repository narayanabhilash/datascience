#####  fixMissings  #####
#' A function to quickly replace NAs in a vector
#' @description A function to quickly replace NAs in a vector with an acceptable default
#' (probably there are better ways to deal with missing data in whatever project you're
#' working on.)
#' @usage fixMissings(x)
#' @param x A vector
#' @return A vector containing no NAs
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' ###### Create table with some missing data
#' #tableWithMissings <- data.table(A=runif(500),
#' #                                B=rnorm(500))
#' #tableWithMissings[, ':='( A = ifelse(B>0.8, NA, A),
#' #                          B = ifelse(A<0.2, NA, B))]
#' #tableWithMissings[, C := ifelse(A>B, "A", "B")]
#' #
#' ###### Create table with some missing data
#' #fixedTable <- funOnTable(tableWithMissings, fixMissings)
#' @export

fixMissings <- function(x){
  if(is.numeric(x)){
    ifelse(is.na(x), min(floor(min(x, 0L, na.rm=TRUE))-1L), x)
  } else{
    ifelse(is.na(x), "", x)
  }
}