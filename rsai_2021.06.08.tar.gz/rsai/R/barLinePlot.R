#####  barLinePlot  #####
#' Function to create a bar-line chart in plotly.
#' @description This function takes a data frame and uses plotly functions to plot a bar-line graph where the column to take the x-axis values and the columns to plot as lines or bars are specified.
#' @usage barLinePlot(dataForPlot, factorCol, barCols=character(0), lineCols=character(0),
#'  title=NULL, xAxisName=factorCol, barAxisName=NULL, lineAxisName=NULL, stacked=FALSE,
#'  Palette=NULL, Thickness = NULL, maxYaxisBar = NULL, ...)
#' @param dataForPlot A data frame.
#' @param factorCol The column defining the x-axis.
#' @param barCols A character vector of column names defining numeric columns to plot as bars.
#' @param lineCols A character vector of column names defining numeric columns to plot as lines.
#' @param title Optional chart title.
#' @param xAxisName Optional x-axis title.
#' @param barAxisName Optional y-axis title for the bar columns.
#' @param lineAxisName Optional y-axis title for the line columns.
#' @param stacked Logical - should multiple bar series be plotted stacked or not?
#' @param Palette Optional colour palette. This is applied to the bars first, then the lines.
#' @param Thickness Optional line width parameter. (Alternatively you can pass this as part of 
#' of an optional `line` argument). Thickness also sets the point size (or you can pass an optional `marker` argument).
#' @param maxYaxisBar Optional plotting argument to hard specify the maximal Y axis bar value.
#' @param ... Optional parameters to be passed through to plot_ly function e.g. width=910 to set the chart width.
#' @return A plotly plot object.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom plotly plot_ly layout add_trace
#' @examples
#' #barLinePlot(dataForPlot, "vehicleType", barCols="exposure", lineCols=c("actualClmFreq", "predictedClmFreq"), title="AvE on PD Claim Frequency by vehicle type", lineAxisName="PD Claim Frequency")
#' @export

barLinePlot <- function(
  dataForPlot,
  factorCol,
  barCols = character(0),
  lineCols = character(0),
  title = NULL,
  xAxisName = factorCol,
  barAxisName = NULL,
  lineAxisName = NULL,
  stacked = FALSE,
  Palette = NULL,
  Thickness = NULL,
  maxYaxisBar = NULL,
  ...) {
  
  # line and marker thickness:
  
  # setup line list:
  if ("line" %in% names(list(...))) {
    Line <- list(...)$line
   if (!("width" %in% names(Line)) && !(is.null(Thickness))) Line$width <- Thickness
  } else {
    Line = list()
    if (!(is.null(Thickness))) Line$width <- Thickness
  }

  if ("marker" %in% names(list(...))) {
    Marker <- list(...)$marker
    if (!("size" %in% names(Marker) && !(is.null(Thickness)))) Marker$size = 4 + Thickness
  } else {
    Marker = list()
    if (!(is.null(Thickness))) {
      Marker$size = 4 + Thickness
    }
  }
  
  
  # Add-in axis names if only
  if(is.null(barAxisName) && length(barCols)==1) barAxisName <- barCols
  if(is.null(lineAxisName) && length(lineCols)==1) lineAxisName <- lineCols
  
  # Create plotly plot object
  p <- plot_ly(...) %>%
    layout(
      title = title,
      xaxis = list(
        categoryorder = "array",
        categoryarray = as.character(dataForPlot[[factorCol]]),
        title = xAxisName
      ))
  
  # Add the bar columns
  for(col in barCols){
    barData <- dataForPlot[[col]]
    barData[is.na(barData)] <- 0
    p <- p %>%
      add_trace(x = as.character(dataForPlot[[factorCol]]),
                y = barData,
                type = "bar",
                name = col)
  }
  
  # Range for y-axis
  maxY <- max(0, sapply(lineCols, function(x) max(dataForPlot[[x]], na.rm=TRUE)))
  minY <- min(0, sapply(lineCols, function(x) min(dataForPlot[[x]], na.rm=TRUE)))
  range <- maxY-minY
  if(range==0){
    maxY <- maxY + 1
    range <- 1
  } else{
    scaleRange <- 10^floor(log10(range))
    maxY <- max(ceiling(maxY/scaleRange)*scaleRange, signif(maxY*1.1, 2))
    minY <- min(floor(minY/scaleRange)*scaleRange, signif(minY*1.1, 2))
  }
  
  # If zero bars then add lines on left hand y-axis, else add on right hand y-axis
  if(length(barCols) > 0){
    Yaxis <- list(
      fixedrange = TRUE,
      title = barAxisName)
    if (!(is.null(maxYaxisBar)))
      Yaxis <- list(
        range = c(0, maxYaxisBar),
        title = barAxisName)
    
    p <- p %>%
      layout(yaxis = Yaxis,
        yaxis2 = list(
          overlaying = "y",
          side = "right",
          title = lineAxisName,
          range = c(minY, maxY)
        ))
    
    # Add lineCols as lines
    for(col in lineCols){  
      p <- p %>%
        add_trace(
          x = as.character(dataForPlot[[factorCol]]),
          y = dataForPlot[[col]],
          type = "scatter",
          mode = "lines+markers",
          name = col,
          yaxis = "y2",
          line = Line,
          marker = Marker)
    }
    
  } else {
    p <- p %>%
      layout(yaxis = list(title = lineAxisName,
                          range = c(minY, maxY)))
    
    # Add lineCols as lines
    for (col in lineCols) {
      p <- p %>%
        add_trace(
          x = as.character(dataForPlot[[factorCol]]),
          y = dataForPlot[[col]],
          type = "scatter",
          mode = "lines+markers",
          name = col
        )
    }
  }
  if(stacked) p <- p %>% layout(barmode="stack")
  if(!(is.null(Palette))){
    
    if (length(Palette) <= length(barCols)){
      warning("Palette was too short and was not applied")
      return (p)
    }
    pCount = ceiling(length(lineCols) / (length(Palette) - length(barCols)))
    if (length(barCols)) Palette <- c(
      Palette[1:length(barCols)], rep (Palette[-1:-length(barCols)]), pCount) 
    
    p <- p %>% layout(colorway = Palette)
  }
  return(p)
}

#########################