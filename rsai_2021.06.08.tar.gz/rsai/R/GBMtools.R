setOldClass("gbm")
setOldClass("xgb.Booster")

#' work out how many trees are available from an xgb.dump
#' @description work out how many trees are available from an xgb.dump
#' @param x A xgb.dump object.
#' @export
findMaxTrees <- function(x){
	t1 <- grep("booster",x)
	if(!length(t1)) stop("this doesn't look like an xgb.dump object!")
	as.integer(gsub("booster\\[([0-9]+)]","\\1",x[max(t1)]))+1L
}

#' convert an xgb.dump to a list with one element per tree
#' @description convert an xgb.dump to a list with one element per tree
#' @param x A xgb.dump object
xgbDumpToList <- function(x){
	t1 <- grepl("booster",x)
	if(!sum(t1)) stop("this doesn't look like an xgb.dump object!")
	if(sum(t1) == 1L) return(list(x))
	splind <- cumsum(t1)
	unname(split(x,splind))
#	if(length(t1) == 2L) return(list(x[2:(t1[2] - 1)]))
#	t2 <- mapply(function(i,j) x[(i+1):(j-1)],t1[-length(t1)],t1[-1])
#	t2
}



#' Variable Importance Plots for GBMs
#' 
#' @description Illustrates the importance of each variable in a GBM, plotted for each
#' iteration.
#' 
#' For each i between 1 and the number of selected trees, the cumulative (and
#' optionally normalised) variable importance is plotted. This is proportional
#' to the decrease in deviance based on the variable in question.\cr The size
#' of each coloured band will correspond to the values returned by
#' \code{summary.gbm} with \code{n.trees=i}.
#' @usage gbmImportancePlot(x, n = x$n.trees, cex = 2, cxpo = 0.4, rightspace = 0.1, norm = TRUE, ...)
#' @param x A \code{gbm} object.
#' @param n The maximum number of trees to scan over when producing the plot.
#' @param cex Character expansion factor. Controls how large the labels are
#' (the value corresponds to the value of \code{cex} passed to \code{text} for
#' the largest label).
#' @param cxpo Character expansion exponent. Should be between 0 and 1. Smaller
#' values make the labels more even in size, but they may start overlapping.
#' @param rightspace Amount of space to leave in the right hand portion of the
#' plot for labels. Increase this if the labels are becoming truncated (or,
#' alternatively, lower \code{cex}).
#' @param norm Logical. \code{TRUE} will plot relative importance, \code{FALSE}
#' will plot absolute importance.
#' @param \dots Further arguments to be passed to \code{text} (such as a font,
#' for instance).
#' @return NULL.
#' @note This function does not actually require the \code{gbm} library to be
#' loaded, it works as a stand-alone. \code{x} is required to have the
#' \code{"gbm"} class, though.
#' @details For each i between 1 and the number of selected trees, the cumulative
#'  (and optionally normalised) variable importance is plotted. 
#'  This is proportional to the decrease in deviance based on the variable 
#'  in question.\cr
#'  The size of each coloured band will correspond to the values 
#'  returned by \code{summary.gbm} with \code{n.trees=i}.
#'
#' @author James Lawrence
#' @import xgboost
#' @seealso \code{gbm}, \code{plot.gbm}, \code{\link{text}}.
#' @export
#' @examples
#' 
#' require(gbm)
#' ## three GBM examples:
#' ## 1) no interactions, x4 - x6 not used
#' ## 2) two-way interaction between x2 and x3, x4 - x6 not used
#' ## 3) same as (2) but with a three way interaction x4*x5*x6
#' df.tmp <- data.frame(x1=rnorm(5000),x2=rnorm(5000),x3=rnorm(5000),x4=rnorm(5000),x5=rnorm(5000),x6=rnorm(5000))
#' df.tmp$y1 <- rnorm(5000,df.tmp$x1 + df.tmp$x2 + df.tmp$x3,1)
#' df.tmp$y2 <- rnorm(5000,df.tmp$x1 + df.tmp$x2*df.tmp$x3,1)
#' df.tmp$y3 <- rnorm(5000,df.tmp$x1 + df.tmp$x2*df.tmp$x3 + df.tmp$x4 * df.tmp$x5 * df.tmp$x6,1)
#' ## fit the GBMs (might take a few seconds)
#' gbm1 <- gbm(y1 ~ x1 + x2 + x3 + x4 + x5 + x6,interaction.depth=6L,data=df.tmp,n.trees=500L,verbose=FALSE,shrinkage=0.05)
#' gbm2 <- gbm(y2 ~ x1 + x2 + x3 + x4 + x5 + x6,interaction.depth=6L,data=df.tmp,n.trees=500L,verbose=FALSE,shrinkage=0.05)
#' gbm3 <- gbm(y3 ~ x1 + x2 + x3 + x4 + x5 + x6,interaction.depth=6L,data=df.tmp,n.trees=500L,verbose=FALSE,shrinkage=0.05)
#' par(mfrow=c(2,3))
#' ## importance plots
#' ## I specify rightspace and cex here since there is not a lot of space for labels
#' ## scaled
#' gbmImportancePlot(gbm1,rightspace=0.15,cex=1.5)
#' gbmImportancePlot(gbm2,rightspace=0.15,cex=1.5)
#' gbmImportancePlot(gbm3,rightspace=0.15,cex=1.5)
#' ## unscaled
#' gbmImportancePlot(gbm1,norm=FALSE,rightspace=0.15,cex=1.5)
#' gbmImportancePlot(gbm2,norm=FALSE,rightspace=0.15,cex=1.5)
#' gbmImportancePlot(gbm3,norm=FALSE,rightspace=0.15,cex=1.5)
#' ## notice how the variables with interactions are learned slower
#' ## i.e. their bands widen later than those with no interactions (i.e. x1)
#' 
gbmImportancePlot <- function(x,n=x$n.trees,cex=2,cxpo=0.4,rightspace=0.1,norm=TRUE,...){stop("'x' should be either a gbm or xgboost object")}
setGeneric("gbmImportancePlot",signature="x")

#' @export
#' @rdname gbmImportancePlot
gbmImportancePlot.gbm <- function(x,n=x$n.trees,cex=2,cxpo=0.4,rightspace=0.1,norm=TRUE,...){
	if(!inherits(x,"gbm")) stop("'x' isn't a gbm!")
	if (n > x$n.trees){
		n <- x$n.trees
		warning(paste0("tried to use too many trees! Using ",n))
	}	
	get.rel.inf <- function(obj){
		lapply(split(obj[[6]],obj[[1]]),sum)
	}
	temp <- unlist(lapply(x$trees[1:n],get.rel.inf))
	trInd <- cumsum(names(temp)=="-1")
	M <- matrix(0,length(x$var.names),n)
	M[cbind(as.integer(names(temp))+1,trInd)] <- temp[names(temp) != "-1"]
	M2 <- t(apply(M,1,cumsum))
	M2 <- apply(M2,2,cumsum)
	M2 <- rbind(0,M2)
	if(norm) M2 <- sweep(M2,2,apply(M2,2,max),"/")
	col <- rev(rainbow(dim(M)[1],s=0.75,v=0.75,start=0.25,end=0.75))
	plot(0,pch=".",col="white",xlab="iteration",ylab="cumulative importance",xlim=c(0,n*(1+rightspace)),ylim=c(0,max(M2)),main=paste0("variable importance in ",substitute(x)))
	xs <- c(seq_len(n),rev(seq_len(n)))
	for(i in 2:(dim(M2)[1])){
		polygon(x=xs,y=c(M2[i,],rev(M2[i-1,])),col=col[i-1])
	}
	text(x$var.names,x=n,y=c(M2[-1,n]+M2[-dim(M2)[1],n])/2,pos=4,cex=(diff(M2[,n])+1E-6)^cxpo*cex/(max(diff(M2[,n]))^cxpo),...)
#	legend("right",legend=rev(sort(as.character(x$var.names))),col=rev(col),lwd=3,bg="white")
}

setMethod(gbmImportancePlot,signature(x="gbm"),gbmImportancePlot.gbm)

#' @export
#' @rdname gbmImportancePlot
#' 
gbmImportancePlot.xgb.Booster <- gbmImportancePlot.character <- function(x,n,cex=2,cxpo=0.4,rightspace=0.1,norm=TRUE,...){
.NotYetImplemented()
#	if(!is.character(x)) x <- xgboost::xgb.dump(x,with.stats=TRUE)
#	maxTrees <- findMaxTrees(x)
#	x <- 
#	if(missing(n)){
#		cat("n not specified. Using max number of trees: ",maxTrees,"\n")
#		n <- maxTrees
#	}
#	if(n > maxTrees){
#		cat("n out of range. Using max number of trees: ",maxTrees,"\n")
#		n <- maxTrees
#	}
#	M <- matrix(0,length(x$var.names),n)
### some stuff to actually fill M
#
#
###
#	M2 <- t(apply(M,1,cumsum))
#	M2 <- apply(M2,2,cumsum)
#	M2 <- rbind(0,M2)
#	if(norm) M2 <- sweep(M2,2,apply(M2,2,max),"/")
#	col <- rev(rainbow(dim(M)[1],s=0.75,v=0.75,start=0.25,end=0.75))
#	plot(0,pch=".",col="white",xlab="iteration",ylab="cumulative importance",xlim=c(0,n*(1+rightspace)),ylim=c(0,max#(M2)),main=paste0("variable importance in ",substitute(x)))
#	xs <- c(seq_len(n),rev(seq_len(n)))
#	for(i in 2:(dim(M2)[1])){
#		polygon(x=xs,y=c(M2[i,],rev(M2[i-1,])),col=col[i-1])
#	}
#	text(x$var.names,x=n,y=c(M2[-1,n]+M2[-dim(M2)[1],n])/2,pos=4,cex=(diff(M2[,n])+1E-6)^cxpo*cex/(max(diff(M2[,n]))^cxpo),...)
}

setMethod(gbmImportancePlot,signature(x="xgb.Booster"),gbmImportancePlot.xgb.Booster)
setMethod(gbmImportancePlot,signature(x="character"),gbmImportancePlot.xgb.Booster) ## assumes it came from xgb.dump(,with.stats=TRUE)
