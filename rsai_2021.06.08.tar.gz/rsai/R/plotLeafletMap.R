#####  plotLeafletMap  #####
#' create html maps with backgrounds within R.
#' @description This function produces a zoomable html object showing a heat
#' map of data values by their actual location. The values are plotted as
#' circles on top of local map data which is produced by the \code{leaflet}
#' package.
#' @usage plotLeafletMap(
#'   dt,
#'   col,
#'   XY = c("coordinate_x", "coordinate_y"),
#'   Country = "Ireland",
#'   XY_CRS = NULL,
#'   circlearea = NULL,
#'   circleScale = 1,
#'   opacity = 0.5,
#'   palette = "Spectral",
#'   subsample = 0L,
#'   NA_default = -2,
#'   bins = 10,
#'   legendPlacement ="topleft",
#'   Title = NULL,
#'   percentile = FALSE,
#'   rounding = NULL,
#'   colourScaleDT = NULL,
#'   distScale = 0L,
#'   labelCol = NULL,
#'   invert = FALSE
#'   )

#' @param dt data charted. Must include spatial coordinate and
#' response columns .
#' @param col name of the column to map.  Should contain numeric data
#' @param XY character vector of the x and y coordinate column names. These 
#' should contain "eastings" and "northings" and be consistent with a WSG84 map
#' projection. 
#' @param Country country the data relates to. This is used to set a default map 
#' projection used (XY_CRS). Defaults are set for "UK", "UK_ONS", "Ireland" and "Sweden".
#' @param XY_CRS additional command info for the particular map projection used.
#' This should be consistent with your x and y coordinates.
#' example default values are "+init=epsg:23030" for the UK and
#' "+init=epsg:29903" for Ireland. See http://epsg.io 
#' or https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system
#' "UK", Ireland" and "Sweden" are consistent with the default output of 
#' `quickSpatialTransform`. However, the UK quarterly ONS data contains eastings and northings
#' but uses a different map (`+init=epsg:27700`).
#' @param circlearea optional column containing area size. This can help avoid
#' overplotting.
#' @param circleScale numeric value to rescale the circles. The function will 
#' guess an appropriate size for the circles based on the area plotted and the 
#' size of your datasets, but increasing this value will give a larger circle.
#' Note that larger circles will make your map harder to process.
#' @param opacity numeric between 0 and 1 of the opacity of the circles drawn.
#' @param palette colour palette name used to draw the circles. See 
#' \code{leaflet::colorNumeric} for details of possible values. Note that 
#' if you wish to use an alternative scale (e.g. "blues"), make sure that it
#' contains sufficient colours. (Or turn \code{bins}) down.)
#' @param subsample integer. If you wish to save time/memory, setting this 
#' greater than zero produces a map on a random subsample of \code{dt} with this
#' many rows in.  
#' @param NA_default any NA values in \code{col} are set to this value.
#' @param bins number of colour bins plotted. (Maximum of 10 if \code{percentile} is true.)
#' \code{plotLeafletMap} will attempt to bin the data into bins with an equal 
#' number of rows in each bin, and will adjust bin boundaries where this is
#' not possible. 
#' @param legendPlacement where the colour scale is placed in the html image.
#' @param Title of the html chart.
#' @param percentile logical.  If true, scale is displayed as banded percentiles.
#' @param rounding optional integer. Number of decimal places in the colour scale.
#' if not specified the function guesses.
#' @param colourScaleDT optional character / numeric vector (If a character, this 
#' would be a column name of dt). If used, the map is shown using a scale based on 
#' the values of \code{colourScaleDT} rather than the values of \code{col}. This
#' enables maps with a consistent scale to be produced. At present, 
#' \code{colourScaleDT} only has an effect if \code{percentile} is\code{FALSE}.
#' @param distScale optional numeric. If set, the area of the circles is overriden
#' by a value proportional to \code{(distance to nearest circle) ^ distScale}.
#' This enables you to get around overplotting issues.
#' @param labelCol optional column of point labels (eg, postcode)
#' @param invert logical: if TRUE then the colour spectrum is inverted (this
#' assumes a text argument to `palette`, like "Spectral").
#' @seealso \code{LongLatToUTM}, \code{xgb_fi}
#' @return an htmlwidget object.
#' @author Tom Bratcher (Tom.Bratcher@uk.rsagroup.com)
#' @export
#' @note Note that in practice, if your data contain duplicate values or NAs, the colour
#' scales produced by using \code{colourScaleDT} may appear to differ slightly.
#' You can also get odd issues from 
#' the use of \code{subsample} with \code{colourScaleDT}: You may wish to specify
#' a random subsample of dt explicitly instead.
#' @examples
#' data("UKTheftFreq")
#' set.seed (11235813L)
#' plotLeafletMap(UKTheftFreq,
#' col = "ACQ_hhld_10km_bnd",
#' Country = "UK",
#' subsample = 20000,
#' legendPlacement = "topright",
#' distScale = 1,
#' Title = "Crime band"
#' )
plotLeafletMap <-
  function(
    dt,
    # consistent with other RSAI
    col,
    # as per plotResponsebyCol
    XY = c("coordinate_x", "coordinate_y"),
    Country = "Ireland",
    XY_CRS = NULL,
    circlearea = NULL,
    circleScale = 1,
    opacity = 0.5,
    palette = "Spectral",
    subsample = 0L,
    NA_default = -2,
    bins = 10, #consistent with rsaiband
    legendPlacement = "topleft",
    Title = NULL,
    percentile = FALSE,
    rounding = NULL,
    colourScaleDT = NULL,
    distScale = 0L,
    labelCol = NULL,
    invert = FALSE
  ) {
    
 # TODO: refine NA treatment?
  
# set up some defaults ----------------------------------------------------
 
      if (is.null (Title)) Title <- paste0("Chart of ", col)  
  
  CRS_WGS84 <- 
    "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0 "  
  
  # get XY_CRS:
  
  if (is.null (XY_CRS)){
    if (Country == "Ireland") XY_CRS <- "+init=epsg:29903"
    if (Country == "UK")      XY_CRS <- "+init=epsg:23030"
    if (Country == "UK_ONS")  XY_CRS <- "+init=epsg:27700"
    if (Country == "Sweden")  XY_CRS <- "+init=epsg:3006"
  if (is.null (XY_CRS)){
    warning ("no default map setting set")
    return (NULL)
  }
  }

# Error checking / data munging -------------------------------------------

  if (invert) palette <- colorNumeric(palette, 0:1, reverse = T)
  if (!(is.data.frame(dt))) stop ("dt must be a data table or data frame")
  if (!(is.data.table(dt))) dt <- as.data.table(dt)
  if (!(col %in% names (dt))) stop ("col is not a column of dt")
  if (!is.null (colourScaleDT)) {
    if (is.character(colourScaleDT)) {
      if (colourScaleDT %in% names (dt)) colourScaleDT <- dt[[colourScaleDT]] else stop (
        "colourScaleDT is not a numeric vector or a column name of dt"
      )
    }
   if (!(is.numeric(colourScaleDT))) stop ("colourScaleDT is not numeric")
  }
  if (!(is.null(labelCol))) {
    if (!(labelCol %in% names (dt))) stop (
    "labelCol should be NULL or a column name of dt")
   } 
# function actually starts here -------------------------------------------

  # dt contains x/y with joined response 
  
  # get x and y coords
  if (!(XY[1] %in% names (dt))) {
    temp <- grep("^[Xx]|[Xx]$", names(dt), value = T)
    if (length (temp) == 0) {
      warning ("X coordinate not found")
      return (NULL)
    } else {
      XY[1] <- temp[1]
      warning (paste0("X coordinate not found: using ", temp[1]))
    }
      }
  if (!(XY[2] %in% names (dt))) {
    temp <- grep("^[Yy]|[Yy]$", names(dt), value = T)
    if (length (temp) == 0){
      warning ("Y coordinate not found")
      return (NULL)
    } else {
      XY[2] <- temp[1]
      warning (paste0("Y coordinate not found: using ", temp[1]))
    }
  }
  sp_SA_dt <- dt[, c(XY, col, circlearea), with = FALSE] 
  
  # convert factors to integer: 
  # now needed for things like "hour"
  if (inherits(sp_SA_dt[, get(col)], "factor")) {
    warning("response column is factor data: converted to integer")
    sp_SA_dt[, eval(col) := as.integer(get(col))]
  }
  
  if (is.null(circlearea)) sp_SA_dt<-cbind(sp_SA_dt,
                                             data.table(ones=rep(1,nrow(dt))))
  names(sp_SA_dt) <- c("X","Y", "z", "circlearea")
  
  # deal with NAs: ----------------
  sp_SA_dt[is.na(z), z:=NA_default]
 
   #and add labels: ------------
  if (!(is.null(labelCol))) {
    sp_SA_dt$cLabel <- dt[[labelCol]]
    
  } else sp_SA_dt$cLabel <- " "

  # deal with duplicates:-----------------
  sp_SA_dt <- sp_SA_dt[, .(z = mean(z, na.rm=TRUE),
                           cLabel = getMode(cLabel, na.rm = TRUE),
                           circlearea=sum(circlearea, na.rm=TRUE)), 
                         by = c("X","Y")]
  

  # spec rounding  -------------------------------------------
  if (is.numeric(sp_SA_dt$z)) {
    if (is.null(rounding)) 
      rounding <- max (0, 3 - trunc(
        log10(1E-9 + max(abs(sp_SA_dt$z), na.rm = TRUE)))) 
    sp_SA_dt[, zr := round (z,rounding)]
  } else sp_SA_dt[, zr := z]
 
  if (!(is.null(labelCol))) {
      sp_SA_dt$cLabel <- apply (sp_SA_dt[, c("cLabel","zr"), with=F],
                            1, paste, collapse =": - ")
  } else sp_SA_dt[, cLabel := zr] 

  # deal with circle areas:-----------
  Area <- mean(sp_SA_dt$circlearea, na.rm=T)
  sp_SA_dt[is.na(circlearea), circlearea:= Area]

    # if distScale, apply that:----------
  if (distScale >0){
    temp <- ppp (sp_SA_dt$X, sp_SA_dt$Y,
                    window = owin(c(min(sp_SA_dt$X), max(sp_SA_dt$X)),
                                  c(min(sp_SA_dt$Y), max(sp_SA_dt$Y))),
                 check = F)
    temp <- (1 + nncross(temp, temp, what = "dist", k = 2)) ^ distScale 
    sp_SA_dt[, circlearea := temp]
    rm(temp)
  }
  
  
  # subsample if desired:
  if (subsample) 
    if (subsample<nrow (sp_SA_dt)) 
      sp_SA_dt <- sp_SA_dt[sample(1:nrow(sp_SA_dt), subsample)]
  
  # get a reasonable circle size: as.double needed otherwise sweden gives error
  areaplotted = as.double((max(sp_SA_dt$X) - min(sp_SA_dt$X))) *
                          (max(sp_SA_dt$Y) - min(sp_SA_dt$Y))
  
  areaplotted <- max(areaplotted, 1E-6)
  circleScale <- circleScale * sqrt(areaplotted / nrow(sp_SA_dt)) /(0.5 * Area)
  circleScale <- circleScale / mean(sp_SA_dt$circlearea)
  # about right...
    
  coordinates(sp_SA_dt) <- c("X","Y")
  proj4string(sp_SA_dt) <- CRS(XY_CRS)

# Add scale: might not be the same as our data. ---------------------------

  sp_SA_dt$zq <- ecdf(sp_SA_dt$z)(sp_SA_dt$z)
  
  if (is.null(colourScaleDT)) { 
    colourScaleDT <- sp_SA_dt$z
  }

  # set the values plotted:
  sp_SA_dt$zs <- ecdf(colourScaleDT)(sp_SA_dt$z)
    
 sp_SA_dt <- spTransform(sp_SA_dt, CRS(CRS_WGS84))
 

# if using percentiles: ---------------------------------------------------
# (the old fashioned way)

  if (percentile){  
    
    bins <- median(c(2,bins,10))  
    # set up the bin limits -----
    probs <- seq(0, 1, length.out = bins + 1)
    breaks <- quantile(sp_SA_dt$z, probs, na.rm = TRUE, names = FALSE)
    # problem if not unique...
    temp <- T
    trycount <- 0
    while (max(duplicated(breaks))){ 
      if (temp){
        b1 <- quantile(sp_SA_dt$z, 0.002 * (0:500), na.rm = TRUE, names = FALSE)
        bins <- min (bins, length(unique(b1)))
        if (bins == 1){
          warning (col, "does not have enough variability to map, returning NULL.
                   Try setting percentile = FALSE.")
          return (NULL)
        }
        # wobble the breaks around until we find something that works, or give up:
        probs <- seq(0, 1, length.out=bins + 1)
        breaks <- quantile(sp_SA_dt$z, probs, na.rm = TRUE, names = FALSE)
        temp = F}
      wasprobs <- probs
      probs <- probs + 0.001 * duplicated(breaks)
      probs <- probs - 0.001 * c(duplicated(breaks)[-1], F)
      probs <- pmax(0, pmin(1, probs))
      
      if ((identical(wasprobs, probs)) | trycount > 20000) {
        warning ("can't find unique break points in ", col,", returning NULL")
        return (NULL)
      }
      breaks <- quantile(sp_SA_dt$z, probs, na.rm = TRUE, names = FALSE)
      trycount <- trycount + 1
    }
    
    # get the required colours from leaflet's colorQuantile function:
    pal <- colorQuantile(palette=palette,  
                         domain=sp_SA_dt$z[!is.na(sp_SA_dt$z)],
                         reverse=TRUE,
                         n=bins,
                         probs=probs) 
    
    # not using quantiles...
    sp_SA_dt$zq <- sp_SA_dt$z
    quant <- identity
    
    p <- leaflet(data = sp_SA_dt) %>%
      addTiles(urlTemplate = "http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png") %>%
      addCircles(
        radius=~sqrt(circlearea) * circleScale, 
        stroke=FALSE,
        label = ~as.character(cLabel),
        fillOpacity=opacity, 
        fillColor=~pal(zq)
      ) %>%
      addLegend(position = legendPlacement,pal=pal,
             #   bins = bins,
                values=~zq,
                title=Title)
    
  } else {# or: would really like to tidy this but bins = bins gives a warning in the above
    quant <- function (x) quantile (colourScaleDT, probs = x, na.rm = TRUE) 
    pal <- colorNumeric(palette = palette, ecdf(colourScaleDT)(colourScaleDT), reverse = TRUE)

  p <- leaflet(data = sp_SA_dt) %>%
      addTiles(urlTemplate = "http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png") %>%
      addCircles(
        radius=~sqrt(circlearea) * circleScale, 
        stroke=FALSE,
        label = ~as.character(cLabel),
        fillOpacity=opacity, 
        fillColor=~pal(zs)
      ) 
  if (!("Date" %in% class (sp_SA_dt$z)))
  p <- p %>% 
    addLegend(
      position = legendPlacement,
      labFormat = labelFormat(transform = quant, digits = rounding),
      pal = pal,
      bins = bins,
      values =  ~ zq,
      title = Title
    )
  
  
  }
  gc()  
  return (p)
  }

