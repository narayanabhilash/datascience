#####  cv.glm  #####
#' Function to run cross-validation on a glm model.
#' @description Wrapper around the glm function that runs cross-validation.
#' @usage cv.glm(data, cvFoldCol = NULL, folds = NULL, ...)
#' @param data A data.frame to be passed to \code{glm()} as you normally might (this is no longer an optional argument).
#' @param cvFoldCol A character variable containing the name of a column of integers in data that is used to define the crossfolds.
#' @param folds A list of row numbers of data which make up the crossfolds. One of \code{cvFoldCol} and \code{folds} must be specified
#' @param ... All/any other arguments used by \code{glm()}. Must include a formula parameter, and so on. See the \code{\link{glm}} help file.
#' @return A list of 2 objects. The first (fittedModels) is a list with k fitted glm objects, where k is the number of cross-folds defined using the cvFoldCol column. The second (OOFpreds) contains a data frame with the same number of rows as the input data table containing the out-of-fold predictions at the response level.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #cvGlmFit <- cv.glm(data = clmFreqData,
#' #                   cvFoldCol = "cvFold",
#' #                   formula = claimCount ~ PHAge + Tenure,
#' #                   family = poisson(link = "log"),
#' #                   offset = log(exposure))
#' @export


cv.glm <- function(data, cvFoldCol = NULL, folds = NULL, ...){
  # Validate input is correct
  if(!("data.frame" %in% class(data))) stop(paste0("Data must be a data.frame object"))
  if (is.null(folds) & is.null(cvFoldCol)) stop ("One of folds and cvFoldCol must be specified")
  if (!is.null (cvFoldCol)) {
    if (anyNA(data[[cvFoldCol]])) stop(paste0(cvFoldCol, "Column contains NAs"))
    if (!(all(data[[cvFoldCol]] == as.integer(data[[cvFoldCol]])))) stop(paste0(cvFoldCol, "Column must contain integer values"))
    if (!is.null(folds)) warning ("cvFoldCol and folds both specified: folds argument will be ignored")
    # Find number of folds and their Ids
    foldIds <- unique(data[[cvFoldCol]])
    foldIds <- foldIds[order(foldIds)]
    
    # Get folds
    folds <- lapply(foldIds, function(i) which(data[[cvFoldCol]] == i))
  } else {
    foldIds <- seq(1, length(folds))
    # validation of folds... 
    if (!("list" %in% class (folds))) stop ("folds must be a list of row numbers")
    if(!all(sapply(folds, is.integer))) stop("folds must be a list of integer row numbers")
    tempFolds <- unlist (folds)[order (unlist (folds))]
    if (!(length (tempFolds))== nrow(data)) stop ("folds must correspond to the rows in data")
    if  (!(all(tempFolds == seq (1,nrow(data))))) stop ("folds must contain each row number of data exactly once")
  }
  
  # Create a call to glm() by editing the current call to cv.glm()
  call <- match.call()
  call[[1]] <- quote(glm) # changes function to glm()
  call$cvFoldCol <- NULL # drops cvFoldCol argument as not needed (and will throw error) for glm()
  call$folds <- NULL # drops folds argument as not needed (and will throw error) for glm()
  
  # Function to fit a glm holding out fold i (done by changing the data argument, then evaluating)
  fitForFold <- function(rowsToHoldOut, call2){
    call2$data <- quote(data[-rowsToHoldOut, ]) # replace the data argument in the call to glm
    return(stripGlmLR(eval(call2))) #evaluate call to glm. stripGlmLR strips the returning glm object to bare bones
  }
  
  # Run fitForFold function for each of our folds
  fittedModels <- lapply(folds, fitForFold, call2=call)
  
  # Get out of fold predictions
  OOFpreds <- do.call("rbind", lapply(seq(1, length(folds)), function(i){
    data.frame(row=folds[[i]], fold=foldIds[[i]], prediction=predict(fittedModels[[i]], newdata=data[folds[[i]], ], type="response"))
  }))
  
  # Re-order and drop row and row names
  OOFpreds <- OOFpreds[order(OOFpreds$row), ]
  row.names(OOFpreds) <- NULL
  OOFpreds$row <- NULL
  
  # Return a list including the fitted models and out-of-fold predictions
  return(list(fittedModels=fittedModels, OOFpreds=OOFpreds))
}