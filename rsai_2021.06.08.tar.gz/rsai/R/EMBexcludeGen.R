#' Creates cut down EMB model files built by excluding specific factors (ie with any multipliers in the model associated with them set to 1).
#'
#' @param mod1 the starting model (as a data table or frame)
#' @param excludeSuper a named list of the group(s) of factors which you wish to create models without. All such factor effects, and ALL their interactions,
#' are removed from the relevant models. 
#' @param exclude2 an (optional) named list, but if it exists it must have the same names as excludeSuper. these factor effects will be excluded 
#' unless they are an interaction with other factors which are not in the same group of factors (or superfactors). 
#' @param baseString a character string that only appears in the names of the model(s) you wish to modify. By default this is set to "Value"
#' and thus creates modified versions of all the models in the data. 
#' @param type NULL (default) or 'Multiplicative', 'Additive' or 'Logistic'.
#' @return mod1 with additional calculated columns
#' @export
#'
#' @examples
#'modelFile <- data.table (Factor1 = c("",rep ("Age",10),rep("NCDYears",5)),Level1 = c("",31:40, 0:3,"4+" ),
#'ValueAll = c (0.02,1.5 - 0.1* (0:9), 1.5-0.2*(0:4) ) )
#'
#'EMBexcludeGen (modelFile, excludeSuper = list (NoAge ="Age", NoNCD = "NCDYears"))

 EMBexcludeGen <- function (mod1,
            excludeSuper = list(),
            exclude2 = NULL,
            baseString = "Value",
            type = NULL) {
    # excludeSuper are our superfactors which we always want to remove
    # exclude2 are not superfactors but are related to them
    # eg "Transmission" would be related to a vehicle superfactor but might interact on its own with non vehicle factors.
    # these we want to remove iff they aren't interacting with anything that's not in the list with them
    # (so for Vehicle, we might remove an interaction between Transmission type and fuel type -
    #but not between transmission and location superfac).
    
    # Start with validity checks - exclude2, if it exists, should have the same names as excludeSuper
   
   validate.EMBglm(mod1)
   
   if (is.null(type)){
     if (! is.null(attributes(mod1)$type)){
       type <- attributes(mod1)$type
     } else type <- "Multiplicative"
   } else{
     if (!is.character(attributes(object)$type)) stop("The type attribute is invalid")
     if (length(attributes(object)$type) != 1) stop("The type attribute is not valid")
     if (! attributes(object)$type %in% c("Multiplicative", "Additive", "Logistic")){
       stop("The type attribute should be 'Multiplicative', 'Additive', or 'Logistic'")
     }
   }
   
   if (type=="Multiplicative"){
     replaceVal <- 1
   } else if (type=="Additive"){
     replaceVal <- 0
   } else{
     replaceVal <- 0.5
   }
    
    if (!(is.null(exclude2))) {
      if (!(identical(names(exclude2), names (excludeSuper))))
        stop("exclude lists must have the same names")
    }
    
   mod1 <- copy (mod1)
   
    # for starters, these are the models we wish to create stripped versions of:
    basecols <-
      names (mod1)[intersect(grep ("Value", names (mod1)), grep(baseString, names(mod1)))]
    # and these are the columns containing factors:
    facCols <- names (mod1)[grep ("Factor", names (mod1))]
    
    for (nm2 in names (excludeSuper)) {
      # start by getting the rows to set to 1:
      oneRows <- NULL
      oneRows2 <- NULL
     
      # first, exclude anything in excludeSuper
      
      for (nm3 in facCols) {
        for (item in excludeSuper[[nm2]]) {
          oneRows <- union (oneRows, which (mod1[[nm3]] == item))
        }
      }
      # next, go to work on exclude2, if it's there
      
      if (!(is.null(exclude2))) {
        ex2List <- exclude2[[nm2]]
        for (nm3 in facCols) {
          
          # first time round, pick up every row that's got something from exclude2 in
          # subsequently, want to drop anything that doesn't  (and isn't empty)
          # if it's a superfactor, then it's in oneRows above anyway
          oneRows3 <- NULL
          for (item in ex2List) {
            
            oneRows3 <- union (oneRows3, which (mod1[[nm3]] == item))
          }
          
          if (nm3 == "Factor1") {
            oneRows2 <- oneRows3
            ex2List <- c(ex2List, "")
          } else {
            oneRows2 <- intersect(oneRows2, oneRows3)
          }
        }
        
      }
      oneRows <-  unique(union (oneRows, oneRows2))
      
      # now create the new columns:
      for (nm1 in basecols) {
        newCol <- gsub(baseString, nm2, nm1)
        if (!(grepl("Value",newCol))) newCol <- paste0("Value.",newCol)
        mod1[[newCol]] <- mod1[[nm1]]
        mod1[[newCol]][oneRows] <- replaceVal
        
        
      }
    }
    return (mod1)
  }