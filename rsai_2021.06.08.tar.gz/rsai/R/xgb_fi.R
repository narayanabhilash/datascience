#' Produce and save out xgboost model effects and fit
#'
#' @description This function allows you to generate, store and organise xgboost
#' model diagnostics as html. It can also launch a shiny app 
#' that outputs the relative strength of the interactions.
#' @usage xgb.fi (
#' model,
#' features = NULL,
#' max.interaction.depth = 2, 
#' max.trees = -1, 
#' top.k = 100, 
#' output_dir = "./modelhtml",
#' makeShiny = FALSE,
#' makeHTML = TRUE,
#' max_1way = 10,
#' max_2way = 5,
#' model_name = "model",
#' overwrite = T, 
#' plotXgbArgs=list(), 
#' plot_data = NULL,
#' plotResponseArgs=list(),
#' maps = NULL,
#' mapArgs = list(),
#' shortPath = FALSE,
#' autoWidth = FALSE,
#' xgbfi.loc = "C:/xgbfi",
#' max.histograms = 10,
#' max.deepening = -1,
#' outfile = "./modelhtml/xgbfi.xlsx"
#' ) 
#'
#' @param model the xgboost model to calculate on. 
#' @param max.interaction.depth Upper limit for extracted feature interactions depth.
#' (An interaction depth N involves N+1 variables.)
#' @param max.trees Upper limit for number of trees (default = -1, uses all of them)
#' @param features A character vector of the features in the model.
#' @param top.k Integer upper bound for exported feature interactions per depth level 
#' @param output_dir directory into which charts and data are saved.
#' @param makeShiny do you want a shiny app to open?
#' @param makeHTML do you want html charts saved?
#' @param max_1way maximum number of 1-way charts
#' @param max_2way maximum number of 2-way charts
#' @param model_name name of the model as displayed in the html output 
#' @param overwrite if TRUE, function can overwrite existing output, otherwise an error is thrown if it is detected
#' @param plotXgbArgs Optional list of extra non-default arguments passed to \code{plot.xgb.booster}
#' @param plot_data Optional data table used for 1 way A/E and/or maps.
#' @param plotResponseArgs other optional arguments list passed to \code{plotResponseFactor}- 
#' in particular you will need to pass some preds columns.
#' If not specified, these charts are not produced.
#' @param maps do you want maps via \code{plotLeafletMap}? if NULL (default) maps
#' are produced unless mapArgs is empty.
#' @param mapArgs = list()... other optional arguments list for maps. Note that maps are not
#' produced for factors. 
#' @param shortPath logical. Saves html files out with shorter paths: this makes them harder to
#' navigate but in some cases long variable names and directory paths cause failure, which this 
#' allows the user to get around.
#' @param autoWidth logical. Controls the \code{autoWidth} option in the \code{datatable} package used
#' to produce the html charts. Some users have found that columns are misaligned in the output.
#' This appears to be caused by changes to datatable in 2019: changing this variable may help.
#' Otherwise you get it in a series of csvs.
#' @param xgbfi.loc deprecated 
#' @param max.histograms deprecated 
#' @param max.deepening deprecated 
#' @param outfile deprecated 
#' @return NULL, invisibly.
#' @details The function runs xgbfi (the macro) to get statistics on the
#' relative importance of 1 way factors and their interactions. 
#' Note that an interaction indicated may be a false positive, particularly if both of the factors
#' in the intearction are individually important.
#' By default, 2 way interaction charts produced here show an interaction effect
#' over and above the 1-way effects.
#' xgbfR will sometimes show an interaction of a variable with itself
#' (because that's what the tree did): these effects are stripped out. 
#' @author Nigel Carpenter and Tom Bratcher
#' @export
#' @seealso \code{plot.xgb.booster}, \code{plotLeafletMap}, \code{plotResponseFactor} .
#' @keywords xgboost, xgbfi
#' @export
#' @examples
#' ## Not run:
#' # data ("UKTheftFreq") # gets dt_postcodes
#' # rowList <- list(train = UKTheftFreq[, which(year < 2016)],
#' #                 test = UKTheftFreq[, which(year == 2016)])
#' # modelVars <- setdiff(
#' #   names(UKTheftFreq),
#' #   c(
#' #     "exposure",
#' #     "numClaims",
#' #     "weight",
#' #     "offset",
#' #     "currentModel",
#' #     "foldId"
#' #   )
#' # )
#' # xgbData <- xgbSetupdata2(UKTheftFreq,
#' #                          response = "numClaims",
#' #                          explanatory_vars = modelVars,
#' #                          exposure = "exposure",
#' #                          sampleWeight = "weight",
#' #                          offset_model = "offset",
#' #                          rowIndicesList = rowList)
#' # 
#' # foldList <- folds_VecToList(UKTheftFreq[rowList$train, foldId])
#' # 
#' # param <- list(
#' #   objective = "count:poisson",
#' #   max_depth = 3L,           # tree-depth
#' #   subsample = 0.9,          # randomly sample rows before fitting each tree
#' #   colsample_bytree = 0.9,   # randomly sample columns before fitting each tree
#' #   min.child.weight = 20,    # minimum weight per leaf
#' #   eta = 0.08               # Learning rate
#' #   )
#' # set.seed(7857699L)
#' # 
#' # xgbFit <- xgb.train(
#' #   params                 = param,
#' #   data                   = xgbData$train,
#' #   nrounds                = 100,
#' #   base_score             = 1,
#' #   watchlist              = xgbData,
#' #   print_every_n          = 50
#' # )
#' # 
#' # UKTheftFreq$preds <-1
#' # UKTheftFreq[rowList$test,preds:=predict(xgbFit,xgbData$test)]
#' # 
#' # xgb.fi(xgbFit, 
#' #       features = colnames(xgbData$train),
#' #       max_1way = 3,
#' #       max_2way = 2,
#' #       makeShiny = F,
#' #       plot_data = UKTheftFreq[rowList$test],
#' #       plotResponseArgs = list (response = "numClaims",
#' #                                predCols = c("currentModel", "preds"),
#' #                                exposure = "exposure",
#' #                                weight = "weight",
#' #                                maxLevs = 10),
#' #       mapArgs = list (XY=c("coordinate_x","coordinate_y"),
#' #                       Country = "UK",
#' #                       legendPlacement = "topright")
#' #       )

xgb.fi <-
  function(
    model,
    features = NULL,
    max.interaction.depth = 2, # riff on this and see
    max.trees = -1,
    top.k = 100, #xgbfi
    output_dir = "./modelhtml",
    makeShiny = FALSE,
    makeHTML = TRUE,
    max_1way = 10,
    max_2way = 5,
    model_name = "model",
    overwrite = T, # does it already exist?
    plotXgbArgs = list(), # OPTIONAL extra arguments list for plot.xgb
    plot_data = NULL,
    plotResponseArgs = list(), #REQUIRED: arguments list for plotResponse
    maps = NULL,
    mapArgs = list(), # optional arguments list for map
    shortPath = FALSE,
    autoWidth = FALSE,
   # XL = FALSE,
    #DEPRECATED::
    xgbfi.loc = "C:/xgbfi",
    max.histograms = 10, 
    max.deepening = -1,
    outfile = "./modelhtml/xgbfi.xlsx" 
) {
  #######   

# Issues list -------------------------------------------------------------

# because of construction order, get map links where maps are not desirable (factors) 
# if you save and reload models stuff gets lost: have I found it all?
# would / could function still work of xgb.dump (with stats, natch)    
    
###########    
  
  # model <- curr_model
  # features = colnames(xgb_data$dt_train)
  # outfile = output_dir
  # makeHTML = TRUE
  # model_name = "model"
  # xgbfi.loc = "C:/xgbfi"
  # max.interaction.depth = 2
  # max.deepening = -1
  # max.trees = -1
  # top.k = 100
  # max.histograms = 10
  # outfile = NULL
  # makeShiny = FALSE
  # max_1way = 10
  # max_2way = 5
    
    # 1. Quality Control ------------------------------------------------------

    if (!("xgb.Booster") %in% class (model)) stop ("model needs to be an xgb.Booster object")  
    # possibly could do this off a dump, but not going to try right now
    if (is.null (maps)) maps <- length(mapArgs) > 0
    
    # 2. xgbfR ----------------------------------------------------------- 
  
  xgbfRtables <- xgbfR(
    model,
    features = features,
    top.k = top.k,
    condenseFlag = T,
    condenseSeparator = "~",
    max.interaction.depth = max.interaction.depth,
    max.trees = max.trees
  )
  
  if (max.interaction.depth >= length(xgbfRtables)){
    cat("Model appears to be of max depth", length(xgbfRtables), "\n")
  }
  
  # max interaction depth is actually...  
  max.interaction.depth <- length(xgbfRtables) - 1  

  # 3. HTML bits ------------------------------------------------------------
 
 shinyBits = F #!?
  
    tableVars1 <- function(){
      featuresimp <- xgbfRtables[[1]]
      featuresimp[, Gain.Percentage := round (Gain/sum(Gain), 4)]
       # want to remove a bunch of these, I suspect... Can add stuff back in later if really needed
      if (!(shinyBits)){
      featuresimp[, '1 way PD' := paste0("<a href=\".\\CHT_ParDep_1way\\1way_", .I, "_", Feature, ".html\">Par Dep</a>")]
      featuresimp[, '1 way AvE' := paste0("<a href=\".\\CHT_AvE_1way\\", .I, "_", Feature, ".html\">AvE</a>")]
      featuresimp[, 'Map' := paste0("<a href=\".\\CHT_MAP\\", .I, "_", Feature, ".html\"> Map</a>")]
      # remove any links which won't work:

      
      # shortNames:
      if (shortPath){
      featuresimp[, '1 way PD' := paste0("<a href=\".\\CHT_ParDep_1way\\1way_", .I, ".html\">Par Dep</a>")]
      featuresimp[, '1 way AvE' := paste0("<a href=\".\\CHT_AvE_1way\\", .I, ".html\">AvE</a>")]
      featuresimp[, 'Map' := paste0("<a href=\".\\CHT_MAP\\", .I, ".html\"> Map</a>")]           
      }
      featuresimp[-1:-min(max_1way,nrow(featuresimp)),`:=`('1 way PD'="",'1 way AvE'="",Map="")] # yes, this works if max_1way is zero
      if(!(length(plotResponseArgs))) featuresimp[,'1 way AvE':=""]
      if(!(maps)) featuresimp[, Map:= ""] # not perfect because factor maps shouldn't exist...
      } else setcolorder(
        featuresimp,
        c("Feature", "Gain.Percentage",
          colnames(featuresimp)[!colnames(featuresimp) %in% c("Feature", "Gain.Percentage")])
      )
      return(featuresimp)
    }
    
    tableVars2 <- function(){
      if (max.interaction.depth<1) return (
        data.table(Feature="",
        '2 way PD'="",
        Gain.Percentage=1))
      featuresimp <- xgbfRtables[[2]]
      featuresimp[, c("Var1", "Var2") := tstrsplit(Feature, "|", fixed=TRUE)]
      # remove any duplicates, which can happen still...
      featuresimp<-featuresimp[Var1!=Var2]
      featuresimp[, Gain.Percentage := Gain/sum(Gain)]
      if (!(shinyBits)){
      featuresimp[, '2 way PD' := paste0("<a href=\".\\CHT_ParDep_2way\\2way_",.I,"_",
                                         featuresimp[.I,Var1],"_",
                                         featuresimp[.I,Var2],".html\">Par Dep</a>")]
        if (shortPath){
          featuresimp[, '2 way PD' := paste0("<a href=\".\\CHT_ParDep_2way\\2way_",.I,".html\">Par Dep</a>")]           
        }
      featuresimp[-1:-min(max_2way,nrow(featuresimp)),'2 way PD':=""]
      featuresimp[, Gain.Percentage := round (Gain/sum(Gain), 4)]
      setcolorder(
        featuresimp,
        c("Feature",
          "2 way PD",
          "Gain.Percentage",
          colnames(featuresimp)[!colnames(featuresimp) %in% c("Feature", "2 way PD", "Gain.Percentage")]))
      } else setcolorder(
        featuresimp,
        c("Var1", "Var2", "Gain.Percentage",
          colnames(featuresimp)[!colnames(featuresimp) %in% c("Var1", "Var2", "Gain.Percentage")]))
      return(featuresimp)
        
    }
      tableVars3 <- function(){
        if (max.interaction.depth<2) return (
          data.table(Feature="",'3 way PD'="",
          Gain.Percentage=1
        ))
      featuresimp <- xgbfRtables[[3]]
      featuresimp[, c("Var1", "Var2", "Var3") := tstrsplit(Feature, "|", fixed=TRUE)]
      featuresimp <- featuresimp[(Var1!=Var2&Var1!=Var3)&Var2!=Var3]
      featuresimp[, Gain.Percentage := round (Gain/sum(Gain), 4)]
      setcolorder(featuresimp, c("Var1", "Var2", "Var3", "Gain.Percentage",
                                 colnames(featuresimp)[!colnames(featuresimp) %in% c("Var1", "Var2", "Var3", "Gain.Percentage")]))
      
      return(featuresimp)
    }

    if (makeHTML){
    # Create 1 way partial dependency html table
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   
    sketch = htmltools::withTags(table(
     class = 'display',
     thead(
       tr(th(colspan = 5, paste0('Table 1: One way variable importance for model ',model_name))),
       tr(lapply(names(tableVars1()), th))
     )
    ))
        output_Vars1 <- datatable(
          tableVars1(),
          class = 'cell-border stripe',
          escape = FALSE,
          extensions = 'Buttons',
          container = sketch,
          rownames = FALSE,
          options = list(
            dom = 'Bfrtip',
            buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
            pageLength = 20,
            autoWidth = autoWidth
          )) %>% 
      formatStyle(
        'Gain.Percentage',
        background = styleColorBar(c(0, max(tableVars1()$Gain.Percentage)), 'lightblue'),
        backgroundSize = '90% 80%',
        backgroundRepeat = 'no-repeat',
        backgroundPosition = 'center') %>% 
          formatPercentage(columns = c('Gain.Percentage'), digits = 2)  %>%
          formatRound(
            columns = c('Gain', 'FScore'),
            digits = 0
          ) 
        
    # check output folder exists before save.
    if((dir.exists(file.path (output_dir,"CHT_ParDep_1way")))){
      if (!(overwrite)) stop ("Output directories already exist. Either create a new directory or set overwrite to TRUE")
    } else dir.create(file.path (output_dir),recursive = T,showWarnings = F)
    saveWidget(widget = output_Vars1, file = paste0(normalizePath(output_dir), "\\output_Vars1.html"),selfcontained = TRUE)

    # Create 1 way partial dependency plots
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    # if you have a loaded and resaved model, niter doesn't get saved. LOVELY.
    # recover it:
    if (!("niter") %in% names(model)){
      model$niter = length (grep("^booster\\[",xgb.dump(model)))
    } 
    
  #  XLFile <- file.path(output_dir, paste0("DTab",gsub("[^0-9]","",Sys.time()),".xls"))
    ntrees <- ifelse(is.null(model$best_iteration),model$niter,model$best_iteration)
    featuresimp <- tableVars1()
    
    # make sure we have only one data set:
    if (length (plotResponseArgs) && length (mapArgs)) mapArgs$dt <- NULL
    
    # check folder exists before save.
    ifelse(!dir.exists(file.path (output_dir,"CHT_ParDep_1way")), dir.create(file.path (output_dir, "CHT_ParDep_1way")), FALSE)
    if (length (plotResponseArgs)){
      ifelse(!dir.exists(file.path (output_dir,"CHT_AvE_1way")), dir.create(file.path (output_dir, "CHT_AvE_1way")), FALSE)
    }
      if (length (mapArgs)){
        ifelse(!dir.exists(file.path (output_dir,"CHT_MAP")), dir.create(file.path (output_dir, "CHT_MAP")), FALSE)
    }
    # have we generated a warning?
    warned =F
    # set up arguments for plot:
    nWayList <- plotXgbArgs
    nWayList$x=model
    nWayList$var.names=features
    if(is.null(nWayList$n.trees)) nWayList$n.trees=ntrees
    if(max.trees>0)nWayList$n.trees=min(nWayList$n.trees,max.trees)
    nWayList$ex1Way=F
    
    for (i in 1:max_1way) if(max_1way > 0) {
     
      varSTR = featuresimp[i,Feature]
      if (is.na(varSTR)) {
        if (warned ==F) warning ("Not that many features/interactions in the model")
        warned = T
        } else {

          cat(paste0(i," ", varSTR, "\n"))
    # add to nWayList and call:  
       nWayList$vars <- varSTR   
      p <- do.call(plot.xgb.Booster, nWayList) # plot must always exist, say!
      if (!("plotly" %in% class(p))) {
        p$plot <- p$plot %>%
        layout(
          title = paste0(varSTR, " - 1 way partial dependency plot"),
          yaxis = list(title = "Proxy risk multiplier"),
          xaxis = list(title = varSTR)
        )} else {
          p <- p %>%
            layout(
              title = paste0(varSTR, " - 1 way partial dependency plot"),
              yaxis = list(title = "Proxy risk multiplier"),
              xaxis = list(title = varSTR)
            )
        }
      tempStr <- paste0("_",varSTR)
      if (shortPath) tempStr <- ""
      if (!("plotly" %in% class(p))) {
       # print(p$plot)
        saveWidget(as_widget(p$plot), paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1way_",i,tempStr,".html"))
        # if (XL) {
        #   write.xlsx(
        #   p$table, file = XLFile,
        #   sheetName = paste0("1WT_", i, substr(tempStr, 1, 20)),
        #   append = file.exists(XLFile))
        # } else 
        fwrite(p$table, file = paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1tab_",i,tempStr,".csv"))
         if ("EMB" %in% names(p)) {
        #   if (XL) {
        #     write.xlsx(
        #       p$EMB, file = XLFile,
        #       sheetName = paste0("1WEMB_", i, substr(tempStr, 1, 20)),
        #       append = file.exists(XLFile))
        #   } else
            fwrite(
          p$EMB, file = paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1emb_",i,tempStr,".csv"))  
       }
      } else {
        saveWidget(
        as_widget(p), paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1way_",i,tempStr,".html"))
      }
      # Create A/E charts using plotResonpseByCol:
      # set up arguments for plotresponseArgs:
   
      if (length(plotResponseArgs) & varSTR %in% names(plot_data)) { #TO DO: remove the others!
        plotResponseArgs$col <- varSTR
        p <- do.call(plotResponseByCol, c(plotResponseArgs, list(data=plot_data)))
        saveWidget(as_widget(p), paste0(normalizePath(output_dir), "\\CHT_AvE_1way\\",i,tempStr,".html"))
      }
      
      # Similarly, create maps:
      if (maps & varSTR %in% names(plot_data)) { 
          if (any(c("integer", "numeric", "POSIXt", "Date") %in% class(plot_data[[varSTR]]))){
          # cat ("mapping", varSTR, "\n")
            mapArgs$col <- varSTR
            p <- do.call(plotLeafletMap, c(mapArgs, list(dt = plot_data)))
            if (!(is.null(p))) saveWidget(
              as_widget(p),
              paste0(normalizePath(output_dir), "\\CHT_MAP\\", i, tempStr, ".html"))
            }
          }
        }
      }
   
    # Create 2 way partial dependency html table
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if (max.interaction.depth > 0){ #! ok, so now these just don't get produced...
    sketch = htmltools::withTags(table(
      class = 'display',
      thead(
        tr(th(colspan = 5, paste0('Table 2: Two way variable importance for model ',model_name))),
        tr(lapply(names(tableVars2()), th))
      )
    ))
    
    output_Vars2 <- datatable(
      tableVars2(),
      class = 'cell-border stripe',
      escape = FALSE,
      extensions = 'Buttons',
      container = sketch,
      rownames = FALSE,
      options = list(
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
        pageLength = 20,
        autoWidth = autoWidth
      )) %>% 
      formatStyle(
        'Gain.Percentage',
        background = styleColorBar(c(0, max(tableVars1()$Gain.Percentage)), 'lightblue'),
        backgroundSize = '90% 80%',
        backgroundRepeat = 'no-repeat',
        backgroundPosition = 'center') %>% 
      formatPercentage(columns = c('Gain.Percentage'), digits = 2)  %>%
      formatRound(columns = c('Gain', 'FScore'), digits = 0)
 
    saveWidget(
      widget = output_Vars2,
      file = paste0(normalizePath(output_dir), "\\output_Vars2.html"),
      selfcontained = TRUE)
   
    
    # Create 2 way partial dependency plots
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    featuresimp <- tableVars2()
    
    # check folder exists before save.
    ifelse(!dir.exists(file.path (output_dir, "CHT_ParDep_2way")),
           dir.create(file.path (output_dir, "CHT_ParDep_2way")),
           FALSE)

    # set up arguments for plot:
    
    nWayList$ex1Way <- TRUE # default here
    nWayList$line <- NULL #(does nothing for 2 ways) 
    nWayList$marker <- NULL #(ditto) 
    if (!(is.null(plotXgbArgs$ex1Way)))nWayList$ex1Way=plotXgbArgs$ex1Way
    
    for (i in 1:max_2way) if (max_2way>0){
        varSTR = featuresimp[i,Feature]
        if (is.na(varSTR)) {
          if (warned ==F) warning ("Not that many features/interactions in the model")
          warned <- T
        } else 
      cat(paste0(i," ", varSTR, "\n"))
        nWayList$vars=unlist (strsplit(varSTR,"\\|"))
         p <- do.call (plot.xgb.Booster,nWayList)
      
      tempStr <- paste0("_",featuresimp[i,Var1],"_", featuresimp[i,Var2])
      if(shortPath) tempStr <- ""     
      if (!("plotly" %in% class(p))){
        if ("plot" %in% names(p)) saveWidget(
            as_widget(p$plot), paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2way_",i,tempStr,".html"))
        # if (XL) {
        #   write.xlsx(
        #     p$EMB, file = XLFile,
        #     sheetName = paste0("2WT_", i, substr(tempStr, 1, 20)),
        #     append = file.exists(XLFile))
        # } else
          fwrite(p$table, file = paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2tab_",i,tempStr,".csv"))
        if ("EMB" %in% names(p)) {
            # if (XL) {
            #   write.xlsx(
            #     p$EMB, file = XLFile,
            #     sheetName = paste0("2WEMB_", i, substr(tempStr, 1, 20)),
            #     append = file.exists(XLFile))
            # } else
              fwrite(
              p$EMB,
              file = paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2emb_", i, tempStr, ".csv"))
          }
      } else saveWidget(
        as_widget(p), paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2way_",i,tempStr,".html"))
    }
    
    }
    
    if (max.interaction.depth > 1){
    
    output_Vars3 <- datatable(tableVars3(),
                filter = 'top',
                class = 'hover stripe',
                options = list(pageLength = 100,
                               lengthMenu = c(10, 50, 100, 200))
      ) %>% formatStyle('Gain.Percentage',
                        background = styleColorBar(c(0, max(tableVars3()$Gain.Percentage)), 'lightgreen'),
                        backgroundSize = '100% 90%',
                        backgroundRepeat = 'no-repeat',
                        backgroundPosition = 'center') %>%
        formatPercentage(columns = c('Gain.Percentage'),
                         digits = 4)
      
    
    saveWidget(widget = output_Vars3, file = paste0(normalizePath(output_dir), "\\output_Vars3.html"),selfcontained = TRUE)
    
    }
  }
  
  if (makeShiny){
    # rationalise these tables with those above. Obviously.
    shinyBits=T
    shinyApp(ui = fluidPage(navbarPage(
      "XGBoost",
      tabPanel(
        
        "XGBoost Feature Interaction",
        fluidPage(tabsetPanel(
          tabPanel(
            "Feature Interaction",
            value = 1,
            h4("Feature Interaction"),
            p("The feature interactions present in the model."),
            DT::dataTableOutput("tableVars1")
          ),
          tabPanel(
            "2 Variable Feature Interaction",
            value = 2,
            h4("Feature Interaction"),
            p("The 2 variables feature interactions present in the model."),
            DT::dataTableOutput("tableVars2")
          ),
          tabPanel(
            "3 Variable Feature Interaction",
            value = 2,
            h4("Feature Interaction"),
            p("The 3 variables feature interactions present in the model."),
            DT::dataTableOutput("tableVars3")
          ),
          id = "conditionedPanels"
        )))
    )),                                              
    server = function(input, output, max.interaction.depth = max.interaction.depth) {
      output$tableVars1 <- DT::renderDataTable(
        datatable(
          tableVars1(),
          # This goes and gets the data to display. However it's just displaying hyperlinks as text...
          filter = 'top',
          class = 'hover stripe',
          options = list(
            pageLength = 100,
            lengthMenu = c(10, 50, 100, 200)
          )
        ) %>% formatStyle(
          'Gain.Percentage',
          background = styleColorBar(c(0, max(
            tableVars1()$Gain.Percentage
          )), 'lightgreen'),
          backgroundSize = '100% 90%',
          backgroundRepeat = 'no-repeat',
          backgroundPosition = 'center'
        ) %>%
          formatPercentage(columns = c('Gain.Percentage'),
                           digits = 4)
      )
      #   if (max.interaction.depth>0){
      output$tableVars2 <- DT::renderDataTable(
        datatable(
          tableVars2(),
          filter = 'top',
          class = 'hover stripe',
          options = list(pageLength = 100,
                         lengthMenu = c(10, 50, 100, 200))
        ) %>% formatStyle(
          'Gain.Percentage',
          background = styleColorBar(c(0, max(
            tableVars2()$Gain.Percentage
          )), 'lightgreen'),
          backgroundSize = '100% 90%',
          backgroundRepeat = 'no-repeat',
          backgroundPosition = 'center'
        ) %>%
          formatPercentage(columns = c('Gain.Percentage'),
                           digits = 4)
      )
      # } #else output$tableVars2 <- DT::renderDataTable(data.frame(NotUsed="TreetooShallow"))
      
      #  if (max.interaction.depth>1){
      output$tableVars3 <- DT::renderDataTable(
        datatable(
          tableVars3(),
          filter = 'top',
          class = 'hover stripe',
          options = list(pageLength = 100,
                         lengthMenu = c(10, 50, 100, 200))
        ) %>% formatStyle(
          'Gain.Percentage',
          background = styleColorBar(c(0, max(
            tableVars3()$Gain.Percentage
          )), 'lightgreen'),
          backgroundSize = '100% 90%',
          backgroundRepeat = 'no-repeat',
          backgroundPosition = 'center'
        ) %>%
          formatPercentage(columns = c('Gain.Percentage'),
                           digits = 4)
        
      )
      #    } else output$tableVars3 <- DT::renderDataTable(data.frame(NotUsed="TreetooShallow"))
    }
    )
  }else return (invisible(NULL))      
}
