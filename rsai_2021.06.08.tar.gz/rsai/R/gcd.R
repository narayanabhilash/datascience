#####  gcd  #####
#' Greatest common divisor
#' @description This function takes a vector, and returns the greatest common divisor.
#' @usage gcd(x)
#' @param x A numerical vector (should be integers but does return meaningful values for some sets of fractions, I.E. multiples of 0.5)
#' @return Value representing the greatest common divisor
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #gcd(c(28, 70, 84))
#' @export
#' 

gcd <- function(x){
  # Unique values not including zero
  x <- unique(abs(x))
  x <- x[which(x!=0)]
  
  # Euclid's Algorithm to calculate GCD for 2 numbers
  EuclidsAlgoritm <- function(x1, x2) {
    r <- x1%%x2
    return(ifelse(r, EuclidsAlgoritm(x2, r), x2))
  }
  
  # Loop through Euclid's algorithm along the lenght of x
  for(i in seq(1, length(x))){
    if(i==1){
      r <- x[1]
    } else{
      r <- EuclidsAlgoritm(x[i], r)
    }
  }
  
  # Return GCD
  return(r)
}