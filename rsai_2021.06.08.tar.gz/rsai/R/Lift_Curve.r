#####  LiftCurve  #####
#' Plot a lift curve for observed and fitted values.
#' @description Plot a lift curve for observed and fitted values.
#' @usage LiftCurve(Observed,
#'           Fitted,
#'           Exposure=NULL,
#'           SampleWeight=NULL,
#'           Bands=20,
#'           Title='Lift Chart',
#'           ...)
#' @param Observed Vector of response variable being modelled. For claims frequency, this is number of claims, for severity, total loss.
#' @param Fitted Vector of model predictions. If frequency model this should be annualised (and an exposure specified.) If severity this is a model of average claim severity.
#' @param Exposure Optional vector of exposure for claims frequency (or claim count for severity.) These are called Weights in Emblem.
#' @param SampleWeight Optional vector of weighting to apply that is unrelated to exposure or claim count (E.G. weights arising from sampling.)
#' @param Bands Number of bands to plot. Default is 20.
#' @param Title Chart title. Default is 'Lift Chart'.
#' @param \dots Arguments to pass through to \code{plot_ly}, for example, \code{width} to change the width of the plotting window.
#' @return Plotly plot.
#' @author Aravind Lakshminarayanan (Aravind.Lakshminarayanan@gcc.rsagroup.com)
#' @export

LiftCurve <- function(Observed,
                      Fitted,
                      Exposure=NULL,
                      SampleWeight=NULL,
                      Bands=20,
                      Title='Lift Chart',
                      ...) {
  
  # merge all the necessary columns
  lift_curve_data <- data.table(Observed=Observed, Fitted=Fitted)
  if(!is.null(Exposure)) lift_curve_data[, ':='(Observed=Observed/Exposure, Weight=Exposure)] else lift_curve_data[, Weight := 1]
  if(!is.null(SampleWeight)) lift_curve_data[, Weight := Weight*SampleWeight]
  
  # order by ascending of fitted values
  lift_curve_data <- lift_curve_data[order(Fitted)]
  
  # calculate total Exposure and break into n bands
  lift_curve_data$Cum_Weight <- cumsum(lift_curve_data$Weight)
  lift_curve_data$Weight_Banding <- (cut(lift_curve_data$Cum_Weight, breaks = Bands, labels = FALSE))
  
  # calcualte Weighted oberved and fitted for each band
  banded_table <- lift_curve_data[, .(Weighted_Observed=weighted.mean(Observed, Weight),
                                      Weighted_Fitted=weighted.mean(Fitted, Weight),
                                      Weight=sum(Weight)), keyby=Weight_Banding]
  
  # plot the lift curve using existing complot
  p <- plot_ly(banded_table, x = banded_table$Group.1, y = banded_table$Weight, type = "bar", name = "Weight",
               marker = list(color = '#d9d9d9'), 
               hoverinfo = "text",
               text = ~paste(Weight),
               ...) %>%
    add_trace(x = banded_table$Group.1, y = banded_table$Weighted_Observed, type = "scatter", mode = "lines+markers", name = "Observed",
              yaxis = "y2", marker = list(color = '#ff49a4'), 
              line = list(color = '#ff49a4'), hoverinfo = "text",
              text = ~paste(Weighted_Observed)) %>%
    add_trace(x = banded_table$Group.1, y = banded_table$Weighted_Fitted, type = "scatter", mode = "lines+markers", name = "Fitted",
              yaxis = "y2",marker = list(color = '#00c2db'),
              line = list(color = '#00c2db'), hoverinfo = "text",
              text = ~paste(Weighted_Fitted)) %>%
    layout(title  = Title,
           xaxis  = list(title = ""),
           yaxis  = list(side = 'right', title = 'Weight', showgrid = FALSE, zeroline = FALSE),
           yaxis2 = list(side = 'left', overlaying = "y", title = 'Fitted (and) Observed Values', showgrid = FALSE, zeroline = FALSE)) %>%
   
     print(p)
  
}
