#' logit function
#' @description logit function
#' @param x numeric vector
#' @export
logit <- function(x) log(x/(1-x))

#' Inverse function of logit
#' @description Inverse function of logit
#' @param x numeric vector
#' @export
invlogit <- function(x) exp(x)/(exp(x)+1)

#' CBA function
#' @description Estimator for value added from a pricing update
#' @param premium input
#' @param relativity input
#' @param exposure input
#' @param elasticity input
#' @param LRM input
#' @param fixTPA technical pricing adjustment
#' @param elType string. One of exponential or logistic
#' @param conversion  input
#' @export
#' 
CBA <- function(
  premium = 100, relativity, exposure, elasticity = -8, LRM = 0.8,
  fixTPA = FALSE, elType = c("exponential", "logistic"), conversion =
    0.05){
  
  warning("This function is deprecated: claimsCBA suggested")
  
	elType <- match.arg(elType)
	if(elType=="logistic"){
		if(any(conversion < .Machine$double.xmin * 1E10)){
			warning("'conversion' should be strictly positive. Making it so")
			conversion <- pmax(.Machine$double.xmin * 1E10,conversion)
		}
		alpha <- logit(conversion)
	}
	if(any(elasticity>0)){
		warning("positive components of elasticity detected. Elasticities are supposed to be negative.")
		elasticity <- -abs(elasticity)
	}
	exposure <- exposure / sum(exposure)
	GWP0 <- sum(premium * exposure)
	RMI0 <- sum(exposure * premium * relativity)
	if(fixTPA){
		prem1 <- premium * relativity
		vol1 <- switch(elType,
			"logistic"=exposure * invlogit(alpha+elasticity*(relativity-1))/conversion,
			"exponential"=exposure * exp(elasticity * (prem1/premium-1))
		)
		RMI1 <- sum(vol1 * prem1)
		GWP1 <- sum(vol1 * prem1)
		return(list(GWP0=GWP0,RMI0=RMI0,GWP1=GWP1,RMI1=RMI1,PIF1=sum(vol1),dLR=(RMI0/GWP0)-(RMI1/GWP1)))
	}
	if(any(elasticity > -3)) warning("using elasticities greater than -3 is not recommended\n  as results can be misleading (or even negative!)\n  Consider increasing elasticity and reducing relativity instead.")
	dGWP <- function(TPA){
		prem1 <- premium * relativity * TPA
		vol1 <- switch(elType,
			"logistic"=exposure * invlogit(alpha+elasticity*(relativity*TPA-1))/conversion,
			"exponential"=exposure * exp(elasticity * (prem1/premium-1))
		)
		return(sum(vol1*prem1) - GWP0)
	}
	## maybe better to target same total PIF? (try to avoid negative benefits!)
	t1 <- uniroot(dGWP,c(0.5,2),tol=.Machine$double.eps^0.35)
	TPA <- t1$root
	GWP1 <- t1$f.root + GWP0
	prem1 <- premium * relativity * TPA
	vol1 <- switch(elType,
		"logistic"=exposure * invlogit(alpha+elasticity*(relativity*TPA-1))/conversion,
		"exponential"=exposure * exp(elasticity * (prem1/premium-1))
	)
	RMI1 <- sum(vol1 * premium * relativity)
	RMIben <- (RMI0 - RMI1)/RMI0
	return(list(TPA=TPA,PIF=vol1,dRMI=RMIben,dLR=RMIben * LRM))
}

