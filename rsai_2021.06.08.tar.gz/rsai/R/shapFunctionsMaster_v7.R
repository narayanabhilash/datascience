

###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~----

## 1. Creating SHAP values ----
# Saving as a list

# {f}  createShapValues
#' Tidies up xgboost shap values from a dMatrix
#' @description  returns Shapley values on a row by row basis for an xgboost
#' tree model applied to a datset constructed using xgbSetupdata2 together with summary statistics
#' @param xgb_model the model
#' @param xgb_data the dMatrix (or list of them, in which case you get a list)
#' created by xgbSetupdata2
#' @param numTrees optional, number of trees to apply
#' @param report optional extra printed output during processing for...
#' @param rowToCheck ... the row to check
#' @param factorLength control on the length of the check output
#' @param Attributes optional attribute list to apply to the dMatrix.
#' @param Combine whether to combine dMatrix columns with a common input feature or not 
#' This allows you to restore attributes easily if taking a row subsample
#' @return a list of shapley objects
#' @author Russell Green 
#' @export
#'
#' @examples
#'
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000

#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )

#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )

#' # Create the shap values on test:

#' shapList <- createShapValues(
#'   xgbModel,
#'   xgbdata$test
#' )

#'# Also see tutorial on the data science blog.
#'
createShapValues <- function(
  xgb_model,
  xgb_data,
  numTrees = NULL,
  report = FALSE,
  rowToCheck = 1, #can it be NULL?
  factorLength = 10,
  Attributes = list(),
  Combine = TRUE
  ){
  
  # VALIDATION
  
  if (!(inherits(xgb_model, "xgb.Booster"))) stop (
   "Model must be an xgboost tree model"
  )
  # want a possilble list so....
  if (inherits(xgb_data, "list")){
    if(!(all(sapply(xgb_data, function (x) inherits(x, "xgb.DMatrix"))))) stop(
      "If xgb_data is a list all its elements must be DMatrices"
    )
    return (lapply(xgb_data, function (x) createShapValues(
      xgb_model = xgb_model, xgb_data = x,  numTrees = numTrees, 
      report = report, rowToCheck = rowToCheck, factorLength= factorLength
    )))
  }
  if (!(inherits(xgb_data, "xgb.DMatrix"))) stop (
    "xgb_data must be a DMatrix (or list of them)")
    
  if(!(inherits(Attributes, "list"))) stop ("Attributes must be a named list") 
  
  numberRows <- getinfo(xgb_data, "nrow")
  
  # set attributes:
  for (nm in names(Attributes)) attr(xgb_data, nm) <- Attributes[[nm]]
  if (is.null(colnames(xgb_data))) 
    colnames(xgb_data) <- attributes(xgb_data)$.Dimnames[[2]]
  
  # numtrees defaults to NULL so
    shap_contrib <- as.data.table(predict(
      xgb_model, xgb_data, ntreelimit=numTrees,
      predcontrib = TRUE, approxcontrib = FALSE))
  
  # first create the shap values using xgbDmatrix data and xgbooster model

  # Last column is bias. it's adjusted for the actual values in the data but it's not
    # constant if the offset isn't. so rather than removing it, don't remove it
  BIAS0 <- shap_contrib[,ncol(shap_contrib), with = FALSE]
  shap_contrib[, ncol(shap_contrib) := NULL]
  if (Combine){
    for (selectedOrderedFactor in names(attributes(xgb_data)$facEncodingTbls)){
      cols <- names(attributes(xgb_data)$facEncodingTbls[[selectedOrderedFactor]]) # gets NA, too
      cols <- cols[grep("~", cols)] 
      shap_contrib[, eval(selectedOrderedFactor) := rowSums(.SD), .SDcols = cols]
      # add a sampling for report...
      
      if (report) {
        shap_contrib2 <-
          shap_contrib[rowToCheck, c(cols, selectedOrderedFactor), with = FALSE]
        print(shap_contrib3 <- data.frame(shap = t(round(shap_contrib2, 5))))[
          1:min(factorLength, 1 + length(cols))]
        # shows for 1st row the additive cols for each OHE
      } 
      # remove combined columns
      for (k in cols){
        shap_contrib[, (k) := NULL] 
      }
    }
    # sort out names of encoded logical, date etc in case not covered by this
    colnames(shap_contrib) <- gsub("~.*","",colnames(shap_contrib))
 }
  # create WEIGHTED mean absolute SHAP score in decreasing order:
  w <- getinfo(xgb_data, "weight")
  if (is.null(w)) w <- rep(1, nrow(shap_contrib))
  
  mean_shap_score <- sort(
    apply(
      shap_contrib, 2, function(x)
        weighted.mean(abs(x), w = w)
      ), decreasing = TRUE)
    # colMeans(abs(shap_contrib))[
    # order(colMeans(abs(shap_contrib)), decreasing = T)]
  shap <- data.frame(shap= round(mean_shap_score, digits = 4) )
  temp <- data.table(Feature=row.names(shap), shap)

  # also their maximal absolutes:
  max_shap_score <- sort(
    apply(
      shap_contrib, 2, function(x)
        max(abs(x))
    ), decreasing = TRUE)

  
  # summary of shap values for each feature (min, 1stQ, median, 3rdQ, max) for output
  range_shap_score <- sapply(shap_contrib, function(x) summary(x, digits=3))
  df_rangeShap <- range_shap_score[which(row.names(range_shap_score)!= "Mean"),] # data frame screws the names up
  df_rangeShap2 <- t(df_rangeShap)
  
  dt_rangeShap <- cbind(
    data.table(feature=row.names(df_rangeShap2), df_rangeShap2), Mean_abs=temp$shap)
  dt_rangeShap <- dt_rangeShap[, lapply(
    .SD, format, scientific = FALSE, drop0trailing = TRUE)]
  
  # return a list of row shap scores, column means, various feature vectors, total n and BIAS
  return(
    list(
      shapValues = shap_contrib,
      meanAbsShap = mean_shap_score,
      baseline = as.numeric(unlist(BIAS0)),
      # summaryStats = dt_rangeShap,
      rankedImportance = temp$Feature,
      numberOfFeatures = length(temp$Feature),
      numberRowsListShap = numberRows,
      xgbAttributes = attributes(xgb_data),
      Weights = w,
      maxShap = max_shap_score
    )) #dont need the other encodings because attributes contains what we need
}

# {f}  createShaph2o
#' Create equivalent Shapley value object to createShapValues, for h2o model
#' @description  returns Shapley values on a row by row basis for an h2o regression model
#' together with summary statistics
#' @param h2o_model the model
#' @param h2o_data the "H2OFrame" (or list of them, in which case you get a list)
#' created by the h2o package
#' @param weights Optional weights (as a numeric vector or list thereof).
#' Default is NULL i.e. weight == 1
#' @return a list of shapley objects
#' @author Russell Green & Tom Bratcher
#' @importFrom h2o h2o.predict_contributions
#' @export
#' @note h2o combines factor feature shap values itself,
#' so many of the original arguments are not required.
#' # However, unlike the xgboost implementation, 
#' weights must be specified explicitly.
#' Also, h2o does not (in 3.30.0.4 at least, which is the Earnix compatible version)
#' properly allow for offsets in its shap values. 
#' This requires the `link` and `offset` arguments.
#' @examples
#' # 
#'# See the h2o shap tutorial on the data science blog
createShaph2o <- function(
  h2o_model,
  h2o_data,
  Attributes = list(),
  weights = NULL,
  offsets = NULL,
  link = "log"
){
  
  # VALIDATION------------
  
  if (!(inherits(h2o_model, "H2ORegressionModel"))) stop (
    "Model must be an h2o regression model"
  )
  # want a possilble list so....
  if (inherits(h2o_data, "list")){
    if(!(all(sapply(h2o_data, function (x) inherits(x, "H2OFrame"))))) stop(
      "If h2o_data is a list all its elements must be H2O Frames"
    )
    return (lapply(seq_along(h2o_data), function (x) createShaph2o(
      h2o_model = h2o_model, h2o_data = h2o_data[[x]],
      Attributes = Attributes, weights = weights[[x]],
      offsets = offsets[[x]], link = link
    )))
  }
  if (!(inherits(h2o_data, "H2OFrame"))) stop (
    "h2o_data must be a H2O data frame (or list of them)")
  
  if(!(inherits(Attributes, "list"))) stop ("Attributes must be a named list") 
 
   numberRows <- nrow(h2o_data)
  if(!(is.null(offsets))){
    if(length (offsets) != numberRows) stop (
      "If offsets are specified, they must equal the number of rows in the data")
  }    

# the function ------------------------------------------------------------

  # set attributes:
  for (nm in names(Attributes)) attr(h2o_data, nm) <- Attributes[[nm]]

  # create shap vals:
  shap_contrib <- as.data.table(h2o::h2o.predict_contributions(
    h2o_model, h2o_data))
  
  # first create the shap values using xgbDmatrix data and xgbooster model
  
  # Last column is bias. it's adjusted for the actual values in the data but it's not
  # constant if the offset isn't. so rather than removing it, don't remove it
  BIAS0 <- shap_contrib[,ncol(shap_contrib), with = FALSE]
  shap_contrib[, ncol(shap_contrib) := NULL]
  
  if (is.null(weights)) weights <- rep(1, nrow(shap_contrib))
  
  mean_shap_score <- sort(
    apply(
      shap_contrib, 2, function(x)
        weighted.mean(abs(x), w = weights)
    ), decreasing = TRUE)
  shap <- data.frame(shap= round(mean_shap_score, digits = 4) )
  temp <- data.table(Feature=row.names(shap), shap)
  
  # also their maximal absolutes:
  max_shap_score <- sort(
    apply(
      shap_contrib, 2, function(x)
        max(abs(x))
    ), decreasing = TRUE)
  
  # summary of shap values for each feature (min, 1stQ, median, 3rdQ, max) for output
  range_shap_score <- sapply(shap_contrib, function(x) summary(x, digits=3))
  df_rangeShap <- range_shap_score[which(row.names(range_shap_score)!= "Mean"),] 
  # data frame screws the names up
  df_rangeShap2 <- t(df_rangeShap)
  
  dt_rangeShap <- cbind(
    data.table(feature=row.names(df_rangeShap2), df_rangeShap2), Mean_abs=temp$shap)
  dt_rangeShap <- dt_rangeShap[, lapply(
    .SD, format, scientific = FALSE, drop0trailing = TRUE)]
  
  # NOTE: h2o data doesn't have weights as an attribute. 
  # this might affect future functions.
  

# fix bias term: ----------------------------------------------------------

  if(!(is.null(offsets))){
    BIAS0 <- BIAS0 + sapply(offsets, link)
  }  
  

# add attributes which xgbdata would have had -----------------------------
  xgbAttributes = attributes(h2o_data)
  xgbAttributes$.Dimnames <- list(NULL, colnames(shap_contrib))
  
  # return a list of row shap scores, column means, various feature vectors, total n and BIAS
  return(
    list(
      shapValues = shap_contrib,
      meanAbsShap = mean_shap_score,
      baseline = as.numeric(unlist(BIAS0)),
      rankedImportance = temp$Feature,
      numberOfFeatures = length(temp$Feature),
      numberRowsListShap = numberRows,
      xgbAttributes = xgbAttributes,
      Weights = weights,
      maxShap = max_shap_score
    ))
}


# ~ ----

# {f} creating a long data table of shap values
# big functions like this can lie outside the main function call
# probably just need to move this back in if it's not being used elsewhere
# but maybe it is...?

createLongShap <- function(
  listShap,
  newData,
  start_n,
  stop_n,
  Sample = 1000,
  seed = 86832L,
  Features = NULL,
  colourScale = "ecdf"
){ # duplication of the data like this is less than ideal, but not much you can do
  
  # Checks for arguments
  if (is.null(listShap)) {
    stop("requires listShapValues as input\n")
  } 
  
  if (is.null(listShap$rankedImportance)) {
    stop("requires ordered Features in list\n")
  } 
    rankedImportance <- listShap$rankedImportance

    shapValues <-  listShap$shapValues

  if (is.null(newData)) {
    stop("requires newData \n")
  }


  if (is.null(listShap$meanAbsShap)) {
    stop("requires mean absolute shap in list\n")
  } 
    # get list of features to return
    shap <- data.frame(shap= listShap$meanAbsShap )
    temp <- data.table(Feature=row.names(shap), shap)

      # create a list of features to include in  SHAP summary
  if(length(Features)){
    selectedFeatures <- intersect(
      Features,
      rankedImportance[which(listShap$meanAbsShap > 0)]
      )
  } else selectedFeatures <- intersect( 
    rankedImportance[
    start_n:(min(stop_n, length(listShap$rankedImportance)))],
    rankedImportance[which(listShap$meanAbsShap > 0)]
    )
  if (!(length(selectedFeatures))){
    warning("None of the Features requested are in the Importance vector")
    return(invisible(NULL))
  }
  # sample
  if (Sample > 0 && Sample < nrow(newData)){
    set.seed(seed)
    rowSample <- sample(nrow(newData), Sample, replace = FALSE)
  } else rowSample <- (1:nrow(newData))

  # numeric
  orderedShapValues <- setDT(shapValues)[rowSample, selectedFeatures, with = F]
  #may indirectly set your shapvalues to a data table if they werent. 
  #they should have been
  longShap_numeric <- melt.data.table(
    orderedShapValues, 
    measure.vars = selectedFeatures)
 
  # get feature values from the original dataset
  fv <- newData[rowSample, selectedFeatures, with = FALSE]

  # what if a feature is a factor
  # change everything into numerics before applying melt....
  fv[, names(fv) := lapply(.SD, as.numeric)]

  long_fv_numeric <- melt.data.table(fv, measure.vars = selectedFeatures)

  # function to standardise feature values between zero and one
  std1 <- function(x){  
    return ((x - min(x, na.rm = T)) / (max(x, na.rm = T) - min(x, na.rm = T)))
  } # function in a function in a function not great. we might pinch this...
  # also questionable whether this is the best choice for long tailed
  # eg engine size etc...
  # standardize feature values, zero and one
  # but std1 maybe better for factors...
  if(colourScale == "ecdf"){
    long_fv_numeric[
      ,
      Feature_Value := ecdf(pmax(value, 1e-10 + min(value, na.rm = TRUE)))(value),
      by = "variable"]
  } else {
     long_fv_numeric[
      ,
      Feature_Value := std1(value), by = "variable"]
  }
   # SHAP value: value
  # raw feature value: rfvalue;
  # standarized: Feature_Value
  names(long_fv_numeric) <- c("variable", "rfvalue", "Feature_Value")
  shap_long_Numeric <- cbind(longShap_numeric, long_fv_numeric[,c('rfvalue','Feature_Value')])
  shap_long_Numeric[, mean_value := listShap$meanAbsShap[match(variable, listShap$rankedImportance)]]

  # return a whole host of information
  return(list(
    all_n_Features = temp$Feature,  # vector of features
    plotLabel = paste0(
      "SHAP Global Feature Importance: ",
      "[",
      start_n,
      ":",
      min(stop_n, length(listShap$rankedImportance)),
      "]"),  # interactive plot label
    FeaturesExtracted = selectedFeatures, # vector of features EXTRACTED
    #fv_DD = fv_DD,  # data dictionary
    #factorLevels = fv_DD@levels[fv_DD@colClasses %in% c('factor', 'ordered')], # levels of all factors
    shapLong = shap_long_Numeric  # the shap values melted with feature values in a long format
  )
  )
  
}

## 2. Global Feature Importance----

# {f} plotShapFeatureSummary

#' Plotting the global Shapley importance of features
#' @description gives a visual summary of the effect of features in an xgboost model using 
#' Shapley importance and values
#' @param listShap shapley list created by `createShapValues` 
#' @param newData The data used to create `listshap` (
#' this is the data used to create the dmatrix not the dmatrix itself)
#' @param start_n start of the feature importances to plot. 
#' features are ranked by the average mean absoulte shap value
#' @param stop_n end of the feature importances to plot 
#' @param Sample to speed calculation, plot using a row sample of your features.
#' If non-zero, this is the selected sample size: if zero, uses all rows
#' @param seed random seed used, if Sample is > 0
#' @param Title Plot title
#' @param Features optional vector of the feature names you want, rather than
#' just the most important ones
#' @param x_bound optional hard coding of the scale used for showing Shapley effect
#' @param scientific optional logical parameter to control the label format in the chart
#' @param my_format optional parameter to hard code the ggplot label format
#' @param returnDetails logical - if true, also get a data summary returned
#' @param colourScale colour scale. either "ecdf" (empirical dist) or "linear"
#' @param pal ggplot compatible colour palette. This must be of length 3, 
#' and run from high to low
#' @importFrom ggforce geom_sina
#' @return a ggplot object
#' @author Russell Green 
#' @export
#'
#' @examples
#'
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000
#' 
#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )
#' 
#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )
#' 
#' # Create the shap values on test:
#' 
#' shapList <- createShapValues(
#' xgbModel,
#' xgbdata$test
#' )
#' 
#' # Feature summary:
#' 
#' fsplot <- plotShapFeatureSummary(
#'   shapList,
#'   newData = UKTheftFreq[testSet], 
#'   # note this is consistent with shapList's rows
#'   stop_n = 10,
#'   Title = "Example chart"
#' )
#'# Also see tutorial on the data science blog.
#'

plotShapFeatureSummary <- function(
  listShap,
  newData,
  start_n = 1,
  stop_n = 20, # add error checking? or assume people aren't idiots?
  Sample = 1000,
  seed = 86832L,
  Title = NULL,
  Features = NULL,
  x_bound = NULL,
  dilute = FALSE,
  scientific = FALSE,
  my_format = NULL,
  returnDetails = FALSE,
  colourScale = "ecdf", 
  pal = c("red3", "thistle2", "blue3")) {
  
  if(!(colourScale == "linear")) colourScale = "ecdf"
  ## Note that `newData` used with this function 
  #needs to be same as that used to create create `listShap`
  # check data sources are the same!
  if (listShap$numberRowsListShap != nrow(newData)) {
    stop("\n newData is required to be the same data as that used to create listShap data\n
         \n check that your data sources are the same")
  } 

  # out of range error:
  if(start_n > length(listShap$rankedImportance)){
    message("not that many features in the model")
    return(invisible(NULL))
  }
  
  # required function:
  if (!requireNamespace("ggforce", quietly = TRUE)) {
    stop("Package \"ggforce\" needed for this function to work. Please install it.",
         call. = FALSE)
  }
  
  # create listLongShap using the above function, createLongShap
  listLongShap <- createLongShap(
    listShap, newData, start_n, stop_n, Sample, seed, Features, colourScale)
  if(is.null(listLongShap)) return (invisible(NULL))
  # doesn't really need to be its own function if you're not using it elsewhere
  # but we'll see

  data_long = listLongShap[["shapLong"]] # probably unnecessary
  # set desired format
  if (scientific){label_format = "%.1e"} else {label_format = "%.3f"}
  # otherwise set your own format using my_format
  if (!is.null(my_format)) label_format  <- my_format
  # check number of observations
  N_features <- setDT(data_long)[,uniqueN(variable)]
  x_bound <- if (is.null(x_bound)) max(abs(data_long$value))*1.1 else as.numeric(abs(x_bound))
  
  # use ggplot_
  plot1 <- ggplot(data = data_long) +
    coord_flip(ylim = c(-x_bound, x_bound)) +
    # sina plot:
   ggforce::geom_sina(
      aes(x = variable, y = value, color = Feature_Value ),
     method = "counts", maxwidth = 0.7, alpha = 0.7) +
      # scale_color_gradient(low="#FFCC33", high="#6600CC",
    scale_color_gradient2(
      low = pal[3], high = pal[1], mid = pal[2],
      midpoint = 0.5, breaks = c(0.05,0.95), labels = c("Low","High"),
      guide = guide_colorbar(barwidth = 12, barheight = 0.3)) +

        # print the mean absolute value:
    geom_text(
      data = unique(data_long[, c("variable", "mean_value")]),
      aes(
        x = variable,
        y = -Inf,
        label = sprintf(label_format, mean_value)
      ),
      size = 3, alpha = 0.7,
      hjust = -0.2,
      fontface = "bold") +
    
    # # add a "SHAP" bar notation
    # annotate("text", x = -Inf, y = -Inf, vjust = -0.2, hjust = 0, size = 3,
    #          label = expression(group("|", bar(SHAP), "|"))) +
    
    
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5),
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(), # remove axis line
      legend.position = "bottom",
      legend.title = element_text(size = 10),
      legend.text = element_text(size = 8),
      axis.title.x = element_text(size = 10)) +
    geom_hline(yintercept = 0) + # the vertical line
    # reverse the order of features, from high to low
    # also relabel the feature using `label.feature`
    scale_x_discrete(limits = rev(levels(data_long$variable))
    #   , labels = label.feature(rev(levels(data_long$variable)))   
    ) + labs(
      y = "SHAP value (impact on prediction)", x = "" )
  #, color = "Feature value  ")
  
  p <-  plot1  +  ggtitle(ifelse(is.null(Title),listLongShap[["plotLabel"]], Title))
  
  if(returnDetails){
    return (list (data = listLongShap, plot = p))
  }
  return(p)
}

# ~----

# list to data table cantrip ----------------------------------------------

#' Convert a list to a data table
#'
#' @param l a named list
#'
#' @return a data table with "Name" the list names and "Element" the elements
#' @export
#'
#' @examples
#' 
#' listToDT(
#'   l = list(
#'   fruit = c("Apples", "Bananas"),
#'   Vegetables = c("Cauliflower")))
#' 

listToDT <- function (l) {
  if(is.null(names(l))) names(l) <- seq_along(length(l))
  return(
    rbindlist(lapply(names(l), function (x) data.table(Name = x, Elements = unlist(l[x]))))
  )
}
## 3. Plotting local feature interpretation----

# newData = smallTest
# listShap = listShapValues
# rowNum = 10
# alt_format = FALSE
# top_n=10
# plot = TRUE
# lower = NULL
# upper = NULL
# width = 800
# height = 500
# fontSize = 18L

#' Plotting local feature interpretation
#'
#' @description `plotLocalShap` produces one or more waterfall charts of the 
#' shapley value breakdown for individual prediction rows or groups of rows.
#' @param listShap shapley list created by `createShapValues` 
#' @param newData The data used to create `listShap` (
#' this is the data used to create the dmatrix not the dmatrix itself)
#' @param rowNum the Row number(s) you wish to illustrate on (or a list of them)
#' @param byColumn optional column name within newData,
#' not necessarily appearing in the model. if specified,
#' one chart showing the average shapley value impact is created for each of the... 
#' @param plotLevels ...specified levels of byColumn.
#' @param defaultLevel optional character input. By default, all of them
#' If specified, sets a default level for the factor and charts produced
#' show the average shap values relative to the default level0
#' (alternatively, default is set to the mode of `byColumn` if set equal to -1 )
#' @param Grouping optional named list (or 2 column data table with columns 
#' "Name" and "Elements").
#' Each list element should contain a vector of model input variables.
#' This enables a waterfall chart to be produced with similar input features
#' grouped together (e.g. vehicle factors, demographic, location etc.)
#' @param alt_format logical: if TRUE orders the effects shown by absolute effect
#' @param Title chart title
#' @param color_decreasing colour used for factors with net negative effect
#'  on the response prediction (must be a plot_ly colour)
#' @param color_increasing colour used for factors with net positive effect
#' @param top_n number of +/- input factors to show, if not grouping 
#' (other features are aggregated)
#' @param Plot to return a plot rather than the underlying data
#' @param lower optional hard coded lower limit for the chart values.
#' allows for easier comparison between charts
#' @param upper similar to lower
#' @param width plot width in pixels
#' @param height plot height in pixels
#' @param fontSize plot font size
#' @author Russell Green
#' @return A waterfall plot_ly object or list of them
#' @export
#'
#' @examples
#'
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000
#' 
#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )
#' 
#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )
#' 
#' # Create the shap values on test:
#' 
#' shapList <- createShapValues(
#' xgbModel,
#' xgbdata$test
#' )
#' 
#' # Plot a Single value:
#' 
#' localplot <- plotLocalShap(
#'   shapList,
#'   newData = UKTheftFreq[testSet],
#'   # note this is consistent with shapList's rows
#'   rowNum = 5,
#'   top_n = 3,
#'   width = 1000
#' )
#' 
# See the tutorial vignette for an example of plotting differences between groups.
 
plotLocalShap <- function(
  listShap,
  newData,
  rowNum = 1,
  byColumn = NULL, # allows average shap by gender
  plotLevels = NULL, # level(s) of said column to plot
  defaultLevel = NULL, # if using byColumn, the default starting point
  Grouping = NULL, # either way, can group factors together
  alt_format = FALSE,
  Title = "Waterfall chart of local feature impact\n",
  color_decreasing="limegreen",  # easier for the colourblind, see
  color_increasing="red",
  top_n = 10,
  Plot = TRUE,
  lower = NULL,
  upper = NULL,
  width = 800,
  height = 500,
  fontSize = 18L # these are quite selective aren't they :-)
) {
  
  # This function takes the required inputs and creates the data
  # for a single (row) instance and returns a waterfall plot of its SHAP values
  # OR produces a comparative average analysis for different factor levels
  # (Which could I guess be in the model so let's tread carefully.)
 
  ## Note that `newData` used with this function needs to be same as that used to create create `listShap`
  # check data sources are the same!
  if (listShap$numberRowsListShap != nrow(newData)) stop(
    "newData is required to be the same data as that used to create listShap data\n
    \n check that your data sources are the same")

  # Checks for arguments
  if (is.null(newData)) {
    stop("requires new data as input\n")
  } 
  
  if (is.null(listShap)) {
    stop("requires list of Shap Values as input\n")
  } 
 
  features <- listShap$rankedImportance


# convert grouping to data.table ------------------------------------------
if(!(is.null(Grouping))){
  if(inherits(Grouping, "list")) Grouping  <- listToDT(Grouping) else setDT(Grouping)
  if(!(identical(sort(names(Grouping)), c("Elements", "Name")))) stop(
    "Names of Grouping table must be Name and Elements"
  )
  setkey(Grouping, Name)
}

# Rows to use... ----------------------------------------------------------

  if (!(is.null(byColumn))){
        # is it there for a start?
    if (!(byColumn %in% names(newData))) stop (
      "byColumn specified but not in newData")
  # it's there? good. so now we want the appropriate levels.
    levelData <- as.character(newData[, get(byColumn)])
      temp <- unique(levelData)
      if (is.null(plotLevels)){
      if (length (temp) > 20) stop (
        "You have not specified a level of your factor to plot
        and you have more than 20 levels in your data.
        If you really want all of these plotted please specify them explicitly")
      plotLevels <- sort(temp)
    } else plotLevels <- intersect (as.character(plotLevels), temp)
 
          # default level
    if (!(is.null(defaultLevel))){
      if(defaultLevel == - 1) defaultLevel <- getMode(levelData)
      if(!(defaultLevel %in% temp)) {
        warning ("default level is specified but is not in data: ignoring")
        defaultLevel <- NULL
      }
      plotLevels <- setdiff(plotLevels, defaultLevel)
    }
    rm(temp)
   rowNums = lapply(plotLevels, function(x) as.integer(
     which(levelData == as.character(x))))
    names(rowNums) <- plotLevels
    defaultNums <- which(
      levelData == as.character(defaultLevel))
 
    } else { # otherwise: specified rows
      if(!is.list(rowNum)) rowNums <- list(rows = rowNum)
      defaultNums <- NULL
      defaultLevel <- NULL
      # could put some error checking in here... 
    }
  # start with an empty return... # TO DO Add in effect of default and multiple rows mean,
  # only calc mean once...

# baseline ----------------------------------------------------------------

  # creating the baseline row entry- if starting from baseline...
  bias <- listShap$baseline # bias is offset adjusted for level
  # so right now it's a vector 

# baseline scaling --------------------------------------------------------

  # might be necessary?...   the charts really don't seem to like negatives
  # so...
  
  # baseScale <- 1 # we should probably report it somewhere...
  # while (mean(bias) < 0.1) 
  
  

  if(!(is.null(defaultLevel))){ # so if we're doing a relative chart...
    defaultValues <- newData[defaultNums, features, with = FALSE]
    dWeights <- listShap$Weights[defaultNums]
    # just taken bias off:  but don't want to because of lazy eval
    defRowValues <- round(listShap[["shapValues"]][
      defaultNums, lapply(.SD, weighted.mean, w=dWeights)],4)
    defCol <-
      melt(
        defRowValues, measure.vars = names(defRowValues),
        variable.name = 'Feature')
    #print(defCol)
    defaultBias <- round(
      weighted.mean(bias[defaultNums], w = dWeights),  4) # so a single wtd value ok
    defaultEffect <- round(sum(defCol$value), 4)
     } else { # we have a starting point of the general biased offset:
    defaultBias <- round(weighted.mean(bias, w = listShap$Weights), 4)
    defaultEffect = 0
  }

  shapColmeans <- listShap[["meanAbsShap"]] # want this for the default...  
 p <- list()
 for (nm in names(rowNums)){ 
   rowNum <- rowNums[[nm]]
  # get feature values for selected data row
    xRowValues <- newData[rowNum, features, with = FALSE] 
  # xRowValues[, names(xRowValues) := lapply(.SD, as.character)] 
  # used for labelling but in general this is a bad idea it will be massive
  # can do if just the one row
 
  # round SHAP values for all rows
  shapRowValues <- round(listShap[["shapValues"]][
    rowNum, lapply(.SD, weighted.mean, w =listShap$Weights[rowNum])],4) 
    shapCol <-
    melt(
      shapRowValues, measure.vars = names(shapRowValues),
      variable.name = 'Feature')
 
  #... SHAP! unless we have a default level in which case
  if(!(is.null(defaultLevel))){
  shapCol[, value:= value - defCol$value]
  }
  xRowValues <- newData[eval(rowNum[1]), features, with = FALSE]  
  xRowValues[, names(xRowValues) := lapply(.SD, as.character)]

  xCol <-
    melt(
      xRowValues, measure.vars = names(xRowValues),
      variable.name = 'Feature', value.factor = TRUE)
  xCol[, ':=' (
    measure= "relative", # for waterfalls
    featureValue = paste0(Feature, " {", value, "}")
  )]
  if(length(rowNum)!=1 |!is.null(Grouping)) xCol$featureValue <- xCol$Feature

  xCol[, shapValue := shapCol$value[match(Feature, shapCol$Feature)]]

# grouping ----------------------------------------------------------------

    if(!(is.null(Grouping))) {
       xCol[, featureValue := Grouping$Name[
        match(as.character(Feature), as.character(Grouping$Elements))]]
      # not working
      xCol[is.na(featureValue), featureValue := "~Other~"]
      xCol <- xCol[, .(shapValue = sum(shapValue)), by = .(featureValue)]
      xCol[, Feature := featureValue]
      xCol[, measure:= "relative"]
      
    }
  
  # grouped labels
  
  if((!is.null(Grouping)) | length(rowNum) > 1){
    xCol[shapValue > 0, featureValue := paste0(
      featureValue, "{ +", sprintf("%.3f", shapValue), " }")]
    xCol[shapValue <= 0, featureValue := paste0(
      featureValue, "{ ", sprintf("%.3f", shapValue), " }")]
  }
  
  # ordering the rows for plotting
  
  if(alt_format) xCol <- xCol[order(abs(shapValue))] else 
  xCol <- xCol[order(shapValue)]   # edited here !!
  
  shapSum <- sum(xCol[["shapValue"]])
 
  localBias <- round(weighted.mean(bias[rowNum], w = listShap$Weights[rowNum]), 4)
  # creating the prediction row entry
  prediction <-
    data.table(
      Feature = paste0("Local prediction = ", round((
        defaultEffect + localBias + shapSum), 3), " "),
      value = "",
      measure = "total"
    )
  prediction[,':=' (featureValue = Feature,
                    shapValue = shapSum
  )]

# baseline (ADJUST for Variable bias) -------------------------------------
  #print(defaultBias)
  if(is.null(defaultLevel)) defaultBias <- localBias # so unless comparing 
  #2 groups start from local bias
  
  baseline <-
    data.table(Feature = paste0("Baseline = ", defaultBias + defaultEffect, " "),
               value = "",
               measure = "total"
    )
  
  baseline[,':=' (featureValue = Feature,
                  shapValue = 0
  )]

  # adjust baseline for difference in bias, if any:
  if(abs(defaultBias - localBias) >= 5E-04){
    baseline <- rbind( baseline, data.table(
      Feature = "Difference in offsets",
      value = localBias - defaultBias,
      featureValue = "Difference in offsets",
      measure = "relative"
    ), fill = TRUE
    )
  }
  
  # binding together rows
  dataForPlotting <-rbind(baseline, xCol , prediction , fill = TRUE)
  # add bespoke limits for plotting 
  negativeShapRows <- which(xCol$shapValue <0)
  # could set as an input...
  dataForPlotting$lowerX <- ifelse(
    is.null(lower),
    round(sum(xCol$shapValue[negativeShapRows]) + defaultBias + defaultEffect - 0.02, 4),
    lower)
  dataForPlotting$upperX <- ifelse(
    is.null(upper),
    round(sum(xCol$shapValue[-negativeShapRows]) + defaultBias + defaultEffect + 0.02, 4),
    upper)
  # save global model baseline and local prediction 
  dataForPlotting$baseline <- defaultBias + defaultEffect
  dataForPlotting$prediction <- round(localBias + shapSum + defaultEffect, 3) 
  #print(dataForPlotting)
  # # explore values on true response scale
  # dataForPlotting[, premium := round((exp(shapValue)-1)*exp(baseline),1)]
  # # assumes you're actually on an exponential link
  # # and moves away from the shapliness. 

  if(Plot){
    endRow <- nrow(dataForPlotting)
    if (endRow > top_n*2 & is.null(Grouping)) { # think we ignore tjhis bit beif using grouping...
    
      
      start <- top_n+2
      end  <- endRow - top_n - 1
      temp_c <- dataForPlotting[start:end]
      temp_c1 <- temp_c[(which(shapValue <0))]
      temp_c2 <- temp_c[(which(shapValue >0))]
      
      temp_s1 <- data.table(
        Feature="Other features", value=NA, measure="relative",
        featureValue = paste0("* ", nrow(temp_c1), " other features with -ve Shap aggregated *"), 
                            shapValue = sum(temp_c1$shapValue))
      temp_s2 <- data.table(
        Feature="Other features", value=NA, measure="relative",
        featureValue = paste0("* ", nrow(temp_c2) , " other features with +ve Shap aggregated *"), 
                            shapValue = sum(temp_c2$shapValue))
      if(!(nrow(temp_c1))) temp_s1 <- data.table()
      if(!(nrow(temp_c2))) temp_s2 <- data.table()
      temp <- rbind(dataForPlotting[1:(start-1)],temp_s1, temp_s2, dataForPlotting[(end+1):endRow], fill=TRUE)
      dataForPlotting <- temp
    }
   
    fullTitle <- Title
    if (!(is.null(byColumn))){
      fullTitle <- paste(Title, "for", byColumn, "=", nm)
      if(!is.null(defaultLevel)) fullTitle <- paste(fullTitle, "Vs.", defaultLevel)
    }
    #print(dataForPlotting)
    p[[nm]] <- plot_ly(
      dataForPlotting, x = ~ shapValue, y = ~ featureValue, measure = ~ measure,
      type = "waterfall", name = "" ,  base = ~ baseline[1],
      decreasing = list(marker = list(
        color = color_decreasing,
        line = list(color = color_decreasing, width = 0.2)
      )),
      increasing = list(marker = list(
        color = color_increasing,
        line = list(color = color_increasing, width = 0.2)
      )),
      totals = list(
        marker = list(color = "mediumblue", line = list(color = 'black', width = 1))),
      orientation = "h", 
      connector = list(
        mode = "between",
        line = list(width = 0.3,
                    color = "black",
                    dash = 0))) %>%
      layout(
        title = fullTitle, colorscale = rsaPalette(),  # font=list(size=14),
        yaxis = list(
          title = "",
          type = "category",
          categoryorder = "array",
          categoryarray = ~ featureValue,
          autorange = "reversed",
          tickfont = list(size = fontSize)
        ),
        xaxis = list(
          title = "Relative change from baseline prediction to local prediction ",
          font = list(size = fontSize),
          tickfont = list(size = fontSize),
          dtick = 0.25,
          tickmode = "linear",
          range = c( ~ lowerX[1],  ~ upperX[1]),
          ticks = "outside",
          type = "linear"
        ), showlegend = FALSE) 
    }  
      else p[[nm]] <-dataForPlotting
  }
    if (length(p) == 1) p <- p[[nm]]
    return(p)
  
}


# ~----

# 4. Feature Dependence----


# (a) creating SHAP Interactions ----

# {f} creating 3-d array 
#' Create 3 d array of xgb model interactions
#'
#' @param xgb_model an xgboost model
#' @param xgb_data  a consitent dmatrix
#' @param rows optional vector of rows to use
#' @param features subset of features, if desired
#' @param maxD maximum number of values in the initial array
#' (ignored if zero or `rows` specified)
#' @param seed if `maxD` bites, used to select rows
#'
#' @return a named 3-d array used for 2-way shap value analysis,
#' with the "Rows" attribute recording the row indices used
#' @note  because of the computation and memory load of this function
#' you may wish to run it on a model built with fewer columns -
#' i.e. fewer features or numeric factor encodings or both. See the help file
#' for `xgbSetupdata2`or past vignettes for tips on how to do this
#' @author Russell Green
#' @export
#'
#' @examples
#' 
#' 
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000
#' 
#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )
#' 
#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )
#' 
#' # Create the shap values on test:
#' 
#' shapList <- createShapValues(
#' xgbModel,
#' xgbdata$test
#' )
#' 
#' # Create the interactions:
#' # for speed just use the first 100 rows
#' shapInteractions <- createShapInteractions(
#'   xgb_model = xgbModel,
#'   xgb_data = xgbdata$test,
#'   rows = 1:100 
#')
#' 
createShapInteractions <- function(
  xgb_model,
  xgb_data,
  rows = NULL,
  features = NULL,
  maxD = 1E7, # 1000 rows 100 columns...
  seed = 523589L
  ){
  
  # error checking-------------
  # if(!(inherits(xgb_data, "xgb.DMatrix"))) stop(
  #   "xgb_data must be a DMatrix") could just be dcGmatrix

  
  if(maxD && is.null(rows)){
    if (maxD < (nrow(xgb_data) * ncol(xgb_data) ^ 2)){
      message("sampling rows:\nif you want more rows used increase maxD
      or set it to zero\n")  
      set.seed(seed)
      rows <- sample(
        1:nrow(xgb_data), max(5, trunc(maxD / ncol(xgb_data) ^ 2)), replace = T)
      }
  }

  factors <- gsub("~.*", "", colnames(xgb_data)) 
  
  if(is.null(rows)) rows <- (1:nrow(xgb_data))
  cat(paste0("Creating Tree SHAP interactions \n"))
  # remove the bias from the feature matrix (n x f x f)
  colsUsed <- 1:length(colnames(xgb_data))
  if(!(is.null(features))) colsUsed <- which(factors %in% features) 
  
  # interaction numbers we want:
  int_shap <- predict(xgb_model, xgb_data[rows,], predinteraction = TRUE)[
  , colsUsed, colsUsed]
  
  factors <- factors[colsUsed]
  compressFlag <- (length(factors) > length(unique(factors)))
  
  # takes a while maybe...
  # size is n x f x f.
  # perfectly possible to chunk them
  # could probably combine them after a summary>>
     # change the column names of any OHE factor columns to their parent factor name
  dimnames(int_shap) <- list(NULL, factors, factors)
  
  # Function to compress OHE factors back to their parent for shap interaction values
  
  compressByFactor <- function(array){
    
    nFacs <- length(unique(dimnames(array)[[2]]))
    
    compressMatrix <- function(x){
      compressRow <- function(y){
        apply(
          y,
          1,
          function(z){
            m <- aggregate(z, by = dimnames(y)[2], FUN = sum)
            r <- m[, 2]
            names(r) <- m[, 1]
            return(r)
          }
        )
      }
      return(compressRow(compressRow(x)))
    }
    
    final <- aperm(
      vapply(
        seq_len(dim(array)[1]),
        function(i){
          compressMatrix(array[i, , ])
        },
        matrix(0, nrow = nFacs, ncol = nFacs)
      ),
      c(3, 1, 2)
    )
    attr(final, "Rows") <- rows
    return(final)
  }
     # NEEDS WEIGHTS 
  attr(int_shap, "Weights") <- getinfo(xgb_data, "weight")[rows]
  # compress the feature matrix within the interactions array over OHE factor levels
 
  if(compressFlag){
  #  cat(paste0( "Compressing interactons across OHE Factors"))
      return(compressByFactor(int_shap))
  } # takes a while...
 
  
  # return the interactions array
    return(int_shap)
  

}

# (b) summarising shap interactions----
#' Importance summary of Shapley interactions
#' @description This function summarises the array of shapley interaction values
#' from `createShapInteractions` showing the most important ones.
#'
#' @param data_int array created by `createShapInteractions`
#' @param feature optional feature name: the function then returns interactions
#' just with the selected feature
#' @return a table of the most important interactions in the model 
#' measured by shap interaction
#' @export
#' @author Russell Green
#' @examples
#' 
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000
#' 
#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )
#' 
#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )
#' 
#' # Create the shap values on test:
#' 
#' shapList <- createShapValues(
#' xgbModel,
#' xgbdata$test
#' )
#' 
#' # Create the interactions:
#' # for speed just use the first 100 rows
#' shapInteractions <- createShapInteractions(
#'   xgb_model = xgbModel,
#'   xgb_data = xgbdata$test,
#'   rows = 1:100 
#')
#' 
#' # Summarise:
#' shapintsum <- summariseShapInteractions(shapInteractions)
summariseShapInteractions <- function(
  data_int=NULL, feature=NULL){
  

  ## Function to rank  shap interactions for a given feature or across all features
  Weights <- attributes(data_int)$Weights
  if(is.null(Weights)) 
    {
    size <- length(attributes(data_int)$Rows)
    if(!(size)) size <- attr(data_int, "dim")[[1]]
    if(!(size)) stop (
      "function cannot determine the dimensions of the input data. \n
      Try setting the 'dim' attribute.")
   Weights <- rep(1, size)

  }
  dispersion <- function(x){
    mu <- 0L # orly?

    if (!(length(x))){
      cat(feature, "\n")
      stop ("length of feature is zero")
    }
    result <- sum((2 * x * Weights - mu) ^ 2 ) / (
      sum(Weights ^ 2) * (length(x) - 1) / length(x))
    return(round(result * 1, 6))
  }
  
  singleFeatureShapInteractions <- function(
    data_int=NULL, feature=NULL){
    
    # create a temporary data table of n rows x p features
    dt_temp.int <- data.table(
      data_int[,feature, ])
    
    # calculate the dispersion of each interactive feature
    dt_varShap <- dt_temp.int[
      , lapply(.SD, dispersion)]
    dt_varShap <- dt_varShap[
      , lapply(.SD, format, scientific = FALSE, drop0trailing = TRUE)]
    # drop the main effects (primary) feature, x
    dt_varShap[, paste0(feature) := NULL]
    # melt the table into p-1  x 2
    temp <- melt.data.table(
      dt_varShap, measure.vars = names(dt_varShap))[order(-value)]
    setnames(temp, "value", "shap.dispersion")
    temp[, feature := paste0(feature)]
    temp[, shap.interaction := ifelse(
      as.character(feature) < as.character(variable),
      paste0(feature, "~x~", variable), 
      paste0(variable, "~x~", feature)) ]
    temp$feature <- temp$variable <- NULL
    temp[, shap.dispersion := as.numeric(shap.dispersion)]
    return(temp[, c("shap.interaction", "shap.dispersion"), with=FALSE])
  }
  
  if(!is.null(feature)){
    
    # create table of (selected) feature shap interaction importance
    return (singleFeatureShapInteractions(data_int, feature))
   
  }else{
    
    # else create table of global feature shap interactions importance
    dt_temp <- data.table(shap.interaction = character(), shap.dispersion=numeric())
    
    for (i in dimnames(data_int)[[2]]){
      feature.shapInteractions <- singleFeatureShapInteractions(
        data_int = data_int, feature = i)
      dt_temp <- rbind(dt_temp, feature.shapInteractions)
    }
    dt_temp <- unique(dt_temp, by = "shap.interaction")
    dt_temp <- dt_temp[order(-shap.dispersion)]
    return(dt_temp)
  }
  
}

## (c) plotting feature Dependence----

#' Feature dependence plots for shap values
#' @description show how shap values vary with the primary feature, 
#' potentially with interactions with other features.
#' @param listShapValues a list produced by `createShapValues`
#' @param data data consistent with that used to create `listShapValues`.
#' @param primaryFeature the primary feature in the plot
#' @param secondaryFeature optional secondary feature to show interactions
#' @param data_int optional output from `summariseShapInteractions`. 
#' Required for shap interaction plots.
#' @param colourFeature optional colour feature to show interactions
#' @param Yaxis optional input "Shap" or "Int" to show the raw shap values or
#' the interaction shap values on the y-axis. 
#' Defaults to "Shap" unless both secondaryFeature _and_ data_int provided.
#' @param colourScale either "linear" or "ecdf" - changes the colour distribution.
#' This can be useful where values have heavily tailed distributions
#' @param colourTrim quantile value to constrain the linear colour scale (ditto)
#' @param size0 point size
#' @param width width of the resultant plotly object in pixels
#' @param height width of the resultant plotly object in pixels
#' @param margin plotly margins list
#' @param points parameter to determine maximum number of points plotted (0 for all)
#' @param Seed random seed if sampling
#' @param pal colour palette
#' @param xScale either "linear", "log" or "auto" (chooses between the 2 based on your data skew)
#' @param dataOut logical: return the chart data as well as the plot
#' @author Russell Green
#' @return a plotly chart
#' @export
#'
#' @examples
#'
#' data("UKTheftFreq")
#' trainSet = 1:30000
#' testSet  = 30001:40000
#' 
#' # Build an xgboost with train and test:
#' xgbdata <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = names(UKTheftFreq)[11:31],
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = list(
#'     train = trainSet,
#'     test = testSet
#'   )
#' )
#' 
#' xgbModel <- xgb.train(
#'   params = list(
#'     objective = "count:poisson",
#'     max_depth = 2,
#'     gamma = 1
#'   ),
#'   data = xgbdata$train,
#'   nrounds = 20
#' )
#' 
#' # Create the shap values on test:
#' 
#' shapList <- createShapValues(
#' xgbModel,
#' xgbdata$test
#' )
#' 
#' # Create the interactions:
#' # for speed just use the first 100 rows
#' shapInteractions <- createShapInteractions(
#'   xgb_model = xgbModel,
#'   xgb_data = xgbdata$test,
#'   rows = 1:100 
#' )
#'
#' plotShapDependence(
#' shapList, 
#' data = UKTheftFreq[testSet],
#' # note this is consistent with shapList's rows
#' primaryFeature = "ACQ_hhld_bnd",
#' data_int = shapInteractions
#' )
#'
#' # Also see the Tutorial Vignette
#' 
plotShapDependence <- function(
  listShapValues,
  data,
  primaryFeature,
  secondaryFeature = NULL,
  data_int = NULL,
  colourFeature = NULL,
  Yaxis = NULL,
  colourScale = "ecdf",
  colourTrim = 0.95,
  size0 = NULL,
  width = 800,
  height = 600,
  margin = NULL,
  points = 5000L,
  Seed = 4321L,
  pal = rainbow(40)[c(38:40, 1:31)], # curtailed viridis spectrum
  xScale = "auto", 
  dataOut = FALSE
  ) {
  # determine Y-axis
  
  if(is.character((Yaxis))){
    if(grepl("^[Ss]", Yaxis)) Yaxis <- "Shap" else Yaxis <- "Int"
    if (Yaxis == "Int" && is.null(data_int)) stop (
      "data_int interactions required if Int chart selected or implied")
  } else {
  
  if(!(is.null(secondaryFeature)) && !(is.null(data_int))) Yaxis <- "Int" else Yaxis <- "Shap"
  
  }
  

# error check on features, data------------------------------------------

  if(!(all(c(primaryFeature, secondaryFeature) %in% colnames(
  listShapValues$shapValues
  ))))   stop("one or more features specified not in the shap data")

  if(!(all(c(primaryFeature, secondaryFeature, colourFeature) %in% colnames(
    data
  ))))   stop("shap features specified not in the data") 
  
  if(nrow(data) != nrow(listShapValues$shapValues)) stop(
    "shap values and data are of inconsistent length"
  )
  ## if colourFeature not specified -------------------
  # either use secondary feature or most important interaction
  # or null if not
  
  if (is.null(colourFeature)) {
    if (!is.null(secondaryFeature)) {
      colourFeature <- secondaryFeature
    } else {
      if (!is.null(data_int)) {
        temp <- summariseShapInteractions(
          data_int, primaryFeature)$shap.interaction[1]
        temp <- gsub(paste0(primaryFeature, "~x~"), "", temp)
        colourFeature <- gsub(paste0("~x~", primaryFeature), "", temp)
      }
    }
  }
 #cat(colourFeature, "\n")
  # if secondaryFeature is NULL, then plot shap values for same feature
  if (Yaxis == "Shap" && is.null(secondaryFeature)) secondaryFeature <- primaryFeature
  # extracting shap values for secondaryFeature from list
  fShap <-
    listShapValues$shapValues[, secondaryFeature, with = FALSE]  
  names(fShap) <- "shap"
  
  # get feature values for named feature
  fv <- data[, primaryFeature, with = FALSE]
  dataToPlot <- cbind(fShap, fv)   
  factorFlag <- F
  # if colour feature set, then extract the data for it.....
  if (!is.null(colourFeature)){
    dataToPlot$color_value <- data[, colourFeature, with = FALSE]
    if(inherits(dataToPlot$color_value, "ordered")) {
      # assume an ordered factor is at least of sensible ordinal
      factorFlag <- TRUE
      dataToPlot[, c_val := color_value]
      } else if (inherits(dataToPlot$color_value, "factor") || inherits(
        dataToPlot$colour_value, "character"))
        # need to sort out the colours????
      {
        factorFlag <- TRUE
        ChArStR <- as.factor(dataToPlot$color_value)
        # cut down to top 10:
        names(sort(table(ChArStR, useNA = "always"), decreasing = T)[1:4]) -> common
        other <- "Other"
        while (other %in% levels(ChArStR)) other <- paste0("%", other)
        levels(ChArStR) <- c(levels(ChArStR), other)
        #print(common)
        ChArStR[which(!(ChArStR %in% common))] <- other
        dataToPlot[, c_val := ChArStR]
                     } else {
          if (colourScale == "ecdf"){
        dataToPlot[, c_val := ecdf(
          pmax(color_value, 1e-10 + min(color_value, na.rm = TRUE)))(color_value)]
      }else dataToPlot[, c_val := pmin(
        color_value, quantile(color_value, colourTrim, na.rm = T))]
    }
  } 
  
  #cat ("1155/n")
  # If plot shap interaction values, only have those...
  if (Yaxis == "Int"){ 
    dataToPlot <- dataToPlot[
        attr(data_int, "Rows")
        ]
    if(primaryFeature==secondaryFeature)
      # when plotting main effects, take the main diagonal of the feature x feature matrix within the array  
      dataToPlot$int_value <- data_int[, primaryFeature, secondaryFeature]
    # as the off-diagonal interactions are symetrical, we need to double their values
    else  dataToPlot$int_value <- data_int[, primaryFeature, secondaryFeature]*2
  }
  
  # set x axis scale default
  logplot <- FALSE
  ## Setting  primary feature factor to be character for trouble-free plotting with colour gradient
  if (inherits(dataToPlot[[primaryFeature]], "factor")) {
    dataToPlot[[primaryFeature]] <- as.character((dataToPlot[[primaryFeature]]))
    } else {# KEEP nas: need the data to align
      # do we want a logplot?

      if(is.numeric(dataToPlot[[primaryFeature]])){
       
        logplot <- (median(dataToPlot[[primaryFeature]], na.rm = T) < 
                      0.05 * max(dataToPlot[[primaryFeature]], na.rm = T) &&
            min(dataToPlot[[primaryFeature]], na.rm = T) >= 0.1)
        if(is.na(logplot))  logplot <- F
      }
      
    }
  
  if(xScale == "auto" & logplot) xScale <- "log"
  
  # How many rows do we want to plot? # change this next version??
 
  if ((points > 0) & (nrow(dataToPlot) > points)) {
   points <- min(nrow(dataToPlot), max(50, points))
      set.seed(Seed)
    dataToPlot <-
      dataToPlot[sample(nrow(dataToPlot), points)] # dilute
  }
 
  # What size markers do we want?
  # Auto-size depends on sample size
  if (is.null(size0)) size0 <- if(nrow(dataToPlot)<2000L) 6 else 4
  
  # margins?
  if (is.null(margin)) margin <- list(b = height / 5)

  ## Using plotly for SHAP dependence plots based on listShapValues
  
  colourText <- " {feature value}"
  if(colourScale == "ecdf" && !(factorFlag)) colourText <- " {empirical distribution}"
  
  xaxisList = list(
    title = if (is.null(colourFeature))
      paste0(primaryFeature, " {feature value}")
    else paste0(
      primaryFeature,
      " {feature value}",
      "<br> <br>",
      colourFeature, colourText, 
      " used as colour gradient"
    )
  )
  if(xScale =="log")  xaxisList$type = "log" 
  
  # f*****g NAs-----
  dataReturned <- copy(dataToPlot)
  dataToPlot <- dataToPlot[!(is.na(get(primaryFeature)))]
  
  # date axis--------
  
  if (inherits(dataToPlot[[primaryFeature]], "Date")){
    xaxisList$range <- c(
      as.numeric(as.POSIXct(min(dataToPlot[[primaryFeature]])))*1000,
      as.numeric(as.POSIXct(max(dataToPlot[[primaryFeature]])))*1000
    )
    xaxisList$type <- "date"
  }
  
  
  p <- plot_ly(
    data = dataToPlot,
    x = ~ get(primaryFeature),  
    width = width,
    height = height,
    y =  if (Yaxis == "Shap") dataToPlot[["shap"]]
    else{ dataToPlot[["int_value"]] # generated
    },
    type = "scatter",
    name = if (!(is.null(colourFeature)) && !(factorFlag)) colourFeature,
    text = if (!is.null(colourFeature)) ~ paste(colourFeature,
                                                '=', dataToPlot[["color_value"]]),
    colors = pal,
    color = if (!is.null(colourFeature)) 
      dataToPlot[["c_val"]]
    else NULL, 
    mode = "markers",
    marker = list(size = size0)
  )  %>%
    layout(
      showlegend = !(is.null(colourFeature)),
      title = if (Yaxis == "Shap") {
        if (secondaryFeature == primaryFeature)      paste(secondaryFeature, " {shap v feature value} ")
        else      paste0(secondaryFeature, " {Shap} v " , primaryFeature, " {feature value} ")
      }
      else
      {
        if (secondaryFeature == primaryFeature) paste0(secondaryFeature, " {Shap without interactions}")
        else paste(secondaryFeature, " {Shap interaction} v " , primaryFeature, " {feature value} ")
      },
      xaxis = xaxisList,
      yaxis = list(title = paste(secondaryFeature,  "   {SHAP}")),
      margin = margin
    )
  if (dataOut) return (list(
    data = dataReturned, primary = primaryFeature,
    shap = secondaryFeature, colour = colourFeature, plot = p))
  return (p)
  # end of function
}




# ~----




