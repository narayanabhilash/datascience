#' Nice feature importance plot using plotly
#' 
#' @description featImpPlot creates a nice looking feature importance plot using the `niceBarChart` function.
#' The returned object is a plotly chart.
#' @usage featImpPlot(importance_matrix,
#'             top_n = NULL,
#'             measure = NULL,
#'             rel_to_first = FALSE,
#'             highlight = NULL,
#'             main = "Feature importance",
#'             ...)
#' @param importance_matrix a data.table returned by `xgb.importance`.
#' @param top_n The maximum number of features to include.
#' @param measure The column in the importance_matrix to use as the measure of importance.
#' When `NULL`, 'Gain' would be used for trees and 'Weight' would be used for gblinear.
#' @param rel_to_first Whether importance values should be represented as relative to the highest ranked feature. .
#' @param highlight Optional character vector of features to highlight.
#' @param main Main plot title.
#' @param ... Optional parameters to be passed through to plot_ly function e.g. width=910 to set the chart width.
#' @export
#' @author Edwin Graham

featImpPlot <- function(
  importance_matrix,
  top_n = NULL,
  measure = NULL,
  rel_to_first = FALSE,
  highlight = NULL,
  main = "Feature importance",
  ...) {
  
  
  # Get measure if NULL
  if (is.null(measure)){
    if ("Gain" %in% names(importance_matrix)){
      measure <- "Gain"
    }
    else if ("Weight" %in% names(importance_matrix)){
      measure <- "Weight"
    } else{
      stop("measure should be a column in the importance_matrix")
    }
  }
  
  # Get top_n if NULL
  top_n <- min(top_n, nrow(importance_matrix))

  # Create importance column
  if (rel_to_first){
    importance_matrix[, Importance := get(measure)/max(get(measure))]
  } else{
    importance_matrix[, Importance := get(measure)]
  }
  
  # Create plot
  p <- niceBarChart(
    importance_matrix[order(-Importance)[1:top_n], Feature],
    importance_matrix[order(-Importance)[1:top_n], Importance],
    highlight = highlight,
    title = main,
    digits = 2,
    ...)
  
  return(p)
}
