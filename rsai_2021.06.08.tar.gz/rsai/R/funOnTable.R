#####  funOnTable  #####
#' Quickly apply a function onto columns of a data.table.
#' @description A function that applies a function to columns on a data.table and returns a keyed data.table.
#' This has a couple of use cases, firstly, to aggregate/summarise by a group, secondly it can be used to fix
#' missing values in a data table.
#' @usage funOnTable(dt, FUN, by=character(0), cols=NULL, prefix="", suffix="",...)
#' @param dt A data.table
#' @param FUN A function for aggregating (I.E, mean.) Must take a vector of arbitrary length and return a vector
#' of length 1.
#' @param by The columns we are grouping by. This can be character vector of length zero (so no grouping and a single row table is returned.)
#' @param cols The columns to apply aggregation to. If NULL it applies to every column in the table other than
#' the columns used for grouping.
#' @param prefix A prefix to add to the column names of the returning table.
#' @param suffix A suffix to add to the column names of the returning table.
#' @param ... Any arguments to be passed through to the function.
#' @return A data table
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #set.seed(1984)
#' #### Usecase 1 - aggregate data by group
#' ###### Create transactions table
#' #transactions <- data.table(customer=c(rep("A", 12), rep("B", 8)),
#' #                           policy=c(rep(1, 8), rep(2, 4), rep(1, 8)),
#' #                           transactionAmt=round(c(rgamma(19, 1, .02), NA), digits=2),
#' #                           daysSinceTransaction=rpois(20, 7))
#' #
#' ###### Aggregate transactions by customer/policy
#' #transactionSummary <- funOnTable(transactions,
#' #                                       mean,
#' #                                       by=c("customer", "policy"),
#' #                                       suffix="_mean",
#' #                                       na.rm=TRUE)
#' #
#' #### Usecase 2 - change columns of a data.table using the same function
#' ###### Create table with some missing data
#' #tableWithMissings <- data.table(A=runif(500),
#' #                                B=rnorm(500))
#' #tableWithMissings[, ':='( A = ifelse(B>0.8, NA, A),
#' #                          B = ifelse(A<0.2, NA, B))]
#' #tableWithMissings[, C := ifelse(A>B, "A", "B")]
#' #
#' ###### Create table with some missing data
#' #fixedTable <- funOnTable(tableWithMissings, fixMissings)
#' @export

funOnTable <- function(dt, FUN, by=character(0), cols=NULL, prefix="", suffix="", ...){
  if(is.null(cols)) cols <- setdiff(names(dt), by)
  out <- dt[, lapply(.SD, function(x) FUN(x, ...)), keyby=by, .SDcols=cols]
  setnames(out, cols, paste0(prefix, cols, suffix))
  return(out)
}