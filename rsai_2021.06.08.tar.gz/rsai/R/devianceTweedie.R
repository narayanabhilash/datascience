#####  devianceTweedie  #####
#' Function to calculate deviance for model predictions assuming a Tweedie distribution.
#' @description This function calculates a deviance measure for model predictions assuming a Tweedie distribution.
#' @usage devianceTweedie(y, y_hat, p=1.5)
#' @param y a numeric vector of observations.
#' @param y_hat a numeric vector of predictions for y (must have same length as y.)
#' @param p Tweedie distribution variance power parameter
#' @return a numeric vector.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # n <- 1000
#' # 
#' # true <- rgamma(n, shape=15, scale=10)
#' # observed <- rtweedie(n, true, phi=50, p=1.5)
#' # predicted <- exp(log(150)/3 + 2*log(true)/3 + rnorm(n, sd=0.1))
#' # 
#' # plot(observed, predicted)
#' # 
#' # devs <- devianceTweedie(observed, predicted)
#' # sum(devs)
#' @export

devianceTweedie <- function(y, y_hat, p=1.5){
  n <- length(y)
  if(length(y_hat) != n) stop("y and y_hat are not the same length")

  if(p<=1 | p>=2) stop("p should be between 1 and 2")
  
  # Separate into y > 0 and y == 0
  zeros <- which(y==0)
 
  devs <- vector(mode="numeric", length=n)
  devs[zeros] <-  2*y_hat[zeros]^(2-p)/(2-p)
  
  # Fix for very small values
  eps <- 1E-16
  y_hat <- pmax(y_hat, eps)
  
  if(length(zeros) > 0 ){
    devs[-zeros] <- 2*(y[-zeros]*(y[-zeros]^(1-p) - y_hat[-zeros]^(1-p))/(1-p) - (y[-zeros]^(2-p) - y_hat[-zeros]^(2-p))/(2-p))
  } else{
    devs <- 2*(y*(y^(1-p) - y_hat^(1-p))/(1-p) - (y^(2-p) - y_hat^(2-p))/(2-p))
  }
  
  
  return(devs)
}

