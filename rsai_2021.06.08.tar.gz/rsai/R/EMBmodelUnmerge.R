#####  EMBmodelUnmerge  #####
#' Unmerge your EMBglm model
#'
#' \code{EMBmodelUnmerge} allows you to create separate EMBglm models from a single combined EMBglm model.
#' @param EMBlemModel object. Your original EMBglm model.
#' @return As many EMBglm models as were originally combined.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelUnmerge CSVmodelUnmerge
#' @export
#' @examples
#' #EMBmodelUnmerge(allModels)

EMBmodelUnmerge <- function(EMBlemModel) {

  # Get a list of all factor, level, and other columns
  Facs <- names(EMBlemModel)[grepl("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- names(EMBlemModel)[grepl("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]

  for (j in Mdls) {

    # Creating our model to work with
    facsToKeep <- c(Facs, Lvls, j)
    testMdl <- EMBlemModel[, ..facsToKeep]

    # Finding distinct Facs
    allFacs <- unique(testMdl[, ..Facs])

    # Finding distinct Facs where they have a non-1 multiplier and they are not a base rate
    non1Facs <- unique(testMdl[get(j) != 1 | get(Facs) == "", ..Facs])

    # Saving Base Rate
    baseRate <- testMdl[get(Facs) == "", ..j]

    # Getting the difference
    all1Facs <- allFacs[!non1Facs, on = Facs]

    # Now stripping down our dataset into something nice
    testMdl <- testMdl[!all1Facs, on = Facs]

    # Now looking at if the factor/levels are all null
    for (i in 1:length(Facs)) {
      Fac <- Facs[length(Facs) + 1 - i]
      Lvl <- Lvls[length(Lvls) + 1 - i]
      FacLvl <- c(Fac, Lvl)
      if (length(table(testMdl[, ..Fac])) == 1 && names(table(testMdl[, ..Fac])) == "") {
        testMdl[, (FacLvl) := NULL]
      }
    }

    # Adding Base Rate back in if everything else has been removed
    if(ncol(testMdl) == 1){
      testMdl <- data.table("", "", baseRate)
      names(testMdl) <- c(Facs[1], Lvls[1], j)
    }

    # Changing name to "Value"
    setnames(testMdl, j, "Value")

    # Setting the model to be an EMBglmobject
    testMdl <- as.EMBglm(testMdl)

    # Assigning to the global environment
    assign(gsub("^Value","",j), testMdl, envir = globalenv())

  }

  # Verbose output
  txtOutput <- character()
  for (i in Mdls) txtOutput <- paste0(txtOutput, i, "\n ")
  cat(noquote(paste0('The following models have been uncombined:\n ', txtOutput, '\n')))

}

#####  CSVmodelUnmerge  #####
#' Unmerge your EMBglm model and Output to a Folder
#'
#' \code{CSVmodelUnmerge} allows you to create separate EMBglm models from a single combined EMBglm model, and outputs all (as CSVs) to a specified folder.
#' @param EMBlemModel object. Your original EMBglm model.
#' @param Location character. The location of the folder where you want your CSV output to be.
#' @return As many EMBglm models (as CSVs) as were originally combined.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelUnmerge CSVmodelUnmerge
#' @export
#' @examples
#' #CSVmodelUnmerge(allModels, "../my_Loc")

CSVmodelUnmerge <- function(EMBlemModel, Location) {

  # Get a list of all factor, level, and other columns
  Facs <- names(EMBlemModel)[grepl("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- names(EMBlemModel)[grepl("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]

  for (j in Mdls) {

    # Creating our model to work with
    facsToKeep <- c(Facs, Lvls, j)
    testMdl <- EMBlemModel[, ..facsToKeep]

    # Finding distinct Facs
    allFacs <- unique(testMdl[, ..Facs])

    # Finding distinct Facs where they have a non-1 multiplier and they are not a base rate
    non1Facs <- unique(testMdl[get(j) != 1 | get(Facs) == "", ..Facs])

    # Saving Base Rate
    baseRate <- testMdl[get(Facs) == "", ..j]

    # Getting the difference
    all1Facs <- allFacs[!non1Facs, on = Facs]

    # Now stripping down our dataset into something nice
    testMdl <- testMdl[!all1Facs, on = Facs]

    # Now looking at if the factor/levels are all null
    for (i in 1:length(Facs)) {
      Fac <- Facs[length(Facs) + 1 - i]
      Lvl <- Lvls[length(Lvls) + 1 - i]
      FacLvl <- c(Fac, Lvl)
      if (length(table(testMdl[, ..Fac])) == 1 && names(table(testMdl[, ..Fac])) == "") {
        testMdl[, (FacLvl) := NULL]
      }
    }

    # Adding Base Rate back in if everything else has been removed
    if(ncol(testMdl) == 1){
      testMdl <- data.table("", "", baseRate)
      names(testMdl) <- c(Facs[1], Lvls[1], j)
    }

    # Changing name to "Value"
    setnames(testMdl, j, "Value")

    # Setting the model to be an EMBglmobject
    testMdl <- as.EMBglm(testMdl)

    # fwriting the files to the specified location
    fwrite(testMdl, file = .fn_CreateNonExistingDirectory(paste0(Location, "/", gsub("^Value","",j), ".csv")), quote = FALSE)

  }

  # Verbose output
  txtOutput <- character()
  for (i in Mdls) txtOutput <- paste0(txtOutput, i, "\n ")
  cat(noquote(paste0('The following models have been uncombined and stored in ', Location, ':\n ', txtOutput, '\n')))

}
