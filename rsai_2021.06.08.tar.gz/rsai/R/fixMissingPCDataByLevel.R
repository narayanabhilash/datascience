#####  fixMissingPCDataByLevel  #####
#' Function to fix missing UK postcode data.
#' @description For a UK postcode file, this function takes a vector of column names where the columns contain some missing values.
#' The missing values will be replaced using the following logic. For numeric columns the median by sector will be calculated and if this
#' is not missing, this will be used. If the value is missing for all postcodes in the sector, the missing values will be replaced with
#' the median by district, and if this is still missing, by post town. For non-numeric columns, the same logic applies but with mode
#' instead of median. A weight column can be applied (for example, number of households in the postcode could be used or a weight column
#' can be added to zero-weight postcodes that have been deprecated) and if so, the weighted median or weighted mode will be used.
#' @usage fixMissingPCDataByLevel(data,
#'                         colsToFix, 
#'                         postcodeCol,
#'                         weightCol = NULL,
#'                         sector = FALSE,
#'                         rowsToFix = NULL)
#' @param data A data frame or data table. This should contain postcode data at either full postcode or postcode sector level.
#' It should not contain a mixture of rows at different levels.
#' @param colsToFix The name of any columns with missing data to be fixed.
#' @param postcodeCol The name of the column defining either the full postcode or postcode sector.
#' @param weightCol Optional. A column name of a numeric column to be used for weights, for example number of households could be used.
#' Missing and negative weights are ignored.
#' @param rowsToFix Optional. Integer vector of rows to fix. If left as NULL will fix all rows. This might be useful if there are rows with
#' missing values that you want to impute later using a different method.
#' @param sector Either TRUE or FALSE. If FALSE (default) the function assumes the postcodeCol refers to full postcodes.
#' If TRUE it assumes the file is at postcode sector level and fills in missing values using summaries by district or town.
#' @return A data frame or data table.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export


fixMissingPCDataByLevel <- function(data,
                                    colsToFix, 
                                    postcodeCol,
                                    weightCol = NULL,
                                    sector = FALSE,
                                    rowsToFix = NULL){
  
  ###### Validation ######
  
  # Check data
  if (! is.data.frame(data)){
    stop("data must be a data frame")
  }
  if (! is.data.table(data)){
    df <- TRUE
    data <- data.table(data)
  } else df <- FALSE
  
  # Check weightCol
  if (! is.null(weightCol)){
    if (! is.vector(weightCol)) stop("weightCol must be a character vector")
    if (! is.character(weightCol)) stop("weightCol must be a character vector")
    if (! length(weightCol) == 1) stop("weightCol must be length one")
    if (! weightCol %in% names(data)) stop(paste0(weightCol, " is not a column in the specified data"))
    if (! is.numeric(data[[weightCol]])) stop("weightCol column must be numeric")
    if (weightCol %in% c("postcode", "postSector")) stop("weightCol must not be named postcode or postSector")
  }
  
  # Check postcodeCol
  if (! is.vector(postcodeCol)) stop("postcodeCol must be a character vector")
  if (! is.character(postcodeCol)) stop("postcodeCol must be a character vector")
  if (! length(postcodeCol) == 1) stop("postcodeCol must be length one")
  if (! postcodeCol %in% names(data)) stop(paste0(postcodeCol, " is not a column in the specified data"))
  if (! is.character(postcodeCol)) stop("postcodeCol must be a character column")
  
  # Check colsToFix
  if (! is.vector(colsToFix)) stop("colsToFix must be a character vector")
  if (! is.character(colsToFix)) stop("colsToFix must be a character vector")
  if (length(setdiff(colsToFix, names(data))) > 0){
    stop(paste0("All colsToFix must exist in data (missing: ", paste0(setdiff(colsToFix, names(data)), collapse=", "), ")"))
    if (any(colsToFix %in% c("postcode", "postSector", "postDistrict", "postTown", "weight", "rowNum"))){
      stop("No colsToFix can be named any of the following: postcode, postSector, postDistrict, postTown, weight, rowNum.")
    }
  }
  if (length(grep("\\.\\.Town$|\\.\\.Sector$|\\.\\.District", colsToFix)) > 0){
    stop("No colsToFix can end '..Sector', '..District', or '..Town'")
  }
  
  # Check for duplicated column names
  if (anyDuplicated(c(colsToFix, postcodeCol, weightCol))) stop("Duplicated column detected in input arguments.")
  
  # Check sector
  if (! is.vector(sector)) stop("sector must be logical vector")
  if (! is.logical(sector)) stop("sector must be logical vector")
  if (! length(sector) == 1) stop("sector must be of length 1")
  
  # Check rowsToFix
  if (! is.null(rowsToFix)){
    if (! is.vector(rowsToFix)) stop("rowsToFix must be an integer vector")
    if (! is.integer(rowsToFix)) stop("rowsToFix must be an integer vector")
    if (length(rowsToFix) == 0){
      cat("Note: No rows to fix. Returning original data set.\n")
      return(data)
    }
    if (min(rowsToFix) < 1L | max(rowsToFix) > nrow(data)) stop("At least one row to fix is out of range")
  }
  
  ###### Validation ######
  
  
  # Reduce to required columns
  dtSml <- data[, c(colsToFix, postcodeCol, weightCol), with=FALSE]
  
  # Change names to make next steps easier
  setnames(dtSml, postcodeCol, ifelse(sector, "postSector", "postcode"))
  if (!is.null(weightCol)) setnames(dtSml, weightCol, "weight")
  
  # Add original row number
  dtSml[, rowNum := .I]
  
  # Find invalid rows
  if (sector){
    rowsToDrop <- which(! postcodeSectorValid(data[[postcodeCol]]))
  } else{
    rowsToDrop <- which(! postcodeValid(data[[postcodeCol]]))
  }
  
  # Drop invalid rows
  if (length(rowsToDrop) > 0){
    warning(paste0("The following are not valid postcode",
                   ifelse(sector, " sector", ""),
                   "s:\n",
                   paste0(data[rowsToDrop[1:min(10, length(rowsToDrop))]][[postcodeCol]], collapse = ", "),
                   ifelse(length(rowsToDrop) > 10, ", ...\n", ".\n"),
                   "These ", length(rowsToDrop), " row(s) will be ignored."))
    dtSml <- dtSml[-rowsToDrop]
  }
  
  # Create postcode sector, district and town
  if (sector){
    dtSml[, postSector := gsub(" ", "", postSector)]
    dtSml[, ':=' (postDistrict = substr(postSector, 1, nchar(postSector)-1),
                  postTown = gsub("[0-9].*", "", postSector))]
  } else{
    dtSml[, postcode := gsub(" ", "", postcode)]
    dtSml[, ':=' (postSector = substr(postcode, 1, nchar(postcode)-2),
                  postDistrict = substr(postcode, 1, nchar(postcode)-3),
                  postTown = gsub("[0-9].*", "", postcode))]
  }
  
  
  # Function to summarise features from lower level to higher
  summaryFun <- function(x, w=NULL){
    if (is.null(w)){
      if (is.numeric(x)){
        if (is.integer(x)){
          return(as.integer(median(x, na.rm=TRUE)))
        } else return(median(x, na.rm=TRUE))
      } else return(getMode(x, na.rm=TRUE))
    } else{
      if (is.numeric(x)){
        if (is.integer(x)){
          return(as.integer(weighted.median(x, w, na.rm=TRUE)))
        } else return(weighted.median(x, w, na.rm=TRUE))
      } else return(weighted.mode(x, w, na.rm=TRUE))
    }
  }
  
  # Function to summarise data from one level up to the next
  summarisedData <- function(dt_, byCols){
    if (is.null(dt_$weight)){
      expr1 <- paste0(
        'dt_[,
        .(weight = .N, ',
        paste0(sapply(colsToFix, function(x){
          paste0(x, ' = summaryFun(', x, ')')
        }), collapse = ", "),
        '),
        by = c("', paste0(byCols, collapse='", "'), '")]'
      )
    } else{
      expr1 <- paste0(
        'dt_[,
      .(weight = sum(weight), ',
        paste0(sapply(colsToFix, function(x){
          paste0(x, ' = summaryFun(', x, ', weight)')
        }), collapse = ", "),
        '),
      by = c("', paste0(byCols, collapse='", "'), '")]'
      )
    }
    
    return(eval(parse(text=expr1)))
  }
  
  # Summarise up to sector level
  if (sector){
    summaryBySector <- dtSml
  } else{
    summaryBySector <- summarisedData(dtSml, c("postSector", "postDistrict", "postTown"))
  }
  
  # Summarise up to district level
  summaryByDistrict <- summarisedData(dtSml, c("postDistrict", "postTown"))
  
  # Summarise up to town level
  summaryByTown <- summarisedData(dtSml, "postTown")
  
  # Fix missings in the district table
  setnames(summaryByTown,
           colsToFix,
           paste0(colsToFix, "..Town"))
  setkey(summaryByTown, postTown)
  setkey(summaryByDistrict, postTown)
  
  summaryByDistrict <- merge(summaryByDistrict, summaryByTown[, c("postTown", paste0(colsToFix, "..Town")), with=FALSE])
  for (col in colsToFix){
    set(summaryByDistrict,
        i=which(is.na(summaryByDistrict[, col, with=FALSE])),
        j=col,
        value=summaryByDistrict[which(is.na(summaryByDistrict[, col, with=FALSE])), paste0(col, "..Town"), with=FALSE])
  }
  
  summaryByDistrict[, paste0(colsToFix, "..Town") := NULL]
  
  # Fix missings in the sector table
  setnames(summaryByDistrict,
           colsToFix,
           paste0(colsToFix, "..District"))
  setkey(summaryByDistrict, postDistrict)
  setkey(summaryBySector, postDistrict)
  
  summaryBySector <- merge(summaryBySector, summaryByDistrict[, c("postDistrict", paste0(colsToFix, "..District")), with=FALSE])
  for (col in colsToFix){
    set(summaryBySector,
        i=which(is.na(summaryBySector[, col, with=FALSE])),
        j=col,
        value=summaryBySector[which(is.na(summaryBySector[, col, with=FALSE])), paste0(col, "..District"), with=FALSE])
  }
  
  summaryBySector[, paste0(colsToFix, "..District") := NULL]
  
  if (! sector){
    # Fix missings in the postcode table
    setnames(summaryBySector,
             colsToFix,
             paste0(colsToFix, "..Sector"))
    setkey(summaryBySector, postSector)
    setkey(dtSml, postSector)
    
    dtSml <- merge(dtSml, summaryBySector[, c("postSector", paste0(colsToFix, "..Sector")), with=FALSE])
    for (col in colsToFix){
      set(dtSml,
          i=which(is.na(dtSml[, col, with=FALSE])),
          j=col,
          value=dtSml[which(is.na(dtSml[, col, with=FALSE])), paste0(col, "..Sector"), with=FALSE])
    }
    
    dtSml[, paste0(colsToFix, "..Sector") := NULL]
  } else{
    dtSml <- summaryBySector
  }
  
  # Reorder to the correct / original row order
  setkey(dtSml, rowNum)
  
  # Take copy of the original data so we don't accidentally change it
  dt_ <- copy(data)
  
  # Reduce to the rows that need changing
  if (! is.null(rowsToFix)){
    dtSml <- dtSml[rowNum %in% rowsToFix]
  }
  
  # Replace fixed columns in original data
  for (col in colsToFix){
    set(dt_, i=dtSml$rowNum, j=col, value=dtSml[[col]])
  }
  
  # return to data frame only if original data was not a data table
  if (df) dt_ <- as.data.frame(dt_)
  
  # Return fixed data table
  return(dt_)
}