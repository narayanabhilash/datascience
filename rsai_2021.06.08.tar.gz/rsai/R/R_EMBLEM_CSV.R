#' Read BID and FAC files
#' 
#' @description Reads a .Bid and .Fac file, and either constructs a data frame in memory, or
#' outputs to a .csv file in chunks
#' 
#' @details The procedure for creating output is as follows. First, the .Fac file is
#' read and a table of factor levels is created. Then, the .Bid file is read
#' either in chunks or continuously, depending on whether output is to file or
#' data frame. Lastly, at the end (of each chunk) each column is converted to
#' factor if \code{returnFactor=TRUE}. A check is made that the .Fac file did
#' specify at least one level for each factor, if not then that column remains
#' as integer.
#' 
#' If \code{returnFactor=FALSE} then the default column type is integer, not
#' numeric.
#' @usage readEMBlem(
#'   facfile,
#'   bidfile,
#'   outfile = NULL,
#'   chunksize = 5000L,
#'   returnFactor = TRUE,
#'   verbose = FALSE,
#'   makeNames = FALSE
#' ) 
#' @param facfile The .Fac file to use. This file details the factors in the
#' data file, and their levels.
#' @param bidfile The .Bid file to use. This file contains the actual data.
#' @param outfile Either missing (when data frame output is desired) or a
#' filename to output to. Should not be an already existing file. This can also
#' be a file connection (for instance as created by \code{\link{gzfile}}).
#' @param chunksize Number of data rows to read in at once, if outputting to
#' .csv. If creating a data frame, this only controls when progress output is
#' shown. Note that the output will still be a single file regardless of the
#' number or size of the chunks.
#' @param returnFactor Logical. If TRUE, \code{\link{factor}}s are returned (or
#' written to csv). If FALSE, \code{\link{integer}}s are returned. The latter
#' uses less memory, particularly when writing to disk.
#' @param verbose Logical. If TRUE, prints some progress messages.
#' @param makeNames Logical. If TRUE, and outfile=NULL the data frame output will have make.names function applied to column names.
#' @return If \code{outfile} is missing, a data frame. Otherwise, NULL.
#' @note When dealing with large data sets it will be quickest to read into a
#' data frame, however that does require more memory. If you are running out of
#' memory, we suggest writing to disk with \code{returnFactor=FALSE}, and then
#' reading in and coercing to factor as necessary. This will only require one
#' copy of the data, whereas performing the entire operation in memory will
#' require more.
#'
#  Ideas for future modifications
#   1) Find ways of making it faster...!
#   2) turn it into a function with options to write file to csv or load into memory
#   3) modify to have rating factors stored as factors in R (so that we can see the verbose name)

#' @author Nigel Carpenter; James Lawrence
#' @seealso \code{\link{read.csv}}, \code{fread} in package \code{data.table}.
#' @keywords ~EMBlem ~Bid ~Fac
#' @export
#' @examples
#' 
#' ## none yet!
#' 
readEMBlem <- function(facfile,bidfile,outfile=NULL,chunksize=5000L,returnFactor=TRUE,verbose=FALSE,makeNames=FALSE){

	if(identical(bidfile,outfile)) stop("'bidfile' and 'outfile' mustn't be the same!")
	if(identical(facfile,outfile)) stop("'facfile' and 'outfile' mustn't be the same!")
	if(is.character(facfile) && !grepl("\\.[fF][aA][cC]",facfile)) warning("'facfile' doesn't have the '.fac' extension. Are you sure it's the right file?")
	if(is.character(bidfile) && !grepl("\\.[Bb][iI][dD]",bidfile)) warning("'bidfile' doesn't have the '.bid' extension. Are you sure it's the right file?")

	if(verbose) cat("opening and reading FAC file...")
	f <- file(facfile, "rt")
	on.exit(close(f))
	linn=readLines(f)
	if(verbose) cat("OK\n")

	iLineFAC <- 0
	iCounterFAC <- 0
	iLineNext <- 7
	i <- 2

	numFields <- as.integer(linn[i])
	if(verbose) cat(numFields,"fields\n")
	myFactors<- vector(mode="list",length=numFields)
	myFactorName<- vector(mode="character",length=numFields)

	## Read fac file to determine factor names and levels
	if(verbose) cat("parsing FAC file...")

	while (iCounterFAC <= numFields){
		i <- i+1
		if (i == iLineNext){
			iCounterFAC <-iCounterFAC +1      
			if(iCounterFAC <= numFields) myFactorName[iCounterFAC] <- linn[i]
		}
  
		if (i == iLineNext+1){
    
			intFacLevels <- as.integer(gsub('\\t[0-9]{1,3}', '', linn[i]))
			iLineNext <- iLineNext + 1 + intFacLevels + 1
    
			myFactors[[iCounterFAC]]<- vector("character",intFacLevels)
    
			for (j in 1:intFacLevels) myFactors[[iCounterFAC]][j] <- linn[(i+j)]
		}
	}

	if(verbose) cat("OK\n")

	names(myFactors) <- myFactorName

	close(f)

	## Now read the .bid file

	if(verbose) cat("opening BID file...")

	b <- file(bidfile, "rb")
	on.exit(close(b))

	numRecords <- readBin(b,integer(),size=4)
	numFields2 <- readBin(b,integer(),size=4)
	cat("OK\n found",numRecords,"rows and",numFields2,"columns\n")

	## Calc the number of loops given chunksize
	j_chunks <- numRecords %/% chunksize
	## Calc the remainder after last chunk
	j_rem <-  numRecords %% chunksize

	## If there is no outfile, return a data frame

	if(is.null(outfile)){
		df.out <- matrix(0L,numRecords,numFields)
		df2 <- matrix(0,numRecords,2)
		for (i in 1:numRecords)
		{
			df.out[i,] <- readBin(b,integer(),numFields2, signed = FALSE, size=1)
			df2[i,] <- readBin(b, numeric(),2,size=8) ## signed was FALSE, but that does nothing
    			if (i %% chunksize ==0){
			      cat(paste0("num records :", i,"\n"))
			}
		}
		if(makeNames) colnames(df.out) <- make.names(myFactorName) else colnames(df.out) <- myFactorName
		colnames(df2) <- c("Weight","Response")
		if(returnFactor){
			df3 <- as.data.frame(cbind(df.out,df2))
			for(j in seq_along(myFactorName)){
				if(length(myFactors[[j]])){
					df3[[j]] <- factor(myFactors[[j]][df3[[j]]],levels=myFactors[[j]])
				} else warning(paste0("variable ",myFactorName[j]," had no levels. Leaving as integer"))
			}
			return(df3)
		}
		return(as.data.frame(cbind(df.out,df2)))
	} else {
		fout <- file(outfile,"wt")
		on.exit(close(fout),add=TRUE)
		#Write headers to csv file
		write.table(t(as.matrix(c(myFactorName,"Weight", "Response"))), file = fout, sep = ",", col.names = FALSE, row.names = FALSE)
		chunkSizeVector <- c(rep(chunksize,j_chunks),j_rem)
		ncat <- 0
		for(k in chunkSizeVector){
			df.out <- matrix(0L,k,numFields)
			df2 <- matrix(0,k,2)
			for (i in 1:k)
			{
				df.out[i,] <- readBin(b,integer(),numFields2, signed = FALSE, size=1)
				df2[i,] <- readBin(b, numeric(),2,size=8) ## see above
    				if (i==k){
				      cat(paste0("num records :", ncat <- ncat + k,"\n"))
				}
			}
			df3 <- as.data.frame(cbind(df.out,df2))
			for(j in seq_along(myFactorName)){
				if(length(myFactors[[j]])){
					df3[[j]] <- factor(myFactors[[j]][df3[[j]]],levels=myFactors[[j]])
				} else warning(paste0("variable ",myFactorName[j]," had no levels. Leaving as integer"))
			}
			write.table(df3,fout,col.names=FALSE,row.names=FALSE,sep=",")
		}
	}
}




