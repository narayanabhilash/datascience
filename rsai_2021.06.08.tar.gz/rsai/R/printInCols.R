#####  printInCols  #####
#' Function to output neatly to console.
#' @description This function takes a vector and prints in neatly to the console in columns. Useful to control the look if R notebooks.
#' @usage printInCols(x, cols = 1)
#' @param x Vector to print.
#' @param cols Number of columns.
#' @return NULL.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #printInCols(c("Alpha", "Beta", "Gamma", "Delta"))
#' @export

printInCols <- function(x, cols = 1){
  if (is.null(x)){
    print(NULL)
  } else{
    
    # Max character length
    maxN <- max(nchar(x))
    
    # Add on training spaces to make lengths equal
    x <- paste0(
      x,
      sapply(
        x,
        function(y){
          paste0(rep(" ", maxN - nchar(y) + 1), collapse = "")
        }
      )
    )
    
    # Which lines need line breaks at the start
    newLines <- which((seq(1, length(x)-1) %% cols) == 0) + 1
    
    # Add line breaks
    x[newLines] <- paste0("\n", x[newLines])
    
    # Output to console
    cat(x)
  }
}