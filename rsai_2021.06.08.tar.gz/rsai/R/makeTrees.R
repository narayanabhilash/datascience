#' create trees from gbm
#' @description create trees from gbm
#' @param x input of a gbm object
#' @param n the number of tree to retrieve
#' @param language One of "R" or "SAS
#' @author James Lawrence
#' @importFrom gbm pretty.gbm.tree
#' @export
#' @examples  
#' 
#' df.tmp <- data.frame(x1=rnorm(1000),x2=rbinom(1000,10,0.5),x3=rbinom(1000,20,0.5))
#' df.tmp$x2f <- as.factor(df.tmp$x2)
#' df.tmp$x3f <- as.factor(df.tmp$x3)
#' df.tmp$y1 <- rnorm(1000,df.tmp$x1,0.5)
#' df.tmp$y2 <- rnorm(1000,df.tmp$x1+df.tmp$x2/3,0.5)
#' df.tmp$y3 <- rnorm(1000,df.tmp$x1+df.tmp$x2/3 + df.tmp$x3/5,0.5)

#' then <- identity

#' gbm1 <- gbm(y3 ~ x1 + x2f + x3f,n.trees=4L,shrinkage=0.5,data=df.tmp,keep.data=FALSE)
#' cat(makeTrees(gbm1,language="R"))
#' cat(makeTrees(gbm1,language="SAS"))
#' p1 <- predict(gbm1,df.tmp,n.trees=1L)
#' p2 <- predict(gbm1,df.tmp,n.trees=2L)
#' p20 <- predict(gbm1,df.tmp,n.trees=20L)
#' x1 <- df.tmp$x1[1]
#' x2f <- df.tmp$x2f[1]
#' x3f <- df.tmp$x3f[1]
#' eval(parse(text=makeTrees(gbm1,language="R")))


makeTrees <- function(x,n=gbm::gbm.perf(x),language=c("R","SAS")){
	language <- match.arg(language)
	treeStrs <- sapply(1:n,function(i){
		df.tree <- gbm::pretty.gbm.tree(x,i=i)
		df.tree$depth <- 0L
		for(i in which(df.tree$SplitVar > -1)){
			df.tree$depth[df.tree$LeftNode[i]+1] <- 
			df.tree$depth[df.tree$RightNode[i]+1] <- 
			df.tree$depth[df.tree$MissingNode[i]+1] <- 
			df.tree$depth[i] + 1L
		}
		switch(language,
"R"=			{nodeStrs <- sapply(1:(dim(df.tree)[1]),f <- function(j){
				pfx <- paste0(rep("\t",df.tree$depth[j]),collapse="")
				## terminal nodes
				if(df.tree$SplitVar[j] == -1) return(as.character(paste0(pfx,df.tree$SplitCodePred[j])))
				vname <- x$var.names[df.tree$SplitVar[j]+1]
				## continuous
				if(x$var.type[df.tree$SplitVar[j]+1]==0) return(paste0(
					pfx,
					"if(is.na(",
					vname,
					")) {\n",
					"#NODE",
					df.tree$MissingNode[j],
					"#\n",
					pfx,
					"} else if(",
					vname,
					" < ",
					df.tree$SplitCodePred[j],
					") {\n",
					"#NODE",
					df.tree$LeftNode[j],
					"#\n",
					pfx,
					"} else {\n",
					"#NODE",
					df.tree$RightNode[j],
					"#\n",
					pfx,
					"}")
				)
				## categorical
				if(x$var.type[df.tree$SplitVar[j]+1]>0) return(paste0(
					pfx,
					"if(is.na(",
					vname,
					")) {\n",
					"#NODE",
					df.tree$MissingNode[j],
					"#\n",
					pfx,
					"} else if(",
					vname,
					" %in% c(",
					paste0(x$var.levels[[df.tree$SplitVar[j]+1]][x$c.splits[[df.tree$SplitCodePred[j]+1]]==1],collapse=","),
					")) {\n",
					"#NODE",
					df.tree$RightNode[j],
					"#\n",
					pfx,
					"} else {\n",
					"#NODE",
					df.tree$LeftNode[j],
					"#\n",
					pfx,
					"}")
				)
			})},
"SAS"=			{nodeStrs <- sapply(1:(dim(df.tree)[1]),function(j){
				pfx <- paste0(rep("\t",df.tree$depth[j]),collapse="")
				## terminal nodes
				if(df.tree$SplitVar[j] == -1) return(as.character(paste0(pfx,df.tree$SplitCodePred[j])))
				vname <- x$var.names[df.tree$SplitVar[j]+1]
				## continuous
				if(x$var.type[df.tree$SplitVar[j]+1]==0) return(paste0(
					pfx,
					"if (",
					vname,
					"=.",
					") then (\n",
					"#NODE",
					df.tree$MissingNode[j],
					"#\n",
					pfx,
					") else if (",
					vname,
					" < ",
					df.tree$SplitCodePred[j],
					") then (\n",
					"#NODE",
					df.tree$LeftNode[j],
					"#\n",
					pfx,
					") else (\n",
					"#NODE",
					df.tree$RightNode[j],
					"#\n",
					pfx,
					")")
				)
				## categorical
				if(x$var.type[df.tree$SplitVar[j]+1]>0) return(paste0(
					pfx,
					"if (",
					vname,
					"=\"\"",
					") then (\n",
					"#NODE",
					df.tree$MissingNode[j],
					"#\n",
					pfx,
					") else if (",
					vname,
					" in (\"",
					paste0(x$var.levels[[df.tree$SplitVar[j]+1]][x$c.splits[[df.tree$SplitCodePred[j]+1]]==1],collapse="\" \""),
					"\")) then (\n",
					"#NODE",
					df.tree$RightNode[j],
					"#\n",
					pfx,
					") else (\n",
					"#NODE",
					df.tree$LeftNode[j],
					"#\n",
					pfx,
					")")
				)
			})}
		)
		while(grepl("#NODE",nodeStrs[1],fixed=TRUE)){
			for(j in 1:(dim(df.tree)[1])){
				nodeStrs[1] <- gsub(paste0("#NODE",j,"#"),nodeStrs[j+1],nodeStrs[1],fixed=TRUE)
			}
		}
	return(nodeStrs[1])})
	return(paste0(x$initF," + \n(",paste0(treeStrs,collapse=") + \n("),")",ifelse(language=="SAS",";","")))
}


