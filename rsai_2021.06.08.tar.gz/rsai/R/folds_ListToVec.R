#####  folds_ListToVec  #####
#' Change a list representing a data partition to a vector
#' @description Change a list where each element represents a fold or data partition and contains a vector of the row numbers for that fold, into a vector.
#' @usage folds_ListToVec(folds)
#' @param folds A list of integer vectors which run from 1 to some N with no repeating values.
#' @return A vector of integers that range from 1 to the length of the input list and represent the same data partion in vector form.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #folds_ListToVec(list(seq(1, 496, by=5), seq(2, 497, by=5), seq(3, 498, by=5), seq(4, 499, by=5), seq(5, 500, by=5)))
#' @export

folds_ListToVec <- function(folds){
  # Validation of input
  if(!is.list(folds)) stop("Must supply a list.")
  if(!all(sapply(folds, is.numeric))) stop("Must supply a list of integers.")
  if(!all(sapply(folds, is.integer))) folds <- lapply(folds, as.integer)
  if(min(sapply(folds, min)) != 1) stop("Lowest value in lists must be 1L.")
  if(max(sapply(folds, max))!=sum(sapply(folds, length)))  stop("Highest value in lists must equal the total number within all lists.")
  if(anyDuplicated(unlist(folds)) != 0) stop("Duplicate values detected.")
  
  # Create matrix with row numbers and fold Ids
  mat <- do.call(rbind, lapply(seq(1, length(folds)), function(i){
    cbind(i, folds[[i]])
  }))
  
  # Return fold Ids sorted by row numbers
  return(mat[order(mat[, 2]), 1])
}