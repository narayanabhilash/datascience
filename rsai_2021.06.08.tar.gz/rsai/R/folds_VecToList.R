#####  folds_VecToList  #####
#' Change a vector representing a data partition to a list
#' @description Change a vector representing folds (a partition of a data set) to a list where each element represents a fold and contains a vector of the row numbers for that fold.
#' @usage folds_VecToList(foldId)
#' @param foldId A vector with elements that represent an Id for a fold/partition of a data set.
#' @return A list of integer vectors representing row numbers
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #folds_VecToList(rep(seq(1, 5), 100))
#' @export

folds_VecToList <- function(foldId){
  vals <- unique(foldId)
  vals <- vals[order(vals)]
  folds <- lapply(vals, function(x) which(foldId==x))
}