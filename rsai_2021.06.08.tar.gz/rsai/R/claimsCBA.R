#####  claimsCBA  #####
#' Benefit analysis for new claims models
#' @description Cost benefit analysis of implementing a new claims model to replace a current model.
#' By default, this routine carries out the following steps: \cr
#' \cr
#' 1) Rebase the old and new model predictions against the observed values. \cr
#' \cr
#' 2) Multiply by the 'intensity' to get expected peril claim costs for old and new. \cr
#' \cr
#' 3) Use the 'perilProp' and 'perilDependency' to caluculate the expected _other_ peril claim costs. \cr
#' \cr
#' 4) Add these together and use the 'lossRatio' to calculate the old premium. \cr
#' \cr
#' 5) Add the old premium difference between expected difference in claims costs to get an unrebased new premium. \cr
#' \cr
#' 6) Rebase the new premiums by multiplying by the constant that leads to the same premium being written.
#' This uses the 'elasticity' and 'baseConversion' assumptions. \cr
#' \cr
#' 7) Calculate the difference in written claims costs and return this result as part of a list of KPIs. \cr
#' \cr
#' \cr
#' This function needs to be run on hold-out data.
#' It will always overestimate benefit if run on the data you trained your model with.
#' You need to create a dataset where each row of data represents exposure to a risk or group of risks.
#' The output is relatively sensitive to the input assumptions, and you should test this yourself on your data.
#' The function is designed so that you can run at a high level, for example by grouping your data into 10 decile groups
#' using the ratio of your 2 models and assuming that elasticity, intensity, loss ratio etc. are constant across all 10 groups.
#' This will give you a good rule of thumb for the potential benefit in implementing the model.
#' You could also run at a much lower level by using raw exposure data where
#' each row corresponds to an exposure for a single risk, and you could score on your severity model and
#' models for other perils so you can get best estimates per row for every assumption being made
#' (including using a demand model to generate individual estimates of price elasticity).
#' While the results are accurate given the input assumptions, care should be taken when interpreting the results! \cr
#' \cr
#' The following KPIs are returned:
#' \describe{
#'   \item{OldRebasingFactor}{The multiplier used to rebase the old model predictions}
#'   \item{NewRebasingFactor}{The multiplier used to rebase the new model predictions}
#'   \item{ChangeInWrittenPremium}{The percentage change in total written premium from the old scenario to the new}
#'   \item{BaseAdjustment}{The base adjustment multiplier used on the new premiums to equalise the total written
#'   premiums between scenarios}
#'   \item{ChangeInPerilClaimsCost}{The percentage change in claims costs for the peril being modelled between
#'   the old scenario and the new}
#'   \item{ChangeInOverallClaimsCostTotal}{The percentage change in overall claims costs for the peril being modelled
#'   between the old scenario and the new}
#'   \item{ChangeInOverallClaimsCostPeril}{The change in overall claims costs between the old scenario and the new
#'   as a proportion of the peril-only claim costs from the current scenario}
#'   \item{OldPerilOnlyLossRatio}{The ratio of written peril-only claims costs and written premium for the current scenario}
#'   \item{NewPerilOnlyLossRatio}{The ratio of written peril-only claims costs and written premium for the new scenario}
#'   \item{OldLossRatio}{The total overall loss ratio for the current scenario}
#'   \item{NewLossRatio}{The total overall loss ratio for the new scenario}
#'   \item{ChangeInPerilOnlyLossRatio}{Change in peril-only loss ratio between the old scenario and the new}
#'   \item{ChangeInLossRatio}{Change in overall loss ratio between the old scenario and the new}
#' }
#' @usage claimsCBA(
#'   obs,
#'   old,
#'   new,
#'   exposure = 1,
#'   perilProp = 1,
#'   elasticity = -5,
#'   lossRatio = 1,
#'   intensity = 1,
#'   minRateChange = -Inf,
#'   maxRateChange = Inf,
#'   perilDependency = 0,
#'   baseConversion = 0,
#'   family = "Poisson",
#'   tweedieP = NULL,
#'   baseChange = NULL,
#'   rebase = TRUE,
#'   returnParams = FALSE,
#'   returnData = FALSE,
#'   plotDoubleLift = FALSE
#')
#' @param obs A vector of observed claims frequency, severity or burning cost
#' @param new A vector of predicted claims frequency, severity or burning cost for the proposed new model
#' @param old A vector of predicted claims frequency, severity or burning cost for the existing model
#' @param exposure A vector of total exposure for each row (or a scalar if all exposures are constant)
#' This could be claim counts if this is a severity model
#' and the rows are grouped by policy with an observed average claim size.
#' @param perilProp The proportion of total burning cost that can be assigned to the peril being modelled.
#' This can either be a vector or a constant scalar value.
#' If this is a scalar constant, then you can use the `perilDependency` argument to vary how the other peril burning cost
#' is assigned row by row.
#' The output of the routine can be very sensitive to this argument.
#' If `perilProp` is a scalar and is low, and if you have a constant `elasticity`,
#' the routine will often predict that the new scenario will likely write more in claims costs for the other perils
#' which offsets the claim cost reduction for the peril being modelled.
#' This means that the predicted benefit may not scale down linearly with this parameter as it moves away from 1.
#' In real life if your model is a genuine improvement, this increase in claims costs from other perils may not happen,
#' and there are a number of reasons why not. Here are two:
#' Firstly, price elasticity will likely be lower in areas where you were underpriced previously and higher when 
#' overpriced. Taking this into account may better balance the other peril claim costs.
#' Secondly, your future claim costs for the other perils may be more correlated to your new model predictions
#' than your old (since your new are - hopefully - better predictions and peril claim costs tend to be correlated) so moving your
#' prices in the right direction with respect to the peril being modelled may have unaccounted for benefits in the
#' other perils.
#' @param elasticity Elasticity.
#' Either a constant value or a vector if you have a conversion model and an understanding of 
#' how elasticity varies for each row of data.
#' Elasticity is the (\% change in demand) / (\% change in premium).
#' @param lossRatio Loss ratio. Either a constant value or a vector if the expected loss ratio varies by row.
#' @param intensity If you're modelling frequency, you can use `intensity` to specify the expected severity,
#' either on an overal basis as a constant value, or as a vector if this varies row by row. If you're modelling
#' severity, you can use this to specify the expected frequency. If specifying a constant value, this will have
#' no effect unless you set `returnData` to be true, in which case some of the columns denoting overall claims
#' cost or premium will be scaled to be more realistic values.
#' @param minRateChange The lowest proportional premium adjustment we are allowed to make from the current premiums.
#' For example, if a 20\% reduction was as far as we were allowed to go, you would specify -0.2.
#' @param maxRateChange The highest proportional premium adjustment we are allowed to make from the current premiums.
#' For example, if a 25\% increase was as far as we were allowed to go, you would specify 0.25.
#' @param perilDependency If the `perilProp` argument is a scalar, then this parameter is used to assign
#' burning cost for the other perils to each row. The assignment will be proportional to
#' \code{old ^ perilDependency}. A `perilDependency` of 0, for example, will lead to a constant other perils burning
#' cost by row, whereas a `perilDependency` of 1 will lead to the other peril burning cost being a multiple
#' of the old model predictions.
#' If the `perilProp` argument is specified as a vector, or is set to 1, then this argument is ignored.
#' @param baseConversion This argument is used to determine the shape of the demand curves for each row.
#' A `baseConversion` of 0.5 for example means that the maximum possible volume increase is 200\% and the
#' price elasticity will start to reduce as you lower premiums. A `baseConversion` of zero assumes that the
#' price elasticity is constant and volume will vary exponentially with premium.
#' This argument can be specified as a constant or a vector that varies row by row.
#' @param family This effects how the rebasing is done. The rebasing is performed using the `rebasePreds` function.
#' Should be set to "Poisson" (default) for claims frequency, "Gamma" for severity or "Tweedie" for burning cost.
#' @param tweedieP This only has an effect if `rebase` is true and and `family` is set to "Tweedie".
#' This is the Tweedie power parameter used when rebasing both sets of predictions.
#' @param baseChange This parameter is NULL by default, which means there is a base level premium adjustment
#' that leads the old and new scenarios to write the same level of premium. If you want to see the affect
#' if you don't make such an adjustment then set this parameter to zero. You can also choose any value
#' to see the impact. If you do this, some of the benefit of the new model might be in increasing GWP rather
#' than reducing written burning cost.
#' @param rebase Logical. Whether or not to rebase the old and new predictions against the observed values.
#' Doing so is often useful since validation data is often taken from a different time period where the base
#' level is different. It also puts both models, that might have been trained on different data onto
#' a consistent footing.
#' @param returnParams Logical, whether or not to include the input parameters in the output list.
#' @param returnData Logical, whether or not to return a data set with intermediate calculations in the output list.
#' @param plotDoubleLift Logical, whether or not to plot a double lift chart.
#' @return A list of KPIs relating to the projected new scenario, E.G. projected loss ratio change.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export
#' @examples
#' # # Number of rows
#' # n <- 100000
#' # 
#' # # For replicability
#' # set.seed(1984)
#' # 
#' # # Create dummy data with random features and exposure
#' # CBATest <- data.table(
#' #   x1 = exp(runif(n, -log(1.2), log(1.2))),
#' #   x2 = exp(runif(n, -log(1.2), log(1.2))),
#' #   x3 = exp(runif(n, -log(1.2), log(1.2))),
#' #   exposure = runif(n)
#' # )
#' # 
#' # # Create random observed frequency and old and new frequency models
#' # CBATest[
#' #   ,
#' #   ':='(
#' #     observedFreq = rpois(n, 0.05 * exposure * x1 * x2^0.7 * x3^0.3) / exposure,
#' #     oldModel = 0.05 * x1,
#' #     newModel = 0.05 * x1 * x2 ^ 0.7
#' #   )
#' # ]
#' # 
#' # # Run CBA 
#' # CBA <- claimsCBA(
#' #   obs              =  CBATest[, observedFreq],
#' #   old              =  CBATest[, oldModel],
#' #   new              =  CBATest[, newModel],
#' #   exposure         =  CBATest[, exposure],
#' #   elasticity       =  -7,
#' #   lossRatio        =  0.8,
#' #   intensity        =  1000,
#' #   minRateChange    =  -0.2,
#' #   maxRateChange    =  0.25,
#' # )
#' @export

claimsCBA <- function(
  obs,
  old,
  new,
  exposure = 1,
  perilProp = 1,
  elasticity = -5,
  lossRatio = 1,
  intensity = 1,
  minRateChange = -Inf,
  maxRateChange = Inf,
  perilDependency = 0,
  baseConversion = 0,
  family = "Poisson",
  tweedieP = NULL,
  baseChange = NULL,
  rebase = TRUE,
  returnParams = FALSE,
  returnData = FALSE,
  plotDoubleLift = FALSE
){
  # Number of rows
  n <- length(obs)
  
  # Validation - parameter length
  if (n < 2) stop("Length of 'obs' must be at least 2")
  if (length(old) != n) stop("'old' must be the same length as 'obs'")
  if (length(new) != n) stop("'new' must be the same length as 'obs'")
  if (!length(exposure) %in% c(1, n)) stop("'exposure' must either be length 1 or the same length as 'obs'")
  if (!length(perilProp) %in% c(1, n)) stop("'perilProp' must either be length 1 or the same length as 'obs'")
  if (!length(elasticity) %in% c(1, n)) stop("'elasticity' must either be length 1 or the same length as 'obs'")
  if (!length(lossRatio) %in% c(1, n)) stop("'lossRatio' must either be length 1 or the same length as 'obs'")
  if (!length(intensity) %in% c(1, n)) stop("'intensity' must either be length 1 or the same length as 'obs'")
  if (length(minRateChange) != 1) stop("'minRateChange' must be length 1")
  if (length(maxRateChange) != 1) stop("'maxRateChange' must be length 1")
  if (length(perilDependency) != 1) stop("'perilDependency' must be length 1")
  if (!length(baseConversion) %in% c(1, n)) stop("'baseConversion' must either be length 1 or the same length as 'obs'")
  if (length(family) != 1) stop("'family' must be length 1")
  if (!is.null(tweedieP)){
    if (length(tweedieP) != 1) stop("'tweedieP' must be length 1")
  }
  if (!is.null(baseChange)){
    if (length(baseChange) != 1) stop("'baseChange' must be length 1")
  }
  if (length(returnParams) != 1) stop("'returnParams' must be length 1")
  if (length(returnData) != 1) stop("'returnData' must be length 1")
  if (length(plotDoubleLift) != 1) stop("'returnData' must be length 1")

  # Validation - parameter class
  if (!is.numeric(obs)) stop("'obs' must be numeric")
  if (!is.numeric(old)) stop("'old' must be numeric")
  if (!is.numeric(new)) stop("'new' must be numeric")
  if (!is.numeric(exposure)) stop("'exposure' must be numeric")
  if (!is.numeric(perilProp)) stop("'perilProp' must be numeric")
  if (!is.numeric(elasticity)) stop("'elasticity' must be numeric")
  if (!is.numeric(lossRatio)) stop("'lossRatio' must be numeric")
  if (!is.numeric(intensity)) stop("'intensity' must be numeric")
  if (!is.numeric(minRateChange)) stop("'minRateChange' must be numeric")
  if (!is.numeric(maxRateChange)) stop("'maxRateChange' must be numeric")
  if (!is.numeric(perilDependency)) stop("'perilDependency' must be numeric")
  if (!is.numeric(baseConversion)) stop("'baseConversion' must be numeric")
  if (!is.character(family)) stop("'family' must be character")
  if (!is.null(tweedieP)){
    if (!is.numeric(tweedieP)) stop("'tweedieP' must be numeric")
  }
  if (!is.null(baseChange)){
    if (!is.numeric(baseChange)) stop("'baseChange' must be numeric")
  }
  if (!is.logical(rebase)) stop("'rebase' must be logical")
  if (!is.logical(returnParams)) stop("'returnParams' must be logical")
  if (!is.logical(returnData)) stop("'returnData' must be logical")
  if (!is.logical(plotDoubleLift)) stop("'returnData' must be logical")
  
  # Validation - NAs
  if (anyNA(obs)) stop("'obs' contains NAs")
  if (anyNA(old)) stop("'old' contains NAs")
  if (anyNA(new)) stop("'new' contains NAs")
  if (anyNA(exposure)) stop("'exposure' contains NAs")
  if (anyNA(perilProp)) stop("'perilProp' contains NAs")
  if (anyNA(elasticity)) stop("'elasticity' contains NAs")
  if (anyNA(lossRatio)) stop("'lossRatio' contains NAs")
  if (anyNA(intensity)) stop("'intensity' contains NAs")
  if (anyNA(minRateChange)) stop("'minRateChange' contains NAs")
  if (anyNA(maxRateChange)) stop("'maxRateChange' contains NAs")
  if (anyNA(perilDependency)) stop("'perilDependency' contains NAs")
  if (anyNA(baseConversion)) stop("'baseConversion' contains NAs")
  if (anyNA(family)) stop("'family' contains NAs")
  if (!is.null(tweedieP)){
    if (anyNA(tweedieP)) stop("'tweedieP' contains NAs")
  }
  if (!is.null(baseChange)){
    if (anyNA(baseChange)) stop("'baseChange' contains NAs")
  }
  if (anyNA(rebase)) stop("'rebase' contains NAs")
  if (anyNA(returnParams)) stop("'returnParams' contains NAs")
  if (anyNA(returnData)) stop("'returnData' contains NAs")
  if (anyNA(plotDoubleLift)) stop("'returnData' contains NAs")
  
  # Allowable values
  if (any(obs < 0)) stop("'obs' contains negative values")
  if (any(old < 0)) stop("'old' contains negative values")
  if (any(new < 0)) stop("'new' contains negative values")
  if (any(exposure < 0)) stop("'exposure' contains negative values")
  if (any(perilProp <= 0)) stop("'perilProp' must be positive")
  if (all(c(-1, 1) %in% sign(elasticity))) stop("'elasticity' contains both positive and negative values")
  if (any(lossRatio <= 0)) stop("'lossRatio' must be positive")
  if (any(intensity < 0)) stop("'intensity' contains negative values")
  if (any(minRateChange > 0)) stop("'minRateChange' must be positive")
  if (any(maxRateChange < 0)) stop("'maxRateChange' must be negative")
  if (any(baseConversion < 0 | baseConversion >= 1)) stop("'baseConversion' must be >= 0 and < 1")
  if (!family %in% c("Poisson", "Gamma", "Tweedie")) stop("'family' must be Poisson, Gamma or Tweedie")
  
  # Check to see whether peril proportion is specified as overall or by row
  if (length(perilProp) == 1){
    overallPerilProp <- perilProp
    perilProp <- NULL
  } else{
    overallPerilProp <- NULL
  }
  
  # Put into a table for ease of understanding
  dt <- data.table(
    obs = obs,
    old = old,
    new = new,
    oldExposure = exposure,
    intensity = intensity,
    elasticity = -abs(elasticity), # Make sure elasticity is negative
    perilProp = perilProp,
    oldExpLossRatio = lossRatio,
    baseConversion = baseConversion
  )
  
  # Save out list of return parameters to send back if required
  if (returnParams){
    parameterList <- list(
      perilProp = perilProp,
      elasticity = elasticity,
      lossRatio = lossRatio,
      minRateChange = minRateChange,
      maxRateChange = maxRateChange,
      perilDependency = perilDependency,
      baseConversion = baseConversion
    )
  }
  
  # Clear environment
  rm(obs, old, new, exposure, intensity, elasticity, perilProp, lossRatio, baseConversion)
  
  # Drop zero weighted rows
  dt <- dt[oldExposure > 0 & intensity > 0]
  
  # Check length is still > 2
  if (nrow(dt) < 2) stop("There must be at least 2 non-zero weighted observations")
  
  # After dropping zero-weighted rows, check that model predictions are positive
  if (any(dt[, old] == 0)) stop("'old' contains zero values")
  if (any(dt[, new] == 0)) stop("'new' contains zero values")
  
  # Since the value of our models comes from better differentiating risk
  # and often the validation period has a different base level of risk
  # we rebase both sets of predictions (unless rebase = FALSE)
  if (rebase){
    # Rebase
    dt[
      ,
      ':='(
        oldRebased = rebasePreds(obs, old, family, oldExposure, tweedieP),
        newRebased = rebasePreds(obs, new, family, oldExposure, tweedieP)
      )
    ]
    
    # Find rebasing factors
    oldRebasingFactor <- dt[old > 0][1, oldRebased / old]
    newRebasingFactor <- dt[new > 0][1, newRebased / new]
      
  } else{
    dt[
      ,
      ':='(
        oldRebased = old,
        newRebased = new
      )
    ]
    # No rebasing is the equivalent of a rebasing factor of 1
    oldRebasingFactor <- 1
    newRebasingFactor <- 1
  }
  
  # Calculate the observed and expected claim cost for this peril
  dt[
    ,
    ':='(
      obsPerilClaimCost = obs * intensity,
      oldPerilClaimCost = oldRebased * intensity,
      newPerilClaimCost = newRebased * intensity
    )
  ]
  
  # Calculate the expected claim cost of the other perils
  if (! is.null(overallPerilProp)){
    # If the peril proportion was specified on an overall level
    # We use 'perilDependency' to calculate the other claims costs
    # This allows users to vary how the value of claims for other perils varies as the peril claims cost varies
    # A value of 1 means that cell by cell, other peril costs will be a constant multiple of the peril cost
    # A value of 0 means that 
    
    # Calculate the amount that the total other perils costs must sum to
    totalOtherPerilCost <- dt[, sum(obsPerilClaimCost * oldExposure)] * (1 - overallPerilProp) / overallPerilProp
    # Find the constant value we will need to mut
    k <- totalOtherPerilCost / dt[, sum(oldExposure * oldPerilClaimCost ^ perilDependency)]
    
    dt[, otherClaimCost := k * oldPerilClaimCost ^ perilDependency]
    
    # Tidy environment
    rm(totalOtherPerilCost, k)
  } else{
    # If the peril prop is set row by row, there is a simple calculation to find the other peril cost
    dt[, otherClaimCost := oldPerilClaimCost * (1 - perilProp) / perilProp]
    dt[, perilProp := NULL]
  }
  
  # Create premium columns
  dt[, oldPremium := (oldPerilClaimCost + otherClaimCost) / oldExpLossRatio]
  dt[, newPremiumNoBaseAdj := oldPremium - oldPerilClaimCost + newPerilClaimCost]
  
  # Function that takes an elasticity and a rate change and returns a total volume change
  rateChangeEffect <- function(rateChange, elasticity, baseProb = 0){
    1 / (baseProb + (1 - baseProb) * exp(elasticity * rateChange / (baseProb - 1)))
  }
  
  # Users can specify their own base change. If they haven't...
  if (is.null(baseChange)){
    # Function to minimise to find a base change that equalises total written premium
    minFunc <- function(baseChange){
      # Difference in premiums
      premRateChange <- dt[
        ,
        pmin(
          pmax(
            (newPremiumNoBaseAdj * (1 + baseChange)) / oldPremium - 1,
            minRateChange
          ),
          maxRateChange
        )
      ]
      # Volume change using elasticity
      volChange <- dt[, rateChangeEffect(premRateChange, elasticity, baseConversion)]
      # Calculate the total written premiums before and after
      oldGWP <- dt[, oldPremium * oldExposure]
      newGWP <- dt[, (oldPremium * (1 + premRateChange)) * oldExposure * volChange]
      # Return square of difference
      return((sum(newGWP) - sum(oldGWP)) ^ 2) 
    }
    
    # What is the range of the ratio between new and old
    rangeRatio <- dt[, range(newPremiumNoBaseAdj / oldPremium)]
    
    # Make the search range as narrow as possible to speed up search and help convergece
    minSearchRange <- max((1 + minRateChange) / rangeRatio[2] - 1, -0.5)
    maxSearchRange <- min((1 + maxRateChange) / rangeRatio[1] - 1, 1)

    # Find the base change that minimises change in volume of premium written
    baseChange <- optimise(minFunc, c(minSearchRange, maxSearchRange), tol=1e-07)$minimum
    
    optimisedBaseChange <- TRUE
  } else{
    optimisedBaseChange <- FALSE
  }
  
  # Use the base change and the newPremiumNoBaseAdj to find the new premium
  dt[
    ,
    premiumRateChange := pmin(
      pmax(
        (newPremiumNoBaseAdj * (1 + baseChange)) / oldPremium - 1,
        minRateChange
      ),
      maxRateChange
    )
  ]
  dt[, newPremium := (premiumRateChange + 1) * oldPremium]
  dt[, newPremiumNoBaseAdj := NULL]

  # Volume change
  dt[, volumeChange := rateChangeEffect(premiumRateChange, elasticity, baseConversion)]
  dt[, baseConversion := NULL]
  
  
  ##### RETURN METRICS 
  
  # Create new exposure column
  dt[, newExposure := oldExposure * volumeChange]
  
  # Create columns of written totals for help creating metrics
  dt[, ':='(
    oldWrittenPremium = oldPremium * oldExposure,
    newWrittenPremium = newPremium * newExposure,
    newExpLossRatio = (newPerilClaimCost + otherClaimCost) / newPremium,
    oldWrittenPerilClaimCost = obsPerilClaimCost * oldExposure,
    newWrittenPerilClaimCost = obsPerilClaimCost * newExposure,
    oldWrittenTotalClaimCost = (obsPerilClaimCost + otherClaimCost) * oldExposure,
    newWrittenTotalClaimCost = (obsPerilClaimCost + otherClaimCost) * newExposure
  )]
  
  # Change to a neater column order
  setcolorder(
    dt,
    c(
      "obs",
      "old",
      "new",
      "oldExposure",
      "newExposure",
      "oldRebased",
      "newRebased",
      "intensity",
      "obsPerilClaimCost",
      "oldPerilClaimCost",
      "newPerilClaimCost",
      "otherClaimCost",
      "oldExpLossRatio",
      "newExpLossRatio",
      "oldPremium",
      "newPremium",
      "premiumRateChange",
      "elasticity",
      "volumeChange",
      "oldWrittenPremium",
      "newWrittenPremium",
      "oldWrittenPerilClaimCost",
      "newWrittenPerilClaimCost",
      "oldWrittenTotalClaimCost",
      "newWrittenTotalClaimCost"
    )
  )

  # Create list of metrics to return
  rtnList <- list(
    OldRebasingFactor = oldRebasingFactor,
    NewRebasingFactor = newRebasingFactor,
    ChangeInWrittenPremium = dt[, sum(oldWrittenPremium) / sum(newWrittenPremium)],
    BaseAdjustment = baseChange,
    ChangeInPerilClaimsCost = dt[, sum(newWrittenPerilClaimCost) / sum(oldWrittenPerilClaimCost) - 1],
    ChangeInOverallClaimsCostTotal = dt[, sum(newWrittenTotalClaimCost) / sum(oldWrittenTotalClaimCost) - 1],
    ChangeInOverallClaimsCostPeril = dt[
      ,
      (sum(newWrittenTotalClaimCost) - sum(oldWrittenTotalClaimCost)) / sum(oldWrittenPerilClaimCost)
    ],
    OldPerilOnlyLossRatio = dt[, sum(oldWrittenPerilClaimCost) / sum(oldWrittenPremium)],
    NewPerilOnlyLossRatio = dt[, sum(newWrittenPerilClaimCost) / sum(newWrittenPremium)],
    OldLossRatio = dt[, sum(oldWrittenTotalClaimCost) / sum(oldWrittenPremium)],
    NewLossRatio = dt[, sum(newWrittenTotalClaimCost) / sum(newWrittenPremium)]
  )
  rtnList$ChangeInPerilOnlyLossRatio <- rtnList$NewPerilOnlyLossRatio - rtnList$OldPerilOnlyLossRatio
  rtnList$ChangeInLossRatio <- rtnList$NewLossRatio - rtnList$OldLossRatio
  
  # Warn if premiums have not converged
  if (optimisedBaseChange){
    if (round(rtnList$ChangeInWrittenPremium, digits = 4) != 1){
      warning(
        paste0(
          "Projected premium written in new scenario does not match current scenario.\n",
          "Routine may not have converged on a sensible base rate change.\n",
          "Proceed with caution!"
        )
      )
    }
  }

  # Print results to console
  cat("###############################################################\n")
  cat("New model scenario tested using assumptions provided.\n")
  cat(
    paste0(
      "## Overall premium written is ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInWrittenPremium),
      " of current scenario\n## Base rate adjustment used: ",
      sprintf("%.2f%%", 100 * baseChange),
      ".\n"
    )
  )
  cat("\n")
  cat("###############################################################\n")
  cat("Change in peril-only claims performance\n")
  cat(
    paste0(
      "## Projected change in claims costs for this peril: ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInPerilClaimsCost),
      ".\n"
    )
  )
  cat(
    paste0(
      "## Projected change in peril-only Loss Ratio: ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInPerilOnlyLossRatio),
      ".\n"
    )
  )
  
  cat("\n")
  cat("###############################################################\n")
  cat("Change in overall claims performance\n")
  cat(
    paste0(
      "## Projected change in overall claims cost (total): ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInOverallClaimsCostTotal),
      ".\n"
    )
  )
  cat(
    paste0(
      "## Projected change in overall claims cost (peril): ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInOverallClaimsCostPeril),
      ".\n"
    )
  )
  cat(
    paste0(
      "## Projected change in overall Loss Ratio: ",
      sprintf("%.2f%%", 100 * rtnList$ChangeInLossRatio),
      ".\n"
    )
  )

  if (plotDoubleLift){
    DoubleLiftCurve(
      Observed = dt[, obs],
      Expected_1 = dt[, new],
      Expected_2 = dt[, old],
      Weight = dt[, oldExposure],
      Lower = 0.1,
      Upper = 2,
      Percent = 2,
      Model_1 = "New",
      Model_2 = "Old"
    )
  }
  
  # Add a list of a subset of the input parameters if required
  if(returnParams){
    rtnList$parameters <- parameterList
  }
  
  # Add the data table to the output if required
  if (returnData){
    rtnList$data <- dt
  }
  
  # Return list
  return(rtnList)
}


