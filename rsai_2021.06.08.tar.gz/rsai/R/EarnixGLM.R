setClass("EarnixGLM",representation(
	EarnixFormulaVersion="character",
	EarnixTerms="character"
),contains="glm"
)

#' makeInputVector
#' @description makeInputVector
#' @param terms the formula terms.
#' @export
makeInputVector <- function(terms){
	dataCalls <- vector(mode="expression",length=length(terms))
	for (i in 1:length(terms)) dataCalls[i] <- parse(text=terms[i])
	return(dataCalls)
}


#' fit GLMs using Earnix-style formulas and data
#' 
#' @description \code{fitEarnixGLM} fits a GLM to a specified data set using Earnix-style
#' repeated application rather than R-style vectorised application.
#' 
#' The actual model fit is still done using \code{\link{glm}}.
#' 
#' The coefficients of the internal GLM object are all quoted (because they may
#' be non-syntactic) and preceded by \code{"df.fit$"}
#' @usage fitEarnixGLM(data,terms,response,...)
#' @param data A data frame to fit the model against. This need not contain the
#' response but should contain all the explanatory variables.
#' @param terms A character vector of expressions to use as the terms in the
#' model. Earnix functions can be used here, but they must be in uppercase (for
#' example, an item in \code{terms} could be \code{LOG(x)}, even though there
#' is no function \code{LOG} in . Not all Earnix functions are implemented yet,
#' but most of the common ones are.)
#' @param response A vector of responses.
#' @param ...  Further arguments to pass to \code{glm}.
#' @details The coefficients of the internal GLM object are all quoted (because they may be non-syntactic) and preceded by \code{"df.fit$"}
#'
#' @return An (S4) object of class \code{EarnixGLM}. This extends the standard
#' \code{glm} S3 class, with S4 slots \code{@EarnixFormulaVersion} and
#' \code{@EarnixTerms}. The former contains a formula version of the model
#' suitable for importing into Earnix, and the latter contains the \code{terms}
#' argument as supplied to \code{fitEarnixGLM}.
#' @note The returned slot \code{@EarnixFormulaVersion} may require some
#' editing to make it valid for exporting to Earnix. If the column names in
#' \code{data} match their Earnix variable names and only Earnix functions are
#' used in \code{terms} then the formula should be correct.
#' 
#' If any terms have quotes in them (such as testing for equality to a
#' character constant) these need to be escaped with a backslash, as in the
#' examples.
#' 
#' You may find that this function returns an error but works if copied into the
#' global environment. I haven't the faintest idea why - TB
#' 
#' Using \code{fitEarnixGLM} is significantly slower than using
#' \code{\link{glm}} directly, due to the extra overhead in repeatedly applying
#' the expressions in \code{terms}. In some cases the speed difference can be
#' of the order of ten times. If this is a problem, it is more efficient to use
#' an ordinary call to \code{glm}, and then if desired call
#' \code{\link{EarnixFormulaVersion}} with suitable arguments to produce the
#' formula version for export. This requires that you are able to express
#' \code{terms} in vectorised form (see \code{\link{sapply}} and
#' \code{\link{mapply}}).

#' @author James Lawrence
#' @seealso \code{\link{glm}}.\cr \code{\link{sapply}} and
#' \code{\link{replicate}}, on which the repeated application is based.
#' 
#' @export
#' @examples
#' 
#' ## simple lm 
# #X <- data.frame(a=1:10,b=c(rep("a",5),rep("b",5)),c=rnorm(10))
# #y <- rnorm(10,1+X$a/10 + as.integer(X$b) + X$c)
# #terms <- c("a","b==\"b\"","c")
# #fitEarnixGLM(X,terms,y,family=gaussian)
#' 
fitEarnixGLM <- function(data,terms,response,...){
	if(!inherits(data,"data.frame")) stop("'data' should be a data frame")
	if(dim(data)[1] != length(response)) stop("length of response does not match number of rows in 'data'")
	applyInputExpr <- makeInputVector(terms)
	## can we use mapply?
	##data.lists <- apply(data,1,as.list)
	data.lists <- lapply(1:(dim(data)[1]),function(i) as.list(data[i,]))
	ft <- function(i) sapply(applyInputExpr,eval,envir=data.lists[[i]])
	df.fit <- data.frame(t(sapply(1:(dim(data)[1]),ft)))
	rm(data.lists)
	colnames(df.fit) <- gsub("\\\"","\"",terms)
	inputFormula <- formula(paste0(deparse(substitute(response))," ~ ",paste0("df.fit$\"",gsub("\"","\\\\\"",names(df.fit)),"\"",collapse="+")))
	print (inputFormula)
	model <- as(glm(inputFormula,...),"EarnixGLM")
	names(model$coefficients) <- gsub("df.fit[$]\\\"([[:print:]]*?[^\\])\\\"","\\1",names(model$coefficients))
	names(model$coefficients) <- gsub("\\\\\\\"","\"",names(model$coefficients))
	names(model$coefficients) <- gsub("df.fit[$]","",names(model$coefficients))
	model@EarnixTerms <- terms
	model@EarnixFormulaVersion <- EarnixFormulaVersion(model,nocat=TRUE)
	return(model)
}


