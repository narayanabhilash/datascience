# unpack pairings and triples

unpacktriple <- function (triplet){
  pairs <- combinations(length(triplet), 2, triplet)
  return(lapply(1:nrow(pairs), function (x) sort(pairs[x,])))
  
}

# find a name in a list
inhere <- function(element, List = assignments) {
  which(!is.na(lapply(List, function(x) match(element, x))))
}

# swap 2 people in a list
swapPair <- function (assignmentList, p1, p2){
  # find p1 and p2 in the assignment:
  p1in <- inhere(p1, assignmentList)
  p2in <- inhere(p2, assignmentList)
  if(p1in == p2in) return(assignmentList)
  assignmentList[[p1in]] <- sort(c(p2, setdiff(assignmentList[[p1in]], p1)))
  assignmentList[[p2in]] <- sort(c(p1, setdiff(assignmentList[[p2in]], p2)))
  return(assignmentList)
}
# swapPair(assignments, "a", "z")

#unpacktriple(letters[1:5])


# function to assign roulettes

coffeeRoulette <- function(
  names,
  existingPairings, #assume these are lists... # because that's what the output will be
  seeed = 1234L,
  showevery = 0L
 ){
  set.seed(seeed)
 # start with an initial setup 
  Twos <- (-1 * length(names)) %% 3
  Threes <- (length(names) - Twos * 2) / 3
  unassigned <- names
  assignments <- list()
  if(Twos){
    for (i in 1:Twos){
      assignments[[i]] <- sort(sample(unassigned, 2, F))
      unassigned <- setdiff(unassigned, assignments[[i]])
    }
  }
  for (i in (Twos + 1):(Twos + Threes)){
    assignments[[i]] <- sort(sample(unassigned, 3, F))
    unassigned <- setdiff(unassigned, assignments[[i]])
  }
  # ok so now we have some assignments, how good are they? 
 cat("initial assignments\n")
 print((assignments))
  # Existing pairings is in the list
  # want a weighting so that those who are hard to assign don't get swapped around so much
  weights <- rep(1, length(names))
  for (i in seq_along(names)){
    weights[i]<- pmax(0.1, 0.9 ^ length(grep(names[i], existingPairings)))
  }
  
  # want to ensure everyone has someone new to chat to
  swapmax = 1000 #knownElephantInCairo
  best = 0
  counter = 0
  
  # start off by creating a list of who we can pair people with:
  canpair <- lapply(
    names,
    function (x) setdiff(names, unique(unlist(existingPairings[inhere(x, existingPairings)]
    ))))
  cantmatch = which(lapply(canpair, length) == 0)
  while (counter < swapmax & best == 0){
    counter <- counter + 1
   # print((assignments))
    for (i in seq_along(names)){
      nm <- names[i]
    #  print(nm)
      # can we match?
      if(i %in% cantmatch) next()
      # otherwise, are they with someone new already?
      best = 1
      group <- assignments[[inhere(nm, assignments)]]
      members <- unique(unlist(group))
      newpairs = length(intersect(members, unlist(canpair[i])))
      #make an adjustment here for swapping those who know one of
      # their triplet but not both...
      oldpairs <- length(members) - newpairs - 1
      # so if oldpairs > 0, we might be able to improve someone's lot
      # likelihood of staying put:
      # - goes down with oldpairs and length of canpair[i]
      # goes up with counter and number of members to match
      ok <- (counter / swapmax) ^ (
        oldpairs / length(names) * length(unlist(canpair[i])) * 3)
            if (newpairs > 0 & ok > runif(1)) next() 
      best = 0 
      # could change best etc. to try to do better than zero for a while...
      # then have to consider with whom swap is possible in the lines below
      break()
    }
    # someone is not well assigned: swap them at random
    # probably with someone in another group 
    # who they don't currently know
    # ideally someone we haven't previously checked this iteration
    
    if(!(best)){
     # cat ("person = \n", nm, "\n index =\n", i)
      #print((assignments))
      goodswaps <- setdiff(
        assignments[unique(unlist(sapply(unlist(canpair[i]), function (x) inhere(x, List = assignments))))],
        canpair[i]) 
      swapwith <- sample(
        names, 
        1, 
        prob = (
          weights *
          sapply(seq_along(names), function(x) {! names[x] %in% members} *
                   0.4 ^ (x < i)) *
          length(names) ^ sapply(names, function(x) x %in% goodswaps)  
        )
      )
    if(equals(counter %% showevery, 0)) 
      cat(counter," \n swapping ", nm, " with", swapwith, "\n")
    
    assignments <- swapPair(
      assignments,
      nm,
      swapwith
    )
    }
  }
  # add new pairings to the existing pairings
  for (nm in assignments){
    existingPairings <- c(existingPairings, unpacktriple(nm))
  }
  
  return (list(
  newpairings = assignments,
  existingPairings = existingPairings,
  swaps = counter
  ))
}

# names = c(letters, LETTERS)
# existingPairings <- list()
# for (j in 1:1000){
#   existingPairings[[j]] <- sort(sample(names, 2, F))
# }
# tryThis <- coffeeRoulette(names, existingPairings = existingPairings)
