#' Edit Factors and Levels
#' @param EMBlemModels character or data.table. The file path and name of the CSV that contains all the models, or a data.table. For more details of CSV format see \code{\link{data_EMBlemModels}}.
#' @param FacsToCollapse character or data.table. The file path and name of the CSV that contains the factors you would collapse and level to use for collapsing, or a data.table. For more details of CSV format see \code{\link{data_FacsToCollapse}}.
#' @param FacsToDelete character or data.table. The file path and name of the CSV that contains the factors you would like to delete, or a data.table. For more details of CSV format see \code{\link{data_FacsToDelete}}.
#' @param ChildLevsToAdd character or data.table. The file path and name of the CSV that contains the (child) levels you would like to add, or a data.table. For more details of CSV format see \code{\link{data_ChildLevsToAdd}}.
#' @param BaseLevsToAdd character or data.table. The file path and name of the CSV that contains the (base) levels you would like to add, or a data.table. For more details of CSV format see \code{\link{data_BaseLevsToAdd}}.
#' @param LevsToDelete character or data.table. The file path and name of the CSV that contains the levels you would like to delete, or a data.table. For more details of CSV format see \code{\link{data_LevsToDelete}}.
#' @param LevsToRename character or data.table. The file path and name of the CSV that contains the levels you would like to rename, or a data.table. For more details of CSV format see \code{\link{data_LevsToRename}}.
#' @param FacsToRename character or data.table. The file path and name of the CSV that contains the factors you would like to rename, or a data.table. For more details of CSV format see \code{\link{data_FacsToRename}}.
#' @param CombinedLoc character. The location of the folder where you want your combined models CSV output to be.
#' @param IndividualLoc character. The location of the folder where you want your indivdual model CSV's output to be.
#' @param EMBglm logical. Would you like the outputs to be in EMBmodel format.
#' @return A set of CSV's, one for each peril, with the edited factors and levels.
#' @export

CSVmodelNewSquiggly <- function(EMBlemModels, FacsToCollapse = NULL, FacsToDelete = NULL, ChildLevsToAdd = NULL,
                                BaseLevsToAdd = NULL, LevsToDelete = NULL, LevsToRename = NULL, FacsToRename = NULL,
                                CombinedLoc = NULL, IndividualLoc = NULL, EMBglm = FALSE){

  if (!exists("EMBlemModels")){
    stop(paste0("The combined model input does not exists."))
  }

  if(!is.data.table(EMBlemModels)){
    EMBlemModels <- fread(EMBlemModels)
  }

  if(!is.null(FacsToCollapse)){
    if(!is.data.table(FacsToCollapse)){
      FacsToCollapse <- fread(FacsToCollapse, colClasses = "character", sep = ",")
    }

    if(nrow(FacsToCollapse) > 0){
      EMBlemModels <- .EMBmodelFacCollapse(EMBlemModels, FacsToCollapse)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else {

    EMBlemModels <- EMBlemModels

  }

  if(!is.null(FacsToDelete)){
    if(!is.data.table(FacsToDelete)){
      FacsToDelete <- fread(FacsToDelete, colClasses = "character", sep = ",")
    }

    if(nrow(FacsToDelete) > 0){
      EMBlemModels <- .EMBmodelFacDelete(EMBlemModels, FacsToDelete)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else {

    EMBlemModels <- EMBlemModels

  }

  if(!is.null(ChildLevsToAdd)){
    if(!is.data.table(ChildLevsToAdd)){
      ChildLevsToAdd <- fread(ChildLevsToAdd, colClasses = "character")
    }

    if(nrow(ChildLevsToAdd) > 0){
      EMBlemModels <- .EMBmodelAddChildLev(EMBlemModels, ChildLevsToAdd)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else {

    EMBlemModels <- EMBlemModels

  }

  if(!is.null(BaseLevsToAdd)){
    if(!is.data.table(BaseLevsToAdd)){
      BaseLevsToAdd <- fread(BaseLevsToAdd, colClasses = "character")
    }

    if(nrow(BaseLevsToAdd) > 0){
      EMBlemModels <- .EMBmodelAddBaseLev(EMBlemModels, BaseLevsToAdd)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else {

    EMBlemModels <- EMBlemModels

  }

  if(!is.null(LevsToDelete)){
    if(!is.data.table(LevsToDelete)){
      LevsToDelete <- fread(LevsToDelete, colClasses = "character")
    }

    if(nrow(LevsToDelete) > 0){
      EMBlemModels <- .EMBmodelLevDelete(EMBlemModels, LevsToDelete)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else{

    EMBlemModels <- EMBlemModels

  }

  if(!is.null(LevsToRename)){
    if(!is.data.table(LevsToRename)){
      LevsToRename <- fread(LevsToRename, colClasses = "character")
    }

    if(nrow(LevsToRename) > 0){
      EMBlemModels <- .EMBmodelLevRename(EMBlemModels, LevsToRename)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else{

    EMBlemModels <- EMBlemModels
  }

  if(!is.null(FacsToRename)){
    if(!is.data.table(FacsToRename)){
      FacsToRename <- fread(FacsToRename, colClasses = "character")
    }

    if(nrow(FacsToRename) > 0){
      EMBlemModels <- .EMBmodelFacRename(EMBlemModels, FacsToRename)
    } else {
      EMBlemModels <- EMBlemModels
    }

  } else {

    EMBlemModels <- EMBlemModels

  }

  ################ Rearrangment required for Earnix ################

  multi.mixedorder <- function(..., na.last = TRUE, decreasing = FALSE){
    do.call(order, c(
      lapply(as.list(...), function(l){
        if(is.character(l)){
          factor(l, levels=mixedsort(unique(l)))
        } else {
          l
        }
      }),
      list(na.last = na.last, decreasing = decreasing)
    ))
  }

  EMBNames <- names(EMBlemModels)
  Facs <- EMBNames[grep("^Factor", EMBNames, ignore.case = TRUE)]
  Lvls <- EMBNames[grep("^Level", EMBNames, ignore.case = TRUE)]

  # Pull out "unknown" levels, these will be added back on later
  UnkTab <- EMBlemModels[0,]
  for(i in 1:length(Lvls)){
    UnkTab_i <- EMBlemModels[get(Lvls[i]) == "Unknown" | get(Lvls[i]) == "Otherwise"]
    UnkTab <- rbind(UnkTab, UnkTab_i)
    UnkTab <- unique(UnkTab)
    rm(UnkTab_i)
  }

  for(i in 1:length(Lvls)){
    EMBlemModels <- EMBlemModels[get(Lvls[i]) != "Unknown" & get(Lvls[i]) != "Otherwise"]
  }

  # reordering using mixed sort
  EMBlemModels <- EMBlemModels[multi.mixedorder(EMBlemModels[, c(Facs, Lvls), with = FALSE]),]

  EMBlemModels <- rbind(EMBlemModels, UnkTab)

  setkeyv(EMBlemModels, Facs)

  EMBlemModel <- as.EMBglm(EMBlemModels)

  ################################################################

  if (EMBglm){
    EMBlemModels <- as.EMBglm(EMBlemModels)
  } else {
    setnames(EMBlemModels, names(EMBlemModels), gsub("Value", "", names(EMBlemModels)))
  }

  if (!is.null(CombinedLoc)){
	fwrite(EMBlemModels,
	file = .fn_CreateNonExistingDirectory(paste0(CombinedLoc, "/CombinedModels.csv")))
  }

  if (!is.null(IndividualLoc)){
    CSVmodelUnmerge(EMBlemModels, IndividualLoc)
  }

  return(EMBlemModels)

}
