

#' Create a file consisting of a subsample of columns from a large file
#'
#' @param infile the file name (not an actual connection) you wish to take a subsample 
#' @param outfile the name of the file you wish to create (will probably end in ".csv")
#' @param DD optional - if you have a data dictionary of \code{"infile"} this will apply known column types when reading it in
#' @param chunkSize the number of rows of \code{"infile"} which are read in within each internal loop of the function.  
#' @param columns a string of the column names you want to pass to \code{"outfile"}
#' @param \dots any optional parameters for use in \code{"write.table"}
#'
#' @return null (the outfile doesn't stay in R, so you need to read it in again.)
#' @export 
#'
#' @examples 
#'df.testDownsample <- data.frame(
#'  policyNumber=sample(1:500, 1000, TRUE),
#'  claimOne=rpois(1000, 0.07),
#'  claimTwo=rpois(1000, 0.03)
#')
#'## write it to disk
#'write.csv(
#'  df.testDownsample,
#'  file="testDownsample.csv",
#'  row.names=FALSE)
#'
#'rm (df.testDownsample)
#'
#'ColSub(
#'  infile="testDownsample.csv",
#'  outfile="downsampledTest.csv",
#'  chunkSize=300L,
#'  columns=c("policyNumber", "claimOne")
#')
#'
#'unlink("testDownsample.csv")
#'unlink("downsampledTest.csv")

ColSub <-
  function (infile,
            outfile,
            DD = NULL,
            chunkSize = 5000L,
            columns = list(),
                       ...)
  {
    if (is(infile, "connection"))
      stop("'infile' should be a file name, not an actual connection")
    if (is(outfile, "connection"))
      stop("'outfile' should be a file name, not an actual connection")
      
    if (length (columns) == 0)
      stop ("choose some columns to keep.")
    
    tableHeader <- colnames(read.csv(infile, nrows = 1, ...))

    for (nm in columns) {
      if (!(nm %in% tableHeader))
        stop(nm, " not present in the data")
    }
    
    fin <- gzfile(infile, "rt")
    fout <- file (outfile, "wt")
    nlines <-0
    header<-TRUE
    on.exit({
      close(fin)
      close (fout)
          })
    
    # and now, get some data dictionary
    
    if (!is.null(DD)) {
      ddCstring <- DD@colClasses
       }
    
    else {
      ddCstring <- "character"
    }
   
      df.tmp <-
        read.csv(
          fin,
          nrows = chunkSize,
          header = TRUE,
          stringsAsFactors = FALSE,
          colClasses = ddCstring
         # have to read them all in. Sigh
        )
      
      colsToKeep<- match (columns,colnames (df.tmp))
    
      while (!inherits(df.tmp,"try-error")) {   
      
            write.table(
            df.tmp[,colsToKeep ],
            fout,
            col.names = header,
            row.names = FALSE,
            sep = ",",
            ...
          )
        nlines <- nlines + nrow(df.tmp)
        cat(nlines," lines written to file\n")
        header <- FALSE
        df.tmp <- try(read.csv(fin,stringsAsFactors=FALSE,nrow=chunkSize,header = FALSE,...),silent =TRUE)
   }
    invisible(NULL)

}



