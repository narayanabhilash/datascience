#####  quickSpatialTransform  #####
#' Function to quickly transform location data between two coordinate reference systems.
#' @description 
#' This function can quickly transform location data between two coordinate reference systems. By default it assumes that you
#' are transforming from longitude and latitude to the Irish grid (https://spatialreference.org/ref/epsg/tm75-irish-grid/).
#' You can change this to a CRS applicable to the UK or Sweden, by changing the `country` argument, or to any CRS you want
#' by changing the `CRSOut` argument (which will override the country). You can also change the `CRSIn` argument to the CRS
#' that fits your data if it isn't longitude and latitude.
#' To find the CRS you want, go to https://spatialreference.org, look up the coordinate reference system you need (for example,
#' this is the page for standard longitude and latitude https://spatialreference.org/ref/epsg/wgs-84/) and click on the `Proj4`
#' link. This will give you something like "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs", which you can copy and paste into
#' your script as a character.
#' @usage quickSpatialTransform(
#'   x,
#'   y,
#'   CRSIn = NULL,
#'   CRSOut = NULL,
#'   ignoreOutOfRange = FALSE,
#'   country = "Ireland"
#' )
#' @param x The input x (East/West) coordinates as a numeric vector.
#' @param y The input y (North/South) coordinates as a numeric vector.
#' @param CRSIn A coordinate reference system to use to interpret the input. Leave NULL to use Longitude/Latitude.
#' @param CRSOut A coordinate reference system to use for creating the output. Leave NULL to use Eastings/Northings.
#' @param country Should be one of "Ireland", "UK", "Sweden", "UK_ONS". If `CRSOut` is specified, country will be ignored.
#' The reference systems used for the output will be as follows:
#' Ireland - Irish grid - https://spatialreference.org/ref/epsg/tm75-irish-grid/
#' UK - UTM zone 30 (UK) - https://spatialreference.org/ref/epsg/ed50-utm-zone-30n/
#' Sweden - SWEREF 99 - https://spatialreference.org/ref/epsg/sweref99-tm/
#' UK_ONS - UK Ordinance Survey National Grid - https://spatialreference.org/ref/epsg/osgb-1936-british-national-grid/
#' @param ignoreOutOfRange if CRSIn is NULL (default) the function expects long / lat data. 
#' Setting \code{ignoreOutOfRange} to \code{TRUE} means you will get NAs returned for data out of the possible long/ lat range, 
#' rather than an error.
#' This argument is ignored if CRSIn is specified, so you'll get a less helpful error message
#' if you haven't cleaned your data properly.
#' @return A data table containing 2 columns, x and y. These are the new coordinates.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @export

quickSpatialTransform <- function(
  x,
  y,
  CRSIn = NULL,
  CRSOut = NULL,
  ignoreOutOfRange = FALSE,
  country = "Ireland") {
  
  # Check x and y
  if (! (is.vector(x) & is.vector(y))) stop("x and y must be vectors.")
  if (! (is.numeric(x) & is.numeric(y))) stop("x and y must be numeric.")
  if (length(x) != length(y)) stop("x and y must be the same length.")
  
  # Check CRSIn
  if (is.null(CRSIn)){
    CRSIn <- "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"
    # Check for out-of-range x and y
    if (max(abs(x), na.rm=TRUE) > 180 | max(abs(y), na.rm=TRUE) > 90){
      if (ignoreOutOfRange){
        x[abs(x) > 180] <- NA
        y[(abs(y) > 90)] <- NA
      } else stop(
        "Some value of x and/or y is out of range for long/lat. If these are 'missing' set ignoreOutOfRange to TRUE.")
    }
  } else{
    if (! (is.vector(CRSIn) & is.character(CRSIn) & length(CRSIn)==1)) stop("CRSIn must be a character vector of length 1")
  }
  CRSCheck1 <- try(CRS(CRSIn, doCheckCRSArgs=TRUE))
  if ("try-error" %in% class(CRSCheck1)) stop("CRSIn is not a valid coordinate reference system")
  
  # Check CRSOut and zone
  if (! is.null(CRSOut)){
    if (! (is.vector(CRSOut) & is.character(CRSOut) & length(CRSOut)==1)) stop("CRSOut must be a character vector of length 1.")
    CRSCheck2 <- try(CRS(CRSOut, doCheckCRSArgs=TRUE))
    if ("try-error" %in% class(CRSCheck2)) stop("CRSOut is not a valid coordinate reference system.")
    message("CRSOut is specified, so country will be ignored")
  } else{
    if (! (is.vector(country) & is.character(country) & length(country) == 1)){
      stop("country must be a character vector of length 1")
    }
    if (country == "Ireland"){
      CRSOut <- "+init=epsg:29903"
    } else if (country == "UK"){
      CRSOut <- "+init=epsg:23030"
    } else if (country == "Sweden"){
      CRSOut <- "+init=epsg:3006"
    } else if (country == "UK_ONS"){
      CRSOut <- "+init=epsg:27700"
    } else stop("country must be one of: Ireland, UK, Sweden, UK_ONS.")
  }
  
  # Put coordinates into table
  xy <- data.table(rowNum = 1:length(x), x = x, y = y)
  
  # Filter out missing values
  xy2 <- xy[! (is.na(x) | is.na(y))]
  
  # Create initial coordinates
  coordinates(xy2) <- c("x", "y")
  proj4string(xy2) <- CRS(CRSIn)
  
  # Run spTransform
  res <- as.data.table(spTransform(xy2, CRS(CRSOut)))
  
  # Merge
  xy <- merge(xy[, .(rowNum)], res, by="rowNum", all.x=TRUE, sort=TRUE)

  # Return output
  return(xy[, .(x, y)])
}