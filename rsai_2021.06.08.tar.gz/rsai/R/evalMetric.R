#####  evalMetric  #####
#' Function to calculate an evaluation metric.
#' @description This function calculates a model evaluation metric from a number of possible supported metrics.
#' You must supply the function with observations and predictions and optionally weights and it returns the number.
#' @usage evalMetric(y, y_hat, eval_metric, w=NULL, p=1.5)
#' @param y A numeric vector or matrix of observations.
#' @param y_hat A numeric vector or matrix of predictions for y, with the same length and/or dimensions as y.
#' @param eval_metric The evaluation metric to calculate. The choices are listed below:
#' \describe{
#'   \item{rmse}{Root mean square error.}
#'   \item{mae}{Mean absolute error.}
#'   \item{logloss}{Negative log-likelihood for binary classification.}
#'   \item{error}{Binary classification error rate. It is calculated as #(wrong cases)/#(all cases).
#'   For the predictions, the evaluation will regard the instances with prediction value larger than 0.5 as
#'   positive instances, and the others as negative instances.}
#'   \item{error@t}{A different than 0.5 binary classification threshold value could be specified 
#'   by providing a numerical value through 't'}
#'   \item{auc}{Area under the curve for ranking evaluation.}
#'   \item{poisson-nloglik}{Negative log-likelihood for Poisson regression}
#'   \item{poisson-deviance}{Residual deviance log-likelihood for Poisson regression}
#'   \item{gamma-nloglik}{Negative log-likelihood for Gamma regression}
#'   \item{gamma-deviance}{Residual deviance log-likelihood for Gamma regression}
#'   \item{tweedie-nloglik}{Negative log-likelihood for Tweedie regression}
#'   \item{tweedie-deviance}{Residual deviance log-likelihood for Tweedie regression}
#' }
#' @param w A vector of weights. If used, should match the shape of the observations and predictions.
#' @param p Tweedie power parameter. Should be between 1 and 2. Ignored except for tweedie-nloglik and tweedie-deviance.
#' @return a number.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # # Gamma example
#' # set.seed(1984)
#' # y_hat <- rnorm(1000, 1000, 200)
#' # w <- runif(1000)
#' # y <- rgamma(1000, 1, 1/y_hat)
#' # 
#' # evalMetric(y, y_hat, "gamma-nloglik", w=w)
#' # evalMetric(y, y_hat, "gamma-deviance", w=w)
#' # evalMetric(y, y_hat, "tweedie-deviance", w=w, p=1.9999999999)
#' # evalMetric(y, y_hat, "auc", w=w)
#' # 
#' # 
#' # # Logistic example
#' # set.seed(1984)
#' # y_hat <- runif(1000)
#' # y <- rbinom(1000, 1, y_hat)
#' # w <- runif(1000, 1, 5)
#' # 
#' # evalMetric(y, y_hat, "logloss", w=w)
#' # evalMetric(y, y_hat, "auc", w=w)
#' # evalMetric(y, y_hat, "error", w=w)
#' # evalMetric(y, y_hat, "error@0.7", w=w)
#' # 
#' # 
#' # # Poisson example
#' # set.seed(1984)
#' # y_hat <- runif(1000, 0, 2)
#' # w <- runif(1000)
#' # y <- rpois(1000, y_hat*w)/w
#' # 
#' # evalMetric(y, y_hat, "poisson-nloglik", w=w)
#' # evalMetric(y, y_hat, "poisson-deviance", w=w)
#' # evalMetric(y, y_hat, "tweedie-deviance", w=w, p=1.0000000001)
#' # evalMetric(y, y_hat, "auc", w=w)
#' # 
#' # 
#' # # Normal example
#' # set.seed(1984)
#' # y_hat <- rnorm(1000)
#' # y <- rnorm(1000, y_hat)
#' # w <- runif(1000)
#' # 
#' # evalMetric(y, y_hat, "mae", w=w)
#' # evalMetric(y, y_hat, "rmse", w=w)
#' @export

evalMetric <- function(y, y_hat, eval_metric, w=NULL, p=1.5){
  
  # Some evaluation metrics use the @ sign for extra parameter
  # Find where the @ sign is, if it exists
  findAt <- regexpr("@", eval_metric)
  if(findAt>-1){
    # Find the base evaluation metric
    baseEvalMetric <- substr(eval_metric, 1, findAt-1)
    # If base metric not known, throw error
    if(!baseEvalMetric %in% c("error", "map", "ndcg")){
      validEvalMetrics <- c("rmse",
                            "mae",
                            "logloss",
                            "error",
                            "error@t",
                            "mlogloss",
                            "auc",
                            "ndcg",
                            "map",
                            "ndcg@n",
                            "map@n",
                            "ndcg-",
                            "map-",
                            "ndcg@n-",
                            "map@n-",
                            "poisson-nloglik",
                            "poisson-deviance",
                            "cox-nloglik",
                            "cox-deviance",
                            "gamma-nloglik",
                            "gamma-deviance",
                            "tweedie-nloglik",
                            "tweedie-deviance")
      
      stop(paste0("Valid evaluation metrics are: ",
                  paste0(validEvalMetrics, collapse=", "),
                  ".\nHowever, not all of these are supported yet."))
    }
    # Find the remainder after the @ sign
    remainder <- substr(eval_metric, findAt+1, nchar(eval_metric))
    # Some metrics have a minus sign on the end which changes the behaviour
    # Move minus sign back onto base metric if it exists
    if(substr(remainder, nchar(remainder), nchar(remainder))=="-"){
      baseEvalMetric <- paste0(baseEvalMetric, "-")
      remainder <- substr(remainder, 1, nchar(remainder)-1)
    }
  } else{
    # If no @ sign base evaluation metric is just what was specified
    baseEvalMetric <- eval_metric
    remainder <- NULL
  }
  
  ###### Now run through cases in turn ###### 
  ##### rmse #####
  if(baseEvalMetric=="rmse"){
    
    if(is.null(w)){
      return(sqrt(mean((y-y_hat)^2)))
    } else return(sqrt(weighted.mean((y-y_hat)^2, w)))
    
    
  ##### mae #####
  } else if(baseEvalMetric=="mae"){
    
    if(is.null(w)){
      return(mean(abs(y-y_hat)))
    } else return(weighted.mean(abs(y-y_hat), w))
    
    
  ##### logloss #####
  } else if(baseEvalMetric=="logloss"){

    # Predictions that are *exactly* 1 or 0 and are wrong *should* result in an infinite result.
    inf <- any((y_hat==1 & y<1)|(y_hat==0 & y>0))
    if(inf) return(Inf)

    # For all other cases, the eps and pmax function deal with predictions very close to 0 or 1  
    eps <- .Machine$double.xmin
    logLoss <- -y*log(pmax(y_hat, eps)) - (1-y)*log(pmax(1-y_hat, eps))

    # Return
    if(is.null(w)){
      return(mean(logLoss))
    } else return(weighted.mean(logLoss, w))
    
    
  ##### error #####
  } else if(baseEvalMetric=="error"){
    if(is.null(remainder)) t <- 0.5 else{
      t <- as.numeric(remainder)
      if(is.na(t)) stop("For 'error@t', t needs to be interpretable as a number.")
      if(t <= 0 | t >= 1) stop("For 'error@t', t needs to be between zero and one.")
    }
    
    if(is.null(w)){
      return(1-mean((y>t)*(y_hat>t) + (y<=t)*(y_hat<=t)))
    } else return(1-weighted.mean((y>t)*(y_hat>t) + (y<=t)*(y_hat<=t), w))
    

  ##### mlogloss #####
  } else if(baseEvalMetric=="mlogloss"){
    stop(paste0("Unfortunately, ", eval_metric, " is not supported currently."))
    
    
  ##### auc #####
  } else if(baseEvalMetric=="auc"){
    
    return(rocAUC(y, y_hat, w))

  ##### ndcg #####
  } else if(baseEvalMetric %in% c("ndcg", "ndcg-")){
    if(!is.null(remainder)){
      n <- as.numeric(remainder)
      if(is.na(n)){
        if(baseEvalMetric=="ndcg"){
          stop("For 'ndcg@n', n must be an integer.")
        } else stop("For 'ndcg@n-', n must be an integer.")
      }
      if(as.integer(n) != n){
        if(baseEvalMetric=="ndcg"){
          stop("For 'ndcg@n', n must be an integer.")
        } else stop("For 'ndcg@n-', n must be an integer.")
      }
    }
    stop(paste0("Unfortunately, ", eval_metric, " is not supported currently."))
    
    
  ##### map #####
  } else if(baseEvalMetric %in% c("map", "map-")){
    if(!is.null(remainder)){
      n <- as.numeric(remainder)
      if(is.na(n)){
        if(baseEvalMetric=="map"){
          stop("For 'map@n', n must be an integer.")
        } else stop("For 'map@n-', n must be an integer.")
      }
      if(as.integer(n) != n){
        if(baseEvalMetric=="map"){
          stop("For 'map@n', n must be an integer.")
        } else stop("For 'map@n-', n must be an integer.")
      }
    }
    stop(paste0("Unfortunately, ", eval_metric, " is not supported currently."))
    
    
  ##### poisson-nloglik #####
  } else if(baseEvalMetric=="poisson-nloglik"){
    
    # Fix for very small values
    eps <- .Machine$double.xmin

    # Negative log-liklihood
    nloglik <- y_hat + lgamma(y+1) - y*log(pmax(y_hat, eps))

    # Return
    if(is.null(w)){
      return(mean(nloglik))
    } else return(weighted.mean(nloglik, w))
    
    
  ##### poisson-deviance #####
  } else if(baseEvalMetric=="poisson-deviance"){
    
    # Fix for very small values
    eps <- .Machine$double.xmin

    # Deviance
    devs <- 2*(y*log(pmax(y, eps)) - y*log(pmax(y_hat, eps)) - y + y_hat)
    
    # Return
    if(is.null(w)){
      return(mean(devs))
    } else return(weighted.mean(devs, w))
  

  ##### gamma-nloglik #####
  } else if(baseEvalMetric=="gamma-nloglik"){
    
    # Prediction should be strictly positive, or the result *should* by infinite
    inf <- any(y_hat<=0)
    if(inf) return(Inf)
    
    # Fix for very small values
    eps <- .Machine$double.xmin
    y_hat <- pmax(y_hat, eps)

    # Negative log-liklihood
    nloglik <- pmin(y/y_hat, .Machine$double.xmax) + log(y_hat)

    # Return
    if(is.null(w)){
      return(mean(nloglik))
    } else return(weighted.mean(nloglik, w))
    
    
    ##### gamma-deviance #####
  } else if(baseEvalMetric=="gamma-deviance"){
    
    # Prediction should be strictly positive, or the result *should* by infinite
    inf <- any(y_hat<=0)
    if(inf) return(Inf)
    
    # Fix for very small values
    eps <- .Machine$double.xmin
    y_hat <- pmax(y_hat, eps)
    
    # deviance
    devs <- 2*(pmin(y/y_hat, .Machine$double.xmax) - 1 + log(y_hat) - log(y))
    
    # Return
    if(is.null(w)){
      return(mean(devs))
    } else return(weighted.mean(devs, w))
    
    
  ##### cox-nloglik #####
  } else if(baseEvalMetric=="cox-nloglik"){
    stop(paste0("Unfortunately, ", eval_metric, " is not supported currently."))
    
    
  ##### cox-deviance #####
  } else if(baseEvalMetric=="cox-deviance"){
    stop(paste0("Unfortunately, ", eval_metric, " is not supported currently."))
    
    
  ##### tweedie-nloglik #####
  } else if(baseEvalMetric=="tweedie-nloglik"){
    # Check tweedie power parameter
    if(p<=1 | p>=2) stop("p should be between 1 and 2")

    # Fix for very small values
    eps <- .Machine$double.xmin

    # Negative log-liklihood
    nloglik <- (y_hat^(2-p))/(2-p) - (y*pmax(y_hat, eps)^(1-p))/(1-p)
    
    # Return
    if(is.null(w)){
      return(mean(nloglik))
    } else return(weighted.mean(nloglik, w))
    
    ##### tweedie-deviance #####
  } else if(baseEvalMetric=="tweedie-deviance"){
    # Check tweedie power parameter
    if(p<=1 | p>=2) stop("p should be between 1 and 2")
    
    # Fix for very small values
    eps <- .Machine$double.xmin

    # Deviance    
    devs <- 2*(y*(pmax(y, eps)^(1-p) - pmax(y_hat, eps)^(1-p))/(1-p) - (y^(2-p) - y_hat^(2-p))/(2-p))
    
    # Return
    if(is.null(w)){
      return(mean(devs))
    } else return(weighted.mean(devs, w))
    
  } else{
    # If not a recognised metric, throw an error.
    validEvalMetrics <- c("rmse",
                          "mae",
                          "logloss",
                          "error",
                          "error@t",
                          "mlogloss",
                          "auc",
                          "ndcg",
                          "map",
                          "ndcg@n",
                          "map@n",
                          "ndcg-",
                          "map-",
                          "ndcg@n-",
                          "map@n-",
                          "poisson-nloglik",
                          "poisson-deviance",
                          "cox-nloglik",
                          "cox-deviance",
                          "gamma-nloglik",
                          "gamma-deviance",
                          "tweedie-nloglik",
                          "tweedie-deviance")
    
    stop(paste0("Valid evaluation metrics are: ",
                paste0(validEvalMetrics, collapse=", "),
                ".\nHowever, not all of these are supported yet."))
  }
}