#' Input Model for CSVmodelNewSquiggly
#'
#' This is the input model for CSVmodelNewSquiggly call. It comprises of factors,
#'  levels and multipliers for each model. This example dataset is the D21 dataset
#'  with some alterations.
#'
#' @format A data table with 444 rows and 22 variables:
#' \describe{
#'   \item{Factor1}{Model factors}
#'   \item{Level1}{Level of Factor}
#'   \item{ValueD21_ALL_B_COASTAL_POSTCODE, etc.}{Multipliers for corresponding model}
#'   ...
#' }
"data_EMBlemModels"

#' The Factors to Collapse input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the factors that will be collapsed out of a model when 
#' using a CSVmodelNewSquiggly call. The 
#' Old Levels and Weights columns are used to define the weights that will be used when
#' collapsing the factor out of the model.
#'
#' @format A data table with 8 rows and 3 variables:
#' \describe{
#'   \item{Old Factor}{Factors that will be collapsed out of the model}
#'   \item{Old Level}{Level to use for collapsing}
#'   \item{Weight}{Weight to use for collapsing}
#' }
"data_FacsToCollapse"

#' The Factors to Delete input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the factors to delete from the model when
#' using CSVmodelNewSquiggly call. It comprises of Old Factors only.
#'
#' @format A data table with 2 rows and 1 variables:
#' \describe{
#'   \item{Old Factor}{Factors to delete}
#' }
"data_FacsToDelete"

#' The Child Levels to Add input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the new child levels to be added to the model when
#' using CSVmodelNewSquiggly call. It comprises of Old Factors, Old Parent Levels and
#'  New Child Levels
#'
#' @format A data table with 20 rows and 3 variables:
#' \describe{
#'   \item{Old Factor}{Factors that will have a new child level}
#'   \item{Old Parent Level}{Level to replicate when creating new child level}
#'   \item{Old Child Level}{Name of the new child level that will be created}
#' }
"data_ChildLevsToAdd"

#' The Base Levels to Add input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the new base levels to be added to the model when
#' using CSVmodelNewSquiggly call. Factors and Levels listed in this file will be
#' given the multiplier 1 in each model. This file comprises of Old Factors and New Levels.
#'
#' @format A data table with 9 rows and 2 variables:
#' \describe{
#'   \item{Old Factor}{Factors that will have a new base level}
#'   \item{New Level}{The new base level to add}
#' }
"data_BaseLevsToAdd"

#' The Levels to Delete input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the levels to be deleted from the model when
#' using CSVmodelNewSquiggly call. It comprises of Factors and Levels.
#'
#' @format A data table with 3 rows and 2 variables:
#' \describe{
#'   \item{Factor}{Factors that will have levels deleted}
#'   \item{Level}{The level to be deleted}
#' }
"data_LevsToDelete"

#' The Levels to Rename input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the levels that will be renamed when
#' using CSVmodelNewSquiggly call. It comprises of Old Factors, Old Levels and
#'  New Levels
#'
#' @format A data table with 53 rows and 3 variables:
#' \describe{
#'   \item{Old Factor}{Factors that will have a level renamed}
#'   \item{Old Level}{Level to be renamed}
#'   \item{New Level}{New name for the level}
#' }
"data_LevsToRename"

#' The Factors to Rename input file for CSVmodelNewSquiggly
#'
#' This input file lists all of the factors that will be renamed when
#' using CSVmodelNewSquiggly call. It comprises of Old Name and New Name.
#'
#' @format A data table with 21 rows and 2 variables:
#' \describe{
#'   \item{Old Name}{Factors that will be renamed}
#'   \item{New Name}{New name for the factor}
#' }
"data_FacsToRename"

#' The Sample 'Factors to Collapse' input file for CSVmodelNewSquiggly
#'
#' Presumably you get a weighted average of the factor collapsed using this input.
#' Ask Florian!
#'
#' @format A data table with 8 rows and 3 variables:
#' \describe{
#'   \item{Old Factor}{Factor(s) that will be collapsed over}
#'   \item{Old Level}{All the levels for the Factor(s)}
#'   \item{Weight}{Weighting of the level for the relevant collapse.}
#' }
"data_FacsToCollapse"


