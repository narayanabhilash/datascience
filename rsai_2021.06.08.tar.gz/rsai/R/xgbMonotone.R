#####  xgbMonotone  #####
#' Function to create input to the monotone_constraints parameter for xgboost.
#' @description Create the input to the \code{monotone_constraints} parameter for xgboost by
#' supplying the function with a vector of column names, plus a vector or vectors of
#' column names on which to apply an increasing and/or decreasing monotonicity constraint.
#' @usage xgbMonotone(cols, increasing, decreasing)
#' @param cols A character vector of column names
#' @param increasing The columns to set as monotonically increasing
#' @param decreasing The columns to set as monotonically decreasing
#' @return A character to use in the monotoneConstraint parameter.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples # xgbMonotone(c("PHAge", "Premium", "Occupation"), "PHAge", "Premium")
#' @export

xgbMonotone <- function(cols, increasing=character(0), decreasing=character(0)){
  both <- intersect(increasing, decreasing)
  for(x in both){
    warning(paste0(x, " has been defined as both increasing and decreasing and will be ignored."))
  }
  increasing <- setdiff(increasing, both)
  decreasing <- setdiff(decreasing, both)
  
  for(x in setdiff(c(increasing, decreasing), cols)){
    warning(paste0(x, " is not in cols and will be ignored."))
  }
  
  rtnVec <- sapply(cols, function(x) ifelse(x %in% increasing, 1, ifelse(x %in% decreasing, -1, 0)))
  names(rtnVec) <- cols
  
  return(rtnVec)
}