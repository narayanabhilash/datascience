#####################################################
# Code to generate generic xgboost ready matrices from data tables
#####################################################

#-------------------------------------------
# 1. Set up and functions for later
#-------------------------------------------



#' Format a data table ready for modelling using \code{xgboost} 
#' 
#' @description xgbSetupdata reads in a data table and outputs 
#' one or more sparse matrices with appropriate offset models for use by
#' algorithms such as xgboost. 
#' \strong{This function has been deprecated and is included only for backwards compatibility.
#' Please use xgbSetupdata2 for all future scripts.
#' Also note that there is a bug in this version of the function that will impact data for severity and burning cost modelling
#' and we strongly recommend not using this function at all for these use cases.}
#' @param dt_Data The input datatable that contains reponse and explanatory variables for all rows
#' @param response The name of the response column in dt_Data
#' @param explanatory_vars character vector OR list of character vectors. If this is a list, you can vary the explanatory variables in each of the DMatrices produced but there must be a 1:1 mapping. This is useful, for example, if you have a column with a different name in your validation data than your training data.
#   If not specified, all columns are used other than response, sampleWeight, offset_model and exposure.
#' @param NA_treatment value to which numeric NAs are set (this is required behaviour in xgboost).
#'Either a scalar to set to NAs for all columns or a vector the same length as the explanatory_vars character vectors
# with a value for NAs for each. (Any values are ignored for Factor columns but still need to be present).
#' @param exposure optional exposure column. 
#' @param sampleWeight Optional sample weight column. NB this should be weight \emph{over and above} the effect of variable exposure.
#' @param offset_model xoptional offset model to send to base_margin. \code{xgboost} will model from a starting point of (estimated response = offset_model * exposure).
#' \emph{Note that offset models should be specified WITHOUT the log-link applied if logResponse is set to TRUE as the function will apply it for you.}
#' \emph{NB} at time of writing xgb.cv does not automatically pick this up: The R users yammer page contains a work-around. 
#' @param rowIndicesList optional list of integer vectors representing row numbers. 
#' \code{xgbSetupdata} returns a list of matrix objects consistent with the data in these rows.
#' @param nameList optional vector of names. A returned list will be named with these.
#' @param logResponse If True, this adjusts the base margin in the returned matrices. This is desirable if you wish to use \code{xgboost} with a 'log-link' 
#' objective parameter - ie 'reg:gamma', 'reg:tweedie' or 'count:poisson'. This is usually the case in pricing models and so by default \code{logresponse} is True.
#' \emph{Note that is set to TRUE you should NOT apply the log-link yourself if using the offset_model parameter}
#' @return an xgb.Dmatrix object, or a named list of them.
#' @importFrom xgboost xgb.DMatrix
#' @importFrom Matrix sparse.model.matrix
#' @importFrom data.table data.table
#' @export
#' @author Edwin Graham, Tom Bratcher & Nigel Carpenter


xgbSetupdata <- function(dt_Data,
                         response = NULL,
                         explanatory_vars = NULL,
                         NA_treatment = -1e10,
                         exposure = NULL,
                         sampleWeight = NULL,
                         offset_model = NULL,
                         rowIndicesList = NULL,
                         nameList = NULL,
                         logResponse = TRUE){
  
  #####################

  warning(paste0("This function has been deprecated and is included only for backwards compatibility.\n",
                 "Please use xgbSetupdata2 for all future scripts.\n",
                 "Also note that there is a bug in this version of the function that will impact data for severity and burning cost modelling ",
                 "and we recommend not using this function at all for these use cases.",
                 "xgbSetupdata2 has the following benefits:\n",
                 "  1) Fixes all bugs in xgbSetupdata\n",
                 "  2) Flexible link function\n",
                 "  3) Flexible factor encoding (not just one-hot encoding)\n"))
  
  # Check input data is a data table
  if(!("data.table" %in% class(dt_Data))){
    if(!("data.frame" %in% class(dt_Data))) stop("dt_Data must be a data.frame") else {
      dt_Data <- data.table(dt_Data)
    }
  }
  
  # Validate rowIndicesList
  if(is.null(rowIndicesList)) rowIndicesList <- list(seq(1, nrow(dt_Data))) else {
    if(!is.list(rowIndicesList)) stop("rowIndicesList must be a list")
    if(!all(sapply(rowIndicesList, is.integer))) stop("rowIndicesList must contain integer vectors")
    if(max(unlist(rowIndicesList)) > nrow(dt_Data)) stop("Row indices specified in rowIndicesList are out of bounds")
    if(min(unlist(rowIndicesList)) < 1) stop("Row indices specified in rowIndicesList are out of bounds")
  }
  
  # Number of xgbDMatrices to return
  nXgbMats <- length(rowIndicesList)
  if(nXgbMats==0) stop("rowIndicesList must be a list of length >= 1")
  
  # Validate explanatory_vars
  if(is.null(explanatory_vars)) {
    explanatory_vars <- vector(mode = "list", length = nXgbMats)
    for(i in seq(1, nXgbMats)) explanatory_vars[[i]] <- setdiff(colnames(dt_Data), c(response, exposure, sampleWeight, offset_model))
    nVars <- length(explanatory_vars[[1]])
    if(nVars < 1) stop("There must be at least one explanatory variable")
    varTypes <- lapply(explanatory_vars, function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]]))
  } else {
    if(is.character(explanatory_vars)) {
      explanatory_vars <- lapply(seq(1, nXgbMats), function(i) explanatory_vars)
      nVars <- length(explanatory_vars[[1]])
      if(nVars < 1) stop("There must be at least one explanatory variable")
      varTypes <- lapply(explanatory_vars, function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]]))
    } else{
      if(is.list(explanatory_vars)){
        if(length(explanatory_vars) != nXgbMats) stop("explanatory_vars must be list of the same length as rowIndicesList")
        if(!all(sapply(explanatory_vars, is.character))) stop("explanatory_vars must be a character vector or list of character vectors")
        nVars <- length(explanatory_vars[[1]])
        if(nVars < 1) stop("There must be at least one explanatory variable")
        varTypes <- lapply(explanatory_vars, function(x) sapply(x, function(y) class(dt_Data[[y]])[[1]]))
        if(nXgbMats > 1){
          if(!all(sapply(explanatory_vars, length) == nVars)) stop("explanatory_vars must contain character vectors of the same length")
          if(!all(unlist(varTypes) %in% c("integer", "numeric", "factor"))) stop("explanatory_vars must be integer, numeric or factor")
          if(!all(sapply(seq(1, nVars), function(i) all(sapply(seq(2, nXgbMats), function(j) varTypes[[j]][[i]] == varTypes[[1]][[i]]))))){
            stop("When using different explanatory variables for each xgbDMatrix, there must be a 1:1 mapping between the sets of variables. Corresponding columns must be of the same class.")
          }
          factorIndex <- which(varTypes[[1]]=="factor")
          if(length(factorIndex) > 0){
            factorVars <- lapply(explanatory_vars, function(x) x[factorIndex])
            factorLevs <- lapply(factorVars, function(x) sapply(x, function(y) levels(dt_Data[[y]])))
            factorLevLengths <- lapply(factorLevs, function(x) sapply(x, length))
            if(!all(sapply(seq(1, length(factorIndex)), function(i) all(sapply(seq(2, nXgbMats), function(j) factorLevLengths[[j]][[i]] == factorLevLengths[[1]][[i]]))))){
              stop("When using different explanatory variables for each xgbDMatrix, there must be a 1:1 mapping between the sets of variables. Corresponding factor columns must have the same number of levels.")
            }
            if(!all(sapply(seq(1, length(factorIndex)), function(i) all(sapply(seq(2, nXgbMats), function(j) all(factorLevs[[j]][[i]] == factorLevs[[1]][[i]])))))){
              stop("When using different explanatory variables for each xgbDMatrix, there must be a 1:1 mapping between the sets of variables. Corresponding factor columns must have exactly the same levels.")
            }
          }
        }
      } else stop("explanatory_vars must be a character vector or list of character vectors")
    }
  }
  
  # Trim data to required factors. This also serves as a test that all factors specified in explanatory_vars, sampleWeight, exposure, offset_model and response are valid column names
  dt_Data <- dt_Data[, c(unique(unlist(explanatory_vars)), sampleWeight, exposure, offset_model, response), with = FALSE]
  
  # check for character fields: could offer to fix them?
  
  if ("character" %in% sapply (dt_Data, class))   stop (
    "data should not include character data. Either set this to be factor (and record the factor levels) classify numerically")
  
  # Fix NAs
  if(!is.null(NA_treatment)){
    if(!is.numeric(NA_treatment)) stop("NA_treatment should be numeric")
    if(length(NA_treatment) == 1) NA_treatment <- rep(NA_treatment, nVars)
    if(length(NA_treatment) != nVars) stop("NA_treatment must be the same length as the explanatory_vars vector(s), or of length 1.")
    dtExpVars <- unique(rbindlist(lapply(explanatory_vars, function(x){
      dt <- data.table(explanatory_var=x, NA_treatment=NA_treatment)
      dt[, order := .I]
      return(dt)
    })))
    if(any(duplicated(dtExpVars$explanatory_var))) stop("In explanatory_vars, if the same variable is used in more than one xgbDMatrix, it _must_ be listed in the same position in each.")
    for(i in seq(1, nrow(dtExpVars))){
      col <- dtExpVars$explanatory_var[i]
      if(is.factor(dt_Data[[col]])) dt_Data[[col]] <- addNA(dt_Data[[col]]) else{
        dt_Data[[i]][is.na(dt_Data[[i]])] <- dtExpVars$NA_treatment[i]
      }
    }
  }
  
  # base margin
  if(is.null(exposure)){
    if(is.null(offset_model)){
      useBaseMargin <- FALSE
    } else{
      useBaseMargin <- TRUE
      base_margin <- dt_Data[[offset_model]]
     
    }
  } else{
    useBaseMargin <- TRUE
    if(is.null(offset_model)){
      base_margin <- dt_Data[[exposure]]
       } else{
      base_margin <- dt_Data[[offset_model]] *dt_Data [[exposure]]
    }
  }
 if (logResponse) base_margin <- log (base_margin)
  
  # Factors vs non-factors
  factorFeatures <- which(varTypes[[1]] == "factor")
  nonFactorFeatures <- which(varTypes[[1]] != "factor")

  # now build the DMatrixs.
  # Here we are column binding dense and sparse matrix 
  # in so doing we are changing the column names and order of the data matrix used by xgboost
  # so later on we will need to redefine the names vector...!

  naActionOption <- getOption("na.action")
  options(na.action = na.pass)
  
  # Put together the matrices with the data for xgb.DMatrix
  if(length(factorFeatures)==0){
    matrixList <- lapply(seq(1, nXgbMats), function(i){
      as.matrix(dt_Data[rowIndicesList[[i]], explanatory_vars[[i]][nonFactorFeatures], with=FALSE])
    })
  } else if(length(nonFactorFeatures)==0){
    matrixList <- lapply(seq(1, nXgbMats), function(i){
      sparse.model.matrix(~.-1,
                          data=dt_Data[rowIndicesList[[i]], explanatory_vars[[i]][factorFeatures], with=FALSE],
                          contrasts.arg = lapply(dt_Data[, explanatory_vars[[i]][factorFeatures], with=FALSE],
                                                 contrasts,
                                                 contrasts=FALSE))
    })
  } else {
    matrixList <- lapply(seq(1, nXgbMats), function(i){
      cbind2(as.matrix(dt_Data[rowIndicesList[[i]], explanatory_vars[[i]][nonFactorFeatures], with=FALSE]),
             sparse.model.matrix(~.-1,
                                 data=dt_Data[rowIndicesList[[i]], explanatory_vars[[i]][factorFeatures], with=FALSE],
                                 contrasts.arg = lapply(dt_Data[, explanatory_vars[[i]][factorFeatures], with=FALSE],
                                                        contrasts,
                                                        contrasts=FALSE)))
    })
  }
  
  # Now define the names vector that holds the names of features used by xgboost in correct order 
  names <- dimnames(matrixList[[1]])[[2]]
  for (nm in explanatory_vars[[1]][factorFeatures]) names <- gsub (nm, paste0 (nm,"~is~"), names)
    
  # Create the final list of xgb.DMatrix objects to return
  if(is.null(response)){
    if(is.null(sampleWeight)){
      if(useBaseMargin){
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 base_margin=base_margin[rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      } else{
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      }
    } else{
      if(useBaseMargin){
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 weight=dt_Data[[sampleWeight]][rowIndicesList[[i]]],
                                 base_margin=base_margin[rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      } else{
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 weight=dt_Data[[sampleWeight]][rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      }
    }
  } else {
    if(is.null(sampleWeight)){
      if(useBaseMargin){
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 label=dt_Data[[response]][rowIndicesList[[i]]],
                                 base_margin=base_margin[rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      } else{
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 label=dt_Data[[response]][rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      }
    } else{
      if(useBaseMargin){
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 label=dt_Data[[response]][rowIndicesList[[i]]],
                                 weight=dt_Data[[sampleWeight]][rowIndicesList[[i]]],
                                 base_margin=base_margin[rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      } else{
        returnList <- lapply(seq(1, nXgbMats), function(i){
          xgbMat <- xgb.DMatrix( data=matrixList[[i]],
                                 label=dt_Data[[response]][rowIndicesList[[i]]],
                                 weight=dt_Data[[sampleWeight]][rowIndicesList[[i]]])
          colnames(xgbMat) <- names
          return(xgbMat)
        })
      }
    }
  }

  options(na.action = naActionOption)
  
  if(!is.null(nameList)){
    if(!is.character(nameList)) warning("nameList should be a character vector the same length as rowIndicesList - nameList ignored.") else{
      if(length(nameList) != nXgbMats) warning("nameList should be a character vector the same length as rowIndicesList - nameList ignored.") else{
        names(returnList) <- nameList
      }
    }
  }

  return(returnList)
}

