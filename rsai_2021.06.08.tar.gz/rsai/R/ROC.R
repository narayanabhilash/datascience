#' Receiver Operating Characteristic (Gain Curve)
#' 
#' @description  Plot the ROC curve for a given predictor variable or data frame of predictor
#' variables
#' 
#' @usage ROC(y,pred,y.name,pred.name,...)
#' @aliases ROC ROC-methods ROC,ANY,ANY-method ROC,ANY,data.frame-method
#' @param y A vector of observed values.
#' @param pred A vector or data frame of predicted values (these should be in
#' corresponding order to \code{y}). For data frame input, it is expected that
#' each column is a predictor.
#' @param y.name A character vector of length one; the name of \code{y} for use
#' in plotting. Defaults to "y".
#' @param pred.name A character vector of length one; the name of \code{pred}
#' for use in plotting. Defaults to "pred".
#' @param ...  Additional arguments to \code{\link{plot}} and/or
#' \code{\link{lines}}.
#' @return This is mostly invoked for its side effect of plotting the ROC
#' curve(s), but returns the C-statistic(s) defined as the ratio of the amount
#' of gain to the maximum possible for that particular \code{y}.
#' @note This function is still fairly experimental! Bug reports and
#' suggestions for features welcome.
#' @author James Lawrence
#' @seealso \code{\link{sort}}, \code{\link{plot.default}}.
#' @export
#' @examples
#' 
#' ## some explanatory variables
#' x <- rnorm(1000)
#' y <- rnorm(1000,x,1)
#' p <- par(mfrow=c(2,1))
#' ## a poor prediction
#' ROC(y,x^2)
#' ## a useful one
#' ROC(y,x)
#' ## compare the two
#' ROC(y,data.frame(x=x,x2=x^2))
#' par(p)
#' 
ROC <- function(y,pred,y.name=strtrim(deparse(substitute(y))[1],30),pred.name=strtrim(deparse(substitute(pred))[1],30),...){
	standardGeneric("ROC")
}

setGeneric("ROC",signature=c("y","pred"))

ROC.default <- function(y,pred,y.name=strtrim(deparse(substitute(y))[1],30),pred.name=strtrim(deparse(substitute(pred))[1],30),...){
	main <- paste0("ROC curve : ",y.name," against ",pred.name)
	ylab <- paste0("cumulative ",y.name)
	t1 <- order(pred,decreasing=TRUE)
	y <- y[t1]
	pred <- pred[t1]
	plot(cumsum(y),main=main,xlab="n",ylab=ylab,...)
	abline(0,mean(y),lty="dotted")
	m <- mean(y); n <- length(y)
	return((sum(cumsum(y)*2/(n^2*m)) - 1)/(sum(cumsum(sort(y,decreasing=TRUE))*2/(n^2*m)) - 1))
}

ROC.data.frame <- function(y,pred,y.name=strtrim(deparse(substitute(y))[1],30),pred.name=strtrim(deparse(substitute(pred))[1],30),...){
	main <- paste0("ROC curve : ",y.name," against columns of ",pred.name)
	ylab <- paste0("cumulative ",y.name)
	cstats <- numeric()
	plot(numeric(0),xlim=c(1,length(y)),ylim=range(cumsum(sort(y,decreasing=TRUE))),main=main,xlab="n",ylab=ylab,...)
	for (i in 1:ncol(pred)){
		t1 <- order(pred[,i],decreasing=TRUE)
		y2 <- y[t1]
		pred2 <- pred[t1,i]
		lines(cumsum(y2),...,col=i+1)
		m <- mean(y); n <- length(y)
		cstats <- c(cstats,(sum(cumsum(y2)*2/(n^2*m)) - 1)/(sum(cumsum(sort(y2,decreasing=TRUE))*2/(n^2*m)) - 1))
	}
	abline(0,mean(y),lty="dotted")
	legend("bottomright",lwd=1,names(pred),col=1:ncol(pred)+1)
	return(cstats)
}

setMethod("ROC",signature(y="ANY",pred="ANY"),ROC.default)
setMethod("ROC",signature(y="ANY",pred="data.frame"),ROC.data.frame)
