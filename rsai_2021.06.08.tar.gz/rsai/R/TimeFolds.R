
#' Time dependent fold generation for crossfold validation
#' @description Recent versions of the `xgboost` package have allowed have 
#' included a `train_folds` argument to `xgb.cv`. This allows for cross fold 
#' validation on data sets where we want our cross fold models to only train on
#' data which would have been available in the past (from the point of view of 
#' the relevant test datum.) 
#' This function takes an input of time values relating to training data
#' and outputs a list of training and test folds for time dependent cross fold
#' validation.
#' These then form the `folds` and `train_folds` arguments for `xgb.cv`.
#' @param trainK vector of numeric data, recording time period.
#' Each distinct value will give rise to a separate fold. 
#' As ever with `xgb.cv`, this vector covers just the rows in your training data
#' (so for instance the 3rd value of `trainK` relates to the third row in the
#' training data, wherever that might appear in the original data set). Mistakes 
#' here will cause R to encounter fatal errors, so please do not make them.
#' @param decreasing is the vector decreasing as time increases?
#' (See the examples.  This formulation allows consistency with the terminology
#' used by Baudry for creation of reserving triangle predictions via GBMs.)
#' @param method "rolling" or "block" - if rolling, then each training set
#' uses all data preceding its test fold: if "block" then training set
#' uses only data from the immediately preceding time period.
#' @note because only data from the past is used, the number of folds created
#' is one fewer than the number of unique values within `trainK`.
#' @note This formulation allows you to specify multiple rows in the training
#' and test data which effectively relate to the same event- but with different
#' time notations. This may be useful for formulations of complex time related
#' modelling tasks.
#' However, it's not possible to specify folds by (say) location and only train
#' on data from different time windows.
#' @return a list containing `trainFolds` and `testFolds` (which map to 
#' `train_folds` and `folds` respectively).
#' @author Tom Bratcher (tom.bratcher@uk.rsagroup.com)
#' @export
#'
#' @examples
#' 
#' set.seed(123L)
#' trainK <- sample(0:4, 50, replace = TRUE)
#' print(head(trainK, 10))
#' timeFolds(trainK = trainK)
#' timeFolds(trainK = trainK, decreasing = TRUE, method = "block")
#' 
#' 
timeFolds <- function (
  trainK,
  decreasing = FALSE,
  method = "rolling") {
  
  # method
  method = tolower(method)
  if (!(method %in% c ("rolling", "block"))){
    stop ("method must be one of 'rolling' or 'block'")
  }
  times <- sort(unique(trainK), decreasing = decreasing)
  
  # convert trainK into integers to match their place in times:
  # could do this using as.factor
  trainK <- match(trainK, times)
  times <- seq_along(times)
  if(method == "block"){
    trainFolds <- lapply(
      times[-length(times)],
      function(x) which(trainK == x))
  } else {
    trainFolds <- lapply(
      times[-length(times)],
      function(x) which(trainK <= x))
  }
  
  testFolds <- lapply(
    times[-1],
    function(x) which(trainK == x))
  
  return (list(trainFolds = trainFolds, testFolds = testFolds))
}

