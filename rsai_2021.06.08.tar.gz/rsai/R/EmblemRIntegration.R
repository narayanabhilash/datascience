# S4 classes required for EMBlem R integration code. Contains:
## EMBlemFactor
## EMBlemFacFile
## EMBlemGroupedFac
## EMBlemVariate
## EMBlemOffset
## EMBlemModel
## EMBlemModelMap

# Functions required for EMBlem R integration code. Contains:
## readFacFile
## createEMBlemModel
## getRequiredFactors
## getRatingTables
## appendStatsToRatingTbl
## createEMBMap
## getDesignMatrix
## getModelOffsets

# To do list:
## Add validation rules to class EMBlemModelMap.
## Add error trapping at top of functions.
## Add verbose option to each function.


# Required libraries
# require(data.table)
# require(gtools)
# require(Matrix)

###############  CLASSES  ###############
#####  EMBlemFactor  #####
#' An S4 class to represent a single factor from an EMBlem FacFile.
#'
#' @slot levels A character vector representing the levels of the factor.
#' @slot baseLevel A character vector of length 1 representing the base level.
#' @slot contrasts associated contrasts.
#' @importFrom data.table data.table key haskey
#' @importFrom Matrix rankMatrix
#' @exportClass EMBlemFactor

# Class EMBlemFactor for levels and baseLevel of an Emblem factor
setClass(
  "EMBlemFactor",
  representation(
    levels="character",
    baseLevel="character",
    contrasts="data.table"
  ),
  prototype = prototype(levels=c("A", "B", "C"),
                        baseLevel="A",
                        contrasts=data.table(X1=factor(c("A", "B", "C")), X1.B=c(0, 1, 0), X1.C=c(0, 0, 1), key="X1")),
  validity=function(object){
    #require(Matrix)
    if(length(object@baseLevel) != 1) return("Slot: baseLevel, should be a character vector length one.")
    numLevs <- length(object@levels)
    if(numLevs < 1) return("In slot: levels, the character vector should be of length 1 or longer.")
    if(!(object@baseLevel %in% object@levels)) return("Slot: baseLevel should contain one of the values in slot: levels.")
    if(anyDuplicated(object@levels)) return("Slot: levels should contain only unique values.")
    if(numLevs != nrow(object@contrasts)) return("There must be one row in the contrasts table for each level in slot: levels.")
    if(numLevs != ncol(object@contrasts)) return("In slot: contrasts, the first column should contain the factor and all levels, and there should be n-1 further columns specifying contrast for the design matrix where n is the number of levels.")
    if(!all(object@levels %in% object@contrasts[[1]])) return("The first column of the table in slot: contrasts, must contain each level in slot: levels.")
    if(!all(levels(object@contrasts[[1]]) %in% object@levels)) return("The levels of the factor in the first column of the contrasts table should match the levels defined in the slot: levels.")
    if(anyNA(object@levels)) return("Slot: levels, should not contain missing values.")
    if(anyNA(object@baseLevel)) return("Slot: baseLevel, should not contain missing values.")
    if(anyNA(object@contrasts)) return("Slot: contrasts, should not contain missing values.")
    if(!all(sapply(object@contrasts, class) == c("factor", rep("numeric", numLevs-1)))) return("The first column of the table in slot: contrasts, should be a factor, the rest should be numeric.")
    if(numLevs > 1){
      if(!all(object@contrasts[which(object@contrasts[[1]]==object@baseLevel)][, -1, with=FALSE]==0)) return("All values in the base level row should be zero.")
      if(!rankMatrix(object@contrasts[, -1, with=FALSE]) == length(object@levels)-1) return("Columns 2 to n should have matrix rank n-1, where n is the number of levels.")
    }
    if(!haskey(object@contrasts)) return("Data table in slot: contrasts, should be keyed by the first column.")
    if(key(object@contrasts) != names(object@contrasts)[[1]]) return("Data table in slot: contrasts, should be keyed by the first column.")
    return(TRUE)
  }
) -> EMBlemFactor
##########################


#####  EMBlemFacFile  #####
#' An S4 class to represent an EMBlem FacFile.
#'
#' @slot factors A named list of where each element is of class EMBlemFactor.
#' @exportClass EMBlemFacFile

setClass(
  "EMBlemFacFile",
  representation(
    factors="list"
  ),
  prototype = prototype(factors=list(X1=EMBlemFactor())),
  validity=function(object){
    if(length(object@factors) < 1) return("Slot: factors, must be a list with length >= 1.")
    if(!all(sapply(object@factors, is, "EMBlemFactor"))) return("Slot: factors, must contain a list of objects of class EMBlemFactor.")
    if(is.null(names(object@factors))) return("Slot: factors, must be a named list (names represent the names of the factors).")
    if(anyNA(names(object@factors))) return("Names of factors cannot be NA.")
    if(any(names(object@factors)=="")) return("Names of factors must have length >= 1.")
    if(anyDuplicated(names(object@factors))) return("Names of factors must be unique.")
    if(!all(sapply(object@factors, function(x) names(x@contrasts)[[1]]) == names(object@factors))) return("Slot: factors, must be a named list. Names must match the name of the first column of the table in the contrast slot of each factor.")
    return(TRUE)
  }
) -> EMBlemFacFile
###########################


#####  EMBlemGroupedFac  #####
#' An S4 class to represent an EMBlem Grouped Factor.
#'
#' @slot lookupTbl A data table object to lookup the value of the grouped factor from the parent factor levels.
#' @slot parentFactor The name of the parent factor (character of length 1).
#' @slot EMBlemFactor An object of class EMBlemFactor representing the grouped factor.
#' @slot ordered A logical value of length 1. Should the grouped factor be interpreted as ordered?
#' @exportClass EMBlemGroupedFac

setClass(
  "EMBlemGroupedFac",
  representation(
    lookupTbl="data.table",
    parentFactor="character",
    EMBlemFactor="EMBlemFactor",
    ordered="logical"
  ),
  prototype = prototype(lookupTbl=data.table(X1=factor(c("A", "B", "C")), GF1=factor(c("A", "BC", "BC")), key="X1"),
                        parentFactor="X1",
                        EMBlemFactor=EMBlemFactor(levels=c("A", "BC"), baseLevel="A", contrasts=data.table(GF1=factor(c("A", "BC")), GF1.BC=c(0, 1), key="GF1")),
                        ordered=FALSE),
  validity=function(object){
    if(!(ncol(object@lookupTbl)==2)) return("Slot: lookupTbl, must be a data.table of 2 columns")
    if(object@parentFactor!=names(object@lookupTbl)[[1]]) return("Slot: parentFactor, must be the same as the first column in the lookup table.")
    if(!all(sapply(object@lookupTbl, is, "factor"))) return("Both columns of the lookup table must be of type factor.")
    if(key(object@lookupTbl)!=object@parentFactor) return("The lookup table must be keyed and the key must be the parentFactor.")
    if(!(all(levels(object@lookupTbl[[names(object@lookupTbl)[[2]]]])==object@EMBlemFactor@levels))) return("The levels must be identical to the factor levels in column 2 of the lookup table.")
    if(nrow(object@lookupTbl)!=length(levels(object@lookupTbl[[1]]))) return("There must be a row in the lookup table for each factor level in the parent factor.")
    if(anyDuplicated(object@lookupTbl[[1]])) return("There must be excactly one row per factor level in the parentFactor.")
    if(!all(complete.cases(object@lookupTbl))) return("The lookup table must not contain missing values.")
    if(length(object@ordered)!=1) return("Slot: ordered, must be logical of length one.")
    if(!(object@ordered %in% c(TRUE, FALSE))) return("Slot: ordered, must equal TRUE or FALSE.")
    return(TRUE)
  }
) -> EMBlemGroupedFac
##############################


#####  EMBlemVariate  #####
#' An S4 class to represent an EMBlem Variate.
#'
#' @slot lookupTbl A data table object to lookup the value of the variate from the parent factor levels.
#' @slot parentFactor The name of the parent factor (character of length 1).
#' @slot valueAtBase The value that the variate takes at the base level of the parent factor (numeric of length 1).
#' @exportClass EMBlemVariate

setClass(
  "EMBlemVariate",
  representation(
    lookupTbl="data.table",
    parentFactor="character",
    valueAtBase="numeric"
  ),
  prototype = prototype(lookupTbl=data.table(X1=factor(c("A", "B", "C")), VAR1=c(0, 1, 2), key="X1"),
                        parentFactor="X1",
                        valueAtBase=0),
  validity=function(object){
    if(!(ncol(object@lookupTbl)==2)) return("The lookup table must have 2 columns.")
    if(object@parentFactor!=names(object@lookupTbl)[[1]]) return("Slot: parentFactor, must be same as the name of the first column in the lookup table.")
    if(!(is(object@lookupTbl[[1]], "factor"))) return("The first column in the lookup table must be of class factor.")
    if(!(is(object@lookupTbl[[2]], "numeric"))) return("The second column in the lookup table must be of class numeric.")
    if(key(object@lookupTbl)!=object@parentFactor) return("The lookup table must be keyed and key must be the parent factor.")
    if(nrow(object@lookupTbl)!=length(levels(object@lookupTbl[[1]]))) return("There must be a row in the lookup table for each factor level in the parent factor.")
    if(anyDuplicated(object@lookupTbl[[1]])) return("There must be excactly 1 row per factor level in the parentFactor")
    if(!all(complete.cases(object@lookupTbl))) return("The lookup table must not contain missing values.")
    return(TRUE)
  }
) -> EMBlemVariate
###########################


#####  EMBlemOffset  #####
#' An S4 class to represent an EMBlem offset.
#'
#' @slot lookupTbl A data table object to lookup the value of the offset against one or more factors.
#' @importFrom data.table data.table setkeyv key
#' @exportClass EMBlemOffset

setClass(
  "EMBlemOffset",
  representation(
    lookupTbl="data.table"
  ),
  prototype = prototype(lookupTbl=data.table(X1=factor(c("A", "B", "C")), offset=c(1, 1, 1.1), key="X1")),
  validity=function(object){
    if(ncol(object@lookupTbl)<2) return("The lookup table must have at least 2 columns.")
    if(!all(sapply(object@lookupTbl[, -ncol(object@lookupTbl), with=FALSE], is, "factor"))) return("All columns of the lookup table except the final one must be of class factor.")
    if(!(is(object@lookupTbl[[ncol(object@lookupTbl)]], "numeric"))) return("The final column in the lookup table must be of class numeric.")
    if(length(key(object@lookupTbl))!=ncol(object@lookupTbl)-1) return("The lookup table must be keyed by all factor columns.")
    if(length(key(object@lookupTbl))!=length(unique(key(object@lookupTbl)))) return("The lookup table must be keyed by all factor columns.")
    if(names(object@lookupTbl)[ncol(object@lookupTbl)] %in% key(object@lookupTbl)) return("The lookup table must be keyed by all factor columns.")
    temp1 <- data.table(expand.grid(lapply(key(object@lookupTbl), function(x) levels(object@lookupTbl[[x]]))))
    names(temp1) <- key(object@lookupTbl)
    setkeyv(temp1, key(object@lookupTbl))
    temp2 <- object@lookupTbl[, key(object@lookupTbl), with=FALSE]
    if(!identical(temp1, temp2)) return("The rows of the lookup table should contain a Cartesian product of the levels of each factor with an offset column.")
    if(!all(complete.cases(object@lookupTbl))) return("The lookup table must not contain missing values.")
    if(colnames(object@lookupTbl)[[ncol(object@lookupTbl)]]!="offset") return("The final column of the lookup table should be named: offset.")
    return(TRUE)
  }
) -> EMBlemOffset
##########################


#####  EMBlemModel  #####
#' An S4 class to represent an EMBlem Model including factor definitions etc.
#'
#' @slot facFile An object of class EMBlemFacFile containing the names of levels of all the factors.
#' @slot terms A data table containing a list of all factors, groups and variates to include in the model fit.
#' @slot groupedFactors A named list containing objects of class EMBlemGroupedFac defining any required grouped factors.
#' @slot variates A named list containing objects of class EMBlemVariate defining any required variates.
#' @slot offsets A list containing objects of class EMBlemOffset defining any required offsets.
#' @importFrom data.table data.table setkeyv key
#' @exportClass EMBlemModel

setClass(
  "EMBlemModel",
  representation(
    facFile="EMBlemFacFile",
    terms="data.table",
    groupedFactors="list",
    variates="list",
    offsets="list"
  ),
  prototype = prototype(facFile=EMBlemFacFile(),
                        terms=data.table(term=c(1L, 2L), factor1=c("GF1", "VAR1"), factor2=rep("", 2), factor3=rep("", 2), order1=c(as.integer(NA), 1L), order2=rep(as.integer(NA), 2), order3=rep(as.integer(NA),2)),
                        groupedFactors=list(GF1=EMBlemGroupedFac()),
                        variates=list(VAR1=EMBlemVariate()),
                        offsets=list(EMBlemOffset())),
  validity=function(object){
    # Possible improvement - in error messages where specific factors cause the error, return the name of that factor not just the rule it fails
    if(!all(names(object@terms) == c("term", "factor1", "factor2", "factor3", "order1", "order2", "order3"))) return("In slot: terms, the column names of the data table must be: term, factor1, factor2, factor3, order1, order2 and order3.")
    if(!all(sapply(object@terms[, seq(2, 4), with=FALSE], is, "character"))) return("In slot: terms, the data table columns: factor1, factor2 and factor3, must all be of class character.")
    if(!all(sapply(object@terms[, c(1, 5, 6, 7), with=FALSE], is, "integer"))) return("In slot: terms, the data table columns: terms, order1, order2 and order3 must be all be of class integer.")
    if(min(nchar(object@terms[["factor1"]]))<1) return("In slot: terms, the data table column factor1 must not contain values with character length less than one.")
    if(length(setdiff(which(object@terms[["factor2"]]==""), which(object@terms[["factor3"]]=="")))>0) return("In slot: terms, the column factor3 must contain a character of length zero for all rows where factor2 contains a character of length zero.")
    if(!all(sapply(object@groupedFactors, is, "EMBlemGroupedFac"))) return("In slot: groupedFactors, all members of the list must be of class EMBlemGroupedFac.")
    if(!all(sapply(object@variates, is, "EMBlemVariate"))) return("In slot: variates, all members of the list must be of class EMBlemVariate.")
    if(!all(sapply(object@offsets, is, "EMBlemOffset"))) return("In slot: offsets, all members of the list must be of class EMBlemOffset.")
    if(anyDuplicated(names(object@groupedFactors))) return("The names of each grouped factor must be unique.")
    if(anyDuplicated(names(object@variates))) return("The names of each variate must be unique.")
    if(length(intersect(names(object@groupedFactors), names(object@facFile@factors)))>0) return("The names of grouped factors cannot intersect with names of factors.")
    if(length(intersect(names(object@variates), names(object@facFile@factors)))>0) return("The names of variates cannot intersect with names of factors.")
    if(length(intersect(names(object@variates), names(object@groupedFactors)))>0) return("The names of variates cannot intersect with names of grouped factors.")
    termsFactors <- unique(c(object@terms[["factor1"]], object@terms[["factor2"]], object@terms[["factor3"]]))
    termsFactors <- termsFactors[which(nchar(termsFactors)>0)]
    if(!all(sapply(termsFactors, function(x) x %in% c(names(object@facFile@factors), names(object@variates), names(object@groupedFactors))))) return("All model terms specified in the terms data table must be attributes defined in facFile, groupedFactors or variates.")
    orders <- c(object@terms[which(factor1 %in% names(object@variates)), order1], object@terms[which(factor2 %in% names(object@variates)), order2], object@terms[which(factor3 %in% names(object@variates)), order3])
    if(!all(c(orders>=1, orders<=10))) return("All variates specified in the terms data table must have a valid polynomial order of between 1 and 10 inclusive.")
    if(!all(sapply(sapply(object@groupedFactors, function(y) y@parentFactor), function(x) x %in% names(object@facFile@factors)))) return("The parent factor must exist in the facFile for all grouped factors.")
    if(!all(sapply(object@groupedFactors, function(x) identical(levels(x@lookupTbl[[1]]), object@facFile@factors[[names(x@lookupTbl)[1]]]@levels)))) return("The levels of the parentFactor must exactly match those in the facFile for all grouped factors.")
    if(!all(sapply(sapply(object@variates, function(y) y@parentFactor), function(x) x %in% names(object@facFile@factors)))) return("The parent factor must exist in the facFile for all variates.")
    if(!all(sapply(object@variates, function(x) identical(levels(x@lookupTbl[[1]]), object@facFile@factors[[names(x@lookupTbl)[1]]]@levels)))) return("The levels of the parentFactor must exactly match those in the facFile for all variates.")
    if(!all(sapply(unlist(sapply(object@offsets, function(x) names(x@lookupTbl)[-ncol(x@lookupTbl)])), function(y) y %in% names(object@facFile@factors)))) return("Each factor column must exist in the facFile for all offsets.")
    offsetLevels <- do.call(c, lapply(object@offsets, function(x) lapply(x@lookupTbl[, key(x@lookupTbl), with=FALSE], function(y) levels(y))))
    if(!all(sapply(seq_along(offsetLevels), function(i) identical(offsetLevels[[i]], object@facFile@factors[[names(offsetLevels)[i]]]@levels)))) return("The levels of each factor column must exactly match those in the facFile for all offsets.")
    if(!all(sapply(object@groupedFactors, function(x) as.character(x@lookupTbl[[2]][which(x@lookupTbl[[1]]==object@facFile@factors[[x@parentFactor]]@baseLevel)]) == x@EMBlemFactor@baseLevel))) return("The base levels of each grouped factor must correspond to the base level of the parent factor.")
    if(!all(sapply(object@variates, function(x) x@lookupTbl[[2]][which(x@lookupTbl[[1]]==object@facFile@factors[[x@parentFactor]]@baseLevel)] == x@valueAtBase))) return("The slot: valueAtBase, of all variates must match the value the variate takes at the base level of the parent factor.")
    terms2 <- object@terms[, list(factor1, factor2, factor3, order1, order2, order3)]
    setkey(terms2)
    if(!identical(terms2, unique(terms2))) return("Terms listed in the model should be unique.")
    if(anyDuplicated(object@terms[["term"]])) return("In slot: terms, the term column of the table must contain unique values.")
    return(TRUE)
  }
) -> EMBlemModel
#########################


#####  EMBlemModelMap  #####
#' An S4 class to represent an EMBModelMap - an object to map data table to model spec.
#'
#' @slot expandedTerms A data table object containing all information required to map a
#' model design matrix or model coeffients back into rating table form.
#' @slot lookupList A list of lookups for design matrix columns against raw factors.
#' @slot facFile The facfile information including base levels.
#' @slot offsets A list of offsets
#' @importFrom data.table data.table
#' @exportClass EMBlemModelMap

setClass(
  "EMBlemModelMap",
  representation(
    expandedTerms="data.table",
    lookupList="list",
    offsets="list",
    facFile="EMBlemFacFile"
  ),
  prototype = prototype(expandedTerms=data.table(term=1,
                                                 ways=1,
                                                 parentFactor1=1,
                                                 parentFactor2=1,
                                                 parentFactor3=1,
                                                 factor1=1,
                                                 factor2=1,
                                                 factor3=1,
                                                 childFactor1=1,
                                                 childFactor2=1,
                                                 childFactor3=1,
                                                 type1=1,
                                                 type2=1,
                                                 type3=1,
                                                 order1=1,
                                                 order2=1,
                                                 order3=1,
                                                 designMatrixColName=1),
                        lookupList=list(),
                        offsets=list(),
                        facFile=EMBlemFacFile()),
  validity=function(object){

    return(TRUE)
  }
) -> EMBlemModelMap
############################
#########################################


###############  FUNCTIONS  ###############
#####  readFacFile  #####
#' Function to read an Emblem *.fac file.
#' @description A function that reads Emblem *.Fac files into R, storing a list of all the factors, their levels and which level is the base level.
#' @usage readFacFile(loc)
#' @param loc The location of the *.fac file as a character string
#' @return An object of class EMBlemFacFile.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #facFile <- readFacFile("./EMBLEM data/Drop 10/PD_Freq_v8.Fac")
#' @export

readFacFile <- function(loc){
  if(!is.character(loc)) stop("The parameter loc must be a character string containing a valid location.")
  if(length(loc)>1) stop("The parameter loc must be a character string containing a valid location.")
  facText <- readLines(loc)
  
  # Get number of Factors then trim header of Fac text
  numFactors <- as.numeric(facText[2])
  facText <- facText[seq(which(facText == "No. Levels  Base") + 1, length(facText))]
  
  # Loop through each factor in FAC file and extract name, levels and base level
  factors <- vector("list", numFactors)
  for(i in seq(1, numFactors)) {
    # Get info about current factor and assign to list
    factor <- facText[1]
    numLevels <- as.numeric(substr(facText[[2]], 1, regexpr("\t", facText[[2]]) - 1))
    levels <- facText[seq(3, numLevels + 2)]
    baseLevel <- levels[as.numeric(substr(facText[[2]], regexpr("\t", facText[[2]]) + 1, nchar(facText[[2]])))]
    contrasts <- data.table(factor=factor(levels, levels=levels), key="factor")
    if(length(levels)>100) alloc.col(contrasts, length(levels))
    for(lev in levels){
      if(lev != baseLevel) set(contrasts, j=paste0(factor, ".", lev), value=1*(contrasts$factor==lev))
    }
    setnames(contrasts, "factor", factor)
    factors[[i]] <- EMBlemFactor(levels=levels, baseLevel=baseLevel, contrasts=contrasts)
    names(factors)[i] <- factor
    # Clear stored info from facText
    facText <- facText[seq(numLevels+3, length(facText))]
  }
  return(EMBlemFacFile(factors=factors))
}
#########################


#####  createEMBlemModel  #####
#' Function to create an EMBlemModel object.
#' @description The function creates an EMBlemModel object from output that can be automatically generated from within Emblem. This contains definitions of all grouped factors and variates, any offsets used, and a list of attributes (simple factors, grouped factors, variates of different polynomial order and interactions) that are included in the model.
#' @usage createEMBlemModel(fac, dir, trim=TRUE)
#' @param fac The location of an Emblem *.fac file.
#' @param dir A directory containing Emblem model info in the required format (can be automatically generated from EMBLEM).
#' @param trim A logical value. If TRUE, information on factors not required for the actual model fit is stripped out. If FALSE, this information is kept.
#' @return A object of class formula that matches the model terms from the input.
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #EMBlemModelSpec <- createEMBlemModel(fac="./input/EmblemModelSpecs/PD_Freq_v8.Fac", dir="./input/EmblemModelSpecs/PDF_Drop10/")
#' @export

createEMBlemModel <- function(fac, dir, trim=TRUE){
  ## Remove code added to deal with blank columns which is no longer required.
  ## Add in error trapping
  
  if(substr(dir, nchar(dir), nchar(dir))!="/") dir <- paste0(dir, "/")
  
  ### facFile
  if(class(fac)=="EMBlemFacFile") facFile <- fac else facFile <- readFacFile(fac)
  
  ### terms
  termsColClasses <- c(rep("character", 3), rep("integer", 3))
  names(termsColClasses) <- c("factor1", "factor2", "factor3", "order1", "order2", "order3")
  terms <- fread(paste0(dir, "ModelTerms.csv"), colClasses=termsColClasses, showProgress=FALSE)
  terms[, term := .I]
  terms <- terms[, list(term, factor1, factor2, factor3, order1, order2, order3)]
  
  # Find attributes (simple factors, grouped factors, variates) that are used in the model
  usedAttributes <- unique(c(terms$factor1, terms$factor2, terms$factor3))
  usedAttributes <- usedAttributes[which(nchar(usedAttributes)>0)]
  
  ### groupedFactors
  groupFiles <- list.files(path = paste0(dir, "Groups"), pattern = "*.csv", ignore.case = TRUE)
  groupedFactors <- unlist(lapply(groupFiles, function(x){
    colNames <- names(fread(paste0(dir, "Groups/", x), nrows=0, showProgress=FALSE))
    parentFactor <- colNames[[1]]
    listOfGroupedFacs <- lapply(colNames[-1], function(y) {
      # Read in lookup table
      #colClasses <- rep(NA_character_, length(colNames))
      #colClasses[which(colNames %in% c(parentFactor, y))] <- "character"
      lookupTbl <- fread(paste0(dir, "Groups/", x), select=c(parentFactor, y), colClasses="character", showProgress=FALSE)
      # Find parent levels & base level
      parentLevels <- facFile@factors[[parentFactor]]@levels
      parentBaseLevel <- facFile@factors[[parentFactor]]@baseLevel
      # Convert characters to factors maintaining levels and set key
      lookupTbl[[parentFactor]] <- factor(lookupTbl[[parentFactor]], levels=parentLevels)
      lookupTbl[[y]] <- factor(lookupTbl[[y]])
      setkeyv(lookupTbl, parentFactor)
      # Useful assignments
      levels <- levels(lookupTbl[[y]])
      baseLevel <- as.character(lookupTbl[[y]][which(lookupTbl[[parentFactor]]==parentBaseLevel)])
      # Create contrasts table
      contrasts <- data.table(factor=factor(levels, levels=levels), key="factor")
      if(length(levels)>100) alloc.col(contrasts, length(levels))
      ordered <- length(grep("ordered", y))==1
      if(ordered){
        for(lev in levels){
          if(as.numeric(lev) < as.numeric(baseLevel)) set(contrasts, j=paste0(y, ".", lev), value=1*(as.numeric(as.character(contrasts$factor)) <= as.numeric(lev)))
          if(as.numeric(lev) > as.numeric(baseLevel)) set(contrasts, j=paste0(y, ".", lev), value=1*(as.numeric(as.character(contrasts$factor)) >= as.numeric(lev)))
        }
      } else {
        for(lev in levels){
          if(lev != baseLevel) set(contrasts, j=paste0(y, ".", lev), value=1*(contrasts$factor==lev))
        }
      }
      # EMBlemFactor
      EMBlemFactor <- EMBlemFactor(levels=levels, baseLevel=baseLevel, contrasts=contrasts)
      # output
      return(EMBlemGroupedFac(lookupTbl=lookupTbl, parentFactor=parentFactor, EMBlemFactor=EMBlemFactor, ordered=ordered))
    })
    names(listOfGroupedFacs) <- colNames[-1]
    return(listOfGroupedFacs)
  }))
  
  ### variates
  variateFiles <- list.files(path = paste0(dir, "Variates"), pattern = "*.csv", ignore.case = TRUE)
  variates <- unlist(lapply(variateFiles, function(x){
    colNames <- names(fread(paste0(dir, "Variates/", x), nrows=0, showProgress=FALSE))
    parentFactor <- colNames[[1]]
    listOfVariates <- lapply(colNames[-1], function(y) {
      # Read in lookup table
      colClass <- c("character", "numeric")
      names(colClass) <- c(parentFactor, y)
      lookupTbl <- fread(paste0(dir, "Variates/", x), select=c(parentFactor, y), colClasses=colClass, showProgress=FALSE)
      # Find parent levels & base level
      parentLevels <- facFile@factors[[parentFactor]]@levels
      parentBaseLevel <- facFile@factors[[parentFactor]]@baseLevel
      # Convert characters to factors maintaining levels and set key
      lookupTbl[[parentFactor]] <- factor(lookupTbl[[parentFactor]], levels=parentLevels)
      setkeyv(lookupTbl, parentFactor)
      # valueAtBase
      valueAtBase <- lookupTbl[[y]][which(lookupTbl[[parentFactor]]==parentBaseLevel)]
      # output
      if(anyNA(lookupTbl[[2]])) return(0)
      return(EMBlemVariate(lookupTbl=lookupTbl, parentFactor=parentFactor, valueAtBase=valueAtBase))
    })
    names(listOfVariates) <- colNames[-1]
    listOfVariates[which(sapply(listOfVariates, identical, y=0))] <- NULL
    return(listOfVariates)
  }))
  
  ### offsets
  offsetFiles <- list.files(path = paste0(dir, "Offsets"), pattern = "*.csv", ignore.case = TRUE)
  offsets <- lapply(offsetFiles, function(x){
    colNames <- names(fread(paste0(dir, "Offsets/", x), nrows=0, showProgress=FALSE))
    offsetPos <- which(colNames=="offset")
    offsetColClasses <- c(rep("character", offsetPos-1), "numeric")
    names(offsetColClasses) <- colNames[1:offsetPos]
    colNames <- colNames[which(offsetColClasses!="NULL")]
    offset <- fread(paste0(dir, "Offsets/", x), colClasses=offsetColClasses, select=colNames[1:offsetPos], showProgress=FALSE)
    # Convert characters to factors maintaining levels and set key
    for(i in seq(1, length(colNames)-1)){
      parentLevels <- facFile@factors[[colNames[i]]]@levels
      offset[[colNames[i]]] <- factor(offset[[colNames[i]]], levels=parentLevels)
    }
    setkeyv(offset, colNames[-length(colNames)])
    return(EMBlemOffset(lookupTbl=offset))
  })
  
  if(length(groupedFactors)==0) groupedFactors <- list()
  if(length(variates)==0) variates <- list()
  
  if(trim){
    # Remove factor definitions not required by the model terms
    ## grouped factors and variates
    if(length(groupedFactors)>0) groupedFactors[which(sapply(names(groupedFactors), function(x) !(x %in% usedAttributes)))] <- NULL
    if(length(variates)>0) variates[which(sapply(names(variates), function(x) !(x %in% usedAttributes)))] <- NULL
    ## facFile
    simpleFactors <- intersect(names(facFile@factors), usedAttributes)
    groupFactors <- sapply(groupedFactors, function(x) names(x@lookupTbl)[1])
    variateFactors <- sapply(variates, function(x) names(x@lookupTbl)[1])
    offsetFactors <- unlist(lapply(offsets, function(x) key(x@lookupTbl)))
    
    requiredFactors <- unique(c(simpleFactors, groupFactors, variateFactors, offsetFactors))
    facFile@factors[which(sapply(names(facFile@factors), function(x) !(x %in% requiredFactors)))] <- NULL
  }
  
  return(EMBlemModel(facFile=facFile,
                     terms=terms,
                     groupedFactors=groupedFactors,
                     variates=variates,
                     offsets=offsets))
}
###############################


#####  getRequiredFactors  #####
#' Function to find the factors that are required to build a model.
#' @description The function takes an Emblem model object and returns a character vector containin the names of the factors required for building a the model.
#' @usage getRequiredFactors(x)
#' @param x An object of class EMBlemModel
#' @return A character vector of the required factors for building a model using the supplied EMBlemModel object.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #factorsNeeded <- getRequiredFactors(EMBlemModel)
#' @export

getRequiredFactors <- function(x){
  if(!is(x, "EMBlemModel")) return("The parameter x must be an EMBlemModel object.")
  
  usedAttributes <- unique(c(x@terms$factor1, x@terms$factor2, x@terms$factor3))
  usedAttributes <- usedAttributes[which(nchar(usedAttributes)>0)]
  
  simpleFactors <- intersect(names(x@facFile@factors), usedAttributes)
  groupFactors <- sapply(x@groupedFactors, function(y) names(y@lookupTbl)[1])
  variateFactors <- sapply(x@variates, function(y) names(y@lookupTbl)[1])
  offsetFactors <- unlist(lapply(x@offsets, function(y) key(y@lookupTbl)))
  
  requiredFactors <- unique(c(simpleFactors, groupFactors, variateFactors, offsetFactors))
  return(requiredFactors)
}
################################


#####  getRatingTables  #####
#' Function to create rating table style output from a list of model coefficients.
#' @description This function creates rating table style output when given a set of model coefficients and a corresponding EMBlemModelMap object.
#' @usage getRatingTables(coefficients, EMBlemModelMap)
#' @param coefficients Output from applying the coef function to a model to extract model coefficients or glmFit$coefficients where glmFit is a model generated by the glm function.
#' @param EMBlemModelMap An EMBlemModelMap object that can be used to create a design matrix that the coefficients would apply to.
#' @return A object of class EMBglm.
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #ratingTbls <- getRatingTables(glmFit$coefficients, EMBlemModelMap)
#' @export

getRatingTables <- function(coefficients, EMBlemModelMap){
  # Make sure coefficients are named-numeric with name matching design matrix names
  if(class(coefficients) == "matrix"){
    coefNames <- gsub("`", "", rownames(coefficients))
    coefficients <- as.numeric(coefficients[, 1])
    names(coefficients) <- coefNames
  } else names(coefficients) <- gsub("`", "", names(coefficients))
  
  # Find names of features
  featureNames <- do.call(c, lapply(EMBlemModelMap@lookupList, function(x){
    setdiff(names(x), key(x))
  }))
  
  # If any features in the coefficients don't exist in the model map return an error message
  if(any(!names(coefficients)[-1] %in% featureNames)) {
    missingFeats <- names(coefficients)[-1][which(!names(coefficients)[-1] %in% featureNames)]
    stop(paste0("Specified model map does not contain definitions for the following features: ", paste0(missingFeats, collapse = ", ")))
  }
  
  # If any features in the model map don't exist in the coefficents, add zeros and return a warning message
  missingCoefs <- featureNames[which(!featureNames %in% names(coefficients))]
  if(length(missingCoefs) > 0){
    newCoefs <- rep(0, length(missingCoefs)) # zeroes = neutral ok...
    names(newCoefs) <- missingCoefs
    coefficients <- c(coefficients, newCoefs)
    warning(paste0("Coefficients don't exist for the following features: ", paste0(missingCoefs, collapse = ", "), ". Assuming zero."))
  }
  
  # Function to create a rating table formatted ready to combine.
  ## type=1 are tables based on coefs, otherwise tables based on offsets.
  createTbl <- function(x, type=1){
    ways <- length(key(x))
    returnTbl <- copy(x[, key(x), with=FALSE])
    if(ways<2) returnTbl[, Level2 := ""]
    if(ways<3) returnTbl[, Level3 := ""]
    setnames(returnTbl, names(returnTbl), c("Level1", "Level2", "Level3"))
    returnTbl[, Factor1 := key(x)[1]]
    if(ways<2) returnTbl[, Factor2 := ""] else returnTbl[, Factor2 := key(x)[2]]
    if(ways<3) returnTbl[, Factor3 := ""] else returnTbl[, Factor3 := key(x)[3]]
    if(type==1){
      nonKeyCols <- names(x)[-which(names(x) %in% key(x))]
      mat <- as.matrix(x[, nonKeyCols, with=FALSE])
      coefs <- coefficients[sapply(seq(1+length(key(x)), ncol(x)), function(i) which(names(coefficients)==names(x)[[i]]))]
      returnTbl[, Value := exp(apply(mat %*% coefs, 1, prod))]
    } else returnTbl[, Value := x$offset]
    setnames(returnTbl,
             c(paste0("Factor", order(key(x))), paste0("Level", order(key(x)))),
             c(paste0("Factor", seq(1, ways)), paste0("Level", seq(1, ways))))
    returnTbl <- returnTbl[, list(Factor1, Factor2, Factor3, Level1, Level2, Level3, Value)]
    returnTbl[, ':=' (ways=ways,
                      Order1=as.integer(Level1),
                      Order2=as.integer(Level2),
                      Order3=as.integer(Level3),
                      Level1=as.character(Level1),
                      Level2=as.character(Level2),
                      Level3=as.character(Level3))]
    setkey(returnTbl, Factor1, Factor2, Factor3, Order1, Order2, Order3)
    return(returnTbl)
  }
  
  # Get combined rating table from coefficients
  ratingTbls1 <- c(list(data.table(Factor1="", Factor2="", Factor3="",
                                   Level1="", Level2="", Level3="",
                                   Value=exp(as.numeric(coefficients)[1]),
                                   ways = 0,
                                   Order1 = 1, Order2 = 1, Order3 = 1)),
                   lapply(EMBlemModelMap@lookupList, createTbl))
  
  # Get combined rating table from offsets
  ratingTbls2 <- lapply(EMBlemModelMap@offsets, function(x) createTbl(x@lookupTbl, type=2))
  
  # Combine, checking for uniqeness of factors and merging any matches
  facs1 <- lapply(ratingTbls1, function(x) c(x$Factor1[[1]], x$Factor2[[1]], x$Factor3[[1]]))
  for(tbl in ratingTbls2){
    facs <- c(tbl$Factor1[[1]], tbl$Factor2[[1]], tbl$Factor3[[1]])
    matchIndex <- which(sapply(facs1, function(x) identical(x, facs)))
    if(length(matchIndex)==0) ratingTbls1 <- c(ratingTbls1, list(tbl)) else {
      tbl2 <- ratingTbls1[[matchIndex]]
      tbl <- tbl[tbl2][, Value := Value*i.Value]
      tbl <- tbl[, list(Factor1, Factor2, Factor3, Level1, Level2, Level3, Value, ways, Order1, Order2, Order3)]
      ratingTbls1[[matchIndex]] <- tbl
    }
  }
  
  # Formating and combining into a single table
  ratingTbl <- rbindlist(ratingTbls1, fill = TRUE)
  setkey(ratingTbl, ways, Factor1, Factor2, Factor3, Order1, Order2, Order3)
  ratingTbl <- ratingTbl[, list(Factor1, Factor2, Factor3, Level1, Level2, Level3, Value)]
  ratingTbl[is.na(Factor2), `:=`(Factor2 = "", Level2 = "")]
  ratingTbl[is.na(Factor3), `:=`(Factor3 = "", Level3 = "")]
  if(length(which(ratingTbl$Factor3 != ""))==0) ratingTbl[, ':=' (Factor3=NULL, Level3=NULL)]
  if(length(which(ratingTbl$Factor2 != ""))==0) ratingTbl[, ':=' (Factor2=NULL, Level2=NULL)]
 
  ratingTbl <- rebaseEMBglm(as.EMBglm(ratingTbl), EMBlemModelMap)
  
  return(ratingTbl)
}
#############################


#####  EMBAppendStats  #####
#' Function to append summary statistics from a data table to a rating table.
#' @description The function takes an Emblem-style data table with a weight and response column (and optionally a set of model predictions)
#' and summarises them by each factor or combination of factors specified by the EMBglm object.
#' @usage EMBAppendStats(dt, ratingTbl, Response="Response", Weight="Weight", predictionCols=character(0))
#' @param dt A data table with the required columns.
#' @param ratingTbl An EMBglm object which is a model in the form of a rating tables object (with columns: Factor1, Factor2, ..., Level1, Level2, ..., Value.)
#' @param Response A character vector - the name of the response column in dt. Default: "Response".
#' @param Weight Either NULL or a character vector - the name of the (unweighted) exposure column in dt. Default: "Weight".
#' @param predictionCols A character vector naming any prediction columns in dt to be summarised (default is a character vector of length zero.)
#' @return A rating tables style data table with summary stats appended.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #ratingTblWithStats <- EMBAppendStats(dt, ratingTbl, predictionCols=c("GLM_preds", "XGB_Preds"))
#' @export

EMBAppendStats <- function(
  dt,
  ratingTbl,
  Response="Response",
  Weight="Weight",
  predictionCols=character(0)
){
  
  # Validation
  validate.EMBglm(ratingTbl)
  
  # Find type
  if (! is.null(attributes(ratingTbl)$type)){
    origType <- attributes(ratingTbl)$type
  } else origType <- NULL
  
  # Number of factor columns
  facCols <- colnames(ratingTbl)[substr(colnames(ratingTbl), 1, 6) == "Factor"]
  nFac <- length(facCols)
  
  # Factors in ratingTbl
  factors <- unique(rbindlist(lapply(seq(1, nFac), function(i){
    dt <- ratingTbl[, paste0("Factor", i), with=FALSE]
    setnames(dt, "Factor")
    return(dt)
  })))
  factors <- factors[Factor != ""]
  
  # Take copies to avoid changing anything in the parent environment
  ratingTbl <- copy(ratingTbl)
  dt <- copy(dt[, c(factors$Factor, Response, Weight, predictionCols), with=FALSE])
  
  # If Weight isn't specified
  if (is.null(Weight)){
    dt[, zz__Weight := 1]
    Weight <- "zz__Weight"
  }
  
  # Frequencies / averages to Counts / totals
  set(dt, j=Response, value=dt[[Response]]*dt[[Weight]])
  for (x in predictionCols){
    set(dt, j=x, value=dt[[x]]*dt[[Weight]])
  }
  
  # Find the value columns
  valCols <- grep("Value", colnames(ratingTbl), value = TRUE)
  
  # Other columns
  otherCols <- colnames(ratingTbl)[which(! colnames(ratingTbl) %in% c(valCols, paste0("Factor", seq(1, nFac)), paste0("Level", seq(1, nFac))))]
  if (length(otherCols) > 0){
    origOtherCols <- otherCols
    otherCols <- paste0("OtherCol", 1:length(otherCols))
    setnames(ratingTbl, origOtherCols, otherCols)
  }
  levCols <- paste0("Level", seq(1, nFac))
  
  # Tables in ratingTbl
  tables <- unique(ratingTbl[, facCols, with=FALSE])
  tables[, ways := sapply(1:nrow(tables), function(i){
    nFac - length(which(tables[i] == ""))
  })]
  
  summary <- rbindlist(
    lapply(1:nrow(tables), function(i){
      facs <- as.character(tables[i, facCols, with=FALSE])
      ways <- nFac - length(which(facs == ""))
      summary <- dt[, lapply(.SD, sum), .SDcols=c(Response, Weight, predictionCols), by=c(facs[which(facs != "")])]
      for (j in 1:nFac){
        set(summary, j=paste0("Factor", j), value=facs[j])
        if (j <= ways){
          setnames(summary, facs[j], paste0("Level", j))
        } else{
          set(summary, j=paste0("Level", j), value="")
        }
      }
      # Undo totals/counts back to frequency/averages
      set(summary, j=Response, value=summary[[Response]]/summary[[Weight]])
      for (x in predictionCols){
        set(summary, j=x, value=summary[[x]]/summary[[Weight]])
      }
      summary <- summary[, c(facCols, levCols, Weight, Response, predictionCols), with=FALSE]
      return(summary)
    })
  )
  
  # Merge with rating table then output
  ratingTbl <- ratingTbl[, zz__order := .I]
  setkeyv(ratingTbl, c(facCols, levCols))
  setkeyv(summary, c(facCols, levCols))
  
  ratingTbl <- summary[ratingTbl]
  set(ratingTbl, i=which(is.na(ratingTbl[[Weight]])), j=Weight, value=0)
  setkey(ratingTbl, zz__order)
  
  ratingTbl <- ratingTbl[, c(facCols, levCols, valCols, otherCols, Weight, Response, predictionCols), with=FALSE]
  if (length(otherCols) > 0) setnames(ratingTbl, otherCols, origOtherCols)
  ratingTbl <- as.EMBglm(ratingTbl, type=origType)
  return(ratingTbl)
}


#############################


#####  appendStatsToRatingTbl  #####
#' Function to append summary statistics from a data table to a rating table.
#' @description The function takes a data table with exposure, samplingWeight and response columns (and optionally a set of model predictions) and summarises them by each factor or combination of factors specified by the EMBlemModel object.
#' @usage appendStatsToRatingTbl(dt, ratingTbl, responseCol="Response", exposureCol=NULL, samplingWeightCol=NULL, predictionCols=character(0))
#' @param dt A data table with the required columns.
#' @param ratingTbl A model in the form of a rating tables object (with columns: Factor1, Factor2, ..., Level1, Level2, ..., Value.)
#' @param responseCol A character vector - the name of the response column in dt.
#' @param exposureCol Either NULL (default) or a character vector - the name of the (unweighted) exposure column in dt.
#' @param samplingWeightCol Either NULL (default) or a character vector - the name of the weight column in dt.
#' @param predictionCols A character vector naming any prediction columns in dt to be summarised (default is a character vector of length zero.)
#' @return A rating tables style data table with summary stats appended.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #ratingTblWithStats <- appendStatsToRatingTbl(dt, ratingTbl, responseCol="response", predictionCols=c("GLM_preds", "XGB_Preds"))
#' @export

appendStatsToRatingTbl <- function(dt, ratingTbl, responseCol="Response", exposureCol=NULL, samplingWeightCol=NULL, predictionCols=character(0)){
  # Validation
  validate.EMBglm(ratingTbl)
  if(!is.null(ratingTbl$Factor4)) stop("Currently only supports interactions of up to 3 factors.")
  
  startColNames <- names(ratingTbl)
  
  # If columns don't exist, create as blank
  ratingTbl <- copy(ratingTbl)
  if(is.null(ratingTbl$Factor3)) ratingTbl[, ':=' (Factor3 = "", Level3 = "")]
  if(is.null(ratingTbl$Factor2)) ratingTbl[, ':=' (Factor2 = "", Level2 = "")]
  
  # Find unique tables
  uniqueTbls <- unique(ratingTbl[, list(Factor1, Factor2, Factor3)])
  
  # Create summary table
  fullSummary <- rbindlist(lapply(seq(1, nrow(uniqueTbls)), function(i) {
    factor1 <- uniqueTbls[i][["Factor1"]]
    factor2 <- uniqueTbls[i][["Factor2"]]
    factor3 <- uniqueTbls[i][["Factor3"]]
    # Ways = 0
    if(factor1==""){
      # Table with required columns
      table <- dt[, c(samplingWeightCol, exposureCol, responseCol, predictionCols), with=FALSE]
      # Apply exposure to predictions
      if(is.null(exposureCol)) {
        exposureCol <- "exposure"
        set(table, j = exposureCol, value = 1)
      } else {
        for (x in predictionCols) set(table, j = x, value = table[[x]]*table[[exposureCol]])
      }
      # Apply weights to all columns
      if(!is.null(samplingWeightCol)){
        for (x in c(exposureCol, responseCol, predictionCols)) set(table, j = x, value = table[[x]]*table[[samplingWeightCol]])
        set(table, j = samplingWeightCol, value=NULL)
      }
      # summarise
      summary <- table[, lapply(.SD, sum), .SDcols=c(exposureCol, responseCol, predictionCols)]
      for (x in c(responseCol, predictionCols)) set(summary, j = x, value = summary[[x]]/summary[[exposureCol]])
      # format
      summary[, ':=' (Factor1 = "", Factor2 = "", Factor3 = "", Level1="", Level2="", Level3="")]
      
      # Ways = 1
    } else if(factor2==""){
      # Table with required columns
      table <- dt[, c(factor1, samplingWeightCol, exposureCol, responseCol, predictionCols), with=FALSE]
      # Apply exposure to predictions
      if(is.null(exposureCol)) {
        exposureCol <- "exposure"
        set(table, j = exposureCol, value = 1)
      } else {
        for (x in predictionCols) set(table, j = x, value = table[[x]]*table[[exposureCol]])
      }
      # Apply weights to all columns
      if(!is.null(samplingWeightCol)){
        for (x in c(exposureCol, responseCol, predictionCols)) set(table, j = x, value = table[[x]]*table[[samplingWeightCol]])
        set(table, j = samplingWeightCol, value=NULL)
      }
      # summarise
      summary <- table[, lapply(.SD, sum), by=eval(factor1), .SDcols=c(exposureCol, responseCol, predictionCols)]
      for (x in c(responseCol, predictionCols)) set(summary, j = x, value = summary[[x]]/summary[[exposureCol]])
      # format
      summary[, ':=' (Factor1 = factor1, Factor2 = "", Factor3 = "", Level2="", Level3="")]
      setnames(summary, factor1, "Level1")
      
      # Ways = 2
    } else if(factor3==""){
      # Table with required columns
      table <- dt[, c(factor1, factor2, samplingWeightCol, exposureCol, responseCol, predictionCols), with=FALSE]
      # Apply exposure to predictions
      if(is.null(exposureCol)) {
        exposureCol <- "exposure"
        set(table, j = exposureCol, value = 1)
      } else {
        for (x in predictionCols) set(table, j = x, value = table[[x]]*table[[exposureCol]])
      }
      # Apply weights to all columns
      if(!is.null(samplingWeightCol)){
        for (x in c(exposureCol, responseCol, predictionCols)) set(table, j = x, value = table[[x]]*table[[samplingWeightCol]])
        set(table, j = samplingWeightCol, value=NULL)
      }
      # summarise
      summary <- table[, lapply(.SD, sum), by=eval(paste0(factor1, ",", factor2)), .SDcols=c(exposureCol, responseCol, predictionCols)]
      for (x in c(responseCol, predictionCols)) set(summary, j = x, value = summary[[x]]/summary[[exposureCol]])
      # format
      summary[, ':=' (Factor1 = factor1, Factor2 = factor2, Factor3 = "", Level3="")]
      setnames(summary, c(factor1, factor2), c("Level1", "Level2"))
      
      # Ways = 3 
    } else {
      # Table with required columns
      table <- dt[, c(factor1, factor2, factor3, samplingWeightCol, exposureCol, responseCol, predictionCols), with=FALSE]
      # Apply exposure to predictions
      if(is.null(exposureCol)) {
        exposureCol <- "exposure"
        set(table, j = exposureCol, value = 1)
      } else {
        for (x in predictionCols) set(table, j = x, value = table[[x]]*table[[exposureCol]])
      }
      # Apply weights to all columns
      if(!is.null(samplingWeightCol)){
        for (x in c(exposureCol, responseCol, predictionCols)) set(table, j = x, value = table[[x]]*table[[samplingWeightCol]])
        set(table, j = samplingWeightCol, value=NULL)
      }
      # summarise
      summary <- table[, lapply(.SD, sum), by=eval(paste0(factor1, ",", factor2, ",", factor3)), .SDcols=c(exposureCol, responseCol, predictionCols)]
      for (x in c(responseCol, predictionCols)) set(summary, j = x, value = summary[[x]]/summary[[exposureCol]])
      # format
      summary[, ':=' (Factor1 = factor1, Factor2 = factor2, Factor3 = factor3)]
      setnames(summary, c(factor1, factor2, factor3), c("Level1", "Level2", "Level3"))
    }
    # Final formatting
    setkey(summary, Level1, Level2, Level3)
    summary[, ':=' (Level1 = as.character(Level1), Level2 = as.character(Level2), Level3 = as.character(Level3))]
    summary <- summary[, c("Factor1", "Factor2", "Factor3", "Level1", "Level2", "Level3", exposureCol, responseCol, predictionCols), with=FALSE]
    return(summary)
  }))
  
  if(is.null(exposureCol)) exposureCol <- "exposure"
  
  # Merge with rating table then output
  ratingTbl <- ratingTbl[, order := .I]
  setkey(ratingTbl, Factor1, Factor2, Factor3, Level1, Level2, Level3)
  setkey(fullSummary, Factor1, Factor2, Factor3, Level1, Level2, Level3)
  
  ratingTbl <- fullSummary[ratingTbl]
  set(ratingTbl, j = exposureCol, value=ifelse(is.na(ratingTbl[[exposureCol]]), 0, ratingTbl[[exposureCol]]))
  setkey(ratingTbl, order)
  ratingTbl <- ratingTbl[, c(startColNames, exposureCol, responseCol, predictionCols), with=FALSE]
  ratingTbl <- as.EMBglm(ratingTbl)
  return(ratingTbl)
}
##################################


#####  createEMBMap  #####
#' Function to create a map object to get from data to a design matrix or from model coefficients to rating table style output.
#' @description The function takes a data table and an EMBlemModel object and creates a map (index plus list of lookup tables)
#' @usage createEMBMap(dt, modelSpec, weightCol=NULL)
#' @param dt A data table containing all factors that are required based on the EMBlemModel object.
#' @param modelSpec An object of class EMBlemModel to apply to the data.
#' @param weightCol An optional column of weights (E.G. sampling weights).
#' @return An object of class EMBlemModelMap.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @importFrom gtools mixedorder
#' @examples
#' # modelMap <- createEMBMap(dt, modelSpec)
#' @export

createEMBMap <- function(dt, modelSpec, weightCol=NULL){
  ## Create expanded version of terms table from modelSpec
  terms <- copy(modelSpec@terms)
  
  # parent factors
  pf1 <- c(sapply(modelSpec@groupedFactors, function(x) x@parentFactor),
           sapply(modelSpec@variates, function(x) x@parentFactor))
  
  pf2 <- data.table(parentFactor=as.character(c(pf1, names(modelSpec@facFile@factors))),
                    factor=c(names(pf1), names(modelSpec@facFile@factors)),
                    type=c(rep("Grouped Factor", length(modelSpec@groupedFactors)),
                           rep("Variate", length(modelSpec@variates)),
                           rep("Simple Factor", length(modelSpec@facFile@factors))),
                    key="factor")
  
  setkey(terms, factor1)
  terms <- pf2[terms]
  setnames(terms, c("parentFactor", "factor", "type"), c("parentFactor1", "factor1", "type1"))
  
  setkey(terms, factor2)
  terms <- pf2[terms]
  setnames(terms, c("parentFactor", "factor", "type"), c("parentFactor2", "factor2", "type2"))
  
  setkey(terms, factor3)
  terms <- pf2[terms]
  setnames(terms, c("parentFactor", "factor", "type"), c("parentFactor3", "factor3", "type3"))
  
  terms[, ways := ifelse(factor2=="", 1, ifelse(factor3=="", 2, 3))]
  
  terms <- cbind(terms, t(apply(terms[, paste0("parentFactor", seq(1, 3)), with=FALSE], 1, mixedorder)))
  
  # Put in alphabetic order by parent factor
  terms <- terms[, ':=' (parentFactor1 = ifelse(V1==1, parentFactor1, ifelse(V1==2, parentFactor2, parentFactor3)),
                         parentFactor2 = ifelse(V2==1 & ways>=2, parentFactor1, ifelse(V2==2 | ways<2, parentFactor2, parentFactor3)),
                         parentFactor3 = ifelse(V3==1 & ways>=3, parentFactor1, ifelse(V3==2 | ways>=3, parentFactor2, parentFactor3)),
                         factor1 = ifelse(V1==1, factor1, ifelse(V1==2, factor2, factor3)),
                         factor2 = ifelse(V2==1 & ways>=2, factor1, ifelse(V2==2 | ways<2, factor2, factor3)),
                         factor3 = ifelse(V3==1 & ways>=3, factor1, ifelse(V3==2 | ways>=3, factor2, factor3)),
                         type1 = ifelse(V1==1, type1, ifelse(V1==2, type2, type3)),
                         type2 = ifelse(V2==1 & ways>=2, type1, ifelse(V2==2 | ways<2, type2, type3)),
                         type3 = ifelse(V3==1 & ways>=3, type1, ifelse(V3==2 | ways>=3, type2, type3)),
                         order1 = ifelse(V1==1, order1, ifelse(V1==2, order2, order3)),
                         order2 = ifelse(V2==1 & ways>=2, order1, ifelse(V2==2 | ways<2, order2, order3)),
                         order3 = ifelse(V3==1 & ways>=3, order1, ifelse(V3==2 | ways>=3, order2, order3))
  )][, c("V1", "V2", "V3") := NULL]
  
  
  # child Factors
  cf1 <- c(lapply(modelSpec@facFile@factors, function(x) names(x@contrasts)[-1]),
           lapply(modelSpec@groupedFactors, function(x) names(x@EMBlemFactor@contrasts)[-1]))
  cf2 <- data.table(factor=unlist(lapply(names(cf1), function(x) rep(x, length(cf1[[x]])))),
                    childFactor=unlist(cf1),
                    key="factor")
  
  setkey(terms, factor1)
  terms <- cf2[terms]
  setnames(terms, c("factor", "childFactor"), c("factor1", "childFactor1"))
  
  setkey(terms, factor2)
  terms <- cf2[terms]
  setnames(terms, c("factor", "childFactor"), c("factor2", "childFactor2"))
  
  setkey(terms, factor3)
  terms <- cf2[terms]
  setnames(terms, c("factor", "childFactor"), c("factor3", "childFactor3"))
  
  terms <- terms[, list(term, ways,
                        parentFactor1, parentFactor2, parentFactor3,
                        factor1, factor2, factor3,
                        childFactor1, childFactor2, childFactor3,
                        type1, type2, type3,
                        order1, order2, order3)]
  
  setkey(terms, ways, parentFactor1, parentFactor2, parentFactor3, factor1, factor2, factor3, childFactor1, childFactor2, childFactor3, order1, order2, order3, term)
  
  terms[, ':='(childFactor1 = ifelse(type1=="Variate", paste0(factor1, " (OPoly(", order1, "))"), childFactor1),
               childFactor2 = ifelse(type2=="Variate", paste0(factor2, " (OPoly(", order2, "))"), childFactor2),
               childFactor3 = ifelse(type3=="Variate", paste0(factor3, " (OPoly(", order3, "))"), childFactor3))][, ':=' (
                 designMatrixColName = ifelse(ways==1, childFactor1, ifelse(ways==2, paste0(childFactor1, ":", childFactor2), paste0(childFactor1, ":", childFactor2, ":", childFactor3))))]
  
  
  ## Now create lookup tables against parent factors for each column of the design matrix
  # Find list of factors needed for variates
  facsForVariates <- unique(c(terms$parentFactor1[which(terms$type1=="Variate" & !is.na(terms$parentFactor1))],
                              terms$parentFactor2[which(terms$type2=="Variate" & !is.na(terms$parentFactor2))],
                              terms$parentFactor3[which(terms$type3=="Variate" & !is.na(terms$parentFactor3))]))
  
  # Keep only required columns
  dt <- dt[, c(facsForVariates, weightCol), with=FALSE]
  
  # Find the polynomial orders required for each variate
  orderTbl <- rbindlist(list(modelSpec@terms[! is.na(order1), list(variate=factor1, order=order1)],
                             modelSpec@terms[! is.na(order2), list(variate=factor2, order=order2)],
                             modelSpec@terms[! is.na(order3), list(variate=factor3, order=order3)]))
  setkey(orderTbl, variate, order)
  orderTbl <- unique(orderTbl)
  
  # Create list of lookups for orthogonal variates of differing polynomial order
  varLookupList <- lapply(modelSpec@variates, function(x){
    # Merge on variate
    setkeyv(dt, key(x@lookupTbl))
    dt <- dt[x@lookupTbl, nomatch=0]
    vecName <- names(x@lookupTbl)[2]
    # Create vectors and weights containing all possible values of variate appended to bottom
    vec <- c(x@lookupTbl[[vecName]], dt[[vecName]])
    if(is.null(weightCol)) w <- c(rep(0, nrow(x@lookupTbl)), rep(1, nrow(dt))) else w <- c(rep(0, nrow(x@lookupTbl)), dt[[vecName]])
    # Scale variate to have sd=1 and have value=0 at base level
    meanVec <- weighted.mean(vec, w)
    sdVec <- sqrt(sum(w * (vec - meanVec)^2)/ sum(w))
    vec <- scale(vec, center=x@valueAtBase, scale=sdVec)
    order <- orderTbl[variate==vecName][["order"]]
    if(max(order)>1){
      mat <- sapply(seq(1, max(order)), function(i) vec^i)
      mat <- sapply(seq(1, ncol(mat)), function(i) if(i==1) mat[, 1] else {
        matCol <- residuals(lm(mat[, i] ~ mat[, seq(1, i-1)]-1, weights=w), type="response")
        meanMatCol <- weighted.mean(matCol, w)
        sdMatCol <- sqrt(sum(w * (matCol - meanMatCol)^2)/ sum(w))
        return(scale(matCol, scale=sdMatCol))
      })
      mat <- mat[, order]
      lookupTbl <- data.table(fac=x@lookupTbl[[1]], mat[seq(1, nrow(x@lookupTbl)), ])
    } else lookupTbl <- data.table(fac=x@lookupTbl[[1]], vec[seq(1, nrow(x@lookupTbl))])
    setnames(lookupTbl, names(lookupTbl), c(names(x@lookupTbl)[[1]], paste0(vecName, " (OPoly(", order, "))")))
    setkeyv(lookupTbl, names(x@lookupTbl)[[1]])
    return(lookupTbl)
  })
  
  # Create list of lookups for grouped factors with dummy columns for design matrix
  gfLookupList <- lapply(modelSpec@groupedFactors, function(x){
    lookupTbl <- copy(x@lookupTbl)
    if(names(lookupTbl)[[2]] %in% c(terms$factor1, terms$factor2, terms$factor3)){
      parentFactor <- names(lookupTbl)[[1]]
      setkeyv(lookupTbl, names(lookupTbl)[[2]])
      lookupTbl <- copy(x@EMBlemFactor@contrasts[lookupTbl])
      lookupTbl <- lookupTbl[, c(parentFactor, names(x@EMBlemFactor@contrasts)[-1]), with=FALSE]
      setkeyv(lookupTbl, parentFactor)
      return(lookupTbl)
    } else return(NULL)
  })
  gfLookupList <- gfLookupList[!sapply(gfLookupList, is.null)]
  
  # Create list of lookups for simple factors with dummy columns for design matrix
  simpleLookupList <- lapply(modelSpec@facFile@factors, function(x){
    lookupTbl <- copy(x@contrasts)
    if(names(lookupTbl)[[1]] %in% c(terms$factor1, terms$factor2, terms$factor3)){
      return(lookupTbl)
    } else return(NULL)
  })
  simpleLookupList <- simpleLookupList[!sapply(simpleLookupList, is.null)]
  
  # Combine lookup tables
  combinedLookupList <- c(varLookupList, gfLookupList, simpleLookupList)
  
  requiredFactors <- unique(c(terms$parentFactor1,
                              terms$parentFactor2[which(!is.na(terms$parentFactor2))],
                              terms$parentFactor3[which(!is.na(terms$parentFactor3))]))
  
  reducedLookupList <- lapply(requiredFactors, function(x){
    tblList <- combinedLookupList[which(sapply(combinedLookupList, key)==x)]
    return(Reduce(merge, tblList))
  })
  
  # Two-way interactions
  if(nrow(terms[ways==2])>0){
    twoWayInteractions <- unique(apply(terms[ways==2], 1, function(x) list(c(x[["parentFactor1"]], x[["parentFactor2"]]))))
    
    twoWayLookups <- lapply(twoWayInteractions, function(x){
      pf1 <- unlist(x)[1]
      pf2 <- unlist(x)[2]
      childFactors <- terms[ways==2 & parentFactor1==pf1 & parentFactor2==pf2][, list(childFactor1, childFactor2)]
      tbl1 <- reducedLookupList[which(sapply(reducedLookupList, key)==pf1)][[1]][, c(pf1, unique(childFactors[["childFactor1"]])), with=FALSE]
      tbl2 <- reducedLookupList[which(sapply(reducedLookupList, key)==pf2)][[1]][, c(pf2, unique(childFactors[["childFactor2"]])), with=FALSE]
      crossJoinTbl <- CJ(tbl1[[1]], tbl2[[1]])
      setnames(crossJoinTbl, names(crossJoinTbl), c(pf1, pf2))
      setkeyv(crossJoinTbl, pf2)
      crossJoinTbl <- tbl2[crossJoinTbl]
      setkeyv(crossJoinTbl, pf1)
      crossJoinTbl <- tbl1[crossJoinTbl]
      for(i in seq(1, nrow(childFactors))){
        cF1 <- childFactors$childFactor1[i]
        cF2 <- childFactors$childFactor2[i]
        crossJoinTbl[[paste0(cF1, ":", cF2)]] <- crossJoinTbl[[cF1]]*crossJoinTbl[[cF2]]
      }
      crossJoinTbl[, unique(c(childFactors$childFactor1, childFactors$childFactor2)) := NULL]
      setkeyv(crossJoinTbl, c(pf1, pf2))
      return(crossJoinTbl)
    })
  } else twoWayLookups <- list()
  
  # Three-way interactions
  if(nrow(terms[ways==3])>0){
    threeWayInteractions <- unique(apply(terms[ways==3], 1, function(x) list(c(x[["parentFactor1"]], x[["parentFactor2"]], x[["parentFactor3"]]))))
    
    threeWayLookups <- lapply(threeWayInteractions, function(x){
      pf1 <- unlist(x)[1]
      pf2 <- unlist(x)[2]
      pf3 <- unlist(x)[3]
      childFactors <- terms[ways==3 & parentFactor1==pf1 & parentFactor2==pf2 & parentFactor3==pf3][, list(childFactor1, childFactor2, childFactor3)]
      tbl1 <- reducedLookupList[which(sapply(reducedLookupList, key)==pf1)][[1]][, c(pf1, unique(childFactors[["childFactor1"]])), with=FALSE]
      tbl2 <- reducedLookupList[which(sapply(reducedLookupList, key)==pf2)][[1]][, c(pf2, unique(childFactors[["childFactor2"]])), with=FALSE]
      tbl3 <- reducedLookupList[which(sapply(reducedLookupList, key)==pf3)][[1]][, c(pf3, unique(childFactors[["childFactor3"]])), with=FALSE]
      crossJoinTbl <- CJ(tbl1[[1]], tbl2[[1]], tbl3[[1]])
      setnames(crossJoinTbl, names(crossJoinTbl), c(pf1, pf2, pf3))
      setkeyv(crossJoinTbl, pf3)
      crossJoinTbl <- tbl3[crossJoinTbl]
      setkeyv(crossJoinTbl, pf2)
      crossJoinTbl <- tbl2[crossJoinTbl]
      setkeyv(crossJoinTbl, pf1)
      crossJoinTbl <- tbl1[crossJoinTbl]
      for(i in seq(1, nrow(childFactors))){
        cF1 <- childFactors$childFactor1[i]
        cF2 <- childFactors$childFactor2[i]
        cF3 <- childFactors$childFactor3[i]
        crossJoinTbl[[paste0(cF1, ":", cF2, ":", cF3)]] <- crossJoinTbl[[cF1]]*crossJoinTbl[[cF2]]*crossJoinTbl[[cF3]]
      }
      crossJoinTbl[, unique(c(childFactors$childFactor1, childFactors$childFactor2, childFactors$childFactor3)) := NULL]
      setkeyv(crossJoinTbl, c(pf1, pf2, pf3))
      return(crossJoinTbl)
    })
  } else threeWayLookups <- list()
  
  # Combine
  lookupListCombined <- c(reducedLookupList, twoWayLookups, threeWayLookups)
  # Remove lookup columns that are not in final design matrix
  lookupListCombined <- lapply(lookupListCombined, function(x){
    dColNames <- setdiff(names(x), key(x))
    keepList <- dColNames[which(dColNames %in% terms$designMatrixColName)]
    if(length(keepList)==0) return(NULL)
    return(x[, c(key(x), keepList), with=FALSE])
  })
  lookupListCombined <- lookupListCombined[!sapply(lookupListCombined, is.null)]
  
  # Return
  return(EMBlemModelMap(expandedTerms=terms, lookupList=lookupListCombined, offsets=modelSpec@offsets, facFile=modelSpec@facFile))
}
##########################

#####  getDesignMatrix  #####
#' Function to get a design matrix from a data table and an EMBModelMap object.
#' @description The function takes a data table that includes all required factors
#' and applies a model map to it to produce a design matrix for regression-type modelling.
#' @usage getDesignMatrix(dt, EMBModelMap)
#' @param dt A data table with the required factor columns.
#' @param EMBModelMap An object of class EMBlemModelMap.
#' @return A matrix with named columns.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #designMatrix <- getDesignMatrix(dt, EMBModelMap)
#' @export

getDesignMatrix <- function(dt, EMBModelMap){
  RequiredFacs <- unique(unlist(sapply(EMBModelMap@lookupList, key)))
  dt <- dt[, RequiredFacs, with=FALSE]
  dt[, order := .I]
  
  # Function to merge
  mergeCols <- function(lookupTbl){
    setkeyv(dt, key(lookupTbl))
    return(dt[lookupTbl, nomatch=0])
  }
  
  # Merge on design columns
  for(x in EMBModelMap@lookupList){
    dt <- mergeCols(x)
  }
  
  dt[, (RequiredFacs) := NULL]
  setkey(dt, order)
  dt[, order := NULL]
  offset <- apply(as.matrix(dt), 1, prod)
  return(as.matrix(dt))
}
#############################


#####  getModelOffsets  #####
#' Function to get a vector of offsets to apply in a model.
#' @description The function takes a data table that includes all required factors and an EMBlemModel or EMBlemModelMap object and returns a vector of offsets to apply (without applying any link function to the offsets).
#' @usage getModelOffsets(dt, modelSpec)
#' @param dt A data table with the required factor columns.
#' @param modelSpec An object of class EMBlemModel or EMBlemModelMap.
#' @return A numeric vector.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table key setkeyv setkey setnames set
#' @examples
#' #offsets <- getModelOffsets(dt, EMBModelSpec)
#' @export

getModelOffsets <- function(dt, modelSpec){
  RequiredFacs <- unique(unlist(sapply(modelSpec@offsets, function(x) key(x@lookupTbl))))
  dt <- dt[, RequiredFacs, with=FALSE]
  dt[, order := .I]
  
  # Function to merge
  mergeCols <- function(lookupTbl){
    setkeyv(dt, key(lookupTbl))
    return(dt[lookupTbl, nomatch=0])
  }
  
  # Merge on offsets
  for(x in modelSpec@offsets){
    dt <- mergeCols(x@lookupTbl)
  }
  
  # Combine and return
  dt[, (RequiredFacs) := NULL]
  setkey(dt, order)
  dt[, order := NULL]
  offset <- apply(as.matrix(dt), 1, prod)
  return(offset)
}
#############################


#############################
#####  createContrasts  #####
#' Function to create a valid contrasts table from a factor given the levels and baselevel.
#' @description From the levels and base level, create a contrasts data table.
#' @usage createContrasts(
#'  facName,
#'  levels,
#'  baseLevel
#')
#' @param facName The name of the factor.
#' @param levels Levels of the factor.
#' @param levels Levels of the factor.
#' @return A data table.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @importFrom data.table data.table setnames set setkeyv
#' @examples
#' # createContrasts(
#' #   facName = "PHAge",
#' #   levels = as.character(seq(18, 80)),
#' #   baseLevel = "50"
#' # )
#' @export
#' 
createContrasts <- function(
  facName,
  levels,
  baseLevel
){
  if (! all(sapply(list(facName, levels, baseLevel), is.character))){
    stop("All arguments must be character vectors")
  }
  if (length(facName) != 1){
    stop("facName must be a single name")
  }
  if (length(baseLevel) != 1){
    stop("baseLevel must be a single level")
  }
  if (length(levels) < 2){
    stop("Must be at least 2 levels")
  }
  if (! baseLevel %in% levels){
    stop("baseLevel must be one of the levels")
  }
  
  baseRow <- which(levels == baseLevel)
  
  mat <- diag(nrow = length(levels) - 1)
  mat2 <- matrix(0, nrow = length(levels), ncol = length(levels) - 1)
  mat2[-baseRow, ] <- mat[]
  
  colnames(mat2) <- paste0(facName, ".", levels[-baseRow])
  
  contrasts <- data.table(
    fac = factor(levels)
  )
  setnames(contrasts, "fac", facName)
  
  contrasts <- cbind(contrasts, mat2)
  
  setkeyv(contrasts, facName)
  
  return(contrasts)
}

#############################
###########################################