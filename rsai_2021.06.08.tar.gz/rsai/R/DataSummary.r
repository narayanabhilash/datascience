#' DataSummary
#'
#' @description This function allows you to have a summary about the given dataset.
#' @usage DataSummary(data,missing=c(NA),sparkline=FALSE)
#' @param data This could be data frame,data.table or a vector.
#' @param missing A vector of string values that all values will be treated as missing.
#' E,g, missing = c("NA","","-99") will treat NA, blank and -99 as missing values.
#' @param sparkline logical. If true, a string of level percentage will be generated, which can be used later in `shiny` app with `sparkline` package.
#' @details This function provides a data summary including min, max, number of unique values and number if missing values.
#' The min and max will ignore missing value in the data.
#' 
#' The number of unique levels includes the NA.
#' @author Sixiang Hu
#' @importFrom data.table data.table := uniqueN
#' @export DataSummary
#' @examples
#' DataSummary(mtcars)

DataSummary <- function(data,missing=c(NA),sparkline=FALSE){
  UseMethod("DataSummary",data)
}

#' @export
#' @rdname DataSummary
DataSummary.data.frame <- function(data,missing=c(NA),sparkline=FALSE){

  dt <- data.table::data.table(data)
  DataSummary.data.table(dt,missing,sparkline)
}

#' @export
#' @rdname DataSummary
DataSummary.data.table <- function(data,missing=c(NA),sparkline=FALSE){

  dsName    <- names(data) 
  dsClass   <- data[,sapply(.SD,function(x) ifelse(length(class(x))>1,class(x)[1],class(x)))]
  dsNLevels <- data[,sapply(.SD,function(x) uniqueN(x))]
  dsMiss    <- data[,sapply(.SD,function(x) sum(as.character(x) %in% missing))]
  
  dsMean    <- data[,sapply(.SD,function(x){
    if(is.numeric(x) || is.integer(x)) as.character(round(sum(x,na.rm = TRUE)/length(x),6))
    else {"NA"}
    })]

  dsMax    <- data[,sapply(.SD,function(x){
    if(is.numeric(x) || is.integer(x)) as.character(round(max(x,na.rm = TRUE),6))
    else {
      x.dt<-data.table::data.table(x)
      dsTemp <- as.character(x.dt[,V1:=.N,by=x][order(-V1)][1,list(x)])
      if(is.null(dsTemp) || is.na(dsTemp)) as.character(x.dt[,V1:=.N,by=x][order(-V1)][2,list(x)])
      else dsTemp
    }
  })]
  
  dsMin    <- data[,sapply(data,function(x){
    if(is.numeric(x) || is.integer(x)) as.character(round(min(x,na.rm = TRUE),6))
    else {
      x.dt<-data.table::data.table(x)
      dsTemp <- as.character(x.dt[,V1:=.N,by=x][order(V1)][1,list(x)])
      if(is.null(dsTemp) || is.na(dsTemp)) as.character(x.dt[,V1:=.N,by=x][order(V1)][2,list(x)])
      else dsTemp
    }
  })]
  
  if (sparkline) {
    dsStr <- data[,sapply(data,function(x) {
      freq <- data.table::data.table(x)[,.N,by=x][order(x)][,f:=N/sum(N)]
      if (dim(freq)[1]>=100) return("More than 100 levels")
      else return(paste0(round(freq[,f],3),collapse= ","))
    })]
    
    return(data.frame("VarName"=dsName,
                      "VarType"=dsClass,
                      "Unique"=dsNLevels,
                      "Missing"=dsMiss,
                      "Mean"=dsMean,
                      "Min"=dsMin,
                      "Max"=dsMax,
                      "%Distribution"=dsStr))
  }
  else{
    return(data.frame("VarName"=dsName,
                      "VarType"=dsClass,
                      "Unique"=dsNLevels,
                      "Missing"=dsMiss,
                      "Mean"=dsMean,
                      "Min"=dsMin,
                      "Max"=dsMax))
  }
}

#global variable
globalVariables(c("V1",".N","f","N",".SD"))
