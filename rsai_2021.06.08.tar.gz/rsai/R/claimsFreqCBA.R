#####  claimsFreqCBA  #####
#' Benefit analysis for new claims frequency models
#' @description For use when you have built a new claims frequency model to replace a current model.
#' This will calculate the benefit in projected change in portfolio loss ratio.
#' This function needs to be run on hold-out data - it will always overestimate benefit if run on the data you trained your model with.
#' You need to create a dataset where each row of data represents exposure to a risk or group of risks.
#' You need observed claims frequency and the expected claims frequencies for both the current and new model (claims counts can also be used by setting 'claimCounts' to TRUE)
#' as well as the overall exposure for each row. You can then include a number of assumptions about the portfolio.
#' The output is relatively sensitive to these assumptions, you can test this yourself. The function is designed so that
#' you can run at a high level, for example by grouping your data into 10 decile groups using the ratio of your 2 models and assuming
#' that elasticity, claims severity, loss ratio etc. are constant across all 10 groups. This will give you a good rule of thumb
#' for the potential benefit in implementing the model. You could also run at a much lower level by using raw exposure data where
#' each row corresponds to an exposure for a single risk, and you could score on your severity model and models for other perils
#' so you can get best estimates per row for every assumption being made
#' (including using a demand model to generate individual estimates of price elasticity.)
#' THIS FUNCTION IS NOW DEPRECATED: all its features are replicable using `claimsCBA`.
#' @usage claimsFreqCBA(obs,
#' new,
#' old,
#' exposure,
#' severity=NULL,
#' elasticity=-1,
#' perilProp=1,
#' lossRatio=1,
#' minRateChange=NULL,
#' maxRateChange=NULL,
#' claimCounts=FALSE)
#' @param obs A vector of observed claims frequency (or claim counts if 'claimCounts' is TRUE)
#' @param new A vector of predicted claims frequency (or claim counts if 'claimCounts' is TRUE) for the new claims frequency model
#' @param old A vector of predicted claims frequency (or claim counts if 'claimCounts' is TRUE) for the current (old) claims frequency model
#' @param exposure A vector of total exposure for each row (or a scalar if all exposures are constant)
#' @param severity Optional - the average expected claims severity for each row for the peril being modelled. If not specified, routine assumes a constant expected claims severity per row.
#' @param elasticity Elasticity. Either a constant value or a vector if you want to assume that elasticity varies for each row of data. Elasticity is the (\% change in demand) / (\% change in price)
#' @param perilProp Proportion of the total burning cost for the peril being modelled. Either a constant value or a vector if this varies by row.
#' @param lossRatio Loss ratio across all perils. Either a constant value or a vector if you want to assume this varies by row.
#' @param minRateChange Optional - the biggest negative price change away from current model we are allowed to make for the peril being modelled.
#' @param maxRateChange Optional - the biggest positive price change away from current model we are allowed to make for the peril being modelled.
#' @param claimCounts Logical. If TRUE then 'obs', 'new' and 'old' are assumed to refer to claims counts rather than claims frequency per exposure period.
#' @return A list of KPIs relating to the projected new scenario, E.G. projected loss ratio change.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # newModelBenefitAnalysis <- claimsFreqCBA(
#' #   obs            =  holdOutData$observedClaimsFreq,
#' #   new            =  holdOutData$expectedClaimsFreq_challenger,
#' #   old            =  holdOutData$expectedClaimsFreq_champion,
#' #   exposure       =  holdOutData$exposure,
#' #   severity       =  holdOutData$currentSeverityModelPredictions,
#' #   elasticity     =  -3,
#' #   perilProp      =  0.2,
#' #   lossRatio      =  0.8,
#' #   minRateChange  =  -0.2,
#' #   maxRateChange  =  0.25)
#' @export

claimsFreqCBA <- function(obs,
                          new,
                          old,
                          exposure,
                          severity=NULL,
                          elasticity=-1,
                          perilProp=1,
                          lossRatio=1,
                          minRateChange=NULL,
                          maxRateChange=NULL,
                          claimCounts=FALSE){
  
  warning("This function is deprecated: claimsCBA suggested")
  
  # If severity is not specified just assume constant
  if(is.null(severity)) severity <- 1 
  
  # Validation - parameter length
  if(length(obs) < 2) stop("Length of 'obs' must be at least 2")
  if(length(old) != length(obs)) stop("'old' must be the same length as 'obs'")
  if(length(new) != length(obs)) stop("'new' must be the same length as 'obs'")
  if(!length(exposure) %in% c(1, length(obs))) stop("'exposure' must either be length 1 or the same length as 'obs'")
  if(!length(severity) %in% c(1, length(obs))) stop("'severity' must either be length 1 or the same length as 'obs'")
  if(!length(elasticity) %in% c(1, length(obs))) stop("'elasticity' must either be length 1 or the same length as 'obs'")
  if(!length(perilProp) %in% c(1, length(obs))) stop("'perilProp' must either be length 1 or the same length as 'obs'")
  if(!length(lossRatio) %in% c(1, length(obs))) stop("'lossRatio' must either be length 1 or the same length as 'obs'")
  if(!is.null(minRateChange)) if(length(minRateChange)!=1) stop("Length of minRateChange must be 1")
  if(!is.null(maxRateChange)) if(length(maxRateChange)!=1) stop("Length of maxRateChange must be 1")
  if(length(claimCounts)!=1) stop("Length of claimCounts must be 1")
  
  # Validation - parameter class
  if(!is.numeric(obs)) stop("'obs' must be numeric")
  if(!is.numeric(old)) stop("'old' must be numeric")
  if(!is.numeric(new)) stop("'new' must be numeric")
  if(!is.numeric(exposure)) stop("'exposure' must be numeric")
  if(!is.numeric(severity)) stop("'severity' must be numeric")
  if(!is.numeric(elasticity)) stop("'elasticity' must be numeric")
  if(!is.numeric(perilProp)) stop("'perilProp' must be numeric")
  if(!is.numeric(lossRatio)) stop("'lossRatio' must be numeric")
  if(!is.null(minRateChange)) if(!is.numeric(minRateChange)) stop("'minRateChange' must be numeric")
  if(!is.null(maxRateChange)) if(!is.numeric(maxRateChange)) stop("'maxRateChange' must be numeric")
  if(!is.logical(claimCounts)) stop("'claimCounts' must be numeric")
  
  # Validation - NAs
  if(anyNA(obs)) stop("'obs' contains NAs")
  if(anyNA(old)) stop("'old' contains NAs")
  if(anyNA(new)) stop("'new' contains NAs")
  if(anyNA(exposure)) stop("'exposure' contains NAs")
  if(anyNA(severity)) stop("'severity' contains NAs")
  if(anyNA(elasticity)) stop("'elasticity' contains NAs")
  if(anyNA(perilProp)) stop("'perilProp' contains NAs")
  if(anyNA(lossRatio)) stop("'lossRatio' contains NAs")
  if(anyNA(minRateChange)) stop("'minRateChange' contains NAs")
  if(anyNA(maxRateChange)) stop("'maxRateChange' contains NAs")
  if(anyNA(claimCounts)) stop("'claimCounts' contains NAs")
  
  # Are observed and expected given in claims Counts rather than claims Frequency?
  if(claimCounts){
    obs <- obs/exposure
    old <- old/exposure
    new <- new/exposure
  }
  
  # Ensure elasticity is negative
  elasticity <- -abs(elasticity)
  
  # Average Current Peril Premium
  AvPerilPrem <- old*severity
  
  # Average Current Premium
  AvCurrentPrem <- (AvPerilPrem/perilProp)/lossRatio
  
  # Current "GWP"
  currentGWP <- exposure*AvCurrentPrem
  
  # Model ratio
  modelRatio <- new/old
  
  # Peril rate change
  perilRateChange <- modelRatio-1
  if(!is.null(minRateChange)) perilRateChange <- pmax(minRateChange, perilRateChange)
  if(!is.null(maxRateChange)) perilRateChange <- pmin(maxRateChange, perilRateChange)
  
  # Function to find baseChange that maintains total volume of premium written when minimised
  minFunc <- function(baseChange){
    # Difference in premiums
    premRateChange <- (perilRateChange*AvPerilPrem/AvCurrentPrem+1)*(baseChange+1)-1
    # Volume change using elasticity
    volChange <- exp(premRateChange*elasticity)-1
    # New exposure levels
    newExposure <- exposure*(volChange+1)
    # New "GWP"
    newGWP <- currentGWP*(1+premRateChange)*(1+volChange)
    return((sum(newGWP)-sum(currentGWP))^2) # return sum of squares
  }
  
  # Find the base change that minimises change in volume of premium written
  baseChange <- optimise(minFunc, c(-0.5, 1), tol=1e-06)$minimum
  
  # Difference in premiums
  premRateChange <- (perilRateChange*AvPerilPrem/AvCurrentPrem+1)*(baseChange+1)-1
  
  # Volume change using elasticity
  volChange <- exp(premRateChange*elasticity)-1
  
  # New exposure levels
  newExposure <- exposure*(volChange+1)
  
  # New "GWP"
  newGWP <- currentGWP*(1+premRateChange)*(1+volChange)
  
  # Current peril Burning Cost
  currentBC <- exposure*obs*severity
  
  # New peril Burning Cost
  newBC <- newExposure*obs*severity
  
  # Peril Loss Ratios
  currentPerilLossRatio <- sum(currentBC)/sum(currentGWP)
  newPerilLossRatio <- sum(newBC)/sum(newGWP)
  
  # Loss ratio change
  lossRatioChange <- newPerilLossRatio-currentPerilLossRatio
  
  if(sprintf("%.2f%%", 100*sum(newGWP)/sum(currentGWP)) != "100.00%"){
    warning("Projected premium written in new scenario does not match current scenario. Routine may not have converged on a sensible base rate change. Check your results carefully!")
  }
  
  # Print scenario results to 
  cat("New model scenario tested using assumptions provided.\n")
  cat(paste0("## Overall premium written is ",
             sprintf("%.2f%%", 100*sum(newGWP)/sum(currentGWP)),
             " of current scenario using a base rate adjustment of ",
             sprintf("%.2f%%", 100*baseChange),
             ".\n"))
  cat(paste0("## Projected change in claims costs for this peril: ",
             sprintf("%.2f%%", 100*(sum(newBC)/sum(currentBC)-1)),
             ".\n"))
  cat(paste0("## Current peril-only loss ratio: ",
             sprintf("%.2f%%", 100*currentPerilLossRatio),
             ".\n"))
  cat(paste0("## Projected peril-only loss ratio: ",
             sprintf("%.2f%%", 100*newPerilLossRatio),
             ".\n"))
  cat(paste0("## Assuming that price changes are L/R neutral for other perils, loss ratio benefit: ", sprintf("%.2f%%", -100*lossRatioChange), "\n"))
  return(list(ProjectedWrittenPremium = sum(newGWP)/sum(currentGWP),
              BasePriceAdjustment = baseChange,
              ProjectedChangeInPerilClaimsCosts = sum(newBC)/sum(currentBC)-1,
              CurrentPerilLossRatio = currentPerilLossRatio,
              ProjectedPerilLossRatio = newPerilLossRatio,
              LossRatioChange = lossRatioChange))
}