#####################################################
# groupingEncoder
#####################################################

#' Create a factor encoder grouping levels together.
#' @description Create an encoder function for factor data where levels can be grouped together in a custom way.
#' @usage groupingEncoder(
#'  x,
#'  colname,
#'  groupingList,
#'  otherLevel = FALSE
#')
#' @param x A factor vector to encode.
#' @param colname The name of your factor as a character.
#' This will affect the column names of the matrix created by the encoder.
#' @param groupingList A list of character vectors.
#' Each element of the list corresponds to a column in the final matrix.
#' Each element of each character vector should correspond to a level in your factor.
#' The resulting column will be a 1 if the level matches one of the levels specified and a zero otherwise.
#' @param otherLevel If TRUE, the encoder will add a final column which corresponds to all the levels
#' which haven't been specified in any of the other columns.
#' @return A function. It is this resulting function that can be used as an encoder for new data of the same form.
#' @importFrom Matrix Matrix
#' @examples 
#' # # Create a factor based on LETTERS drawn at random
#' # n <- 1000
#' # set.seed(1984)
#' # x <- factor(sample(LETTERS, n, replace=TRUE), levels=LETTERS)
#' # 
#' # # Run groupingEncoder to create an encoding function
#' # myEncoder <- groupingEncoder(
#' #   x,
#' #   "LETTERS",
#' #   groupingList = list(
#' #     Vowels = c("A", "E", "I", "O", "U"),
#' #     B = "B",
#' #     C = "C",
#' #     D = "D",
#' #     Z = "Z"
#' #   ),
#' #   otherLevel = TRUE
#' # )
#' # 
#' # # Run the resulting encoding function to create a matrix
#' # mat <- myEncoder(x)
#' @export
#' @author Edwin Graham


groupingEncoder <- function(
  x,
  colname,
  groupingList,
  otherLevel = FALSE
){
  # Validate x
  if (! is.factor(x)){
    stop("x must be a factor")
  }
  
  # Levels is all we need
  levs <- levels(x)
  rm(x)
  
  # Validate groupingList
  if (! is.list(groupingList)){
    stop("groupingList must be a list")
  }
  if (! all(sapply(groupingList, is.character))){
    stop("groupingList must be a list of character vectors")
  }
  if (! all(unlist(groupingList) %in% levs)){
    stop("groupingList entries must all correspond to levels in x")
  }
  
  # Validate colname
  if (is.null(colname)){
    stop("Please specify the name of your factor in the `colname` argument")
  }
  if (! is.character(colname)){
    stop("colname must be a character")
  }
  if (length(colname) != 1){
    stop("colname must be length 1")
  }
  
  # Give names to groupingList
  if (is.null(names(groupingList))){
    names(groupingList) <- paste0("Col", seq_along(groupingList))
  }
  
  # Add other level to groupingList
  if (otherLevel){
    otherLevels <- levs[which(! levs %in% unlist(groupingList))]
    if (length(otherLevels) > 0){
      groupingList <- c(groupingList, list(Other=otherLevels))
    }
  }
  
  # Make names unique
  names(groupingList) <- make.names(names(groupingList), unique = TRUE)
  
  # Create function
  returnFunction <- function(x, trainMode=FALSE, sparse=FALSE){
    # Validate
    if (! is.factor(x)){
      stop("x must be a factor")
    }
    if (! setequal(levels(x), levs)){
      stop("x must have the same levels as were defined when building the encoder")
    }
    
    # Create a matrix
    if (sparse){
      mat <- do.call(rbind, lapply(groupingList, function(lev){
        Matrix(1 * (x %in% lev), sparse = TRUE)
      }))
    } else {
      mat <- sapply(groupingList, function(lev){
        1 * (x %in% lev)
      })
    }
    
    colnames(mat) <- paste0(colname, "~grouping~", names(groupingList))
    
    return(mat)
  }
  
  # Return
  return(returnFunction)
  
}




