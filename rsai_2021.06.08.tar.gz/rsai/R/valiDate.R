#####  valiDate  #####
#' Function to decide a date format
#' @description takes (potential) date data and tries to discern its y/d/m format,
#' consistent with formatting used by `as.Date`.
#' Tries ISO 8601 first and then various alternatives, returning the first
#' format which appears to fit, so you won't get warned if the format is ambiguous.
#' Use ISO 8601. 
#' @usage valiDate(dates, tolerance = 0.9)
#' @param dates The putative dates.
#' @param tolerance proportion of the dates which need to meet the returned format.
#' You probably won't get too many false positives.
#' @return a character field for the date format, or NA if not found.
#' @author Tom Bratcher
#' @examples
#' valiDate("2013-02-27") # This is the _correct_ format
#' valiDate("2013-02-27:01:30:22") # Also good, but you just get the date
#' valiDate("05MAR1976")
#' valiDate("3/5/76")  
#' valiDate("rsai")
#' @export 
valiDate <- function(dates, tolerance = 0.9){
  
  dates <- as.character(dates)
  Encoding(dates)<- "unknown" # otherwise get weird UTF8 errors 
  # remove missing values from dates:
  dates <- dates[!is.na(dates)]
  dates <- dates[nchar(dates) > 0]
  if (!(length(dates))) return (NA)
  #formats = c ("^[0-9]{1,4}[/-][0-9]{1,2}[/-][0-9]{2,4}")
  #grepl(formats, "2011-02-23")
  #but want the actual format returned:
  grepFormats = c(
    "^[0-9]{4}[-][01]{0,1}[0-9][-][0-3]{0,1}[0-9]",# ISO 8601, or near enough
    "^[0-9]{4}[/][01]{0,1}[0-9][/][0-3]{0,1}[0-9]",# You were _so_ close
    "^[0-3]{0,1}[0-9][/][01]{0,1}[0-9][/][0-9]{4}",# dd/mm/yyyy
    "^[0-3]{0,1}[0-9][-][01]{0,1}[0-9][-][0-9]{4}",# dd-mm-yyyy
    "^[0-3]{0,1}[0-9][/][01]{0,1}[0-9][/][0-9]{2}",# dd/mm/yy
    "^[0-3]{0,1}[0-9][-][01]{0,1}[0-9][-][0-9]{2}",# dd-mm-yy
    "^[01]{0,1}[0-9][A-y]{3}[0-9]{4}",# ddmmmyyyy
    "^[01]{0,1}[0-9][A-y]{3}[0-9]{2}",# ddmmmyy
    "^[01]{0,1}[0-9][-][A-y]{3}[-]{0,1}[0-9]{4}",# dd-mmm-yyyy
    "^[01]{0,1}[0-9][-][A-y]{3}[-][0-9]{2}",# dd-mmm-yy
    "^[01]{0,1}[0-9][/][A-y]{3}[/][0-9]{4}",# dd/mmm/yyyy
    "^[01]{0,1}[0-9][/][A-y]{3}[/][0-9]{2}",# dd/mmm/yy
    "^[01]{0,1}[0-9][/][0-3]{0,1}[0-9][/][0-9]{4}",# America LAST 
    "^[01]{0,1}[0-9][-][0-3]{0,1}[0-9][-][0-9]{4}",
    "^[01]{0,1}[0-9][/][0-3]{0,1}[0-9][/][0-9]{2}", 
    "^[01]{0,1}[0-9][-][0-3]{0,1}[0-9][-][0-9]{2}" 
    )
  returnFormats = c(
    "%Y-%m-%d", # I love you...
    "%Y/%m/%d", # ...I hate you
    "%d/%m/%Y", 
    "%d-%m-%Y", 
    "%d/%m/%y", 
    "%d-%m-%y",
    "%d%b%Y",
    "%d%b%y",
    "%d-%b-%Y",
    "%d-%b-%y",
    "%d/%b/%Y",
    "%d/%b/%y",
    "%m/%d/%Y", 
    "%m-%d-%Y", 
    "%m/%d/%y", 
    "%m-%d-%y"
  )

  for (i in seq_along(grepFormats)){ 
    # find a consistently used format
  if (mean(grepl(grepFormats[i], dates)) >= tolerance) return (returnFormats[i])  
  }
  NA
  }
  
