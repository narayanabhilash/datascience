#####  getMode  #####
#' Function to find mode.
#' @description This function gets the mode. Tie-breaker is which value occurs first in the data.
#' @usage getMode(x, na.rm=FALSE)
#' @param x Vector to get mode from
#' @param na.rm ignore missing values?
#' @return The mode of the vector
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #getMode(c(1, 2, 3, 3, 3, 3))
#' @export

getMode <- function(x, na.rm=FALSE) {
  uniq <- unique(x)
  if(na.rm) uniq <- uniq[!is.na(uniq)]
  uniq[which.max(tabulate(match(x, uniq)))]
}


#####  Weighted.mode  #####
#' Function to find mode.
#' @description This function gets the mode but includes an optional weight
#' @usage weighted.mode(x, w, na.rm=FALSE)
#' @param x Vector to get mode from
#' @param w Vector of weights (or just a constant)
#' @param na.rm ignore missing values?
#' @return The mode of the vector
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' letters <- sample(LETTERS, 1000, replace=TRUE)
#' weights <- runif(1000) 
#' weighted.mode(
#'   letters,
#'   weights
#' )

#' @export

weighted.mode <- function(x, w = 1, na.rm = FALSE){
  if (! length(w) %in% c(1, length(x))) stop("Argument w is of wrong length.")
  # Use data table
  dt <- data.table(x=x, w=w, i=1:length(x))
  if (na.rm) dt<-dt[!(is.na(x))]
  if (nrow(dt) == 0) return(x[1])
  dt2 <- dt[, .(w=sum(-w), i=min(i)), by="x"] # is is first row, used for tie-breaker
  setkey(dt2, w, i) # order by descending weight and first row
  return(dt2[1, x])
}