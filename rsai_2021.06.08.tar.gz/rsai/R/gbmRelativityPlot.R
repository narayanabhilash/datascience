#' Plot relativity functions for GBM objects
#' 
#' @description This function is designes to produce the closest possible GBM equivalent to
#' relativity plots that would arise from GLMs. These are either produced in
#' separate graphics windows, or as separate files.
#' 
#' %% ~~ If necessary, more details than the description above ~~
#' @usage gbmRelativityPlot(x, pattern = "", vars = x$var.names, device = c("dev.new", "pdf", "png"), filestart = "")
#' @param x A \code{gbm} object.
#' @param pattern A pattern describing the variables to produce plots against.
#' @param vars A character vector of variables to produce plots against. Should
#' be a subset of \code{x$var.names}, and any that don't match will be ignored.
#' If both \code{vars} and \code{pattern} are specified, \code{pattern} "wins".
#' @param device An option determining where the output is plotted. The default
#' is "dev.new", which in interactive use produces a plot in the R window.
#' Other options output to their respective file types.
#' @param filestart A prefix for the files produced. Not used if \code{device
#' == "dev.new"} and used interactively. Defaults to \code{substitute(x)}. Can
#' also include directories, if you want to save elsewhere than the current
#' working directory.
#' @return NULL, invisibly.
#' @note %% ~~further notes~~
#' @author James Lawrence
#' @seealso %% ~~objects to See Also as \code{\link{help}}, ~~~
#' @references The \code{gbm} package, in particular \code{plot.gbm}.
#' @export
#' @importFrom gbm plot.gbm
#' @examples
#' 
#' ##---- Should be DIRECTLY executable !! ----
#' ##-- ==>  Define data, use random,
#' ##--	or do  help(data=index)  for the standard data sets.
#' 
#' ## The function is currently defined as
#' function (x, pattern = "", vars = x$var.names, device = c("dev.new", 
#'     "pdf", "png"), filestart = "") 
#' {
#'     device <- match.arg(device)
#'     if (missing(filestart)) 
#'         filestart <- substitute(x)
#'     if (!missing(pattern)) {
#'         vind <- grep(pattern, x$var.names)
#'     }
#'     else {
#'         vind <- match(vars, x$var.names)
#'     }
#'     for (i in seq_along(vind)) {
#'         if (is.na(vind[i])) 
#'             next
#'         switch(device, dev.new = dev.new(xpos = (i - 1) * -25 - 
#'             10, ypos = 30 * (i - 1), title = x$var.names[vind[i]]), 
#'             pdf = pdf(fn <- paste0(filestart, ".", x$var.names[vind[i]], 
#'                 ".pdf")), png = png(fn <- paste0(filestart, ".", 
#'                 x$var.names[vind[i]], ".png")), stop("can't start the graphics device"))
#'         plot(x, i = vind[i])
#'         if (device != "dev.new") {
#'             cat("wrote to file", fn, "\n")
#'             dev.off()
#'         }
#'     }
#'   }
#' 
gbmRelativityPlot <- function(x,pattern="",vars=x$var.names,device=c("dev.new","pdf","png"),filestart=""){
	device <- match.arg(device)
	if(missing(filestart)) filestart <- substitute(x)
	if(!missing(pattern)){
		vind <- grep(pattern,x$var.names)
	} else {
		vind <- match(vars,x$var.names)
	}
	for (i in seq_along(vind)){
		if(is.na(vind[i])) next
		switch(device,
			"dev.new"=dev.new(xpos=(i-1)*-25 - 10,ypos=30*(i-1),title=x$var.names[vind[i]]),
			"pdf"=pdf(fn <- paste0(filestart,".",x$var.names[vind[i]],".pdf")),
			"png"=png(fn <- paste0(filestart,".",x$var.names[vind[i]],".png")),
			stop("can't start the graphics device")
		)
		gbm::plot.gbm(x,i=vind[i])
		if(device != "dev.new"){
			cat("wrote to file",fn,"\n")
			dev.off()
		}
	}
}
