#' Produce and save out xgboost SHAP model effects and fit
#'
#' @description This function allows you to generate, store and organise xgboost SHAP
#' model diagnostics as html. It can also launch a shiny app 
#' that outputs the relative strength of the interactions. It is intended as the
#' "Shap" version of xgb.fi
#' @usage xgb.shapFi(
#' shapList,
#' plot_data,
#' model = NULL,
#' shapInteractions = NULL,
#' max.trees = -1, 
#' top.k = 100, 
#' output_dir = "./Shaphtml",
#' makeShiny = FALSE,
#' makeHTML = TRUE,
#' max_1way = 20,
#' max_2way = 20,
#' outputFormat = "html",
#' model_name = "model",
#' overwrite = T, 
#' plotShapArgs=list(), 
#' plotShapSumArgs=list(), 
#' plotResponseArgs=list(),
#' maps = NULL,
#' mapArgs = list(),
#' shortPath = FALSE,
#' autoWidth = FALSE
#' ) 
#'
#' @param shapList Required shap values List created from your model using `createShapValues`. 
#' @param plot_data Required data table - the original data table consistent with the shap list.
#'  Also used for 1 way A/E and/or maps.
#' @param model the xgboost model to calculate on. 
#' @param shapInteractions interactions data created by `createShapInteractions`.
#' Either `model` or `shapInteractions` must be supplied.
#' @param max.trees Upper limit for number of trees (default = -1, uses all of them)
#' @param top.k max number of interactions found from the model if shap interactions is not provided.
#' you can probably leave this. 
#' @param output_dir directory into which charts and data are saved.
#' @param makeShiny do you want a shiny app to open? You probably don't
#' @param makeHTML do you want html charts saved? You probably do.
#' @param max_1way maximum number of 1-way charts 
#' (i.e. value of X vs. shap value for feature X)
#' @param max_2way maximum number of 2-way charts 
#' (i.e. value of X vs. shap value for distinct interactive feature Y)
#' @param outputFormat "html" or "png" for interactive or picture (see note)
#' @param model_name the name given to the model within the html output 
#' @param overwrite if TRUE, function can overwrite existing output,
#'  otherwise an error is thrown where old output would be overwritten
#' @param plotShapArgs Optional list of extra non-default arguments passed to \code{plotShapDependence}.
#' note that by default, dataOut is set to TRUE so you get a data summary saved
#' @param plotShapSumArgs Optional list passed to \code{plotShapFeatureSummary}
#' @param plotResponseArgs other optional arguments list passed to \code{plotResponseByCol}- 
#' in particular you will likely want to pass some preds columns.
#' If not specified, these charts are not produced.
#' @param maps do you want maps via \code{plotLeafletMap}? if NULL (default) maps
#' are produced unless mapArgs is empty.
#' @param mapArgs other optional arguments list for maps. Note that maps are not
#' produced for factors. 
#' @param shortPath logical. Saves html files out with shorter paths: this makes them harder to
#' navigate but in some cases long variable names and directory paths cause failure, which this 
#' allows the user to get around.
#' @param autoWidth logical. Controls the \code{autoWidth} option in the \code{datatable} package used
#' to produce the html charts. Some users have found that columns are misaligned in the output.
#' This appears to be caused by changes to datatable in 2019: changing this variable may help.
#' @return NULL, invisibly.
#' @details The function will produce charts based on the strongest interactions suggested by
#' `shapInteractions` or, if not supplied, by `xgbfR`.
#' @note in order to produce png rather than html chart output you will need to install the "orca" 
#' plot_ly functionality: see the help file for `plotly::orca`` for details.
#' @seealso \code{plot.xgb.booster}, \code{plotLeafletMap}, \code{plotResponseFactor} .
#' @keywords xgboost, shap, xgbfi
#' @export
#' @examples
#' ## Not run:
#' # data ("UKTheftFreq") # gets dt_postcodes
#' # rowList <- list(train = UKTheftFreq[, which(year < 2016)],
#' #                 test = UKTheftFreq[, which(year == 2016)])
#' # modelVars <- setdiff(
#' #   names(UKTheftFreq),
#' #   c(
#' #     "exposure",
#' #     "numClaims",
#' #     "weight",
#' #     "offset",
#' #     "currentModel",
#' #     "foldId"
#' #   )
#' # )
#' # xgbData <- xgbSetupdata2(UKTheftFreq,
#' #                          response = "numClaims",
#' #                          explanatory_vars = modelVars,
#' #                          exposure = "exposure",
#' #                          sampleWeight = "weight",
#' #                          offset_model = "offset",
#' #                          rowIndicesList = rowList)
#' # 
#' # foldList <- folds_VecToList(UKTheftFreq[rowList$train, foldId])
#' # 
#' # param <- list(
#' #   objective = "count:poisson",
#' #   max_depth = 3L,           # tree-depth
#' #   subsample = 0.9,          # randomly sample rows before fitting each tree
#' #   colsample_bytree = 0.9,   # randomly sample columns before fitting each tree
#' #   min.child.weight = 20,    # minimum weight per leaf
#' #   eta = 0.08               # Learning rate
#' #   )
#' # set.seed(7857699L)
#' # 
#' # xgbFit <- xgb.train(
#' #   params                 = param,
#' #   data                   = xgbData$train,
#' #   nrounds                = 100,
#' #   base_score             = 1,
#' #   watchlist              = xgbData,
#' #   print_every_n          = 50
#' # )
#' # 
#' # UKTheftFreq$preds <-1
#' # UKTheftFreq[rowList$test, preds := predict(xgbFit, xgbData$test)]
#' # 
#' # shapList <- createShapValues (xgbFit, xgbData$test)
#' #
#' # xgb.shapFi(
#' #  shapList = shapList,
#' #  plot_data = UKTheftFreq[rowList$test],
#' #  model = xgbFit, 
#' #  plotResponseArgs = list (response = "numClaims",
#' #                           predCols = c("currentModel", "preds"),
#' #                           exposure = "exposure",
#' #                           weight = "weight",
#' #                           maxLevs = 40),
#' #       mapArgs = list (XY=c("coordinate_x","coordinate_y"),
#' #                       Country = "UK",
#' #                       legendPlacement = "topright")
#' #       )

xgb.shapFi <-
  function(
    shapList, # includese the featutyres
    plot_data,
    model = NULL,
    shapInteractions = NULL,
    max.trees = -1, # I guess
    top.k = 100, #xgbfi
    output_dir = "./Shaphtml", # change names for shap??
    makeShiny = FALSE,
    makeHTML = TRUE,
    max_1way = 20, # 
    max_2way = 20, # it's a lot of html. can we get plotly out as a pic? yes
    outputFormat = "html",
    model_name = "model", 
    overwrite = T, # does it already exist?
    plotShapArgs = list(), # optional args for plotShap
    plotShapSumArgs = list(), # opt args 4 plotshapsum
     # you will need this _It's the original data... 
    plotResponseArgs = list(), #REQUIRED?: arguments list for plotResponse
  # need to specify the response, for starters...
    maps = NULL,
    mapArgs = list(), # optional arguments list for map
    shortPath = FALSE,
    autoWidth = FALSE # WHAT DOES THIS EVEN DO??
) {
  #######   

# Issues list -------------------------------------------------------------

# because of construction order, get map links where maps are not desirable (factors) 
# if you save and reload models stuff gets lost: have I found it all?
# would / could function still work of xgb.dump (with stats, natch)    
    
###########    
  
  # model <- curr_model
  # features = colnames(xgb_data$dt_train)
  # outfile = output_dir
  # makeHTML = TRUE
  # model_name = "model"
  # xgbfi.loc = "C:/xgbfi"
  # max.interaction.depth = 2
  # max.deepening = -1
  # max.trees = -1
  # top.k = 100
  # max.histograms = 10
  # outfile = NULL
  # makeShiny = FALSE
  # max_1way = 10
  # max_2way = 5
    
    # 1. Quality Control ------------------------------------------------------

    buildInts <- (max_2way > 0)
    
    if (is.null(shapInteractions)) {
      if (is.null(model))
        stop ("shap interactions or model object required")

    # xgbfr for xgboost model:
     if (inherits(model, "xgb.Booster")){
    xgbfRtables <- xgbfR(
      model,
      features = shapList$xgbAttributes$.Dimnames[[2]],
      top.k = top.k,
      condenseSeparator = "~",
      max.interaction.depth = 1, # for now
      max.trees = max.trees
    )
    if (1 >= length(xgbfRtables)){
      buildInts <- F
      cat("Model appears to be of max depth 1: \n No interactions built.\n")
    } else cat(
      "SHAP interactions not supplied: \n Interactions chosen using xgb.fr \n")
     } else {
       if(!(inherits(model,"H2ORegressionModel")))
         stop ("Unsupported model type: model must be h2o gbm or xgboost")
       xgbfRtables <- h2ofR(
         model,
         top.k = top.k
       )
       buildInts <- as.logical(ncol(xgbfRtables[[2]]))
       # add interaction depth warnings?
     } 
      
      
  } else {
      # MOAR? most quality tests in dependence plot anyway
    temp <- summariseShapInteractions(shapInteractions)
    if(max(temp$shap.dispersion) == 0){
      buildInts <- F
      cat("No significant interactions found \n")
    }
  }
    
    if (is.null(maps)) maps <- length(mapArgs) > 0
    

  # 3. HTML bits ------------------------------------------------------------
 
  #!?
  
    suffix <- paste0(".",outputFormat)
    
       tableVars1 <- function(shinyBits = F){ # seriously?... doubt we need this as a function
         
     
      featuresimp <- data.table(
        Feature = c(shapList$rankedImportance),
        SHAPscore = c(shapList$meanAbsShap)
      )
      featuresimp <- featuresimp[SHAPscore > 0]
      # want this in the summary really but...
      
      
      if (!(shinyBits)){
        Top <- data.table(
          Feature = c("~Summary~"),
          SHAPscore = 0,
          '1 way PD' = "<a href=\".\\CHT_ParDep_1way\\shapSummary.png\">Summary</a>",
          '1 way AvE' = "",
          Map = ""
          
        )

      featuresimp[, '1 way PD' := paste0("<a href=\".\\CHT_ParDep_1way\\1way_", .I,  "_", Feature, suffix,"\">Par Dep</a>")]
      featuresimp[, '1 way AvE' := paste0("<a href=\".\\CHT_AvE_1way\\", .I, "_", Feature, suffix,"\">AvE</a>")]
      featuresimp[, 'Map' := paste0("<a href=\".\\CHT_MAP\\", .I, "_", Feature, suffix,"\">Map</a>")]

      # shortNames:
      if (shortPath){
        featuresimp[, '1 way PD' := paste0("<a href=\".\\CHT_ParDep_1way\\1way_", .I, suffix,"\">Par Dep</a>")]
        featuresimp[, '1 way AvE' := paste0("<a href=\".\\CHT_AvE_1way\\", .I, suffix,"\">AvE</a>")]
        featuresimp[, 'Map' := paste0("<a href=\".\\CHT_MAP\\", .I, suffix,"\">Map</a>")]           
      }
      featuresimp[-1:-min(max_1way, nrow(featuresimp)),`:=`('1 way PD'="",'1 way AvE'="",Map="")] # yes, this works if max_1way is zero
      if(!(length(plotResponseArgs))) featuresimp[,'1 way AvE':=""]
      if(!(maps)) featuresimp[, Map:= ""] # not perfect because factor maps shouldn't exist...
     
      return(rbind(Top, featuresimp))
    } else {
      return(featuresimp)
      }
      
      
       }
       
       tableVars2 <- function(Varswitch = F, shinyBits = F){ #switch var1 and var 2 around
         if (is.null(shapInteractions)) {
           featuresimp <- xgbfRtables[[2]]
          featuresimp[, c("Var1", "Var2") := tstrsplit(Feature, "|", fixed=TRUE)]
          # remove any duplicates, which can happen still...
          featuresimp <- featuresimp[Var1!=Var2]
          featuresimp[, Gain.Percentage := round (Gain/sum(Gain), 4)]
          featuresimp[, Feature := NULL]
 
         } else {
           featuresimp <- summariseShapInteractions(shapInteractions)
           featuresimp[, c("Var1", "Var2") := tstrsplit(shap.interaction, "~x~", fixed=TRUE)]
           featuresimp <- featuresimp[1:min(.N, top.k)]
           featuresimp <- featuresimp[shap.dispersion > 0]
           featuresimp[, shap.interaction := NULL]
         }
         if(Varswitch) setnames(featuresimp, c("Var1", "Var2"), c("Var2", "Var1"))
         if (!(shinyBits)){
           featuresimp[, '2 way PD' := paste0("<a href=\".\\CHT_ParDep_2way\\2way_",.I,"_",
                                              featuresimp[.I,Var1],"_",
                                              featuresimp[.I,Var2], suffix,"\">Par Dep</a>")]
           if (shortPath){
             featuresimp[, '2 way PD' := paste0("<a href=\".\\CHT_ParDep_2way\\2way_", .I, suffix, "\">Par Dep</a>")]           
           }
           featuresimp[-1:-min(max_2way, .N),'2 way PD':=""]
           
         } 
         # reorder columns
         setcolorder(
           featuresimp,
           c("Var1", "Var2", colnames(featuresimp)[!colnames(featuresimp) %in% c("Var1", "Var2")]))
         return(featuresimp)
         
       }
       
       

    if (makeHTML){
    # Create 1 way partial dependency html table
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   
    featuresimp <- tableVars1()  
      
    sketch = htmltools::withTags(table(
     class = 'display',
     thead(
       tr(th(colspan = 5, paste0('Table 1: One way Shap importance for ',model_name))),
       tr(lapply(names(featuresimp), th))
     )
    ))
        output_Vars1 <- datatable(
          featuresimp,
          class = 'cell-border stripe',
          escape = FALSE,
          extensions = 'Buttons',
          container = sketch,
          rownames = FALSE,
          options = list(
            dom = 'Bfrtip',
            buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
            pageLength = 20,
            autoWidth = autoWidth
          )) %>% 
      formatStyle(
        'SHAPscore',
        background = styleColorBar(c(0, max(featuresimp$SHAPscore)), 'lightblue'),
        backgroundSize = '90% 80%',
        backgroundRepeat = 'no-repeat',
        backgroundPosition = 'center') %>%
          formatRound(
            columns = "SHAPscore",
            digits = 4
            ) 
          
        
    # check output folder exists before save.
    if((dir.exists(file.path (output_dir,"CHT_ParDep_1way")))){
      if (!(overwrite)) stop ("Output directories already exist. Either create a new directory or set overwrite to TRUE")
    } else dir.create(file.path(output_dir), recursive = T, showWarnings = F)
    saveWidget(widget = output_Vars1, file = paste0(normalizePath(output_dir), "\\output_Vars1.html"), selfcontained = TRUE)

    # Create 1 way partial dependency plots
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    if(inherits(model, "xgb.Booster")){
    # if you have a loaded and resaved model, niter doesn't get saved. LOVELY.
    # recover it:
    if (!("niter") %in% names(model)){
      model$niter = length (grep("^booster\\[",xgb.dump(model)))
    } 
    
  #  XLFile <- file.path(output_dir, paste0("DTab",gsub("[^0-9]","",Sys.time()),".xls"))
    ntrees <- ifelse(is.null(model$best_iteration), model$niter, model$best_iteration)
    }  else {
      ntrees <- model@model$model_summary$number_of_trees
    } 
   # make sure we have only one data set:
    if (length (plotResponseArgs) && length(mapArgs)) mapArgs$dt <- NULL
    
    # check folder exists before save. just use warnings false here....
    ifelse(!dir.exists(file.path (output_dir, "CHT_ParDep_1way")), dir.create(file.path (output_dir, "CHT_ParDep_1way")), FALSE)
    if (length (plotResponseArgs)){
      ifelse(!dir.exists(file.path (output_dir,"CHT_AvE_1way")), dir.create(file.path (output_dir, "CHT_AvE_1way")), FALSE)
    }
      if (length (mapArgs)){
        ifelse(!dir.exists(file.path (output_dir,"CHT_MAP")), dir.create(file.path (output_dir, "CHT_MAP")), FALSE)
    }
    # have we generated a warning?
    warned = F
 
#generate shap summary plot
   shapPlot <- do.call(
      plotShapFeatureSummary,
      c(list(listShap = shapList, newData = plot_data), plotShapSumArgs)
    )
    
    ggsave(
      "shapSummary.png",
      plot = shapPlot, # does it need to have been plotted? we'll see
      path = paste0(
        normalizePath(
          output_dir), "\\CHT_ParDep_1way"),
      width = 16,
      height = 16,
      units = "cm",
      dpi = "print"
    )
    
    # set up arguments for plot:
    nWayList <- plotShapArgs
    nWayList$listShapValues <- shapList 
    nWayList$data <- plot_data
    nWayList$data_int <- shapInteractions
     
    
    if("points" %in% names(nWayList)) {
      Points <- nWayList$points
      } else {
        Points <- min(5000, nrow(plot_data))
        
      }
    if(!("dataOut" %in% names(nWayList))) nWayList$dataOut <- TRUE
    # setup output data
    outData <- data.table(`Sample~Number` = 1:Points)
    cat("Plotting most important 1 way charts: \n")
    for (i in 1:max_1way) if(max_1way > 0) {
     
      varSTR = featuresimp[i + 1, Feature]
      if (is.na(varSTR)) {
        if (warned == F) warning ("Not that many features/interactions in the model")
        warned = T
        } else {

          cat(paste0(i," ", varSTR, "\n"))
    # add to nWayList and call:  
       nWayList$primaryFeature <- varSTR
      # get colour Feature:
       if(is.null(shapInteractions)){
         nWayList$colourFeature <- NULL
         string <- paste0("^",varSTR,"\\||\\|", varSTR, "$")
        intft <-  grep(string, xgbfRtables[[2]]$Feature)[1]
        if (!(is.na(intft))) nWayList$colourFeature <- gsub(
          string, "", xgbfRtables[[2]]$Feature[intft])

         }
      
      p <- do.call(plotShapDependence, nWayList) 
     
     # save out plot and data:
      tempStr <- paste0("_",varSTR)
      if (shortPath) tempStr <- ""
      if(!(is.null(p))){
      if (!inherits(p, "plotly")) {
        outData[, eval(varSTR) := p$data[,2]]
        if ("colour" %in% names (p$data)) outData[, eval(p$colour) := p$data$color_value]
        outData[, eval(paste0(p$shap,"~SHAP")) := p$data$shap]
        p <- p$plot
      }
      if(outputFormat == "html"){
        saveWidget(
          as_widget(p), paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1way_", i, tempStr,".html"))
       } else {
         orca(p,paste0(normalizePath(output_dir), "\\CHT_ParDep_1way\\1way_", i, tempStr, suffix) )
       }
      }
      # Create A/E charts using plotResonpseByCol:
      # set up arguments for plotresponseArgs:
   
      if (length(plotResponseArgs) & varSTR %in% names(plot_data)) { #TO DO: remove the others!
        plotResponseArgs$col <- varSTR
        p <- do.call(plotResponseByCol, c(plotResponseArgs, list(data=plot_data)))
        if(outputFormat == "html"){
          saveWidget(as_widget(p), paste0(normalizePath(output_dir), "\\CHT_AvE_1way\\",i,tempStr,".html"))
        } else {
          orca(p, paste0(normalizePath(output_dir), "\\CHT_AvE_1way\\",i,tempStr, suffix))
        }
        
      }
        }
      # Similarly, create maps:
      if (maps & varSTR %in% names(plot_data)) { 
          if (any(c("integer", "numeric", "POSIXt", "Date") %in% class(plot_data[[varSTR]]))){
          # cat ("mapping", varSTR, "\n")
            mapArgs$col <- varSTR
            p <- do.call(plotLeafletMap, c(mapArgs, list(dt = plot_data)))
            if (!(is.null(p))) {
              if(outputFormat == "html"){
                saveWidget(as_widget(p), paste0(normalizePath(output_dir), "\\CHT_MAP\\", i, tempStr, ".html"))
              } else {
                orca(p, paste0(normalizePath(output_dir), "\\CHT_MAP\\",i,tempStr, suffix))
              }
            }
                }
          }
        }
      }
   
    # Create 2 way partial dependency html tables
       
    # #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if (buildInts) for (whichOnes in (c(T, F))){ 
      tableNo = 3 - as.integer(whichOnes)
      featuresimp <- tableVars2(Varswitch = whichOnes) 
    sketch = htmltools::withTags(table(
      class = 'display',
      thead(
        tr(th(colspan = 5, paste0('Table ', tableNo, ': Shap interaction charts for ',model_name))),
        tr(lapply(names(featuresimp), th))
      )
    ))
   
    
    output_Vars2 <- datatable(
      featuresimp,
      class = 'cell-border stripe',
      escape = FALSE,
      extensions = 'Buttons',
      container = sketch,
      rownames = FALSE,
      options = list(
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
        pageLength = 20,
        autoWidth = autoWidth
      )) 

    if (is.null(shapInteractions)) {
      output_Vars2 <- output_Vars2 %>%
      formatStyle(
        'Gain.Percentage',
        background = styleColorBar(c(0, max(
          featuresimp$Gain.Percentage
        )), 'lightblue'),
        backgroundSize = '90% 80%',
        backgroundRepeat = 'no-repeat',
        backgroundPosition = 'center'
      ) %>%
      formatPercentage(columns = c('Gain.Percentage'), digits = 2)  %>%
      formatRound(columns = c('Gain', 'FScore'), digits = 0)
    } else {
      output_Vars2 <- output_Vars2 %>%
        formatStyle(
          'shap.dispersion',
          background = styleColorBar(c(0, max(
            featuresimp$shap.dispersion
          )), 'lightblue'),
          backgroundSize = '90% 80%',
          backgroundRepeat = 'no-repeat',
          backgroundPosition = 'center'
        ) 
    }
    saveWidget(
      widget = output_Vars2,
      file = paste0(normalizePath(output_dir), "\\output_Vars", tableNo, ".html"),
      selfcontained = TRUE)
    

    # Create 2 way partial dependency plots
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # check folder exists before save.
    ifelse(!dir.exists(file.path (output_dir, "CHT_ParDep_2way")),
           dir.create(file.path (output_dir, "CHT_ParDep_2way")),
           FALSE)

    # set up arguments for plot:
    if(whichOnes) cat("Plotting interactions: \n")
            nWayList$colourFeature <- NULL
        nWayList$data_int = NULL
    n2 <- min(max_2way, nrow(featuresimp))
    if (n2 > 0) for (i in 1:n2) { # which it should be
        nWayList$primaryFeature <- featuresimp[i, Var1]
        nWayList$secondaryFeature <- featuresimp[i, Var2]
    cat(nWayList$primaryFeature, "~" , nWayList$secondaryFeature, "\n" )
        p <- do.call(plotShapDependence,nWayList)

      tempStr <- paste0("_",featuresimp[i, Var1],"_", featuresimp[i, Var2])
      if(shortPath) tempStr <- ""
      if(!(is.null(p))){
      if (!inherits(p, "plotly")) {
        outData[, eval(p$primary) := p$data[,2]]
        if ("colour" %in% names (p$data)) outData[, eval(p$colour) := p$data$color_value]
        outData[, eval(paste0(p$shap,"~SHAP")) := p$data$shap]
        p <- p$plot
      }
      if(outputFormat == "html"){
        saveWidget(
          as_widget(p), paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2way_", i, tempStr,".html"))
      } else {
        orca(p, paste0(normalizePath(output_dir), "\\CHT_ParDep_2way\\2way_r", i, tempStr, suffix) )
      }
    }
    }
    }   
      if(nWayList$dataOut) fwrite(outData, file = paste0(normalizePath(output_dir), "\\plotData.csv"))
   # 
    # if (max.interaction.depth > 1){
    # 
    # output_Vars3 <- datatable(tableVars3(),
    #             filter = 'top',
    #             class = 'hover stripe',
    #             options = list(pageLength = 100,
    #                            lengthMenu = c(10, 50, 100, 200))
    #   ) %>% formatStyle('Gain.Percentage',
    #                     background = styleColorBar(c(0, max(tableVars3()$Gain.Percentage)), 'lightgreen'),
    #                     backgroundSize = '100% 90%',
    #                     backgroundRepeat = 'no-repeat',
    #                     backgroundPosition = 'center') %>%
    #     formatPercentage(columns = c('Gain.Percentage'),
    #                      digits = 4)
    #   
    # 
    # saveWidget(widget = output_Vars3, file = paste0(normalizePath(output_dir), "\\output_Vars3.html"),selfcontained = TRUE)
    # 
    # }
  
  
  if (makeShiny){
    # rationalise these tables with those above. Obviously.
    featuresimp <- tableVars1(shinyBits=T)
    
    shinyApp(ui = fluidPage(navbarPage(
      "xgboost SHAP",
      tabPanel(
        
        "xgboost SHAP Features",
        fluidPage(tabsetPanel(
          tabPanel(
            "Feature",
            value = 1,
            h4("Feature"),
            p("The relative importance of features within the model"),
            DT::dataTableOutput("tableVars1")
          ),
           id = "conditionedPanels"
        )))
    )),                                              
    server = function(input, output) {
      output$tableVars1 <- DT::renderDataTable(
        datatable(
          featuresimp,
          # This goes and gets the data to display. However it's just displaying hyperlinks as text...
          filter = 'top',
          class = 'hover stripe',
          options = list(
            pageLength = 100,
            lengthMenu = c(10, 50, 100, 200)
          )
        ) %>% formatStyle(
          'SHAPscore',
          background = styleColorBar(c(0, max(
            featuresimp$SHAPscore 
          )), 'lightgreen'),
          backgroundSize = '100% 90%',
          backgroundRepeat = 'no-repeat',
          backgroundPosition = 'center'
        ) 
      )

    #    } else output$tableVars3 <- DT::renderDataTable(data.frame(NotUsed="TreetooShallow"))
    }
    )
  }else return (invisible(NULL))      
}
