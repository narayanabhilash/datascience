#####  EMBmodelCollapse  #####
#' Add a New Level to your EMBglm model
#'
#' \code{EMBmodelCollapse} puts a factor level into the base and removes the factor in your EMBglm model, regardless of interactions.
#' @param fnv_EMBlemModel object. Your EMBglm model.
#' @param fnv_factor character. The rating factor this level is for.
#' @param fnv_levelWeights data table, named. A data table with levels and weights, these weights will be
#' used to remove the factor and put it into the base.
#' @return An updated EMBglm model with the factor removed and base rates updated.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelCollapse EMBmodelRename EMBmodelParent
#' @export
#' @examples
#' #allModels <- EMBmodelCollapse(fnv_EMBlemModel = allModels, fnv_factor = "AA01 - My_Rating_Factor", fnv_levelWeights = data.table("My_New_Level", 1))
EMBmodelCollapse <- function(fnv_EMBlemModel,
                             fnv_factor,
                             ...,
                             fnv_levelWeights) {

  EMBNames <- names(fnv_EMBlemModel)

  Facs <- EMBNames[grep("Factor", names(fnv_EMBlemModel), ignore.case = TRUE)]

  Lvls <- EMBNames[grep("Level", names(fnv_EMBlemModel), ignore.case = TRUE)]

  Mdls <- names(fnv_EMBlemModel)[!grepl("(Level)|(Factor)",
                                        names(fnv_EMBlemModel), ignore.case = TRUE)]

  dt_weights <- data.table(fnv_factor, fnv_levelWeights)
  names(dt_weights) <- c("Factor", "Level", "Weight")
  dt_weights[, Weight := as.numeric(Weight)/sum(as.numeric(Weight))]

  # Checking that Parent Factor exists
  isPresent <- unique(fnv_factor) %in% unique(unlist(fnv_EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(fnv_factor)[!isPresent], collapse = "', '"), "' not in model. Found in 'Levels To Collapse' ")
  }

  # Checking that Parent Factor and Level exist
  duplicatedParents <- merge(dt_weights[, .(Factor, Level)],
                             data.table(Factor = unlist(fnv_EMBlemModel[, ..Facs]), Level = unlist(fnv_EMBlemModel[, ..Lvls]), inModel = TRUE),
                             by = c("Factor", "Level"), all.x = TRUE)
  duplicatedParents <- unique(duplicatedParents[is.na(inModel), .(Factor, Level)])
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Factor,duplicatedParents$Level, sep = ":"), collapse = "', '"), "' not in Model. Found in 'Levels To Collapse'")
  }

  # for each Lvls merge on dt_weights then multiply through the weights. Sum relativities over factor, then factor delete.
  asdf <- copy(fnv_EMBlemModel)

  # attach weights
  for (j in seq_along(Lvls)) {
    asdf[, paste0("Weights", j) := 0]
    for (i in 1:(length(dt_weights[[3]]))) {
      asdf[(get(Facs[j]) == as.character(dt_weights[i, 1]) &
              get(Lvls[j]) == as.character(dt_weights[i, 2]))
           , paste0("Weights", j) := as.numeric(dt_weights[i, 3])]
      asdf[ get(Facs[j]) == as.character(dt_weights[i, 1]),
            c(Facs[j],Lvls[j]) := list("","")]
    }
  }

  # multiply through by weights
  asdf[, Weights := rowSums(.SD), .SDcols = grep("^Weights", names(asdf), value = TRUE)]
  asdf[, (Mdls) := lapply(Mdls, function(x) {get(x) * Weights})]
  
  # Sum through removed levels
  asdf <- asdf[Weights != 0]
  asdf <- asdf[, lapply(.SD, sum), .SDcols = Mdls, by = c(Facs, Lvls)]
  if(length(Lvls) > 1){
    for (i in 1:(length(Lvls) - 1)) {
      asdf[get(Facs[i]) == "" & get(Facs[i + 1]) != "",
           c(Facs[i], Facs[i + 1], Lvls[i], Lvls[i + 1]) := list(get(Facs[i + 1]), "", get(Lvls[i + 1]), "")]
    }
  }

  # multiply through to apply mult from removed level
  fnv_EMBlemModel <- rbind(fnv_EMBlemModel, asdf)
  fnv_EMBlemModel <- fnv_EMBlemModel[ , lapply(.SD, prod), .SDcols = Mdls, by = c(Facs, Lvls)]

  # deleting factor
  for (j in 1:length(Facs)) {
    for (i in 1:length(fnv_factor)) {
      fnv_EMBlemModel <- fnv_EMBlemModel[ !(get(Facs[j]) == fnv_factor[i]), ]
    }
  }

  setkeyv(fnv_EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(fnv_EMBlemModel))
}
# # Checks
# dt_TranCombModelAffinity_Orig <- dt_TranCombModelAffinity
# dt_TranCombModelAffinity <- dt_TranCombModelAffinity_Orig
# factorToRemove <- "CO03 - Division"
# levelToBase <- "Affinity"
# Mdls <- grep("^Value", colnames(dt_TranCombModelAffinity), value = TRUE)
#
# dt_TranCombModelAffinity <- EMBmodelCollapse(fnv_EMBlemModel = dt_TranCombModelAffinity, fnv_factor = "CO03 - Division", fnv_level = "Affinity")
#
# setkey(dt_TranCombModelAffinity_Orig, Factor1, Factor2, Level1, Level2)
# setkey(dt_TranCombModelAffinity, Factor1, Factor2, Level1, Level2)
#
# # check that base rates match
# sum(dt_TranCombModelAffinity[Factor1 == "", ..Mdls] !=
#       (dt_TranCombModelAffinity_Orig[Factor1 == "", ..Mdls]  *
#          dt_TranCombModelAffinity_Orig[Factor1 == factorToRemove & Level1 == levelToBase, ..Mdls]))
#
# # Check that non base rates and non removed factor match
# sum(dt_TranCombModelAffinity[Factor1 != factorToRemove & Factor1 != "", ..Mdls] !=
#       dt_TranCombModelAffinity_Orig[Factor1 != factorToRemove & Factor1 != "", ..Mdls])
#
#
# needs checks on two way interactions





#####  EMBmodelNew  #####
#' Add a New Level to your EMBglm model
#'
#' \code{EMBmodelNew} inserts a new level (relativities all 1) into your EMBglm model, regardless of interactions.
#' @param EMBlemModel object. Your EMBglm model.
#' @param Rating_Factor character. The rating factor this level is for.
#' @param Level_New character, named. The name of the new level you wish to add.
#' @return An updated EMBglm model with the new level specified.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelNew EMBmodelRename EMBmodelParent
#' @export
#' @examples
#' #allModels <- EMBmodelNew(allModels, "AA01 - My_Rating_Factor", Level_New = "My_New_Level")

EMBmodelNew <- function(EMBlemModel,
                        Rating_Factor,
                        ...,
                        Level_New) {

  # Making Factor uppercase, and finding facs/levels from our ratebook
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]

  # Looping over as many interactions as there are in the model
  for (i in 1:length(Lvls)) {

    # Removing the interaction we are on, and making a newrow with those levels
    Lvls2 <- Lvls[Lvls != Lvls[i]]
    dt_newrow <- EMBlemModel[get(Facs[i]) == Rating_Factor]

    if (nrow(dt_newrow) > 0) {

      # Proceeding as long as it is not empty
      dt_uniquerow <- unique(dt_newrow[, c(Facs,Lvls2), with = FALSE])
      lst_colsToAdd <- setdiff(names(EMBlemModel), names(dt_uniquerow))
      dt_exampleRow <- EMBlemModel[1, lst_colsToAdd, with = FALSE]
      dt_exampleRow[, Lvls[i] := Level_New]

      # Change all columns that are not Level_i to be 1
      set(dt_exampleRow, 1L, 2:(length(lst_colsToAdd)), 1)

      # Joining and returning
      dt_joined <- cbind(dt_uniquerow, dt_exampleRow)
      setcolorder(dt_joined, EMBNames)
      EMBlemModel <- rbind(EMBlemModel, dt_joined)

    }

  }

  # Setting key for our returned ratebook
  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))

}

#####  EMBmodelParent  #####
#' Create a new Level in your EMBglm model based off a Prexisting Level
#'
#' \code{EMBmodelParent} creates a new level in your EMBglm model which inherits all scores from the "parent" level specified, regardless of interactions.
#' @param EMBlemModel object. Your EMBglm model.
#' @param Rating_Factor character. The rating factor this level is for.
#' @param Level_Old character, named. The name of the old Level (or "parent") you wish to base the new Level (or "child") on.
#' @param Level_New character, named. The name of the new Level (or "child").
#' @return An updated EMBglm model with the new Level (or "child") included.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelNew EMBmodelRename EMBmodelParent
#' @export
#' @examples
#' #allModels <- EMBmodelParent(allModels, "AA01 - My_Rating_Factor", Level_Old = "My_Old_Level", Level_New = "My_New_Level")

EMBmodelParent <- function(EMBlemModel,
                           Rating_Factor,
                           ...,
                           Level_New,
                           Level_Old) {


  # Making Factor uppercase, and finding facs/levels from our ratebook
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]

  # Looping over as many interactions as there are in the model
  for (i in 1:length(Lvls)) {

    # Making a version
    dt_Fac_i <- EMBlemModel[get(Facs[i]) == Rating_Factor]

    if (nrow(dt_Fac_i) > 0) {

      # Proceeding as long as it is not empty
      dt_exampleRow <- unique(dt_Fac_i[get(Lvls[i]) == Level_Old])
      dt_exampleRow[, Lvls[i] := Level_New]

      # Joining and returning
      EMBlemModel <- rbind(EMBlemModel, dt_exampleRow)

    }

  }

  # Setting key for our returned ratebook
  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))

}

#####  EMBmodelRename  #####
#' Rename a Level in your EMBglm model
#'
#' \code{EMBmodelRename} renames a level in your EMBglm model, regardless of interactions.
#' @param EMBlemModel object. Your EMBglm model.
#' @param Rating_Factor character. The rating factor this level is for.
#' @param Level_Old character, named. The name of the old Level you wish to change the name from.
#' @param Level_New character, named. The name of the new Level you wish to change the name to.
#' @return An updated EMBglm model with the new name specified.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmodelNew EMBmodelRename EMBmodelParent
#' @export
#' @examples
#' #allModels <- EMBmodelRename(allModels, "AA01 - My_Rating_Factor", Level_Old = "My_Old_Level", Level_New = "My_New_Level")

EMBmodelRename <- function(EMBlemModel,
                           Rating_Factor,
                           ...,
                           Level_Old,
                           Level_New) {

  # Making Factor uppercase, and finding facs/levels from our ratebook
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]

  # Looping over as many interactions as there are in the model
  for (i in 1:length(Lvls)) EMBlemModel[get(Facs[i]) == Rating_Factor & get(Lvls[i]) == Level_Old, Lvls[i] := Level_New]

  # Setting key for our returned ratebook
  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))

}


