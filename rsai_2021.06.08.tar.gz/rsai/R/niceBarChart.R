#' Create a clean-looking bar chart
#' 
#' @description niceBarChart creates a plotly bar chart with a clean, minimalistic format. 
#' @usage niceBarChart(factor,
#'              value,
#'              orientation = "h",
#'              highlight = NULL,
#'              title = NULL,
#'              digits = 3L,
#'              ...)
#' @param factor A vector to be used for the names of the bars.
#' @param value A numeric vector to be used for the length of bars.
#' @param orientation Either "h" (horizontal) or "v" (vertical).
#' @param highlight Optional name of column containing exposure periods. Useful for frequency and burn cost modelling.
#' @param title Optional chart title.
#' @param digits Optional, the minimal number of significant digits to display.
#' @param ... Optional parameters to be passed through to plot_ly function e.g. width=910 to set the chart width.
#' @importFrom plotly plot_ly
#' @examples 
#' # set.seed(1984)
#' # val <- runif(15, 0, 80)
#' # niceBarChart(factor = paste0("Feature ", (1:15)[order(-val)]),
#' #              value = val[order(-val)],
#' #              highlight = "Feature 1",
#' #              title = "Feature Importance")
#' @export
#' @author Edwin Graham

niceBarChart <- function(factor,
                         value,
                         orientation = "h",
                         highlight = NULL,
                         title = NULL,
                         digits = 3L,
                         ...){
  
  if (is.null(highlight)) highlight <- character(0)
  
  # Bar colours
  colours <- rep("rgba(178, 178, 178, 1)", length(factor))
  if (length(highlight) > 0) colours[which(factor %in% highlight)] <- "rgba(209, 88, 86, 1)"
  
  # Format values for display
  valText <- niceNum(value, digits = digits)
  hovText <- sapply(1:length(factor), function(i) paste0(factor[i], ": ", valText[i]))
  
  # Set up axes for plot
  if(orientation == "h"){
    x <- value
    y <- factor
    xaxis <- list(title = "",
                  zeroline = FALSE,
                  showline = FALSE,
                  showticklabels = FALSE,
                  showgrid = FALSE)
    yaxis = list(title = "",
                 zeroline = FALSE,
                 showline = FALSE,
                 showgrid = FALSE,
                 categoryorder = "array",
                 categoryarray = rev(factor))
  } else if(orientation == "v"){
    x <- factor
    y <- value
    xaxis <- list(title = "",
                  zeroline = FALSE,
                  showline = FALSE,
                  showgrid = FALSE,
                  categoryorder = "array",
                  categoryarray = factor)
    yaxis = list(title = "",
                 zeroline = FALSE,
                 showline = FALSE,
                 showticklabels = FALSE,
                 showgrid = FALSE)
  } else stop("orientation should be h or v")
  
  # Create and format plot
  require(plotly)
  p <- plot_ly(x = x,
               y = y,
               type = "bar",
               orientation = orientation,
               text = valText,
               textposition = "auto",
               textfont = list(color = "white"),
               marker = list(color = colours),
               hovertext = hovText,
               hoverinfo = "text",
               ...)
  
  p <- p %>% layout(title = title,
                    xaxis = xaxis,
                    yaxis = yaxis)
  
  return(p)
}

