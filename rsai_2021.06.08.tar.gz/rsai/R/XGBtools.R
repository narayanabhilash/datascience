xgb.tree.data.frame <- function(xchunk){
  ## a note on xgboost node numbering:
  ## normally nodes are numbered 1:n
  
  ## but if the gamma parameter is >0
  ## then nodes are not renumbered if they are pruned
  ## so we may end up with non-contiguous numbers
  xci <- as.integer(gsub("(.*):.*","\\1",xchunk))
  xchunk2 <- xchunk
  xchunk2[xci+1] <- xchunk
  xchunk <- xchunk2
  xchunk.leaves <- grep(":leaf=",xchunk,fixed=TRUE)
  SplitVar <- LeftNode <- RightNode <- MissingNode <- rep.int(-1L,length(xchunk))
  SplitVar[-xchunk.leaves] <- as.numeric(gsub(".*\\[f([0-9]*)<.*","\\1",xchunk[-xchunk.leaves]))
  SplitCodePred <- ErrorReduction <- Prediction <- numeric(length(xchunk))
  SplitCodePred[-xchunk.leaves] <- as.numeric(gsub(".*\\[f[0-9]*<([0-9.e+-]*).*","\\1",xchunk[-xchunk.leaves]))
  if(any(t1 <- is.nan(SplitCodePred))){
    warning("NaN detected in split points; replacing with zero")
    SplitCodePred[t1] <- 0
  }
  ## this seems to have issues when the splitting var is 0 or 1
  ## it's due to 0 being a NA in xgb < 0.6
  ## should be alright with xgboost version 0.6 or later
  LeftNode[-xchunk.leaves] <- as.numeric(gsub(".*yes=([0-9]*).*","\\1",xchunk[-xchunk.leaves]))
  RightNode[-xchunk.leaves] <- as.numeric(gsub(".*no=([0-9]*).*","\\1",xchunk[-xchunk.leaves]))
  MissingNode[-xchunk.leaves] <- as.numeric(gsub(".*missing=([0-9]*).*","\\1",xchunk[-xchunk.leaves]))
  ErrorReduction[-xchunk.leaves] <- as.numeric(gsub(".*gain=([0-9.eE+-]*).*","\\1",xchunk[-xchunk.leaves]))
  Weight <- as.numeric(gsub(".*cover=([0-9.eE+-]*)","\\1",xchunk))
  ## reverse evaluate node predictions
  ## they are already partially ordered so stack evaluation is not necessary
  ## thank god :)
  for(i in rev(seq_along(xchunk))){
    ## first, if there is a missing entry
    ## the node was pruned due to gamma; skip to next iteration
    if(is.na(LeftNode[i])) next
    ## should probably use regexec here
    if(LeftNode[i] == -1L){
      Prediction[i] <- SplitCodePred[i] <- as.numeric(gsub(".*leaf=([0-9.eE+-]*),.*","\\1",xchunk[i]))
    } else {
      li <- LeftNode[i]+1L
      ri <- RightNode[i]+1L
      lw <- Weight[li]
      rw <- Weight[ri]
      Prediction[i] <- (Prediction[li]*lw+Prediction[ri]*rw)/(lw+rw)
    }
  }
  data.frame(SplitVar,SplitCodePred,LeftNode,RightNode,MissingNode,ErrorReduction,Weight,Prediction)
  ##	df <- df[!is.na(df$Weight)] ## remove pruned rows
}

# pretty.xgb.trees --------------------------------------------------------


#' Display tree structure for an xgbooster
#' 
#' @description  Analogously to \code{pretty.gbm.tree} from the \code{gbm} package, this
#' function displays the structure of the individual trees of an xgbooster
#' together with their node predictions and gain and cover statistics. Now updated for one-hot factors.
#' @usage pretty.xgb.trees(x, n,oneHots=NULL,var.names=NULL)
#' @details See the help for \code{pretty.gbm.tree}. As with that function, the variable
#' indices and node indices start at zero, not one. 
#' 
#' @param x an \code{xgb.Booster} object, or the results of calling
#' \code{xgb.dump} on one.
#' @param n number of trees to use. Automatically determined as the maximum
#' available if not specified.
#' @param oneHots optional vector of factor names. Values and split points returned are modified
#' for splits relating to these factors.  
#' @param var.names character vector of variable names used to create the xgboost. Required to use \code{oneHots}.
#' To use \code{oneHots} these should be consistent
#' with the column names produced by \code{xgbsetupData2}.
#' @return A list of \code{data.frame}s, with the same eight columns.
#' @author James Lawrence & tom bratcher
#' @seealso \code{pretty.gbm.tree}
#' @export
#' @importFrom  xgboost xgb.dump
#' @examples
#' 
#' require(xgboost)
#' set.seed(20160603L)
#' 
#' ## generate random data
#' ## with response y ~ x1*x2
#' df1 <- data.frame(x1=rnorm(1000),x2=sample(5,1000,replace=TRUE))
#' df1$y <- rnorm(1000,df1$x1*df1$x2)
#' 
#' ## fit an xgboost model to the data
#' xgb.train.matrix <- xgb.DMatrix(data=as.matrix(df1[,-3]),label=df1$y)
#' xgb1 <- xgb.train(
#' 	data=xgb.train.matrix,
#' 	verbose=1,
#' 	nrounds=20,
#' 	eta=0.5,
#' 	max_depth=3L
#' )
#' 
#' ## now we can look at the trees
#' ## this is the first two trees
#' #pretty.xgb.trees(xgb1,2)
#' 


pretty.xgb.trees <- function(x,n,oneHots=NULL,var.names=NULL){
  if(inherits(x,"xgb.Booster")) x <- xgboost::xgb.dump(model=x,with_stats=TRUE)
  maxTrees <- max(as.numeric(gsub(
    "booster\\[([0-9]*)]","\\1",
    x[treeStarts <- grep("booster[",x,fixed=TRUE)])),
    na.rm=TRUE)
  if (maxTrees<1) stop ("x does not appear to be an xgboost tree")
  if(missing(n)) n <- maxTrees + 1
  if (is.null(n)) n <- maxTrees + 1 #paranoia
  if(n > (maxTrees + 1)){
    warning(sprintf("'n' is more than there are trees in the model! Using %d instead",maxTrees + 1))
    n <- maxTrees + 1
  }
  treeStarts <- c(treeStarts, length(x) + 1)
  result <- vector("list", n)
  for(i in 1:n){
    xchunk <- x[(treeStarts[i]+1):(treeStarts[i+1]-1)]
    result[[i]] <- xgb.tree.data.frame(xchunk)
    # BUT then need to alter where we have OneHot	var.names 
    if (length(oneHots)){
      for (i2 in seq_along(oneHots)){
        subs <- grep(paste0("^", oneHots[i2], "~is~"), var.names) - 1 
        # these are the split values which we're going to change.
        # start by overwriting the Split Points:
        # note these won't now _be_ split points.
        for (i3 in seq_along (subs)) {
          result[[i]]$SplitCodePred[result[[i]]$SplitVar==subs[i3]] <- i3
          # then change what's in SplitVar: 
          result[[i]]$SplitVar[result[[i]]$SplitVar==subs[i3]] <- match(oneHots[i2], var.names) - 1
        }
      }
    }
    }
  result
} # Result! this does indeed now do what I want it to. 

prettyTree2Expression <- function(
  tree, n, varNames, length = max(n)){
  tree$relevant <- tree$SplitVar %in% n # still fine...
  returnExpr <- "#0#"
  for(i in 0:(nrow(tree)-1)){
    if(is.na(tree$SplitVar[i+1])) next
    if(tree$SplitVar[i+1] == -1L){
      returnExpr <- gsub(paste0("#",i,"#"),tree$Prediction[i+1],returnExpr,fixed=TRUE)
    } else if(tree$relevant[i+1]){
      returnExpr <- gsub(paste0("#",i,"#"),paste0(
        "if(var",
        tree$SplitVar[i+1]+1,
        ifelse (tree$SplitVar[i+1]>=length, "!= ",	"< "), ## the space is important! Don't delete it!
        tree$SplitCodePred[i+1],
        "){#",
        tree$LeftNode[i+1],
        "#} else {#",
        tree$RightNode[i+1],
        "#}"
      ),returnExpr,fixed=TRUE)
    } else {
      lw <- tree$Weight[tree$LeftNode[i+1]+1]
      rw <- tree$Weight[tree$RightNode[i+1]+1]
      tw <- lw + rw
      returnExpr <- gsub(paste0("#",i,"#"),paste0(
        lw/tw,
        "*{#",
        tree$LeftNode[i+1],
        "#}+",
        rw/tw,
        "*{#",
        tree$RightNode[i+1],
        "#}"
      ),returnExpr,fixed=TRUE)
    }
  }
  parse(text=returnExpr)
}
# Get range from trees: where are our split points? (and do we have infinities?)
getRangeFromPrettyTrees <- function(x,ind,pad=0.001, NALimit = Inf){
  return.df <- data.frame(
    min=numeric(length(ind)),
    max=numeric(length(ind)),
    Inf1 = FALSE,
    Inf2 = FALSE)
  rownames(return.df) <- ind
  if (length (NALimit) < length(ind)) NALimit <- rep(NALimit, length(ind))
  if(!length(ind)) return(return.df)
  for(j in seq_along(ind)){
    i <- ind[j] 
    t1 <- unlist(sapply(x,function(tree)tree$SplitCodePred[tree$SplitVar == i]))
    # shouldn't have NAs but...
    t1 <- t1[!is.na(t1)]
    if (!(length(t1))) {
      return.df[rownames(return.df)==i,] <- c(-0.5, 1.5, FALSE, FALSE)
      next
    } else
    minInf <- (abs(min(t1)) > NALimit[j])
    maxInf <- (abs(max(t1)) > NALimit[j])
    t1 <- t1[abs(t1) <= NALimit[j]]
    if(!length(t1)){
      return.df[rownames(return.df)==i,] <- c(-0.5, 1.5, minInf, maxInf)
    } else {
      t1max <- max(t1,na.rm=TRUE); t1min <- min(t1,na.rm=TRUE); padding <- pad*(t1max-t1min)
      if(!is.finite(padding) || padding <= 0) padding <- 1
      return.df[rownames(return.df)==i,] <- c(t1min-padding, t1max+padding, minInf, maxInf)
    }
  }
  #print (return.df)
  return.df
}
#' Dependency plots for xgboosters
#' 
#' @description  Plots a "partial dependency" plot for the selected variables, according to
#' the specified xgboost model.
#' 
#' @details This is designed to work similarly to \code{plot.gbm}. The function can plot factor or numeric data,
#' however the latter requires \code{var.names} set consistently with \code{xgbsetupdata2}.
#' @usage plot.xgb.Booster(
#' x,
#' i.var = 0, 
#' n.trees = x$niter, 
#' continuous.resolution = 100, 
#' plot = TRUE,
#' return.EMB = FALSE,
#' return.grid = !(plot|return.EMB),
#' xlim = NULL, 
#' evalpoints = NULL,
#' var.names = NULL,
#' inv.link=NULL,
#' vars=NULL,
#' Attributes = NULL,
#' binaryLevels=list(),
#' ex1Way=F,
#' xcdf = NULL,
#' Weight = NULL,
#' NALimit = 7E+8,
#' NARight = TRUE,
#' NAString = "NA",
#' dateVars = c(),
#' ...)
#' @param x An \code{xgb.Booster} object.
#' @param i.var DEPRECATED. Index of the variable(s) to plot, starting at 0 (not 1!). Overridden if \code{vars} are specified 
#' and will give an error if plotting more than one dimension. 
#' @param n.trees Number of trees to use.
#' @param continuous.resolution Number or vector of continuous points to evaluate at. values will be overridden for
#' binary or one-hot encoded factors by the number of relevant levels. Multiples of 10 recommended.
#' @param return.grid If TRUE, return a data frame of point evaluations.
#' @param plot If TRUE, plot the data.
#' @param return.EMB If TRUE, return an EMBglm of point evaluations.
#' @param xlim optional. Either a named list of vectors length 2 which set the minimum
#'  and maximum values of the variables to plot, or a single numeric vector which sets a value for all of them.
#'  If absent, the function sets values based on the trees' split points. Also gets overridden for factor data.
#' @param evalpoints optional. Either a named list of vectors or a single numeric vector: we evaluate the tree output for
#'  these precise values. (Note this doesn't change the x axis scale)
#' @param var.names The names of the variables in the xgboost model.
#' Typically set equal to \code{colnames(xgb_data$train)}.
#' The function gets these from `x` or `Attributes` if provided, so this argument can be omitted.
#' @param inv.link Inverse link function to apply to the dependency values. By default no function is applied.
#' If the model was trained with a log link, specify exp to return (relative) multipliers. 
#' @param vars character vector of the variables to plot. This is the recommended use case. 
#' Can include the names of factors encoded in one-hot / binary / numeric columns 
#' (e.g. enter "make" if factor names are "make~is~ford", etc.)
#' @param Attributes List of attributes of the xgb data object, created by `xgbSetupdata2`.
#' e.g. "Attributes = attributes(xgb_Data$dt_train)". Used to read in the original factor levels
#' for encoded factors, plus encodings. Required argument unless everything is one hot.
#' Attributes _must_ be used to plot numeric, target value or circular encodings.
#' @param binaryLevels DEPRECATED. Named list of the levels behind binary factors.
#' This is needed to control the number, and names, of levels returned. 
#' Now set via `Attributes` argument.
#' @param ex1Way if \code{TRUE}, effect of low depth interactions is removed.  
#' This allows interaction effects to be more easily discerned. Requires \code{vars} to be specified.
#' @param xcdf optional data table. rather than showing the model's effect versus the raw factor
#' (which can be quite skewed) you can choose to show its effect against the empirical distribution 
#' of said factor. This gives a clearer picture of the magnitude of a model's effect on the actual data. 
#' (Note that this won't show NA values.)
#' @param Weight optional character. if \code{xcdf} is specified
#' you can weight its contents by specifying a column name containing weights. 
#' @param NALimit numeric or vector thereof consistent with `vars`, OR a named list with names
#' including all of the vars values. 
#' Any splits in the tree with a higher absolute split point than the NALimit
#' Are treated as splits between "NAs" and the rest of the data. 
#' This can be handy if your "NA" value is well outside the range of the rest of your data,
#' as it probably should be. These NAs currently show up only in 1-d charts.
#' @param NARight if true, NA values always appear on the right (even if they are "low" values)
#' @param NAString how NAs are displayed on the x axis scale, if they are.  
#' @param dateVars vector of column names which are to be interpreted as dates, OR a logical to treat as a date. 
#' (Affects 1-way charts only, until we can get decent 2-way factor ones.) Having this as a vector
#' makes life easier for xgb.fi...
#' @param \dots Other arguments to \code{plot_ly}. See some examples below
#' @return Either a plotly object a \code{data.frame} or an EMBglm format data table,
#' or a list thereof.
#' depending on \code{return.grid} and `return.EMB`.
#' @author Tom Bratcher (tom.bratcher@uk.rsagroup.com)
#' @importFrom plotly plot_ly %>% layout
#' @export
#' @seealso \code{plot.gbm}.
#' @examples
#' 
#' require(xgboost)
#' data ("UKTheftFreq") # gets dt_postcodes
#' rowList <- list (
#' All = seq_along (UKTheftFreq$foldId))
#' modelVars <- setdiff(
#'   names(UKTheftFreq),
#'   c(
#'     "exposure",
#'     "numClaims",
#'     "weight",
#'     "offset",
#'     "currentModel",
#'     "foldId"
#'   )
#' )
#' xgbData <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = modelVars,
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = rowList)
#' 
#' foldList <- folds_VecToList(UKTheftFreq$foldId)
#' 
#' param <- list(
#'   objective = "count:poisson",
#'   max_depth = 3L,           
#'   subsample = 0.9,          
#'   colsample_bytree = 0.9,   
#'   min.child.weight = 100,   
#'   eta = 0.1              
#' )
#' set.seed(1234L)
#' 
#' xgbFit <- xgb.train(
#'   params                 = param,
#'   data                   = xgbData$All,
#'   nrounds                = 100,
#'   base_score             = 1,
#'   verbose                = 0
#' )
#' 
#' plot.xgb.Booster(
#'   xgbFit,
#'   var.names = colnames(xgbData$All),
#'   vars = "ccj_2004",
#'   continuous.resolution = 20L,
#'   line = list(width = 4),
#'   marker = list(line = list(width = 15))
#' )
#' 
plot.xgb.Booster <-
  function(
    x,
    i.var = 0, # the old fashioned way
    n.trees = x$niter,
    continuous.resolution = 100,
    plot = TRUE,
    return.EMB = FALSE,
    return.grid = !(plot|return.EMB),
    xlim = NULL,
    evalpoints = NULL,
    var.names = NULL,
    inv.link = NULL,
    vars = NULL, # the names to plot
    Attributes = NULL,
    binaryLevels = list(),
    ex1Way = F,
    xcdf = NULL, # matrix...
    Weight = NULL,
    NALimit = 7E+8,
    NARight = TRUE,
    NAString = "NA",
    dateVars = c(),
    ...
  ) {
    
    # first, a warning...
    if(compareVersion(as.character(packageVersion("xgboost")), "0.80") < 1)
      stop("You should update your version of xgboost and recreate your models before proceeding")
    
    # Attributes unpacking
    numericLevels <- list()
    binaryLevels <- list() 
    TVElevels <- list()
    
    if (!(is.null(Attributes))){
      # get var.names if not specced:
      if (is.null(var.names)) var.names <- Attributes$.Dimnames[[2]]
      # unpack var names:
      for (nm in names(Attributes$factorLevels)){
        # numerics:
        if (paste0(nm,"~numeric") %in% var.names) numericLevels[[nm]] <- Attributes$factorLevels[[nm]]
        # binaries
        if (paste0(nm,"~binary~0") %in% var.names) binaryLevels[[nm]] <- Attributes$factorLevels[[nm]]
        if (paste0(nm,"~TVEncoder")%in% var.names) TVElevels[[nm]] <- Attributes$factorLevels[[nm]]
      }
    }
  
    # dateVars
    if (!(length(vars))) stop ("Vars should not be empty")
    if (!(length(dateVars))) dateVars <- FALSE
    if (dateVars == TRUE) dateVars <- vars
    if (dateVars == FALSE) dateVars <- c()
    
    # return something?
    if ((plot + return.grid + return.EMB) < 1) {
      warning("Select a return type. Nothing to return, so giving up.")
      return(invisible(NULL))
    }
    
    # var names
    if (!(length(var.names))) var.names <- x$feature_names
    if (!(length(var.names))) stop ("variable names not specified via var.names or stored in x.\nPlease set them")
    
    # check on xcdf, weights --------------------------------------------------
    
    if (!is.null(xcdf)){
      if (length (vars)>1 & !(is.data.frame(xcdf)))stop (
        "if plotting more than one variable, xcdf must be a data frame/table or NULL")
      if (is.vector(xcdf)){
        setDT(xcdf)
        names(xcdf) <- vars
        }
      setDT(xcdf)
      if (is.character(Weight)) {
        if (!(Weight %in% names (xcdf))) stop ("Weight not found in xcdf")
        Weight <- xcdf[[Weight]]
      }
      if (is.null (Weight)) Weight <- rep (1, NROW(xcdf))
      if (!(length (Weight) == NROW(xcdf))) stop ("Weight should be the same length as xcdf")
      
      # filter down xcdf: 
      tempnames <- intersect (names (xcdf),intersect(vars,var.names)) # this removes any factors.
      if (!(length(tempnames)))xcdf<-NULL else xcdf <- xcdf [,tempnames,with=F]
      # possibly want a warning here, but a pain in an automated process.
    }

    # exclude 1 way warning ---------------------------------------------------
    
    if (length (vars)==1 & ex1Way){
      ex1Way <- FALSE
     # warning ("ex1Way automatically set to FALSE for 1 way chart") # not really helping anyone
    }    
     # setup i.var, other bits from vars ---------------------------------------
    
    # tweak to tree length default: 
    if (is.null(n.trees)) n.trees<-x$niter
    varOrig <- var.names # for safe keeping
    binaries <- c()
    oneHots <- c()
    numerics <- c()
    posix <- c()
    TVEs <- c()
    circulars <- c()
    oneHotLevels <- list() # might be needed...
    ctrorig <- continuous.resolution
    if(!(length(ctrorig)))ctrorig = 10L
    if(length(ctrorig)<length (i.var)) ctrorig <- c (ctrorig,rep (ctrorig[1], length(i.var) - length(ctrorig)))
    if(length(ctrorig)<length (vars)) ctrorig <- c (ctrorig,rep (ctrorig[1], length(vars) - length(ctrorig)))
    
    # so at this point ctrorig is assumed to apply to each of the var names in turn... 
    # BUT still need to override this for binary factors later. 
    
    if (ex1Way & ! (length(vars))) stop ("vars should be specified if excluding one way features")
    
    
    # if variable names supplied, need to record factors... -------------------
    
    if (!is.null(vars)){
      i.var = c()
      for (i in seq_along(vars)) {
        nm <- vars[i]
        counter <- length(i.var)
        temp <- match(nm,var.names)
        if (!is.na(temp)){
          i.var <- c(i.var, temp - 1)
          continuous.resolution[length(i.var)]<-ctrorig[i]
        }#Dates
        temp6<-match(paste0(nm,"~POSIXct"), varOrig)
        if(!is.na(temp6)){
          i.var <- c(i.var, temp6 - 1)
          var.names[length(varOrig) + i] <- nm
          continuous.resolution[length(i.var)]<-ctrorig[i]
          posix <- unique(c(posix,nm))
        }#posix
        temp5<-match(paste0(nm,"~Date"), varOrig)
        if(!is.na(temp5)){
          i.var <- c (i.var, temp5 - 1)
          var.names[length(varOrig) + i] <- nm
          continuous.resolution[length(i.var)] <- ctrorig[i]
          dateVars <- unique(c(dateVars ,nm))
        }# numerics
        temp2 <- match(paste0(nm, "~numeric"), var.names) # exact match: there's only one. 
        if (!is.na(temp2)){
          if (!is.na(temp)) stop ("incompatible variable names")
          i.var <- c(i.var, temp2 - 1)
          continuous.resolution[length(i.var)]<-ctrorig[i]
          numerics <- c(numerics, nm)
        }# binaries 
        temp3 <- grep(paste0("^",nm,"~binary~"), var.names)
        i.var<-c(i.var,temp3-1)
        if (length(temp3)){
          binaries <- c(binaries,nm) # fine if it's empty
          nm <- var.names[length(varOrig) + i]
          continuous.resolution[(length(i.var)-length(temp3)+1):length(i.var)] <- 2
        }#1hot
        temp4 <- grep(paste0("^",nm,"~is~"), varOrig)
        if (length(temp4)){
          oneHots <- c(oneHots, nm)
          i.var <- c(i.var, length(varOrig) + i - 1)
          var.names[length(varOrig)+i] <- nm
          continuous.resolution[length(i.var)] <- length(temp4)
          oneHotLevels[[nm]] <- gsub(".*~is~", "", var.names[temp4])
        }  
        # TVEs
        temp7 <- match(paste0(nm, "~TVEncoder"), varOrig)
        if (!is.na(temp7)){
          i.var <- c(i.var, temp7 - 1)
          continuous.resolution[length(i.var)] <- length(Attributes$factorLevels[[nm]])
          TVEs <- c(TVEs, nm)
        }
        # circulars ARGH ARGH
        temp8 <- grep(paste0(nm, "~circular"), varOrig)
        if (length(temp8)){
          i.var <- c(i.var, temp8 - 1)
          continuous.resolution[(length(i.var) - 1) : length(i.var)] <- 2 # eh, they just need to exist
          circulars <- c(circulars, nm)
        }
        
        if(counter==length(i.var)) stop (paste0(nm," is in vars but does not relate to any of var.names"))
      }
    }
    
    encoded <- c(oneHots, binaries, numerics, posix, dateVars, TVEs, circulars)
    
    # Unlist NA limits, if it's a list ----------------------------------------
    NALimitOrig <- NALimit
    if (is.list(NALimit)){
      temp <- unlist(NALimit[vars])
      NALimit <- rep(7E+8, length(vars))
      } else {
      NALimit <- rep(NALimit, length(vars)) 
      temp = NULL
    }
      names(NALimit)<- vars
      #overrides:
      for (nm in vars) {
        if (nm %in% names(temp)) NALimit[[nm]]<- temp[[nm]]
      # overrides for posixcts:
        if (nm %in% gsub("~.*","",posix)) NALimit[[nm]]<- 0.01 * .Machine$double.xmax  
      }
     # error messages ----------------------------------------------------------
  
    if (exp (sum (log(continuous.resolution))) > 2e8) stop(
      "This computation will take an absurd amount of memory. Suggest you turn continuous
      resolution down."
    )
    
    if (!(length(i.var) + length(oneHots)))
      stop("'i.var' should have length more than zero")
    if (length (setdiff (names(binaryLevels),vars))) {
      binaryLevels <- binaryLevels[intersect(names(binaryLevels), vars)]
    }
      # get relevant tree split info and create sum -----------------------------
    xdump <- pretty.xgb.trees(x, n.trees, oneHots = oneHots, var.names = var.names)
    
    # need to record here any one-hot changes - because they get fed into the expression.
    pte <-
      sapply(xdump, prettyTree2Expression, i.var, var.names, length(varOrig))
    # differs in that we've now got something at the end.
    # BUT needs a new argument to pick them up...
    
    # set min/max ranges: override one-hots -----------------------------------
    xr <- getRangeFromPrettyTrees(xdump, i.var, NALimit = NALimit)
    
    #xlim override:
    if (is.list(xlim)) for (nm in names (xlim)) xr[which (rownames (xr)== match (nm, var.names)-1 ),] <- xlim[[nm]]
    if (is.numeric (xlim)) {
      if (length (xlim)!=2) stop ("if xlim is a vector it should be length 2")
      xr[,1]=xlim[1]
      xr[,2]=xlim[2]
    }
    
    # fix one-hots:
    for (i in which (as.integer(rownames(xr))>=length(varOrig))) {
      xr[i,]<-c(1,continuous.resolution[i], FALSE, FALSE) }
    # The way this is done prevents subsetting for factors, so do it later.
    
    ## CHANGE LIMITS FOR XCDF <- min and max of values.
    
    if (!(is.null(xcdf))) for (nm in names (xcdf)) {
      xr[which (rownames (xr)== match (nm, var.names)-1 ),1] <- 0
      xr[which (rownames (xr)== match (nm, var.names)-1 ),2] <- 1
    }
    #print(numerics)
    toExpand <- lapply(seq_len(nrow(xr)), function(i){
      # here's where the hard coding of points needs to happen...
      # need to :
      #- leave factors, xcdfs
      #- otherwise override if named or vector.
      Vname <- var.names[as.integer(rownames(xr)[i]) + 1][1]
      Vnm <- gsub("~.*","", Vname)
      # binaries:
      if (grepl("~binary~", Vname)) return (c(-0.5, 1.5))
      # numerics:
      if (grepl("~numeric", Vname)) return (seq_along(numericLevels[[Vnm]]))
      # TVEs:
      # numerics:
      if (grepl("~TVEncoder", Vname)) return (
        Attributes$facEncodingTbls[[Vnm]][seq_along(TVElevels[[Vnm]]), get(Vname)])
      # circulars: get the _Level names, once_
      if (grepl("~circular", Vname)){
        if (grepl("~sin$", Vname)) return (Attributes$factorLevels[[Vnm]])
        return ("x")
      }
      # listed eval points (for numbers: encodeds come later...)
      if (is.list(evalpoints)) {
        for (nm in names(evalpoints)){
        if (nm %in% var.names && rownames(xr)[i]== match (nm, var.names) - 1)
          return (evalpoints[[nm]])
      } # ie if have evalpoints then ignore cont resolution
      
      } else {
        temp <- F
        # vectors which are not lists... annoyingly, lists can be vectors
        if (is.vector(evalpoints)) temp <- T
      if (i %in% which (as.integer(rownames(xr))>=length(varOrig)))temp <- F # factor
      if (!(is.null(xcdf))) for (nm in names (xcdf)) if (rownames (xr)[i]== match (nm, var.names)-1 ) temp <- F #xcdf override
      if (temp) return (evalpoints)
      }
      # debug in case where no splits, as when if no effect:
      if (is.infinite(xr[i, 1])) {
        xr[i, 1] <- -0.5
        xr[i, 2] <-  1.5
      }
      # infinities:
      if (xr[i, 3]) m1 <- -Inf else m1 <- NULL
      if (xr[i, 4]) m2 <-  Inf else m2 <- NULL
      # but if xcdf, don't show them, they get removed anyway
      if (!(is.null(xcdf))) {
        for (nm in names (xcdf)) {
          if (rownames (xr)[i] == match (nm, var.names) - 1) {
            m1 <- NULL
            m2 <- NULL
          }
        }
      }
      if (NARight){
        c(seq(xr[i, 1], xr[i, 2], length.out = continuous.resolution[i]), m1, m2)  
      } else c(m1, seq(xr[i, 1], xr[i, 2], length.out = continuous.resolution[i]), m2)
    })
  # print(toExpand)
    
  # Now value some points.
    # dftemp includes the numbers to actually value...
    dftemp <- do.call(
      "expand.grid",
      toExpand)
    
    xdfNames <- var.names[1 + i.var]
    names(dftemp) <-  xdfNames
    
    # which means we need to change the values of any circulars now:
    for (nm in circulars){
      nmcols <- grep(paste0(nm, "~circular"), colnames(dftemp))
      rMatch <- match(dftemp[, nmcols[1]], Attributes$facEncodingTbls[[nm]][[nm]])
      dftemp[, nmcols[1]] <- Attributes$facEncodingTbls[[nm]][rMatch,2]
      dftemp[, nmcols[2]] <- Attributes$facEncodingTbls[[nm]][rMatch,3]
      rm(rMatch, nmcols)
    }
    
    # whereas x.df is going to now include the _names_ we want.
    
    namesToExpand <- copy(toExpand)
    for (i in seq_along(xdfNames)){
      nm <- xdfNames[i]
      nm2 <- gsub("~.*", "", nm)
      if (grepl("~TVEncoder|~numeric", nm)) 
        namesToExpand[[i]] <- as.character(Attributes$facEncodingTbls[[nm2]][[nm2]])[
          seq_along(namesToExpand[[i]])]
     
    }
    namesToExpand <- namesToExpand[grep("~cos$", xdfNames, invert = T)]
    #print(namesToExpand)
    x.df <- do.call(
      "expand.grid",
      namesToExpand)
    names(x.df) <-  grep("~cos$", xdfNames, invert = T, value = T)
    
    ## FOR XCDF Now (for non factors) can
    # (where not a factor- and ironically they're in the data where the one hots are not)
    
    if (!is.null(xcdf)) for (nm in intersect(names(xcdf), names(dftemp))){ # probably don't need the intersect, but paranoid
      dftemp[[nm]]<-Hmisc::wtd.quantile(xcdf[[nm]], probs =x.df[[nm]],
                                        na.rm = TRUE, weights = Weight)
      dftemp[[nm]][is.nan (dftemp[[nm]])]<- 1e+20 # sigh. but should never happen
    }
    xString <-
      paste0("var",1+i.var, "=z[", seq_along(i.var), "]", collapse = ",")
    evalfn <-
      eval(parse(
        text = paste0(
          "function(z) sum(sapply(pte,function(e) eval(e,envir=list(",
          xString,
          "))))"
        )
      ))
    ## todo: use Rcpp for this, it will be *much* faster than mucking about with environments
    
    # Evaluation --------------------------------------------------------------
    
    # in case Outcome is one of the variable names - and I know it will be-
    outcome <- "Outcome"
    while (outcome %in% names (x.df)) outcome <-paste0(outcome, "x")

    x.df[[outcome]] <-apply(dftemp, 1, evalfn)  # Apply to temp.df
    rm(dftemp)
    ## FOR xcdf: then put the column back to where it was
    
        # Collapse down binaries and remove any levels not requested --------------
    if(length(binaries)) { # if it is, must have specced vars...
      for (nm in binaries){
        temp <- grep(paste0("^",nm,"~binary~"), names(x.df))
        binaryOutcome <- data.frame(Name = 1 + apply(x.df[,temp], 1, function(x)(
          x > 0.5) %*% 2 ^ (1:length(x) - 1)))
        names(binaryOutcome) <- nm
        
        #aaaagh dimensionality
        if (length(temp) + 1 == ncol(x.df)){
          x.df <- data.frame(a = binaryOutcome, b = x.df[[outcome]])
          colnames(x.df) <- c(nm, outcome)
          if (nm %in% names(binaryLevels)) x.df<-x.df[x.df[[nm]]<=length(binaryLevels[[nm]]),] 
          if (nm %in% names(binaryLevels)) {
            x.df<-x.df[x.df[[nm]]<=length(binaryLevels[[nm]]),] 
            x.df[[nm]] <- binaryLevels[[nm]][x.df[[nm]]]
          }
          next
        } 
       x.df <- x.df[,-temp]
       xdfNames <- names (x.df)
      #change i.var and remove the original columns: BUT want to maintain order argh argh.
      startCol <- min(temp)
           if (startCol == 1) {
        x.df <- cbind(binaryOutcome, x.df) 
        colnames(x.df) <- c(nm, xdfNames)
        } else {
        x.df <- cbind(x.df[,1:(startCol-1)], binaryOutcome, x.df[,startCol:ncol(x.df)])
        colnames(x.df) <- c(xdfNames[1:(startCol-1)], nm, xdfNames[startCol:length(xdfNames)])
        }
      if (nm %in% names(binaryLevels)) {
        x.df<-x.df[x.df[[nm]] <= length(binaryLevels[[nm]]),] 
        x.df[[nm]] <- binaryLevels[[nm]][x.df[[nm]]]
      }
      }
    }
    # # Give numerics back their names
    # for (nm in colnames(x.df)){
    #   nm2 <- gsub("~.*", "", nm)
    #   if (grepl("~numeric", nm) && nm2 %in% names(numericLevels)) {
    #     x.df[[nm]] <- numericLevels[[nm2]][x.df[[nm]]] }
    # }
    colnames(x.df) <- gsub("~numeric|~TVEncoder|~circular.*", "", colnames(x.df))
    
    # Where it's a factor, let's see what happens if we now change the numbers to the levels...
    for (nm in oneHots) x.df[[nm]] <- oneHotLevels[[nm]][x.df[[nm]]]
    
    # Exclude impact of one-way features: -------------------------------------
    if (ex1Way){ 
      eval1Way <- lapply(x.df,unique)
      for (nm in names (eval1Way)) {
        if (!(is.numeric(eval1Way[[nm]]))) eval1Way[[nm]]<- NULL
      }
      # consider each subset of features in turn:
      for (subsetLength in 1:(length(vars)-1)){
        subsetMatrix <- combn(setdiff(names(x.df), outcome), subsetLength)
        subnos <- combn (seq_along(vars), subsetLength)
        for (thisSubset in 1:(dim(subsetMatrix)[2])){
          subvars<-subsetMatrix[, thisSubset]
          ctr <- apply(x.df, 2,
                       function(x)length(unique(x)))[subnos[, thisSubset]]
          
          oneWayTab <- plot.xgb.Booster(
            x = x,
            i.var = 0,
            n.trees = n.trees,
            continuous.resolution = ctr,
            return.grid = TRUE,
            plot = FALSE,
            xlim = xlim,
            evalpoints =  eval1Way,
            var.names = varOrig,
            inv.link = NULL,
            # That comes later
            vars = subvars,
            binaryLevels = binaryLevels,
            Attributes = Attributes,
            ex1Way = FALSE,
            xcdf = xcdf,
            Weight = Weight,
            NALimit = Inf
          )
          # match last column effect back on using inclusion/exclusion rule...
          if (subsetLength==1){
            tempMatch<-match(x.df[[subvars]],oneWayTab[[subvars]]) # ugliest. hack. ever. 
          } else tempMatch<-match(apply(x.df[,subvars],1,paste0,collapse="~"),
                                 apply(oneWayTab[,subvars],1,paste0,collapse="~"))
          
          x.df[[outcome]] <- x.df[[outcome]] +
            ((-1 ^ (length(vars) - subsetLength)) *
               (oneWayTab[tempMatch, 1 + subsetLength]))
        }
      }
    } 
    # NOW remove any unrequested rows and apply inv.link:
    
    for (nm in colnames(x.df)){
      if (nm %in% gsub("~.*", "", encoded) & nm %in% names(evalpoints))
        x.df <- x.df[x.df[[nm]] %in% evalpoints[[nm]],]
    } 
    
    if (!(is.null(inv.link))) x.df[[outcome]] <- inv.link(x.df[[outcome]])
    returnedTable <- copy(x.df)
   #print(returnedTable)
    # plot --------------------------------------------------------------------
    
    if (plot){
   
      #initialise number of infinities:
      Infs <- 0
      #The default order will be alphabetized unless specified as below:
      for (nm in setdiff(names(x.df), outcome)) { # otherwise numeric factors fail
        
        # dates and posixcts:
        if (grepl("~Date$", nm)) {
          nm2 <- gsub("~Date$", "", nm)
          setnames(x.df, nm, nm2)
          nm <- nm2
          x.df[[nm]] <- as.Date(x.df[[nm]], origin = "1970-01-01")
          
        }
        # dates and posixcts:
        if (grepl("~POSIXct$", nm)) {
          nm2 <- gsub("~POSIXct$", "", nm)
          setnames(x.df, nm, nm2)
          nm <- nm2
          x.df[[nm]]<- as.POSIXct.numeric(x.df[[nm]], origin = "1970-01-01")
          
        }
        
        if (is.character(x.df[[nm]])) {
          x.df[[nm]]<- factor(x.df[[nm]], levels=unique(x.df[[nm]]))
        } else {
          # remove NAs for now if y>1: because the factor plot is horrible
          if (length(vars) > 1) x.df <- x.df[which(!(is.infinite(x.df[[nm]]))), ] else {
            
            # convert to dates:
            if (nm %in% dateVars){
              temp <- c()
              temp <- as.character(as.Date(x.df[[nm]], origin = "1970-01-01"))
              temp[is.na(temp)]<- "NA"
              x.df[[nm]] <- temp
              # but have the problem of duplicates, which resolves thus: (maybe)
              temp <- c()
              temp <- gsub(".{10}\\.*","", make.unique(x.df[[nm]]))
              temp[temp == ""] <- "0"
              temp[temp == "NA"] <- "0"
              temp <- sapply(temp, function (x) paste(rep(" ", 1 + as.integer(x)), collapse = ""))
              x.df[[nm]] <- paste0(x.df[[nm]],temp)
              x.df[[nm]] <- factor(x.df[[nm]], levels = x.df[[nm]]) 
            }
            # make factor if NAs are around...
            Infs <- nrow(x.df[which(is.infinite(x.df[[nm]])),])
            
            if (Infs > 0) {
              # round the output labels as much as we can...
              # don't do this for dates 
              if (!("POSIXct" %in% class(x.df[[nm]])| "Date" %in% class(x.df[[nm]]))){
              rounders <- 3 
              while (any (duplicated (signif(x.df[[nm]], rounders)))) rounders <- rounders + 1
              x.df[[nm]] <- signif(x.df[[nm]], rounders)
              x.df[[nm]][abs(x.df[[nm]]) >= 1E6] <- formatC(x.df[[nm]][abs(x.df[[nm]]) >= 1E6])
              } 
              if (Infs == 1) x.df[[nm]][which(x.df[[nm]] %in% c("Inf", "-Inf"))] <- NAString
              x.df[[nm]] <- paste0(as.character(x.df[[nm]]), " ") 
              x.df[[nm]] <- factor(x.df[[nm]],
                levels = x.df[[nm]]) 
            }
          }
        }
      }
      
      #Set outcome (y)
      y <- x.df[[outcome]]
      dim(y) <- sapply(x.df,function(x)length(unique(x)))[1:ncol(x.df)-1]
      
      
      if(is.null(vars)) {
        axisList <- lapply(i.var, function(i)
          list(title = var.names[i + 1]))
      } else {
        axisList <- lapply(seq_along (vars), function(i) list(
          title = vars[i])) # add more stuff here like labels?
        
        # split infinities: this should work nicely for round values of continuous.resolution
        if (length(dim(y)) == 1 && (Infs > 0||nm %in% dateVars)){
          tenticks <- floor((nrow(x.df) - 1) / 10)
          theseticks <- 1 + tenticks * (0:10)
          axisList = list(xaxisList = list(
          ticktext = as.list(x.df[[nm]][theseticks]),
          tickvals = as.list(theseticks),
          tickmode = "array",
          type = "category",
          title = nm
        ))
        }
        # categoricals for the 3d chart:
        if (length(dim(y)) == 2) {
          if (names(x.df)[1] %in% gsub("~.*", "", encoded)){
           axisList[[1]]$type <- "category" 
           x.df[,1] <- substr(as.character(x.df[,1]), 1, 16)
          }
            
          if (names(x.df)[2] %in% gsub("~.*","", encoded)){
            axisList[[2]]$type <- "category" 
            x.df[,2] <- substr(as.character(x.df[,2]), 1, 16)
          }
        }
      }
      
      # setup line list:
      if ("line" %in% names(list(...))) {
        Line <- list(...)$line
        Line$shape <- "hvh"
        if (!("width" %in% names (Line))) Line$width <- 0.5
       # list(...)$line <- NULL
      } else Line = list(shape = "hvh", width = 0.5)
      
      # now plot, conditional on dim of y.
      
      returnedPlot <- switch(length(dim(y)),
             ## 1-D
             { 
               plotly::plot_ly(
                 data=x.df,
                 x=~get(names(x.df)[1]),
                 y=~get(outcome),
                 type = 'scatter',
                 mode = 'lines+markers',
                 line = Line,
                 ...) %>% plotly::layout(
                   xaxis = axisList[[1]], yaxis = list(title="Impact on Prediction"))
             },
             ## 2-D
             { # axis categorisation means we can do this one way. WOOOOOHOOO
              # if (!(length(oneHots) + length(binaries) + length(numerics))){
                   plotly::plot_ly(
                   x = matrix(x.df[, 1], dim(y)[1], dim(y)[2]),
                   y = matrix(x.df[, 2], dim(y)[1], dim(y)[2]),
                   z = y,
                   type = "surface",
                   ...
                 ) %>% plotly::layout(scene = list(
                   xaxis = axisList[[1]], yaxis = axisList[[2]],
                   zaxis = list(title ="Impact on Prediction")),
                   title = paste(names(x.df)[1], "and", names(x.df)[2]))  
             },
             ## many-D
             {
               warning("don't know how to plot in more than 2-D - just returning grids")
               NULL
             })
    }
    # RETURN GRID DATA========-------------

    # return results in EMBGLM format
    if (return.EMB){
    x.dfE <- copy(returnedTable)
    setDT(x.dfE)
      return_table = data.table(Factor1 = rep(vars[1], nrow(x.dfE)))
      for (i in seq_along(vars)) {
        if (i > 1)
          return_table[[paste0("Factor", i)]] <- rep(vars[i], nrow(x.dfE))
      }
      names(x.dfE) <- c(
        sapply(1:(ncol(x.dfE) - 1), function(x) paste0("Level", x)),
        "Value")
      x.dfE <- cbind(return_table, x.dfE)
    } # it probably fails validation nowadays

# What to return ----------------------------------------------------------
    # check on return type
    
    if ((plot + return.grid + return.EMB) > 1) { 
    returnList <- list(table = returnedTable)
    if (plot) returnList$plot <- returnedPlot
    if (return.EMB) returnList$EMB <- x.dfE
    return (returnList)
    }
    if (plot) return (returnedPlot)
    if (return.EMB) return (x.dfE)
    return (x.df)
   }

#' convert xgbooster to gbm
#' 
#' @description  Converts an \code{xgb.Booster} object, or its dump, to a \code{gbm} object
#' to allow use of functions from the \code{gbm} package.
#' @usage xgb2gbm(x, data, n, param = NULL, response.name = "y", 
#' distribution = c("gaussian", "bernoulli", "laplace"))
#' @details Not all distributions are supported. Multinomial and pairwise definitely
#' won't work. The unspecified univariate ones like "tdist", may work in some
#' cases but not others.
#' 
#' @param x an object of class \code{xgb.Booster}, or the results of calling
#' \code{xgb.dump(,with.stats=TRUE)} on the same.
#' @param data A data frame or matrix. This should be of the same format as the
#' training data for \code{x}. It is used to determine variable names and
#' formats, which \code{xgb.Booster} does not retain.
#' @param n Number of trees. Automatically determined if not specified.
#' @param param An optional list of parameters passed to \code{xgb.train},
#' which will then be populated in the resultant \code{gbm} object.
#' @param response.name Name of the response variable.
#' @param distribution Optional name of the distribution, as it would have been
#' specified to \code{gbm}.
#' @return An object of class \code{"gbm"}. \code{summary.gbm} and
#' \code{plot.gbm} should work. It is not recommended to use
#' \code{predict.gbm}: there shouldn't be errors, but the predictions may not
#' be correct (this is due to \code{xgb.dump} getting confused between 0s and
#' missing values).
#' 
#' The \code{rsai} functions \code{\link{gbmImportancePlot}} and
#' \code{\link{gbmRelativityPlot}} should work, as well.
#' @author James Lawrence
#' @seealso \code{gbm} and other functions in that package.
#' @export
#' @examples
#' 
#' require(xgboost)
#' require(gbm)
#' set.seed(20160603L)
#' 
#' ## generate random data
#' ## with response y ~ x1*x2
#' df1 <- data.frame(x1=rnorm(1000),x2=sample(5,1000,replace=TRUE))
#' df1$y <- rnorm(1000,df1$x1*df1$x2)
#' 
#' ## fit an xgboost model to the data
#' xgb.train.matrix <- xgb.DMatrix(data=as.matrix(df1[,-3]),label=df1$y)
#' xgb1 <- xgb.train(
#' 	data=xgb.train.matrix,
#' 	verbose=1,
#' 	nrounds=20,
#' 	eta=0.5,
#' 	max_depth=3L
#' )
#' 
#' ## convert it to a gbm
#' gbm1 <- xgb2gbm(xgb1,as.matrix(df1[,-3]),20)
#' 
#' ## now we can use several new things:
#' ## feature importance
#' summary(gbm1) ## from gbm library
#' xgb.importance(model=xgb1) ## from xgboost library
#' 
#' gbmImportancePlot(gbm1) ## from rsai library
#' 
#' ## plots
#' ## there are some slight differences;
#' ## the axis range may be different
#' ## and plot.xgb.Booster uses stair steps where
#' ## plot.gbm uses straight lines
#' plot(gbm1,1)
#' plot(xgb1, var.names = c("x1","x2"), vars = "x1")
#' 
xgb2gbm <- function(x,data,n,param=NULL,response.name="y",distribution=c("gaussian","bernoulli","laplace")){
  ## x: an xgb.Booster object
  ## data: the training data
  ## n:number of trees
  ## we pretend all factors are integers, as xgboost does
  z <- list(var.names=colnames(data))
  z$distribution <- list(name=match.arg(distribution))
  if(is.matrix(data)){
    dataSummary <- apply(data,2,quantile,0:10/10)
    z$var.levels <- sapply(seq_len(ncol(dataSummary)),function(i)dataSummary[,i],simplify=FALSE)
    z$var.type <- rep(0,ncol(data))
  } else {
    #		z$var.levels <- unname(sapply(z$var.names,function(y){
    #			if(is.factor(data[[y]])) levels(data[[y]]) else quantile(data[[y]],0:10/10)
    #		}))
    z$var.levels <- unname(sapply(data,function(v)quantile(as.numeric(v),0:10/10),simplify=FALSE))
    z$var.type <- sapply(data,nlevels)
  }
  z$trees <- lapply(pretty.xgb.trees(x),function(tree){
    list(
      as.integer(tree$SplitVar),
      tree$SplitCodePred,
      as.integer(tree$LeftNode),
      as.integer(tree$RightNode),
      as.integer(tree$MissingNode),
      tree$ErrorReduction,
      tree$Weight,
      tree$Prediction
    )
  })
  for(j in seq_along(z$trees)){
    z$trees[[j]][[2]][z$trees[[j]][[2]] == 0] <- 1E-5
  }
  for(i in seq_along(z$var.levels)) if(z$var.levels[[i]][1] == 0 && z$var.levels[[i]][11] == 1 && all(z$var.levels[[i]] < 1E-8 | z$var.levels[[i]] > 0.99999999)){
    #		z$var.levels[[i]][1] <- -0.05
    #		z$var.levels[[i]][11] <- 1.05
    ## for some reason, 0/1 splits get messed up --- need to recode the split point as 1/2
    ## apparently this is to do with xgboost thinking 0 is a missing value?
    for(j in seq_along(z$trees)) z$trees[[j]][[2]][z$trees[[j]][[1]]==i-1] <- 0.5
  }
  z$var.monotone <- rep(0,length(z$var.type))
  z$response.name <- response.name
  z$n.trees <- n
  z$num.classes <- 1 ## multinomial won't work yet
  z$c.splits <- list()
  z$initF <- 0
  z$train.error <- numeric(z$n.trees)
  z$train.error[z$n.trees] <- -1
  z$train.fraction <- z$bag.fraction <- 1
  class(z) <- "gbm"
  if(!is.null(param)){
    z$shrinkage <- param$eta
    z$interaction.depth <- param$max_depth
  }
  z
}

.interaction.importance.tree <- function(tree,nvar,var.points,resolution){
  treeWeightRatio <- tree$Weight/tree$Weight[1] ## ratio of weight at a node to its parent, normalised to 1
  isLeaf <- tree$SplitVar == -1
  tree$parent <- -1
  tree$parent[tree$LeftNode[!isLeaf]+1] <- LeftNode[SplitVar[!isLeaf]]
  tree$parent[tree$RightNode[!isLeaf]+1] <- RightNode[SplitVar[!isLeaf]]
  tree$parent[tree$MissingNode[!isLeaf]+1] <- MissingNode[SplitVar[!isLeaf]]
  treeWeightRatio[1] <- 1
  treeWeightRatio[-1] <- tree$Weight[-1]/tree$Weight[tree$parent]
  eta <- array(0,c(resolution,nvar,nrow(tree)))
  eta[,,1] <- 1
  for(i in 2:nrow(tree)){
    eta[,,i] <- eta[,,tree$parent[i]+1]*treeWeightRatio[i]
    eta[tree$SplitCodePred[i]<var.points[[tree$SplitVar[i]+1]],tree$SplitVar[i]+1,i] <- 0
    eta[tree$SplitCodePred[i]>=var.points[[tree$SplitVar[i]+1]],tree$SplitVar[i]+1,i] <- eta[tree$SplitCodePred[i]>=var.points[[tree$SplitVar[i]+1]],tree$SplitVar[i]+1,tree$parent[i]+1]
  }
  list(treeWeightRatio,eta)
}

# try setting methods? nope. this is the recommended procedure for S3 as far as I can see
