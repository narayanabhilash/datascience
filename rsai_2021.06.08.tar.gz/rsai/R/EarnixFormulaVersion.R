EarnixFunctionReplacementTable <- list(
	c("%%",":"),
	c("!=","<>"),
	c("==","="),
	c("([( +/*-])abs[(]","\\1ABS("),
	c("([( +/*-])ceiling[(]","\\1CEILING("),
	c("([( +/*-])tan[(]","\\1TAN("),
	c("([( +/*-])sin[(]","\\1SIN("),
	c("([( +/*-])cos[(]","\\1COS("),
	c("([( +/*-])max[(]([[:print:]]*), ?na.rm*=*TRUE*[)]","\\1MAX_PRESENT(\\2)"),
	c("([( +/*-])max[(]","\\1MAX("),
	c("([( +/*-])min[(]([[:print:]]*), ?na.rm*=*TRUE*[)]","\\1MIN_PRESENT(\\2)"),
	c("([( +/*-])min[(]","\\1MIN("),
	c("([( +/*-])sum[(]([[:print:]]*), ?na.rm*=*TRUE*[)]","\\1SUM_PRESENT(\\2)"),
	c("([( +/*-])sum[(]","\\1SUM("),
	c("([( +/*-])mean[(]([[:print:]]*), ?na.rm*=*TRUE*[)]","\\1AVERAGE_PRESENT(\\2)"),
	c("([( +/*-])mean[(]","\\1AVERAGE("),
	c("([( +/*-])e([ ^*+/-])","\\1E()\\2"),
	c("([( +/*-])pi([ ^*+/-])","\\1PI()\\2"),
	c("([( +/*-])exp[(]","\\1EXP("),
	c("([( +/*-])log[(]","\\1LN("),
	c("([( +/*-])floor[(]","\\1FLOOR("),
	c("([( +/*-])log10[(]","\\1LOG10("),
	c("([( +/*-])sqrt[(]","\\1SQRT("),
	c("([( +/*-])as.logical[(]","\\1IF("),
	c("([( +/*-])ifelse[(]","\\1IF("),
	c("([( +/*-])is.na[(]","\\1IS_MISSING("),
	c("([( +/*-])strtrim[(]","\\1LEFT("),
	c("([( +/*-])nchar[(]","\\1LEN("),
	c("([( +/*-])which.max[(]","\\1MAX_INDEX("),
	c("([( +/*-])which.min[(]","\\1MIN_INDEX("),
	c("([( +/*-])(as.)?factor[(]","\\1NOMINAL("),
	c("([( +/*-])as.character[(]","\\1TEXT("),
	c("([( +/*-])![(]","\\1NOT("),
	c("([( +/*-])grep[(]","\\1REGEX_MATCH("),
	c("([( +/*-])switch[(]","\\1SELECT("),
	c("([( +/*-])I[(]","\\1(")
)

#' substituteEarnixFunctions
#' @description used for substituting R function to Earnix style.
#' @param x string. R glm formula.
#' @export
substituteEarnixFunctions <- function(x){
	for (j in 1:2) for (i in EarnixFunctionReplacementTable) x <- gsub(i[1],i[2],x)
	return(x)
}


#' Export R (g)lms to Earnix
#' 
#' @description Converts a lm or glm object to a text string, suitable for pasting into
#' Earnix.
#' 
#' \code{EarnixFormulaVersion} is an S3 generic function which currently has
#' methods for \code{\link{lm}} and \code{\link{glm}}.
#' 
#' For variable substitution to work correctly, the variable names in
#' \code{env} must exactly match the names of the coefficients in \code{model}.
#' Thus, these need to be syntactic or substitution will cause unpredictable
#' results.
#' 
#' \code{EarnixFormulaVersion} attempts to make simple substitutions of
#' function names such as \code{log(x)} -> \code{"LN(x)"} itself, unless
#' \code{sub=FALSE}. Since Earnix functions are always in uppercase, it is
#' usually easy to tell which substitutions have been made and which need to be
#' converted by the user (for example, the differing syntax of \code{RANGE()}
#' makes it very difficult to reliably substitute automatically). There are
#' some corner cases with nested calls to \code{AVERAGE_PRESENT} and its
#' friends that may not convert correctly, but these should be very rare.
#' 
#' There nay be a few unnecessary brackets in the result. This is to ensure
#' proper operation order with Earnix operators that have a lower precedence
#' than \code{`*`}.
#' @usage EarnixFormulaVersion(model, env = list(), file=NULL, nocat=FALSE, sub=TRUE)
#' @aliases EarnixFormulaVersion EarnixFormulaVersion-methods
#' EarnixFormulaVersion,glm-method EarnixFormulaVersion,lm-method
#' @param model A \code{\link{lm}} or \code{\link{glm}} object.
#' @param env An optional environment or list with named elements, containing
#' the Earnix variable names or expressions associated with the R expressions
#' that form the terms in \code{model}. See example for details.
#' 
#' If this argument is not specified then the R variable names will be used in
#' the resulting call to the Earnix function \code{GET_GAM_RESPONSE} and you
#' will have to substitute and quote the Earnix variables yourself.
#' 
#' It is not necessary to include the single quotes that Earnix usually
#' encloses its variable names with. This is done automatically (but if you did
#' include them, a second set will not be added).
#' @param file An optional filename. If specified, the result will be written
#' to this file.
#' @param nocat Logical. If TRUE, the output will not be echoed to the console
#' even if \code{file} is \code{NULL} or missing.
#' @param sub Logical. If FALSE, no attempt will be made to substitute Earnix
#' functions for R ones.
#' @return A character vector of length one, which contains a call to
#' \code{GET_GAM_RESPONSE}.
#' @note There is currently no support for true GAMs (with splines). This
#' functionality is intended to be released in a later version of \code{rex}.
#' @details \code{EarnixFormulaVersion} is an S3 generic function which currently has methods for \code{\link{lm}} and \code{\link{glm}}.
#'
#' For variable substitution to work correctly, the variable names in \code{env} must exactly match the names of the coefficients in \code{model}. Thus, these need to be syntactic or substitution will cause unpredictable results.
#'
#'\code{EarnixFormulaVersion} attempts to make simple substitutions of function names such as \code{log(x)} -> \code{"LN(x)"} itself, unless \code{sub=FALSE}. Since Earnix functions are always in uppercase, it is usually easy to tell which substitutions have been made and which need to be converted by the user (for example, the differing syntax of \code{RANGE()} makes it very difficult to reliably substitute automatically). There are some corner cases with nested calls to \code{AVERAGE_PRESENT} and its friends that may not convert correctly, but these should be very rare.
#'
#'There nay be a few unnecessary brackets in the result. This is to ensure proper operation order with Earnix operators that have a lower precedence than \code{`*`}.
#' @author James Lawrence
#' @seealso \code{\link{lm}} and \code{\link{glm}} for the modelling
#' routines.\cr \code{\link{substitute}} for substituting variable names.
#' @references Earnix function specifications and documentation, Earnix
#' Technologies, 2013.
#' @export
#' @examples
#' 
#' ## simple lm
#' 
#' x1 <- rnorm(1000); x2 <- rnorm(1000)
#' y <- rnorm(1000,x1+0.5*x2+1,1)
#' lm1 <- lm(y ~ x1)
#' EarnixFormulaVersion(lm1,list(x1="G_premium"))
#' 
EarnixFormulaVersion <- function(model,env=list(),file=NULL,nocat=FALSE,sub=TRUE){
	standardGeneric("EarnixFormulaVersion")
}

setGeneric("EarnixFormulaVersion",signature="model")

#' @export
#' @rdname EarnixFormulaVersion
EarnixFormulaVersion.lm <- function(model,env=list(),file=NULL,nocat=FALSE,sub=TRUE){
	modelno <- 0L
	txt.out <- paste0(model$coef," * ",names(model$coef),collapse=" + ")
	txt.out <- paste0("GET_GAM_RESPONSE( ",modelno," , ",txt.out," )")
	txt.out <- gsub(" [*] [(]{1,2}Intercept[)]{1,2}","",txt.out)
	for (z in names(env)){
		if(!length(grep("'[[:alnum:]_]*'",get(z,env)))) zz <- paste0("'",get(z,env),"'") else zz <- get(z,env)
		txt.out <- gsub(paste0("([( ])",z,"([) ])"),paste0("\\1",zz,"\\2"),txt.out)
	}
	if(sub) txt.out <- substituteEarnixFunctions(txt.out)
	if(missing(file)){
		if (!nocat) cat(txt.out)
	} else cat(txt.out,file=file)
	return(invisible(txt.out))
}

#' @export
#' @rdname EarnixFormulaVersion
EarnixFormulaVersion.glm <- function(model,env=list(),file=NULL,nocat=FALSE,sub=TRUE){
	modelID <- paste0(model$family$family,model$family$link)
	modelno <- switch(modelID,
		"gaussianidentity"=0L,
		"binomiallogit"=1L,
		"quasibinomiallogit"=1L,
		"poissonlog"=2L,
		"quasipoissonlog"=2L,
		"poissonidentity"=3L,
		"quasipoissonidentity"=3L,
		"Gammainverse"=4L,
		"Gammalog"=5L,
		"inverse.gaussian1/mu^2"=6L,
		"inverse.gaussianlog"=7L,
		{
			etxt <- paste0("model not supported in Earnix: family ",model$family$family," with link ",model$family$link)
			stop(etxt)
		}
	)
	txt.out <- paste0(model$coef," * (",names(model$coef),")",collapse=" + ")
	txt.out <- paste0("GET_GAM_RESPONSE( ",modelno," , ",txt.out," )")
	txt.out <- gsub(" [*] [(]{1,2}Intercept[)]{1,2}","",txt.out)
	if(inherits(model,"EarnixGLM")){
		txt.out <- gsub("df.fit[$]\\\"([[:print:]]*?)\\\"","\\1",txt.out)
	}
	for (z in names(env)){
		if(!length(grep("'[[:alnum:]_]*'",get(z,env)))) zz <- paste0("'",get(z,env),"'") else zz <- get(z,env)
		txt.out <- gsub(paste0("([( ])",z,"([) ])"),paste0("\\1",zz,"\\2"),txt.out)
	}
	if(sub) txt.out <- substituteEarnixFunctions(txt.out)
	if(missing(file)){
		if (!nocat) cat(txt.out)
	} else cat(txt.out,file=file)
	return(invisible(txt.out))
}
setMethod("EarnixFormulaVersion",signature(model="glm"),EarnixFormulaVersion.glm)
setMethod("EarnixFormulaVersion",signature(model="lm"),EarnixFormulaVersion.lm)

