#' Nice formatting for numbers
#' 
#' @description niceNum formats numbers nicely for display. 
#' @usage niceNum(x,
#'         digits = 3)
#' @param x Vector of numbers to format.
#' @param digits The minimum number of significant figures to display.
#' @return A character vector.
#' @examples 
#' # library(rsai)
#' # niceNum(sapply(-8:8, function(i) 1.23456*10^i), digits = 4L)
#' @export
#' @author Edwin Graham

niceNum <- function(x, digits = 3L){
  # Round to signigicant figures, if decimal places are required
  low <- which(floor(log10(x)) < digits - 1)
  x[low] <- signif(x[low], digits)
  
  # Non-scientific notation
  f <- gsub(" ", "", formatC(x, digits = digits, big.mark = ",", format = "fg", flag = "#"))
  # Scientific notation
  f2 <- gsub(" ", "", formatC(x, digits = digits-1, format = "E"))
  
  # Choose the one that's smaller
  f[which(nchar(f2) < nchar(f))] <- f2[which(nchar(f2) < nchar(f))]
  
  return(f)
}