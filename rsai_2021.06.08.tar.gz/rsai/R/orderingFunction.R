# Useful function for merging EMBglm tables, does not need to be exported...

orderingFunction <- function(x){
  # Validation
  if (! is.list(x)){
    stop("x must be a list")
  }
  if (! all(sapply(x, is.character))){
    stop("x must be a list of characters")
  }
  if (length(x) < 1){
    stop("x must be a list containing at least one character vector")
  }
  if (length(x) == 1){
    return(x[[1]])
  }
  
  # Drop non-unique elements of each vector
  x <- lapply(x, unique)
  
  # Loop through vectors two at a time and combining them
  while (length(x) > 1){
    
    # Combine first two vectors in wrong order
    x3 <- union(x[[1]], x[[2]])
    
    # If x2 has no new elements...
    if (length(x3) == length(x[[1]])){
      x[2] <- NULL
      # Otherwise, if x1 and x2 are disjoint
    } else if (length(x3) == length(x[[1]]) + length(x[[2]])){
      x[[1]] <- x3
      x[2] <- NULL
      # Otherwise...
    } else {
      
      # Match elements of first two vectors to x3
      x1ord <- match(x3, x[[1]])
      x2ord <- match(x3, x[[2]])
      
      # When elements of x2 are jumbled up, just return the union
      if (any(diff(x2ord[which(! is.na(x1ord) & ! is.na(x2ord))]) < 0)){
        x[[1]] <- x3
        x[2] <- NULL
        # Otherwise...
      } else{
        # Cumulative count of non-missing elements for x2
        x2fill <- cumsum(! is.na(x2ord))
        
        # Find number of elements of x1 that are before missing elements of x2
        index <- sapply(
          # Elements of x2 not in x1
          x2ord[is.na(x1ord)],
          # Find number of elements that are in both that it is after
          function(x){
            sum(x > x2ord[which(! is.na(x1ord) & ! is.na(x2ord))])
          }
        )
        
        # Update positions of x2 elements using index
        x2fill[is.na(x1ord)] <- index
        x1ord[is.na(x1ord)] <- length(x1ord)
        
        # Reorder and replace x1 and drop x2
        x[[1]] <- x3[order(x2fill, x1ord)]
        x[2] <- NULL
      }
    }
  }
  
  # return
  return(x[[1]])
}