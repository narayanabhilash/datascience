#####  rsaiKNN  #####
#' Function to efficiently calculate distance and experience weighted k nearest neighbourhoods with cross folds.
#' @description This function calculates a list of neighbourhoods using the \code{spatstat} package, and/or knn features 
#' based on those neighbourhoods. These could be a response or an input variable.
#' @usage rsaiKNN(
#' dt,
#' dt_scoreOn = NULL,
#' featurestoKNN = character(),
#' coordinates = c ("x_coord", "y_coord"),
#' trainSet = NULL,
#' folds = NULL,
#' distance = FALSE,
#' weights = 100:1,
#' distexponent = 1e-04,
#' weightcol = NULL,
#' return_neighbourhoods = FALSE,
#' just_neighbourhoods = FALSE,
#' neighbourhoods = NULL,
#' exclude_own = FALSE,
#' medianFlag = FALSE) 
#' @param dt a data frame or data table containing planar coordinates and features you wish to compute neighbourhoods from
#' @param dt_scoreOn a data frame or table (containing coordinates) on which you wish to calculate your features. if NULL
#' then the features are calculated on dt.
#' @param featurestoKNN character vector of the columns in dt which you want to calculate KNN values from.
#' @param coordinates the names of the "X" and "Y" coordinates fields in dt. \code{dt_scoreOn} must be consistent with this if provided.
#' note that the function will throw an error if spatial data include missing values.
#' @param trainSet training set, ie a subset of dt on which to calculate. If not supplied all the data are used. 
#' @param folds fold data for cross-fold calculations. this can be a column name of dt, a separate integer vector or a list of folds. If it is not
#' a column name of dt then the fold data must relate exclusively to \emph{trainSet} - this is consistent with folds used in \code{xgboost} etc.
#' e.g. if folds is a separate vector it should be the same length as trainSet. If provided, the function returns out of fold values.
#' @param distance logical: are the weights assigned to the calculated knn features a function of distance from the location for which they are calculated?
#' If not then a weight according to distance ranking is used. This is quicker and less memory intensive.
#' @param weights a (usually declining) vector of weights equal in length to the number of points in each calculated neighbourhood. 
#' This determines the size of the neighbourhoods and so should be specified even if \code{distance} is TRUE.
#' @param distexponent a positive value determining how quickly distance weighting declines. Weight assigned to point A when calculating values for point B
#' = exp (-d(A,B)*\code{distexponent}) where d(A,B) = the Euclidean distance from A to B.
#' @param weightcol if provided, a character string denoting a column of weights (eg exposure, population) to include in the calculation. 
#' @param return_neighbourhoods do you want neighbourhood data returned (as well as the features)?
#' @param just_neighbourhoods do you want just the neighbourhood data returned?
#' @param neighbourhoods a list of neighbourhoods already calculated. If specified, these are used. 
#' @param exclude_own logical used where dt_scoreOn is NULL and folds are not being used. If true, then the neighbourhoods calculated for a point A do not include
#' A itself. This can be useful if you are calculating the KNN of a response variable when building a model and wish to avoid data leakage. 
#' @param medianFlag Return a weighted median rather than a weighted mean. Likely to take a while to run
#' @return  a list containing:
#' - \emph{neighbours}, a list of the neighbourhood(s) rows of dt[trainSet] for each row of dt, dt_scoreOn or the "in fold" subset of dt (as appropriate), and
#' - \emph{knns}, a data table containing a row number index plus the weighted values required.  Note if trainSet is specified the row numbers relate to dt,
#' not to dt[trainSet].
#'   - \emph{exposureWeights}, a list of the weight vectors used. This can be useful if the calculated values use very different exposures
#'   and you wish to normalise your response.
#' @details For each row (i) of data for which a calculation is being done and each response column (R), rsaiKNN calculates the following:
#' - Neighbourhood N(i) of points closest to i in the relevant data set
#' - W(i) vector of distance dependant rates for N(i). This could be a constant vector or could depend on the distance to point i
#' - E(i) vector of exposure weights for N(i): if not specified, E(i) = a vector of Ones.
#' 
#' - Returned output O_R(i), where
#'  O_R(i) = Sum over j in N(i) {R(N(i)[j] x W(i)[j] x E(i)[j]} /  Sum over j in N(i) {W(i)[j] x E(i)[j]} 
#'  
#'  More detailed use cases will be published on the data science blog
#' 
#' @author Tom Bratcher (Tom.Bratcher@uk.rsagroup.com)
#' @examples

#' ## deliberately not run, as may take a while...
#' #data ("UKTheftFreq")
#' #knn <- rsaiKNN(UKTheftFreq, featurestoKNN = c("Social_Grade_DE", "Rented_from_Council"),
#' #coordinates = c("coordinate_x", "coordinate_y"))
#' #UKTheftFreq[, SocialKNN := knn$knns$Social_Grade_DE]
#' #plotMap (UKTheftFreq, "SocialKNN",x_coord = "coordinate_x", y_coord = "coordinate_y", cex = 5)

#' @export


rsaiKNN <- function (
  dt,
  dt_scoreOn = NULL,
  featurestoKNN = character(),
  coordinates = c ("x_coord", "y_coord"),
  trainSet = NULL,
  folds = NULL,
  distance = FALSE,
  weights = 100:1,
  distexponent = 1e-04,
  weightcol = NULL,
  return_neighbourhoods = FALSE,
  just_neighbourhoods = FALSE,
  neighbourhoods = NULL,
  exclude_own = FALSE,
  medianFlag = FALSE
) {
  # Error checks---------------------
  
  if (!(all( c(coordinates, featurestoKNN) %in% names(dt))))
    stop ("one or more coordinate labels and/or features are not columns of dt.
          Have you remembered to specify coordinate labels?"        
    )
  
  for (nm in coordinates) {
    if (any (is.na (dt[[nm]]))) stop ("dt column ", nm, "contains missing values")
    
  }
  
  
  # If dt_scoreOn specified, set some values --------------------------------
  
  if (!(is.null(dt_scoreOn))){
    folds = NULL
    for (nm in coordinates) {
      if (any (is.na (dt_scoreOn[[nm]]))) stop ("dt_scoreon column ", nm, "contains missing values") 
    }
  } 
  
  # fill in missing data from null defaults ---------------------------------
  
  if (is.null (trainSet)) trainSet <- 1:nrow(dt)
  setDT(dt)
  dt <- dt[trainSet]
  #NB - folds should be consistent with this
  # folds
  
  if (is.null (folds))folds <- rep (1, nrow(dt))
  
  if (is.character(folds)) {
    if (!(folds %in% names (dt))) stop ("folds is a character but is not a column of dt")
    folds <- dt[[folds]]
  }
  
  if (is.list(folds)) folds <-rsai::folds_ListToVec(folds)
  # so now have, let's say, a vector of 1,2,3,4,5
  if (length (folds) != nrow(dt))stop ("folds data must have the same number of entries as trainSet")
  #after trainSet
  
  # Exclude own record? -----------------------------------------------------
  
  Own=0L
  if (length (folds)==1) Own = as.integer(exclude_own)
  
  # Specify neighbourhoods if not provided ----------------------------------
  
  if (is.null(neighbourhoods)){
    neighbours <- list()
    
    # loop over folds ---------------------------------------------------------
    uniqueFolds <- unique(folds)
    for (i in seq_along(uniqueFolds)) {
      # get neighbours matrices -------------------------------------------------
      
      # setup subsets
      inFold <- which (folds == uniqueFolds[i])
      outFold <- which (folds != uniqueFolds[i])
      if (length (uniqueFolds) == 1) outFold <- inFold
      
      #... so if haven't specified folds, these 2 are the same.
      
      if (is.null (neighbourhoods)) {
        # ie if we haven't got the neighbourhoods already
        
        
        if (is.null (dt_scoreOn)){
          ppp_in <- ppp(dt[[coordinates[1]]][inFold],
                        dt[[coordinates[2]]][inFold],
                        window = owin(c(min (dt[[coordinates[1]]]), max (dt[[coordinates[1]]])),
                                      c(min (dt[[coordinates[2]]]), max (dt[[coordinates[2]]]))))
        } else {
          ppp_in = ppp(dt_scoreOn[[coordinates[1]]],
                       dt_scoreOn [[coordinates[2]]],
                       window = owin(c(min (dt_scoreOn[[coordinates[1]]]), max (dt_scoreOn[[coordinates[1]]])),
                                     c(min (dt_scoreOn[[coordinates[2]]]), max (dt_scoreOn[[coordinates[2]]]))))
        }
        ppp_out <- ppp(dt[[coordinates[1]]][outFold],
                       dt[[coordinates[[2]]]][outFold],
                       window = owin(c(min (dt[[coordinates[1]]]), max (dt[[coordinates[1]]])),
                                     c(min (dt[[coordinates[2]]]), max (dt[[coordinates[2]]]))))
        
        #do we want distances as well as row numbers?
        what = "which"
        if (distance) what = c ("dist","which")
        
        neighbours[[i]] <- as.data.table(
          nncross (ppp_in,
                   ppp_out,
                   what = what,
                   k = Own+(seq_along(weights))))
        # can split which, dist by...
        # neighbours <- neighbours [,grep ("which", names (neighbours)), with=F]
      } }
  }else {
    neighbours <- neighbourhoods
    if (is.data.table(neighbourhoods)) neighbours <- list(neighbours)
  }
  
  
  # if just want neighbourhoods, return them here ---------------------------
  if (just_neighbourhoods) {
    if (length (neighbours) ==1) return (as.data.table (neighbours)) else return (neighbours)
  }
  
  # calculate out values based on neighbourhoods ----------------------------
  
  first = T
  exposureWeights = list() # list out.
  for (i in seq_along(uniqueFolds)) {  # pathologically might not equal seq_along(folds)
    # and in ptic contain zero which ruins everything
    inFold <- which (folds == uniqueFolds[i])
    outFold <- which (folds != uniqueFolds[i])
    if (length(uniqueFolds) == 1) outFold <- inFold
   
    # change if predicting on new data required... -----------------------
    
    if (!(is.null(dt_scoreOn)))  inFold <- 1:nrow(dt_scoreOn)
    
    foldOutput = data.table(rowNo = inFold)
    # calculate DATA weights<-denominator matrix --------------------------------------------------
    # get weights column data which is the same regardless of wether prediction on new data. 
    if (!is.null (weightcol)) OOFweightVector <- dt[[weightcol]][outFold] else OOFweightVector = rep (1L,length(outFold))
    
    # if weights are done by distance _actual_ we use:
    
    if (!distance){
      # if weights are done by ranking we can use:
      OOFweightMatrix <- apply (neighbours[[i]], 1, function(x) as.numeric(weights %*% OOFweightVector[x]))
    } # it's not actually a matrix...
    # calculate weighted average for each feature in turn>-------
    for (nm in featurestoKNN) {
      if (distance){
        # start with distances... 
        dists <- seq_along(weights)
        refs <- length(weights) + seq_along(weights)
        OOFweightMatrix <- apply (neighbours[[i]],1, function (x)
          (exp (-distexponent*x[dists])%*%(OOFweightVector[x[refs]]) )
        )
        if (medianFlag){
          foldOutput[[nm]] <- apply(
            neighbours[[i]],
            1, function (x)
              as.numeric (weighted.median(dt[[nm]][outFold[x[refs]]], w = exp(-distexponent * x[dists]) * (OOFweightVector[x[refs]]))))
        } else {
          foldOutput[[nm]] <- apply(
            neighbours[[i]],
            1, function (x)
              as.numeric (exp(-distexponent * x[dists]) %*% (OOFweightVector[x[refs]] * dt[[nm]][outFold[x[refs]]]))) /  OOFweightMatrix
        }
        
      } else{
        if (medianFlag){
          foldOutput[[nm]] <- apply(
            neighbours[[i]],
            1, function (x)
              as.numeric (weighted.median(dt[[nm]][outFold[x]], w = weights * (OOFweightVector[as.integer(x)]))))
        } else {
          
          foldOutput[[nm]] <- apply (
            neighbours[[i]],
            1, function (x)
              as.numeric (weights %*% (OOFweightVector[as.integer(x)] * dt[[nm]][outFold[x]]))) /  OOFweightMatrix
        }
      }
    }
    
    if (first) Output = foldOutput else Output = rbind (Output, foldOutput)  
    exposureWeights[[i]]<-OOFweightMatrix 
    first = F   
  }
  setkey(Output,rowNo)
  if (is.null(dt_scoreOn)) Output$rowNo <- Output$rowNo[trainSet]
  
  
  if (!(return_neighbourhoods))neighbours <- NULL
  if (length (neighbours)==1) neighbours <- as.data.table(neighbours)
  return(list (
    neighbourhoods = neighbours,
    knns = as.data.table(Output),
    exposureWeights=exposureWeights))
}


#####  LongLatToUTM  #####
#' Function to convert Lat/Long data to a UTM planar map reference. 
#' @description Function to convert Lat/Long data to a local UTM planar map reference.
#' The UTM mapping used can be specified or inferred.
#' The default should work for most RSA regions at time of writing.
#' Canada is too big to fit in a single local grid but could use a global coordinate system:
#' To do this use \code{epsg = 3857}. 
#' Not built for use in Southern Hemisphere.
#' @usage LongLatToUTM(
#' x,
#' y,
#' zone = 30,
#' epsg = NULL)
#' @param x a vector of longitude data in degrees East (negative for West).
#' @param y a vector of latitude data in degrees North.
#' @param zone the UTM zone used for projection. This would typically be 29 for Ireland,
#' 30 for UK (the default!) and 33 for Sweden. 
#' @param epsg optional character or integer. If used, overrides the projection data and uses
#' a particular epsg map number.
#' @details See https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system for details of the UTM grids.
#' 
#' @author Tom Bratcher (Tom.Bratcher@uk.rsagroup.com)
#' @examples
#' x<-c(-2.99,-2.98,-2.97,-2.97,0.96)
#' y<-c(52.11,52.12,52.13,53.13,52.13)
#' LongLatToUTM(x,y)
#' @export

LongLatToUTM <- function(x, y, zone = 30, epsg = NULL) {
  if (length (x) != length(y))
    stop ("x and y are of different lengths")
  xy <- data.frame(rowNo = 1:length(x),
                   X = x,
                   Y = y)
  coordinates(xy) <- c("X", "Y")
  proj4string(xy) <- CRS("+proj=longlat +datum=WGS84")
  if (is.null (epsg)) {
    zone2 = 1 + (trunc((median (x) + 180) / 6)) # works for most places in the NH
    if (zone != zone2)
      warning (paste0 (
        "zone value may not be appropriate for your data: suggested value =",
        zone2
      ))
    epsg <- paste("+proj=utm +zone=", zone, " ellps=WGS84", sep = '')
  }
  else epsg <- paste0("+init=epsg:",epsg)
  res <- spTransform(xy, CRS(epsg))
  res <- as.data.frame(res)
  setDT(res)
  return (res)
}

#####  rsaiKNN3d  #####
#' Function to efficiently calculate distance and experience weighted k nearest neighbourhoods in multiple dimensions.
#' @description This function calculates a neighbourhood using the \code{spatstat} package, and/or knn features 
#' based on those neighbourhoods. These could be a response or an input variable. Any number of dimensions can be used.
#' @usage rsaiKNN3d (dt,
#' featurestoKNN = character(),
#' coordinates = c ("x_coord", "y_coord"),
#' weights = 100:1,
#' weightcol = NULL,
#' return_neighbourhoods = F,
#' just_neighbourhoods = F,
#' neighbourhoods = NULL,
#' exclude_own = F
#' )
#' @param dt a data frame or data table containing planar coordinates and features you wish to compute neighbourhoods from
#' @param featurestoKNN character vector of the columns in dt which you want to calculate KNN values from.
#' @param coordinates the names of the spatial coordinate fields in \code{dt}. 
#' #' note that the function will throw an error if spatial data include missing values.
#' @param weights a (usually declining) vector of weights equal in length to the number of points in each calculated neighbourhood. 
#' This determines the size of the neighbourhoods.
#' @param weightcol if provided, a character string denoting a column of weights (eg exposure, population) to include in the calculation. 
#' @param return_neighbourhoods do you want neighbourhood data returned (as well as the features)?
#' @param just_neighbourhoods do you want just the neighbourhood data returned?
#' @param neighbourhoods a list of neighbourhoods already calculated. If specified, these are used. 
#' @param exclude_own logical used where dt_scoreOn is NULL and folds are not being used. If true, then the neighbourhoods calculated for a point A do not include
#' A itself. This can be useful if you are calculating the KNN of a response variable when building a model and wish to avoid data leakage. 
#' 
#' @return  a list containing:
#' - \emph{neighbours}, a list of the neighbourhood(s) rows of dt[trainSet] for each row of dt, dt_scoreOn or the "in fold" subset of dt (as appropriate), and
#' - \emph{knns}, a data table containing a row number index plus the weighted values required.  Note if trainSet is specified the row numbers relate to dt,
#' not to dt[trainSet].
#'   - \emph{exposureWeights}, a list of the weight vectors used. This can be useful if the calculated values use very different exposures
#'   and you wish to normalise your response.
#' @details For each row (i) of data for which a calculation is being done and each response column (R), rsaiKNN calculates the following:
#' - Neighbourhood N(i) of points closest to i in the data set.  distance is defined over all of the stated dimensions (which are assumed to
#' be consistent in nature).
#' - W(i) vector of distance dependant rates for N(i). This could be a constant vector or could depend on the distance to point i
#' - E(i) vector of exposure weights for N(i): if not specified, E(i) = a vector of Ones.
#' 
#' - Returned output O_R(i), where
#'  O_R(i) = Sum over j in N(i) {R(N(i)[j] x W(i)[j] x E(i)[j]} /  Sum over j in N(i) {W(i)[j] x E(i)[j]} 
#'  
#' 
#' @author Tom Bratcher (Tom.Bratcher@uk.rsagroup.com)
#' @examples

#' set.seed(39L) # set up a biased random sample:
#' dt<- data.table(x_coord = runif(100000,0,3),
#' y_coord = runif (100000,0,3))
#' dt[,intensity1:=exp(-5*(1.5*(x_coord-1)^2+(y_coord-0.6)^2))]
#' dt[,intensity2:=exp(-20*((x_coord-1.5)^2+(y_coord-2.7)^2))]
#' dt[,intensity3:=exp(-200*((x_coord-2.5)^2+0.2*(y_coord-1.4)^2))]
#' dt[,cityFlag:= (x_coord + y_coord <1)]
#' dt[,totalintensity:= 4+intensity1+2*intensity2+3*intensity3-cityFlag]
#' dt[,randomOutcome:=rpois(100000,totalintensity)]  # a noisy feature based on intensity
#' plotMap(dt,"totalintensity",cex = 2)
#' dt_scoreOn <- data.table(x_coord = runif(3000,0,1),y_coord = runif (3000,0,1))
#' knns<- rsaiKNN3d(dt,
#' coordinates = c ("x_coord","y_coord","cityFlag"),
#' weights = 0.99^(1:300),
#' featurestoKNN = "randomOutcome")
#' dt[,knnRandom:=knns$knns$randomOutcome]
#' plotMap(dt,"knnRandom",cex = 3)
#' @export

rsaiKNN3d <- function (
  dt,
  featurestoKNN = character(),
  coordinates = c ("x_coord", "y_coord"),
  weights = 100:1,
  weightcol = NULL,
  return_neighbourhoods = F,
  just_neighbourhoods = F,
  neighbourhoods = NULL,
  exclude_own = F
  
) {
  
  # Error / sanity checks
  if (!(all( c(coordinates, featurestoKNN) %in% names(dt))))
    stop ("one or more coordinate labels and/or features are not columns of dt")
  
  for (nm in coordinates) {
    if (any (is.na (dt[[nm]]))) stop ("dt column ", nm, "contains missing values")
    
  }
  
  # Specify neighbourhoods if not provided ----------------------------------
  
  if (is.null(neighbourhoods)){
    neighbours <- list()
    
    # get neighbours matrices -------------------------------------------------
    
    ppp_in <- ppx(dt[,coordinates,with=F]) # didn't seem to want to simplify anyway
    
    neighbours <- as.data.table(
      nnwhich (ppp_in, k = seq_along(weights)+exclude_own)) 
  }else neighbours <- neighbourhoods
  
  
  # if just want neighbourhoods, return them here ---------------------------
  if (just_neighbourhoods) {
    if (length (neighbours) ==1) return (as.data.table (neighbours)) else return (neighbours)
  }
  
  # calculate out values based on neighbourhoods ----------------------------
  
  Output = data.table(rowNo = 1:nrow(dt))   
  exposureWeights = list() # list out.
  # change if predicting on new data required... -----------------------
  
  # calculate DATA weights<-denominator matrix --------------------------------------------------
  # get weights column data which is the same regardless of whether prediction on new data. 
  if (!is.null(weightcol)) OOFweightVector <- dt[[weightcol]] else OOFweightVector <- rep (1L,nrow(dt))
  
  # as weights are done by ranking we can use:
  OOFweightMatrix <- apply (neighbours, 1, function(x) as.numeric(weights %*% OOFweightVector[x]))
  # it's not actually a matrix...
  # calculate weighted average for each feature in turn>
  for (nm in featurestoKNN) {
    
    Output[[nm]] <- apply (
      neighbours, 1,
      function (x) as.numeric (weights %*% (OOFweightVector[x] * dt[[nm]][x]))
      ) /  OOFweightMatrix
  }
  
  exposureWeights <- OOFweightMatrix 
  
  setkey(Output, rowNo)
  
  if (!(return_neighbourhoods)) neighbours<- NULL
  if (length (neighbours)==1) neighbours<- as.data.table(neighbours)
  return (list(
    neighbourhoods = neighbours,
    knns = as.data.table(Output),
    exposureWeights=exposureWeights))
}
