#' An S4 class for data dictionary
#'
#' @slot colNames A string for name of variable.
#' @slot colClasses A string for type of variable.
#' @slot levels list of valid possible level of the variable.
#' @slot NALevels list of possible unknown level of the variable.
#' @exportClass dataDictionary
#' 
setClass("dataDictionary", representation(
  colNames="character",
  colClasses="character",
  levels="list", ## named,names=colNames where colClasses="factor"
  NALevels = "list"
),validity=function(object){ l<- sapply(object@levels, length)
if(!all(names(object@levels)[which(l>1)] %in% object@colNames[object@colClasses=="factor"|object@colClasses =="ordered" ])){
  return("names of object@levels do not match those elements with class 'factor' or 'ordered'")}
if(!all(object@colNames[object@colClasses=="factor"| object@colClasses =="ordered"] %in% names(object@levels))){
  return("names of object@levels don't match those elements with class 'factor' or 'ordered'")}
#if(any(!(object@colClasses %in% c("logical","integer","int64","numeric","complex","character","factor","ordered")))) return("unsupported column classes")
}) -> dataDictionary

setAs("ANY", "character", function(from) as.character(from))
setAs("ANY", "numeric", function(from) as.numeric(from))
setAs("ANY", "integer", function(from) as.integer(from))
setAs("ANY", "factor", function(from) as.factor(from))
setAs("ANY","logical",function(from) as.logical(from))
setAs("ANY","ordered",function(from) as.ordered(from))


###############
# Functions to order Data dictionary factors
###############

stringValue <- function (string){
  
  if (!grepl("^[A-Za-z]{1,3}$", string)) return (NA)
  splitNos <- as.integer(sapply(strsplit(toupper(string), ""), function (x) match(x, LETTERS)))
  as.integer(splitNos %*% (26 ^ seq(length(splitNos) - 1, 0, -1)))
}  

orderer <- function (levels){
  if (!(length(levels))) return (NULL)
  if (!(is.character(levels))) levels <- as.character(levels)
  # are all the levels of the correct form:
  formatCheck <- all(grepl("^[A-Z]+ *:", levels))
  if (!(formatCheck)) return (NULL)
  # if so:
  as.integer(sapply(gsub("(^[A-Z]+)( *:.*)","\\1", levels), stringValue))
}

#' Order the levels of a Data Dictionary
#' 
#' @description By default, `extractDataDictionary` reads factor data without
#' an ordering. This function attempts to convert factor data to ordered where
#' a logical ordering is suggested by the data's levels.
#' @usage orderDD(DD)
#' @param DD A data dictionary
#' @return The data dictionary, with some factor levels reordered and the column
#' set to "ordered".
#' @details The function looks for columns with factor levels which are either 1)
#' all prefixed with an obvious alphabetic - style ordering code or 2) can all, or almost
#' all, be parsed by `EMBscrub`. The example below shows them in action.  
#' @export
#'
#' @examples
#' levels1 <- c("A: 0-4", "B: 5-9", "C: 10-14", "AA: 400+")
#' levels2 <- c("6-9 months", "9-12 months", "1-2 years", "2 + years", "unknown", "no period")
#' levels3 <- c("Apple", "Banana", "Cherry")
#' set.seed(111L)
#' dummyData <- data.table(
#'   RowNo = 1:100,
#'   Factor = sample(levels1, 100, replace = TRUE),
#'   Age = sample(levels2, 100, replace = TRUE),
#'   Fruit = sample(levels3, 100, replace = TRUE)
#' )
#' print(DD <- extractDataDictionary(dummyData, stringsAsFactors = TRUE))
#' print(orderDD(DD))
#' 
orderDD <- function (DD){
  # start with the strings:
  orderedLevels <- sapply(DD@levels, orderer)
  these <- setdiff(which(DD@colClasses == "factor"), 
                   which(sapply(orderedLevels, is.null)))
  for (nm in names(DD@levels)[these]) {
  #  cat(nm, "\n")
    DD@levels[[nm]] <- DD@levels[[nm]][order(orderedLevels[[nm]])]
  } # can do with sapply, but these are small it's fine
  DD@colClasses[these] <- "ordered"
  
  # then do what EMBSCRUB would make numeric:
  scrubbedLevels <- sapply(DD@levels, function (x) 
    suppressWarnings(EMBscrub(x, noFlag = T)))
  these <- setdiff(which(sapply(DD@levels, length) > 2),
                   which(sapply(scrubbedLevels, function (x) sum(is.na(x))) > 1))
  for (nm in names (DD@levels[these])){
    DD@levels[[nm]] <- DD@levels[[nm]][order(scrubbedLevels[[nm]])]
  }
  DD@colClasses[these] <- "ordered"
  DD
}


#' maxClass
#' 
#' @description maxClass
#' @param foo vector
#' @param bar vector
#' @export
maxClass <- function (foo, bar) {
  
  x<- length(foo)  
  y<- length(bar)
  if (!(x==y)) stop ("length mismatch")
  z<- 0
  numberWang <- c(
    "logical", "integer", "int64", "numeric", "complex", "Date", "character", "factor", "ordered")

  for (i in 1:x) {
    num1 <- match (as.character (foo[i]), numberWang)  
    num2 <- match (as.character (bar[i]), numberWang) 
    if (is.na(num1) || is.na (num2)) stop ("invalid class")
    foo[i] <- numberWang[max(num1,num2)]
    
    if (num1<num2) cat(
      "coerced", names(foo)[i], "to class", as.character(numberWang[num2]), "\n")
  }
  return(foo)
}

#' mergeDic
#' 
#' @description merge dictionary
#' @param data1,data2 dictionary data to be added
#' @param classList list of class
#' @param warnUnusedColumns whether to warning on unsed columns
#' @param convMessage whether to message
#' @param coercedCols coerced columns with list provided
#' @export
mergeDic <- function (data1,data2,
                      classList =as.character(),warnUnusedColumns=FALSE,
                      convMessage=TRUE, coercedCols = list()){
  
  numberWang <- c ("logical", "integer", "int64", "numeric", "complex")  
  
  for(i in seq_along(colnames(data1))){
    nm <- colnames(data1)[i]
    if(is.null(data2[[nm]])){
      if(warnUnusedColumns) warning(gettextf("column %s not present",nm))
      next
    }
    cl1 <-class(data1[[nm]])
    cl1 <-cl1 [length(cl1)]
    cl2 <- class(data2[[nm]])
    cl2 <-cl2 [length(cl2)]
    
    cl1to <- cl1
    if (nm %in% names (classList)) cl1to <- classList[[nm]]
 
    if( cl2 %in% c("factor", "ordered")) {
      toFactorFlag <- TRUE
      
      if (!(cl1to %in% c("factor","ordered"))) toFactorFlag <- FALSE
      if (!(cl1 %in% c("factor","ordered")) && convMessage && toFactorFlag) { 
        print (gettextf("converting column %s from %s to factor", nm, cl1))
        attr(data1,"Coerced") <- "Yes"
        coercedCols <- c(coercedCols, nm)
        }
      
      if (cl1to == "factor"&& cl1 != "factor")  {data1[[nm]] <- factor(data1[[nm]])}
      if (cl1to == "ordered"&& cl1 != "ordered")  {data1[[nm]] <- ordered(data1[[nm]])} 
      if (toFactorFlag || convMessage) {
        data1[[nm]] <- factor(
          as.character(data1[[nm]]),
          levels = sortA(unique(c(levels(data1[[nm]]), levels(data2[[nm]])))),
          sortA(unique(c(levels(data1[[nm]]), levels(data2[[nm]])))))
      } 
      
      
      if (!(nm %in% names (classList)) && !(convMessage) && cl1 != "factor" ) {
        warning (c(nm, " not converted to factor from ",data2))
        data1[[nm]] <- as.character(data1 [[nm]])}
      
      next
    }
    
    if(cl1 %in% c("factor","ordered")) {
      d2f <- factor(data2[[nm]])
      data1[[nm]] <- factor(
        as.character(data1[[nm]]),
        levels=sortA(unique(c(levels(data1[[nm]]),levels(d2f)))),
        sortA(unique(c(levels(data1[[nm]]),levels(d2f)))))
      if (nm %in% names (classList)) class (data1[[nm]]) <- classList[[nm]]
      next
    }
    
    # dates...
    
    if (cl1 == "Date"| cl2 == "Date") { # would only happen if you specified it as date I think?!
         next #... so no action required.
    }

    ch1 <- (cl1 == "character")
    ch2 <- (cl2 == "character")
    if(ch1 + ch2 ==1 &&  ! (nm %in% names (classList)) ) {
      if (convMessage)   
      {print (gettextf("converted column %s to factor",nm))
        coercedCols <-c (coercedCols, nm)}   
      if (convMessage || cl1to == "factor") {
        
        data1[[nm]] <- factor(data1[[nm]])      
        d2f <- factor(data2[[nm]])
        data1[[nm]] <- factor(
          as.character(data1[[nm]]),
          levels=sortA(unique(c(levels(data1[[nm]]),levels(d2f)))),
          sortA(unique(c(levels(data1[[nm]]),levels(d2f)))))}
      
      else { data1[[nm]] = as.character( data1 [[nm]])  
      warning(
        c(
          "Column", nm,
          "coerced to character due to type mismatch. If this is not desired,
          you can add the column name into colClasses.\n"))
      coercedCols <- c(coercedCols, nm)
      next}
      
      num1 <- match (cl1, numberWang)  
      num2 <- match (cl2, numberWang)    
      if (!(is.na(num1)) && !(is.na (num2))) 
      {class (data1[[nm]]) <- numberWang[max(num1,num2)]
      if (num1 < num2) 
        cat("coerced ", names(foo)[i], " to class ", as.character(numberWang[num2]))
      }
    }
  }
  return (list(data1, coercedCols))
  
}

#' Functions to extract data types and factor levels from a data frame or file
#' and apply them.
#' 
#' @description `extractDataDictionary` extracts data types and factor levels and produces a
#' "data dictionary" object. This can then be viewed, edited if desired, and
#' applied to another file using the applyDataDictionary function. This enables
#' users to automatically produce files with consistent file formatting and in
#' particular consistent factor levels, which is vital for processing using
#' routines that make use of sparse matrices such as xgboost.
#' 
#' `extractDataDictionary` can also be used to just return data types.
#' 
#' Data Dictionaries can also be passed as an argument to the RSAI function
#' `downSample`; this acts to apply a data dictionary to a file while
#' downsampling it. (This will usually be the data dictionary of the original
#' file.)
#' 
#' Data dictionaries can also be added together (essentially, creating a union
#' of their fields and factor levels) and subtracted (doesn't give a data dictionary
#' but does show differences).
#' 
#' From version 2021.02.09 `applyDataDictionary` will always return a data table.
#' This allows for faster execution. it's also possible to apply the function as a method
#' (i.e. make changes to an object without returning anything) by setting `newObj = FALSE`.
#' This gives better memory efficiency, but for backwards compatibility is not the default.
#' 
#' @aliases extractDataDictionary applyDataDictionary addDataDictionary diffDataDictionary
#' +, dataDictionary,dataDictionary-method
#' -, dataDictionary,dataDictionary-method
#' extractDataDictionary, character-method
#' extractDataDictionary, data.frame-method
#' print,dataDictionary, dataDictionary-method
#' @usage extractDataDictionary(obj, stringsAsFactors, colClasses = NULL, 
#' chunkSize =10000L, listFlag = FALSE, rowCount = FALSE,
#' justClasses = FALSE, maxFactor = 255, NALevels =
#'  list(), checkNames = FALSE, ordering = TRUE, ...)
#' applyDataDictionary(
#' x, data, warnUnusedColumns=TRUE, 
#' Origin = "1970-01-01", tolerance = 0.9, newObj = TRUE)
#' addDataDictionary(e1,e2)
#' e1 + e2
#' diffDataDictionary(e1,e2)
#' e1 - e2
#' print(x, maxLevels = 10, rows = NULL, ...)
#' @param obj The file or \code{.csv} filename you wish to produce a data
#' dictionary from.  This can be a \code{\link{data.frame}} or a file in the
#' current working directory, but not a \code{\link{connection}} (see note
#' below).
#' @param stringsAsFactors A logical. If \code{TRUE}, then by default, columns
#' containing \code{character} data (or what \code{\link{read.csv}} interprets
#' as character data when reading them in based on the start of the file) are
#' read in as factors. If false, they are read in as characters.
#' @param colClasses A named list of column classes. extractDataDictionary will
#' apply these (and this overrides stringsAsFactors). For example, this might
#' be set to prevent policy number being read in as a factor, or to coerce a
#' (mostly numeric) field to factor. \emph{See usage notes below.}
#' @param chunkSize Where 'obj' is a filename, this is the number of columns of
#' the file which are read in at a time. Larger chunkSize is likely to result
#' in a slightly longer runtime, however the risk of coercion of columns is
#' reduced.
#' @param listFlag Where 'obj' is a filename, option to return a list of the
#' coerced column names in addition to the data dictionary.
#' @param rowCount Where 'obj' is a filename, option to return the number of
#' rows in the dataset in addition to the data dictionary.  This is useful for
#' subsequent application in the downSample function.
#' @param justClasses Where 'obj' is a filename, option to return just the
#' classes that the file would be read in as rather than including all of the
#' factor levels.  Setting this option to TRUE also prints out any column
#' coercion.
#' 
#' Using this option makes the function run more quickly and can be useful for
#' preliminary investigations. See usage notes below.
#' @param maxFactor Maximum number of levels a read in factor can have. If
#' reading in a factor causes its levels to exceed maxFactor,
#' extractDataDictionary stores the column as being class "character".
#' 
#' This results in a smaller (and more sensible) dictionary file, however note
#' that lowering maxFactor doesn't materially affect runtime. it's better to
#' specify a column which you know is a character field as "character" in
#' colClasses.
#' @param NALevels A named list of character strings which are to be treated as
#' NAs. If extractDataDictionary interprets a column as a factor, it will
#' exclude these from the derived list of factor levels and having done so, and
#' if it is sensible to do so, can interpret the column as numeric.  NALevels
#' do not need to solely be specified for columns containing factor data; You
#' can also use it to coerce strings like "unknown" or "99999" to NA by using
#' applyDataDictionary.
#' @param checkNames If TRUE, extractDataDictionary's list of column names will
#' be coerced to syntactically valid variable names as per check.names in
#' read.csv.  See usage notes below.
#' @param ordering Logical. If TRUE, the function looks for data that it has 
#' read in as `factor` and sees if it can apply a sensible ordering to them 
#' using the `orderDD` function.
#' @param \dots Other arguments to \code{\link{read.csv}}. See usage notes
#' below.
#' @param x In \code{extractDataDictionary}, the data dictionary to apply.
#' @param data The dataset to which it's applied. Column classes are reset,
#' items in NALevels are set to NA, and factor levels are set to the levels in
#' the data dictionary.
#' @param Origin In \code{extractDataDictionary}, the "Origin" date used
#' if coercing numeric values to dates
#' @param tolerance In \code{extractDataDictionary}, passed to \code{valiDate} when applying date formats
#' @param warnUnusedColumns if TRUE, warns if columns exist in the data
#' dictionary but not in the data.
#' @param e1 A dataDictionary object.
#' @param e2 A dataDictionary object.
#' @param maxLevels maximum number of factor levels to return individually when printing
#' @param rows number of lines to return when printing
#' @param newObj logical. do you want a new object returned or the old one?
#' 
#' @details Data dictionaries can also be added together 
#' (essentially, creating a union of their fields and factor levels).
#' @return Returns an object of (S4) class \code{"dataDictionary"}, and
#' (optionally) a list of fields coerced to factor during the data processing
#' and/or the number of columns in the original file.
#' @section Notes: 1. While \code{extractDataDictionary} is designed to run on
#' large files where it is not desirable (or possible) to read in all of the
#' data into memory at once, it will not infallibly produce the data dictionary
#' you would want in some circumstances unless \code{colClasses} are specified.
#' (This is why a list of coerced columns is produced.)
#' 
#' Potential problems arise where the data in a column are almost all numeric
#' but also contains rare character observations. If not specified,
#' extractDataDictonary may read the initial chunk of the file in and interpret
#' the column as numeric (as would read.csv). If it subsequently coerces this
#' column as a factor, any factor levels which do not occur in the data after
#' the coercion occurs will be missed.  In practice this is not a huge problem
#' as long as a consistent data dictionary is ultimately used, however you can
#' avoid it by running the function with \code{justClasses = TRUE}, and then
#' rerunning the function with the class of all coerced fields specified. This
#' can also highlight fields which are unexpectedly being coerced to factor.
#' 
#' Also note that, unless you specify otherwise in \code{colClasses},
#' extractDataDictionary will record a factor field as numeric if the data field appears
#' to exclusively contain data which should be recorded as a numeric value. 
#' (For example, "001" would not be coerced to numeric, but "1" or "1.00" would.)
#' This will give rise to a highly undesirable outcome if you then apply the 
#' dataDictionary object to a new data set. 
#' 
#' What you _can't_ do is specify a column to a class within \code{colClasses}
#' where \code{data} would not be correctly read in to that class from the
#' datafile.
#' For example, a column containing 1, 2, 3, 4 and "unknown" can't be specified as
#' integer. - but it would be coerced to an ordered factor by setting `ordering = TRUE`.
#' 
#' 2. \code{extractDataDictionary} will return a factor as unordered (ie
#' "factor") by default.
#' 
#' 3. \code{extractDataDictionary} makes internal use of read.csv via
#' connections.  Do not use it on a file you have already established an open
#' connection to.
#' 
#' 4. \code{extractDataDictionary} will not impact the original data file.
#' However it will read in column names without spaces and other unusual
#' characteristics (as per check.names = TRUE in \code{\link{read.csv}}).  This
#' means that, even if you want to set checkNames to false (and thus ultimately
#' leave the column names as they are), any column names you specify in
#' \code{colClasses} or \code{NALevels} should be similarly formatted. Also, do
#' not attempt to pass \code{check.names} as a function argument here.
#' 
#' 5. DO NOT use extractDataDictionary on a dataset with missing column names
#' (eg those produced by default by \code{\link{write.csv}}).
#' 
#' 6. data dictionaries can from 2019-08 accept the class "Date", although it is
#' expected that in most cases data will be read in as character (as R does by default).
#' So if you have date data you will likely need to manually alter the data dictionary.
#' It will then attempt to recognise new data as date and coerce it appropriately.
#' 
#' 7. Extracting Data dictionaries does not work if your file has duplicated column names.
#' I'm not intending to fix this.
#' 
#' @author Tom Bratcher & James Lawrence
#' @export  
#' @importFrom Hmisc all.is.numeric
#' @examples
#' 
#' df1 <- data.frame(x1=rnorm(5),x2=1:5,x3=letters[1:5],x4=LETTERS[2* 1:5])
#' df3 <- df2 <- df1
#' df1$x3 <- as.character(df1$x3)
#' extractDataDictionary(df2,FALSE) + extractDataDictionary(df1,FALSE)
#' extractDataDictionary(df1,TRUE) + extractDataDictionary(df2,TRUE)
#' 
#' df3$x4 <- as.factor (LETTERS [1:5])
#' df3a <- applyDataDictionary(extractDataDictionary(df1,TRUE),df3)
#' df3a
#' dd <- extractDataDictionary(df1,TRUE) + extractDataDictionary(df3,TRUE)
#' dd
#' df3b <- applyDataDictionary(dd,df3)
#' df3b
#' 
extractDataDictionary <- function(
  obj, stringsAsFactors, colClasses = NULL,
  chunkSize = 10000L, listFlag = FALSE, rowCount = FALSE,
  justClasses = FALSE, maxFactor = 255, # the argument of makeup artists
  NALevels = list(), checkNames = FALSE, ordering = TRUE,
  ...) {
  UseMethod("extractDataDictionary")
}

setGeneric("extractDataDictionary", signature = "obj")

#' extractDataDictionary.default
#' @rdname extractDataDictionary
#' @export
extractDataDictionary.default <- function(obj,...) {
  print ("No default method defined for this function. Type '?extractDataDictionary' for details")}

#' extractDataDictionary.data.frame
#' @rdname extractDataDictionary
#' @export
extractDataDictionary.data.frame <- function(
  obj,stringsAsFactors = FALSE,
  colClasses = NULL,
  maxFactor = 255, NALevels = list(),
  ordering = TRUE, ...){

  setDT(obj)
  validClasses <- c(
    "logical", "int64", "integer", "numeric", "complex",
    "character", "factor", "ordered", "Date")
  for (i in names(colClasses)) { #ugly
    if (!(colClasses[[i]] %in% validClasses)) stop (
      "Unsupported class name in colClasses") 
  } 
  if (length(colClasses) > 0  && length(names(colClasses)) == 0) warning (
    "No names attached to colClasses")
  
  # duplicate column names cause error, so...
  if(any(duplicated(colnames(obj)))){
    warning("fixing duplicated column names: dictionary will not apply itself perfectly")
    while(any(duplicated(colnames(obj))))
    {
      colnames(obj)[which(duplicated(colnames(obj)))]<- sapply(
        colnames(obj)[which(duplicated(colnames(obj)))], function (x)paste0(x, ".x"))
    }
      
  }
  
  
  colNames <- colnames(obj)
  colClasses2 <- character(length(colNames))
  levels <- list()
  NALevels2 <- list()
  for (i in seq_along(colNames)) {
    
    nm <- colNames[i]
    NALevels2[[nm]] <- NULL
    if (!is.null(t1 <- NALevels[[nm]])) t1 -> NALevels2[[nm]]
    if (i %in% names(colClasses)) cClass <- colClasses[[i]]
    # sAF used to turn into factors
    if(is(obj[, get(nm)],"int64")) colClasses2[i] <- "int64"
    else if(is.logical(obj[, get(nm)])) colClasses2[i] <- "logical"
    else if(is.integer(obj[, get(nm)])) colClasses2[i] <- "integer"
    else if(is.complex(obj[, get(nm)])) colClasses2[i] <- "complex"
    else if(is.numeric(obj[, get(nm)])) colClasses2[i] <- "numeric"
    else if("Date" %in% class(obj[, get(nm)])) colClasses2[i] <- "Date"
    else if(is.factor(obj[, get(nm)]) || stringsAsFactors ==TRUE) colClasses2[i] <- "factor" 
    
    else colClasses2[i] <- "character"
    if (nm %in% names(colClasses)) colClasses2[i] <- colClasses[[nm]] # coercing to specified classes...
    if(colClasses2[i] %in% c( "factor", "ordered")){
      if(is.factor(obj[, get(nm)])) levels[[nm]] <- levels(obj[, get(nm)]) # is.factor includes ordered objects
      else levels[[nm]] <- sortA(unique(obj[, get(nm)]))
      
      levels[[nm]] <- setdiff(levels[[nm]], NALevels[[nm]])   
      tempClass <- "character"
      if (nm %in% names(colClasses)) tempClass <- colClasses[[nm]] 
      if (Hmisc::all.is.numeric(
        levels[[colNames[i]]], what = "test", extras = NALevels[[nm]]
        ) && ! (tempClass %in% c( "factor", "ordered"))) {  
        numFlag <- 1
        
        # so here's the issue. if something was specified as a factor,it shouldn't be coerced to numeric
        #- but you need to tell the function not to. 
        
        for (j in levels [[colNames[i]]]){
          if (substring (j,1,1)=="0" && !(j=="0") && !(substring(j,1,2)=="0.")) numFlag <- 0
        } 
        if (numFlag) {
          colClasses2[i]<- "numeric"
          levels[[colNames[i]]] <- as.character("")
        }
      } 
    # check on Dates:
      if(!is.na(valiDate(obj[, get(nm)]))) {
        colClasses2[i] <- "Date"
        levels[[colNames[i]]] <- as.character("")
      }
    }
    else levels[[colNames[i]]] <- as.character("")
  
    if (length (levels [[colNames[i]]]) > maxFactor) {
      colClasses2[i] <- "character"
      levels[[colNames[i]]] <- as.character("")
    }
    
  }
  DD <- copy(dataDictionary(
    colNames = colNames, colClasses = colClasses2, levels = levels, NALevels = NALevels2))
  if (ordering) DD <- orderDD(DD)
  DD
}

#' extractDataDictionary.character
#' @rdname extractDataDictionary
#' @export
extractDataDictionary.character <- function(
  obj, stringsAsFactors = FALSE, colClasses = NULL,
  chunkSize = 10000L, listFlag = FALSE, rowCount = FALSE,
  justClasses = FALSE, maxFactor = 255,
  NALevels = NULL, checkNames, ordering = TRUE, ...) {
  
  validClasses <- c(
    "logical", "int64", "integer", "numeric", "complex", "character", "factor", "ordered", "Date")
  
  for (i in names(colClasses)) {
    if (!(colClasses[[i]] %in% validClasses)) stop ("unsupported class name in colClasses") }

  chunk <- read.csv(
    obj,
    stringsAsFactors = stringsAsFactors,
    nrows = chunkSize,
    header = TRUE,
    check.names = TRUE,
    ...
  )
  tempClasses <- sapply(chunk, class)
  
  obj2 <- obj
  obj <- file(obj, "rt")
  on.exit(close(obj))
  coercedCols <- list()
  dataDic <- 0
  loop <- 0
  wng <- options(warn = -1)
  on.exit(options(wng), add = TRUE)
  chunk <- read.csv(
    obj, stringsAsFactors = FALSE, nrow = chunkSize,
    header = TRUE,
    colClasses = rep("character", length(tempClasses)),
    check.names = TRUE, ...)
  colnames(chunk) <- names(tempClasses)   
  
  options(wng)
  for(nm in names(colClasses)) {
    if (nm %in% colnames(chunk)) {
      if (colClasses[[nm]] == "factor") chunk[[nm]] <- factor(chunk[[nm]])  
      else class(chunk[[nm]]) <- colClasses[[nm]]
  } else warning (c("column", nm, "specified in colClasses but not present in data"))}
  
  for (nm in colnames(chunk)) { 
    if (!(nm %in% names(colClasses))) {
      if (tempClasses [[nm]] == "factor") {
        chunk[[nm]] <- factor(chunk[[nm]])
      } else class(chunk[[nm]]) <- tempClasses[[nm]] 
    }    
  }
  nlines <- 0
  classList <- lapply(chunk, class)
  
  while (!inherits(chunk, "try-error")) {
    colnames(chunk) <- names(tempClasses)
    if (loop == 0) chunkone <- chunk 
    else {
      colnames(chunk) <- colnames(chunkone)# names but _not_ classes!
      if (!(justClasses)) {
        chunkone <- mergeDic(
          chunkone, chunk, classList = colClasses,
          warnUnusedColumns = FALSE,
          convMessage = TRUE,
          coercedCols = coercedCols)
        coercedCols <- chunkone[[2]]
        chunkone <- as.data.frame (chunkone[[1]])
        
      } else classList <- maxClass(classList, lapply(chunk, class))
    }
    loop <- 1 + loop  
    nlines <- nlines + nrow(chunk)
    
    chunk <- try(read.csv(
      obj,
      stringsAsFactors = stringsAsFactors,
      nrow=chunkSize,
      header = FALSE,
      check.names=TRUE, ...), silent =TRUE)
    
    cat(c("processed chunk",loop,"\n"))
  }
  close(obj)
  rm(obj)
  on.exit(NULL)
  
  if (loop > 0 & !(justClasses)) dataDic <- extractDataDictionary(
    chunkone, stringsAsFactors = stringsAsFactors, 
    colClasses = colClasses, maxFactor = maxFactor, NALevels = NALevels,
    ordering = FALSE, # That comes later
    ...)  
  
  # and finally....
  if (!(checkNames) & loop > 0 & !(justClasses)) {
    chunk <- read.csv(
      obj2, stringsAsFactors = FALSE, nrow = 1,
      header = TRUE, colClasses = rep("character", length(tempClasses)),
      check.names = FALSE, ...) 
    naIndex = match(names(dataDic@NALevels), dataDic@colNames)
    naIndex <- naIndex[!is.na(naIndex)]
    dataDic@colNames <- colnames(chunk)# because they had better always exist
    
    names(dataDic@levels) <- colnames(chunk)# because they always exist
    for (i in seq_along(naIndex)) names(dataDic@NALevels)[i]<- colnames(chunk)[naIndex[i]] }
  # ugly, but tested

  if (rowCount) classList <- list(classList, nlines)
  if (justClasses) return (classList)
  if (!is.null(attributes(chunkone)[["Coerced"]])) warning (
    "One or more fields were initially read in as numbers but subsequently coerced to factors.
    These factor levels may be incomplete.
    You can avoid this problem by specifying the desired class explicitly in colClasses")
  # now sorting:
  if (ordering) dataDic <- orderDD(dataDic)
  if (rowCount) dataDic <- list(dataDic, nlines)
  if (listFlag) return (list(copy(dataDic), coercedCols)) else return (copy(dataDic))
}

#' @rdname extractDataDictionary
setMethod(
  "extractDataDictionary",
  signature = signature (obj = "data.frame"),
  extractDataDictionary.data.frame)

#' @rdname extractDataDictionary
setMethod(
  "extractDataDictionary",
  signature = signature (obj = "character"),
  extractDataDictionary.character)

#' addDataDictionary
#' @rdname extractDataDictionary
#' @export

addDataDictionary <- function (e1,e2){
  z <- e1
  for(i in seq_along(e2@colNames)){
    if(e2@colNames[i] %in% z@colNames){
      i1 <- match(e2@colNames[i],e1@colNames)
      if(e2@colClasses[i] != e1@colClasses[i1]) warning (
        gettextf("column type mismatch in column %s; LHS has %s,
                 RHS has %s",e2@colNames[i],e1@colClasses[i1],e2@colClasses[i]))
      if(e2@colClasses[i] == "factor" && e1@colClasses[i1] == "factor" && !identical(e1@levels[[e1@colNames[i1]]],e2@levels[[e2@colNames[i]]])){
        warning(gettextf(
          "factor level mismatch in column %s,
          expanding and/or reordering dictionary to include all levels in both sides", e1@colNames[i1]))
        z@levels[[e2@colNames[i]]] <- sortA(unique(c(e1@levels[[e1@colNames[i1]]],e2@levels[[e2@colNames[i]]])))
      }
      if(!is.null(e1@NALevels[[e1@colNames[i1]]]) || !is.null(e2@NALevels[[e2@colNames[i]]])){
        z@NALevels[[e2@colNames[i]]] <- sortA(
          unique(c(e1@NALevels[[e1@colNames[i1]]],e2@NALevels[[e2@colNames[i]]])))
      }
    }
    else {
      z@colNames <- c(z@colNames,e2@colNames[i])
      z@colClasses <- c(z@colClasses,e2@colClasses[i])
      if(!is.null(e2@levels[[e2@colNames[i]]])) {
        z@levels[[e2@colNames[i]]] <- e2@levels[[e2@colNames[i]]]
      }
      if(!is.null(e2@NALevels[[e2@colNames[i]]])){
        z@NALevels[[e2@colNames[i]]] <- e2@NALevels[[e2@colNames[i]]]
      }
    }
  }
  z
}

#' @rdname extractDataDictionary
setMethod("+", signature(
  e1 = "dataDictionary", e2 = "dataDictionary"), addDataDictionary)

#' diffDataDictionary
#' @rdname extractDataDictionary
#' @export

diffDataDictionary <- function(e1,e2){
  
  # inclusion/exclusion
  in1 <- setdiff(e1@colNames, e2@colNames)
  in2 <- setdiff(e2@colNames, e1@colNames)
  # class differences:
  
  inboth <- intersect (e1@colNames, e2@colNames)
  class1 <- e1@colClasses[match(inboth, e1@colNames)]
  class2 <- e2@colClasses[match(inboth, e2@colNames)]
  classdiff <- data.table(column = inboth, d1 = class1, d2 = class2)
  classdiff <- classdiff[d1 != d2]
  
  # level differences:
  l1 <- e1@levels[e1@colClasses == "factor"]
  l2 <- e2@levels[e2@colClasses == "factor"]
  ld1 <- sapply (names(l1), function (x) setdiff (l1[[x]], l2[[x]]))
  ld1 <- ld1[which(length(ld1) > 0)]
  ld2 <- sapply (names(l2), function (x) setdiff (l2[[x]], l1[[x]]))
  ld2 <- ld2[which(length(ld2) > 0)]
  return (list(
    colsOnlyIn1 = in1,
    colsOnlyIn2 = in2,
    classdiffs = classdiff,
    levelsOnlyIn1 = ld1,
    levelsOnlyIn2 =ld2))
}

#' @rdname extractDataDictionary
setMethod(
  "-", signature(e1="dataDictionary", e2="dataDictionary"), diffDataDictionary)

#' applyDataDictionary
#' @rdname extractDataDictionary
#' @export

applyDataDictionary <- function(
  x,
  data,
  warnUnusedColumns = TRUE,
  Origin = "1970-01-01",
  tolerance = 0.9, 
  newObj = TRUE ) {
  # for now, assume date origin of 01/01/1970. This will quite possibly give problems in 2038...
  setDT(data)
  colNames <- colnames(data)
  if(any(duplicated(colNames))) stop (
    "please fix duplicated column names before proceeding")
  for(i in seq_along(x@colNames)){
    nm <- x@colNames[i]
    cl <- x@colClasses[i]
    if (! (nm %in% colNames)){
      if (warnUnusedColumns) warning (gettextf("column %s not present", nm))
      next
    }
    
    if(!(cl %in% c("factor", "ordered", "Date"))) {data[, eval(nm) := as(get(nm), cl)]}
    else if (cl== "factor") {data[, eval(nm) := factor(as.character(get(nm)), levels = x@levels[[nm]])]}
    else if (cl == "ordered") {
      data[, eval(nm) := ordered(as.character(get(nm)), levels = x@levels[[nm]])]
      data[as.character(get(nm)) %in% x@NALevels[[nm]], eval(nm) := NA]
    } else { # date
      if("Date" %in% class(data[, get(nm)])) {next} # data is already date, don't mess
      if(is.numeric(data[, get(nm)])) {
        data[, eval(nm): as.Date.numeric(get(nm), origin = Origin)]
        next  
      }
      Format <- valiDate(data[, get(nm)], tolerance = tolerance)
      if (is.na(Format)){
        warning (nm, " could not be interpreted as Date data: converting to character\n")
        data[, eval(nm) := as.character(get(nm))]
        next
      }
      data[, eval(nm) :=  base::as.Date(get(nm), format = Format)]
    }
  }
  if (! newObj)  return(invisible(NULL))
  return (copy(data))
}

#?? will I also need to export this?
# probably not, as I can't find print.dataDictionary - but can find methods for it!

#' print.dataDictionary
#' @export

print.dataDictionary <- function(x, maxLevels=10, rows = NULL ,...){
  cat("column Name     | column Class| levels \n")
  if (is.null(rows)) rows <- seq_along(x@colNames)
  if (length(rows) == 1) rows <- 1:rows    
  for(i in rows){
    nm <- x@colNames[i]
    cl <- x@colClasses[i]
    cat(strtrim(paste0(nm, "             "), 16), " ", strtrim(paste0(cl, "              "), 13))
    
    if(!is.null(t1 <- x@NALevels[[nm]])) { cat("(NA =", t1, ")") }
    if(cl=="factor" || cl == "ordered") {
      if((fl <- length(x@levels[[nm]])) > maxLevels) cat(fl, "levels\n") else cat(x@levels[[nm]], "\n")
    } else cat("\n")
  }
  if(!length(i)) cat("(no columns)\n")
}

#' show.dataDictionary
#' @export

show.dataDictionary <- function(object){
  print.dataDictionary(object)
}

setMethod("print", "dataDictionary", print.dataDictionary)
setMethod("show", signature(object="dataDictionary"), show.dataDictionary)
