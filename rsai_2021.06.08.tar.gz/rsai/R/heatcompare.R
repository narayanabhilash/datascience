#####  heatCompare  #####
#' Wrapper for heat maps via ggplot2
#' @description The function takes a data table, x/y column names to plot
#' and charting parameters.
#' It returns a heat map of the frequency of binned values of the data 
#' using the \code{ggplot2} library.
#' @usage heatCompare(dt, x_coord, y_coord, palette=NULL,
#'  x_lab=x_coord, y_lab=y_coord, 
#' bins=100L, fitLine=0L, abLine=0L, scale_x=NULL,
#'  scale_y=NULL,scaletrans = NULL, filltrans = "sqrt", ...)
#' @param dt data table containing the data. or NULL
#' @param x_coord x coordinate column name in dt. or numeric data
#' @param y_coord y coordinate column name in dt. or numeric data
#' @param palette vector of colurs. If NULL a default spectral palette is 
#' embedded in the function.
#' @param x_lab x coordinate label
#' @param y_lab y coordinate label 
#' @param bins number of bins used. will depend on the size of the data set.
#' @param fitLine either a number specifying line thickness for a fitted fit 
#' line (0 doesn't plot) OR a list
#' of parameters which is passed to \code{geom_smooth}.
#' @param abLine either a number specifying line thickness for the line (y=x)
#'  OR a list
#' of parameters which is passed to \code{geom_abline}. 
#' @param scale_x a list of parameters which is passed to 
#' \code{scale_x_continuous} (or NULL). 
#' @param scale_y a list of parameters which is passed to
#'  \code{scale_y_continuous} (or NULL).
#' @param scaletrans character. An optional more user friendly way to set the 
#' scale transform for x and y.
#' Typical value is "log10" for 2 log transforms.
#' @param filltrans scaling parameter for the transformation used on the 
#' heatmap colour scale.
#' Typical values are "identity", "sqrt", "log2".
#' @param dots any other optional arguments passed to ggplot2
#' @note You can also specify your data as columns in a data table 
#' (as the first 2 unnamed arguments to the function.) 
#' But you will then have to specify the axis labels.
#' @return a ggplot2 chart object
#' @details  this function provides an easy way into useful functionality
#' from the \code{ggplot2} library- if you are 
#' interested in further details then the best thing to do is look at the code!
#' @author Tom Bratcher(tom.bratcher@uk.rsagroup.com)
#' @importFrom ggplot2 ggplot scale_x_continuous scale_y_continuous
#'  geom_smooth geom_abline
#' @examples
#' # SET UP SOME DATA:
#' set.seed (7640827L)
#' dt_temp <- data.table (xcoord = c (rnorm (10000,0,1),rnorm (4000,-2,0.2),rnorm(4000,2,0.2))) 
#' dt_temp$ycoord<-c(dt_temp$xcoord[1:10000]^2 /10+rnorm(10000,0,0.1),rnorm(8000,3,0.2))
#' heatCompare (
#'   x_coord = dt_temp$xcoord, 
#'   y_coord = dt_temp$ycoord,
#'   bins =50,
#'   filltrans = "identity"
#' ) 
#' # Or - just the right eye... 
#' heatCompare (
#'   dt = dt_temp,
#'   x_coord ="xcoord",
#'   y_coord ="ycoord",
#'   bins =50,
#'   abLine = list (size =2L, colour ="darkgreen"), #x=y line
#'   scale_x = list(limits= c (1,4), trans = "log2"),
#'   scale_y = list(limits= c (2,4), trans = "log2"),
#'   palette = blues9 
#' ) + ggtitle("Just the right eye")
#' @export

heatCompare <- function (
  dt = NULL, #data
  x_coord = NULL,
  y_coord = NULL,
  palette = NULL,
  x_lab = x_coord,
  y_lab = y_coord,
  bins = 100L,
  fitLine = 0L, #ggplot fit line
  abLine = 0L, #x=y line
  scale_x = NULL, #list(limits= c (1,16), trans = "log2")
  scale_y = NULL, #list(limits= c (1,16), trans = "log2")
  scaletrans = NULL,
  filltrans = "sqrt", # could be "identity", "log2", etc
  ...
){

if (bins >200){
  warning ("bins restricted to 200: more is likely to break your PC")
  bins = 200
}  

  
# Transform stuff as freely as we can and fill in defaults: ---------------
if (is.numeric(fitLine) && fitLine>0) fitLine<-list(size = fitLine)
if (is.numeric(abLine)  && abLine>0)  abLine<-list (size = abLine) 

# hard code the default spectral palette: 
# could do with adding to rsai data?
if (is.null (palette)) palette <- c("#5E4FA2", "#5758A6", "#5061AA", "#496AAE", "#4273B3" ,"#3B7CB7" ,"#3485BB" ,"#378EBA", "#4097B6" ,"#48A0B2", "#50AAAE" ,"#58B3AB", "#61BCA7",
      "#6AC3A4" ,"#75C8A4" ,"#80CCA4" ,"#8BD0A4", "#96D4A4", "#A1D9A4", "#ABDDA3", "#B5E1A1" ,"#BEE4A0", "#C8E89E", "#D1EC9C", "#DAF09A", "#E4F498",
      "#E9F69C", "#EDF7A3" ,"#F1F9A9" ,"#F5FBAF" ,"#F9FCB5", "#FDFEBB", "#FEFCBA", "#FEF7B2", "#FEF2AA", "#FEEDA2", "#FEE899" ,"#FEE391", "#FDDE89",
      "#FDD683", "#FDCE7C", "#FDC675", "#FDBE6F", "#FDB668" ,"#FDAE61" ,"#FBA45C", "#FA9A57", "#F89053", "#F7854E", "#F67B49", "#F47144" ,"#F16844",
      "#EC6146", "#E75947", "#E25249", "#DD4A4B", "#D8434D", "#D23B4E", "#C9314C","#C0274A", "#B81E48", "#AF1446", "#A60A44", "#9E0142")

# just the data we want:
if (is.null (dt)){
  if (!(is.numeric(x_coord) && is.numeric(y_coord))) stop (
    "if dt is not specified, plot data must be numeric vectors")
  if (length(x_coord) != length(y_coord)) stop (
    "coordinate data are not the same length")
  # sort labels:
  if (length(x_lab) != 1) x_lab <- "x coordinate"
  if (length(y_lab) != 1) y_lab <- "y coordinate"
  
  dt <- data.table (x = x_coord, y = y_coord)
} else {
  if (is.data.frame(dt)){
    if(!(x_coord %in% names(dt) & y_coord %in% names(dt))) stop (
      "if dt is a data frame or table, x_coord and y_coord must both be names of dt")
    dt <- data.table(x = dt[[x_coord]], y = dt[[y_coord]])
  } else {
    if (!(is.numeric(x_coord) && is.numeric(dt))) stop (
      "if dt is not specified, plot data must be numeric vectors")
    if (length(x_coord) != length(dt)) stop (
      "coordinate data are not the same length")
    # sort labels:
    if (is.null(x_lab) || x_lab == x_coord) x_lab <- "x coordinate"
    if (is.null(y_lab) || y_lab == y_coord) y_lab <- "y coordinate"
    dt <- data.table (x = dt, y = x_coord)
  }
  
}

# NAs: No.
dt <- dt[is.finite(x) & is.finite(y)]
if (!nrow(dt)) stop ("no non-missing finite data to plot")

# scale transform ---------------------------------------------------------

if (!is.null(scaletrans)){
  if (is.null(scale_x)) scale_x <- list (trans = scaletrans) else scale_x$trans = scaletrans
  if (is.null(scale_y)) scale_y <- list (trans = scaletrans) else scale_y$trans = scaletrans
}

plotObj <-ggplot(dt, aes(x = x, y = y), ...) +
  xlab(x_lab) + ylab(y_lab) + stat_bin2d(bins = bins) +
  scale_fill_gradientn(colours = palette, trans = filltrans)

if (!is.null(scale_x)) plotObj <- plotObj + do.call(scale_x_continuous, scale_x)
if (!is.null(scale_y)) plotObj <- plotObj + do.call(scale_y_continuous, scale_y)
if (is.list(fitLine))  plotObj <- plotObj + do.call(geom_smooth, fitLine)
if (is.list(abLine))   plotObj <- plotObj + do.call(geom_abline, abLine)

return (plotObj)
}