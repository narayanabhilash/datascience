
#' Function to sum xgboost importances over factors
#' 
#' @description sums (rsai standard formatted) xgboost importances over all factor levels / binary splits.
#' 
#' For this to work you must have already calculated importances using xgb.importance.
#' @usage FeatImportanceSum (imp)
#' @param imp the original importance table

#' @return a summarised data table
#' @author Tom Bratcher
#' @import data.table 
#' @export
FeatImportanceSum = function (imp) {
  imp2 <- copy(imp)
  imp2$Feature <- gsub ("~.*", "", imp2$Feature)
  imp2 <-
    imp2[, .(
      Gain = sum (Gain),
      Cover = sum (Cover),
      Frequency = sum (Frequency)
    ), by = Feature]
  
  return (imp2[order(imp2$Gain, decreasing = TRUE)])
}