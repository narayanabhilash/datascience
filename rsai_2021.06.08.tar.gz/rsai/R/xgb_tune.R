#####  xgb_tune  #####
#' Function to run hyper-parameter tuning for xgboost.
#' @description This function runs xgb.cv repeatedly with different, randomly generated, hyper-parameters.
#' @usage xgb_tune(params=list(), data, eta.tune, eta.final, nrounds.tune, nrounds.final, early_stopping_rounds.tune,
#'  early_stopping_rounds.final, step1.n=5, step2.n=5, step3.n=5, step4.n=5, step5.n=5, min_child_weight.max=500,
#'  max_depth.max=15, gamma.max=20, finalSeed = NULL, ...)
#' @param params An optional list of parameters to send to the 'params' argument of xgb.cv. This is optional as many of the parameters are tuned during the process. If you include any of the parameters being tuned, these will become the starting point to tune from. If eta is included this is overwritten by the eta.tune and eta.final parameters.
#' @param data takes an xgb.DMatrix, matrix, or dgCMatrix as the input (the same as xgb.cv)
#' @param eta.tune The value for the 'eta' parameter in xgb.cv to take during the tuning rounds. It is recommended that this be bigger, or at least no smaller, than the eta.final parameter.
#' @param eta.final The value for the 'eta' parameter in xgb.cv to take for the final round of xgb.cv after the tuning of other hyper-parameters is complete. This final round generates the xgb.cv object that is returned.
#' @param nrounds.tune The maximum number of trees for the tuning rounds
#' @param nrounds.final The maximum number of trees for the final round
#' @param early_stopping_rounds.tune Number of trees for early stopping during the tuning rounds
#' @param early_stopping_rounds.final Number of trees for early stopping during the final rounds
#' @param step1.n Number of times to try random values during step 1 (Wide search for max_depth and min_child_weight)
#' @param step2.n Number of times to try random values during step 2 (Fine-tuning max_depth and min_child_weight)
#' @param step3.n Number of times to try random values during step 3 (Tuning the gamma parameter)
#' @param step4.n Number of times to try random values during step 4 (Tune subsample and colsample_bytree)
#' @param step5.n Number of times to try random values during step 5 (Tune alpha and lambda)
#' @param min_child_weight.max The maximum value for min_child_weight to try.
#' @param max_depth.max The maximum value for max_depth to try.
#' @param gamma.max The maximum value for gamma to try.
#' @param finalSeed A final seed to send to xgb.cv at the final step.
#'  This allows you to replicate the final step with the final tuning parameters at a later date without running the entire tuning routine again.
#' @param ... All/any other arguments that need to be passed straight across to xgb.cv().
#' @return A list with three elements. 1) results, a data.table of output showing, for each tuning step, the parameters used and the training and validation results. 2) cvModel, the output from the final run of xgb.cv(). 3) params, the parameter list used for xgb.cv() in the final step, containing the hyper-parameter values that performed best.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #xgbTuneResult <- xgb_tune(params = list(objective = "reg:gamma",
#' #                                        booster = "gbtree",
#' #                                        gamma = 5,
#' #                                        subsample = 0.6),
#' #                          data = DMatTrain,
#' #                          eta.tune = 0.5,
#' #                          eta.final = 0.3,
#' #                          nrounds.tune = 500,
#' #                          nrounds.final = 1000,
#' #                          early_stopping_rounds.tune = 15,
#' #                          early_stopping_rounds.final = 20)
#' @export

xgb_tune <- function(
  params = list(),
  data,
  eta.tune,
  eta.final,
  nrounds.tune,
  nrounds.final,
  early_stopping_rounds.tune,
  early_stopping_rounds.final,
  step1.n = 5,
  step2.n = 5,
  step3.n = 5,
  step4.n = 5,
  step5.n = 5,
  min_child_weight.max = 500,
  max_depth.max = 15,
  gamma.max = 20,
  finalSeed = NULL, 
  ...) {
  
  # Are we maximising the objective funtion?
  if(hasArg(maximize)) maximize <- list(...)[['maximize']] else maximize <- FALSE
  
  # required library
  require(xgboost)
  require(data.table)
  
  # Create params list for first step
  params$eta <- eta.tune

  # fill out params with any defaults
  defaults <- list(
    max_depth = min(6L, max_depth.max),
    subsample = 1,
    colsample_bytree = 1,
    min_child_weight = 20, # ...yeah
    lambda = 1,
    alpha = 0,
    gamma = 0)
  
  # Change min.child.weight to min_child_weight if exists
  names(params) <- gsub("min.child.weight", "min_child_weight", names(params))
  
  # add defaults to params where parameter does not exist
  params <- c(params, defaults[which(!names(defaults) %in% names(params))])
  
  # Function to run xgb.cv and return a data table of results
  cvStep <- function(...){
    # Run cross-validation step for number of trees, with error catching
    cvModel <-tryCatch(xgb.cv(
      params = params,
      data = data,
      nrounds = nrounds.tune,
      early_stopping_rounds = early_stopping_rounds.tune,
      print_every_n = nrounds.tune,
      prediction = FALSE,
      ...),
      error = function(e){
        print(e)
        return("ERROR")
      }
    )
    
    if (inherits(cvModel, "character")){
      return(
        data.table(
          eta = numeric(0),
          max_depth = numeric(0),
          subsample = numeric(0),
          colsample_bytree = numeric(0),
          min_child_weight = numeric(0),
          lambda = numeric(0),
          alpha = numeric(0),
          gamma = numeric(0),
          nrounds = numeric(0),
          train = numeric(0),
          test = numeric(0)
        )
      )
    }
    
    # Return data table
    data.table(
      eta = params$eta,
      max_depth = params$max_depth,
      subsample = params$subsample,
      colsample_bytree = params$colsample_bytree,
      min_child_weight = params$min_child_weight,
      lambda = params$lambda,
      alpha = params$alpha,
      gamma = params$gamma,
      nrounds = cvModel$best_iteration,
      train = cvModel$evaluation_log[[2]][cvModel$best_iteration],
      test = cvModel$evaluation_log[[4]][cvModel$best_iteration])
  }
  
  # Initialise results using default parameters
  cat(paste0("\n\nStep 0: first run with default parameters.\n\n"))
  results <- cvStep(...)
  
  if (nrow(results) == 0){
    stop("xgb.cv failed on first attempt")
  }
  
  # TUNING STEP 1 - Wide search for max_depth and min_child_weight
  if(step1.n > 0){
    cat("\n\nStep 1: Searching for max_depth and min_child_weight parameters.\n\n")
    
    # not exactly a grid but a change to how this is done...
    
    #cwVals gives a more "uniform"
    # round it?
    if (step1.n < 3) {
      cwVals <- runif (step1.n, 0, 1)
    } else cwVals <- 0:(step1.n - 1) / (step1.n - 1)
    cwVals <- pmax(3, exp(cwVals * log1p(min_child_weight.max)) - 1)
    temp <- step1.n
    depths <- c()
    min_depth = median (c(1, (max_depth.max-1), 2))
    while (temp >= max_depth.max){ 
      depths <- c(depths, sample((min_depth:max_depth.max), (max_depth.max - 1)))
      temp <- temp - max_depth.max + 1
    } 
    if (temp >0) depths <- c(depths, sample(min_depth:max_depth.max, temp))
    for(i in 1:step1.n){
      params$min_child_weight <- cwVals[i] 
      params$max_depth <- depths[i]
      
      results <- rbindlist(list(results, cvStep(...)))
      gc()
    }
  }
  
  # TUNING STEP 2 - Fine-tuning max_depth and min_child_weight
  if(step2.n > 0){
    cat("\nStep 2: Fine-tuning max_depth and min_child_weight.\n\n")
    for(i in 1:step2.n){
      if(maximize) bestRow <- which.max(results$test)[1] else bestRow <- which.min(results$test)[1]
      if(results[bestRow, min_child_weight] < 8) params$min_child_weight <- runif(1, 0, 12) else {
        # where search was over whole space:
        temp <- pmin (pmax (1, (bestRow - 1) : (bestRow + 1)), max(1, step1.n))
        temp <- (1 + max (cwVals[temp])) / (1 + min(cwVals[temp]))
        temp <- ((1 + results[bestRow, min_child_weight]) * temp ^ runif (1, -1 , 1)) - 1 
        params$min_child_weight <- median (c(0, min_child_weight.max, temp))
      }
      params$max_depth <- min(max(results[bestRow, max_depth] + sample(-1:1, 1), 2), max_depth.max)
      results <- rbindlist(list(results, cvStep(...)))
      gc()
    }
  }
  
  # TUNING STEP 3 - Tuning the gamma parameter
  if(maximize) bestRow <- which.max(results$test)[1] else bestRow <- which.min(results$test)[1]
  params$min_child_weight <- results[bestRow, min_child_weight]
  params$max_depth <- results[bestRow, max_depth]
  if(step3.n > 0){
    cat("\nStep 3: Finding value for gamma.\n\n")
    for(i in 1:step3.n){
      params$gamma <- exp(runif(1, 0, log1p(gamma.max)))-1
      results <- rbindlist(list(results, cvStep(...)))
      gc()
    }
  }
  
  # TUNING STEP 4 - Tune subsample and colsample_bytree
  if(maximize) bestRow <- which.max(results$test)[1] else bestRow <- which.min(results$test)[1]
  params$gamma <- results[bestRow, gamma]
  if(step4.n > 0){
    cat("\nStep 4: Finding values for subsample and colsample_bytree.\n\n")
    for(i in 1:step4.n){
      params$subsample <- runif(1, 0.5, 1)
      params$colsample_bytree <- runif(1, 0.5, 1)
      results <- rbindlist(list(results, cvStep(...)))
      gc()
    }
  }
  
  # TUNING STEP 5 - Tune alpha and lambda
  if(maximize) bestRow <- which.max(results$test)[1] else bestRow <- which.min(results$test)[1]
  params$subsample <- results[bestRow, subsample]
  params$colsample_bytree <- results[bestRow, colsample_bytree]
  if(step5.n > 0){
    cat("\nStep 5: Finding values for alpha and lambda\n\n")
    for(i in 1:step5.n){
      params$lambda = 10^runif(1, -2, 2)
      params$alpha = 10^runif(1, -5, 2)
      results <- rbindlist(list(results, cvStep(...)))
      gc()
    }
  }
  
  # FINAL STEP - RE-RUN CV AND FINAL MODEL ON TUNED PARAMETERS
  if(maximize) bestRow <- which.max(results$test)[1] else bestRow <- which.min(results$test)[1]
  params$eta <- eta.final
  params$lambda <- results[bestRow, lambda]
  params$alpha <- results[bestRow, alpha]
  cat("\nFinal parameters found!\n\n")
  print(params)
  
  # if specified a final seed get something which is more readily reproducible...
  if (!is.null (finalSeed)) set.seed(finalSeed)
  
  cvModel <- xgb.cv(params = params,
                    data = data,
                    nrounds = nrounds.final,
                    early_stopping_rounds = early_stopping_rounds.final,
                    print_every_n = nrounds.final,
                    prediction = TRUE,
                    ...)
  
  # Update results table with final run
  results <- rbindlist(list(results, data.table(eta = params$eta,
                                                max_depth = params$max_depth,
                                                subsample = params$subsample,
                                                colsample_bytree = params$colsample_bytree,
                                                min_child_weight = params$min_child_weight,
                                                lambda = params$lambda,
                                                alpha = params$alpha,
                                                gamma = params$gamma,
                                                nrounds = cvModel$best_iteration,
                                                train = cvModel$evaluation_log[[2]][cvModel$best_iteration],
                                                test = cvModel$evaluation_log[[4]][cvModel$best_iteration])))
  
  # Formatting of results table
  results[, ':=' (step = c(0, rep(1, step1.n), rep(2, step2.n), rep(3, step3.n), rep(4, step4.n), rep(5, step5.n), 6),
                  round = .I)]
  if(maximize) {
    bestR <- sapply(1:nrow(results), function(i) which.max(results$test[1:i])[1])
  } else {
    bestR <- sapply(1:nrow(results), function(i) which.min(results$test[1:i])[1])
  }
  results[, bestRound := bestR]
  results <- results[, .(step,
                         round,
                         eta,
                         max_depth,
                         min_child_weight,
                         gamma,
                         subsample,
                         colsample_bytree,
                         lambda,
                         alpha,
                         nrounds,
                         train,
                         test,
                         bestRound)]
  
  gc()
  
  # Output results
  return(list(results = results, cvModel = cvModel, params = params))
}