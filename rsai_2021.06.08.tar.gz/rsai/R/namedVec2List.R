# namedVec2List
# namedList2Vec

#####  namedVec2List  #####
#' Functions that map between named character vectors and lists.
#' @aliases namedVec2List namedList2Vec
#' @description
#' \describe{
#'   \item{namedVec2List}{
#' This takes a named character vector and outputs a named list.
#' Each unique element of the input vector will have its own element in the output.
#' These elements will be character vectors containing the names of the input vector that correspond
#' to the element. E.G.
#'     \code{
#' x <- c("A", "A", "B")
#' names(x) <- paste0("Fac", 1:3)
#' namedVec2List(x)
#'     }
#' will result in the following:
#'     \code{
#' list(A=c("Fac1", "Fac2"), B="Fac3")
#'     }
#' The names of the input vector should be unique.
#'   }
#'   \item{namedList2Vec}{
#' This takes a named list where each element is a character vector and returns a character vector with values
#' that match the names of the corresponding original list element and names that match the corresponding
#' original list name. For example,
#'     \code{
#' namedList2Vec(list(A=c("Fac1", "Fac2"), B="Fac3"))
#'     }
#' will result in the following in a the character vector \code{c("A", "A", "B")}
#' with names \code{c("Fac1", "Fac2", "Fac3")}.
#' The names of the input vector should be unique, as should each element of all list elements.
#'   }
#' }
#' @usage
#' namedVec2List(x)
#' namedList2Vec(x)
#' @param x The input object. For \code{namedVec2List} this will be a named character vector.
#' For \code{namedList2Vec} this will be a named list of character vectors.
#' @return \code{namedVec2List} returns a named list of character vectors,
#' \code{namedList2Vec} returns a named character vector.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # #namedVec2List
#' # x <- c("A", "A", "B")
#' # names(x) <- paste0("Fac", 1:3)
#' # namedVec2List(x)
#' 
#' # #namedList2Vec
#' # namedList2Vec(list(A=c("Fac1", "Fac2"), B="Fac3"))
#' @export

namedVec2List <- function(x){
  
  if (!is.vector(x)) stop("x must be a vector")
  if (is.null(names(x))) stop("x must be a named vector")
  if (anyDuplicated(names(x))) stop("x must have unique names")
  
  x <- x[order(names(x))]
  nms <- unique(x)
  nms <- nms[order(nms)]
  ls <- lapply(nms, function(y) names(x)[which(x==y)])
  names(ls) <- nms
  return(ls)
}

#' @export
namedList2Vec <- function(x){
  
  if (!is.list(x)) stop("x must be a list")
  if (is.null(names(x))) stop("x must be a named list")
  if (anyDuplicated(names(x))) stop("x must have unique names")
  if (!all(sapply(x, is.vector))) stop("x must be a list of vectors")
  if (!all(sapply(x, class) == "character")) stop("x must be a list of character vectors")
  if (anyDuplicated(unlist(x))) stop("duplicated value found")
  
  vec <- do.call(
    c,
    lapply(
      names(x),
      function(y){
        n <- length(x[[y]])
        ch <- rep(y, n)
        names(ch) <- x[[y]]
        return(ch)
      }
    )
  )
  vec <- vec[order(names(vec))]
  return(vec)
}
