#####  rtweedie  #####
#' Random generation for the Tweedie distribution.
#' @description Generates Random generation for the Tweedie distribution with mean, power parameter, dispersion and exposure periods all parameterised.
#' @usage rtweedie(n, mu, p = 1.5, phi = 1, exposure = 1)
#' @param n Length of vector to output.
#' @param mu Mean claims costs per exposure period, either a constant or a vector of length n.
#' @param p Power parameter, either a constant or a vector of length n.
#' @param phi Dispersion parameter, either a constant or a vector of length n.
#' @param exposure Either a vector of length n or a constant representing exposure period(s).
#' @return A vector of random Tweedie generated values.
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' # n <- 50000
#' # costPerExposure <- 350
#' # power <- 1.42
#' # dispersion <- 500
#' # set.seed(1984)
#' # exposurePeriods <- runif(n)) # generate exposure periods
#' # claimCosts <- rtweedie(n, mu=costPerExposure, p=power, phi=dispersion, exposure=exposurePeriods)
#' @export

rtweedie <- function(n, mu, p = 1.5, phi = 1, exposure = 1) {
  # Error trapping
  if(p <= 1 || p >= 2)stop("p must be in (1,2)")
  if(min(mu < 0)) stop("mean, mu, must be non negative")
  if(min(phi) <= 0) stop("scale parameter must be positive")
  if(!length(mu) %in% c(1, n)){
    stop("mu must be a scalar or (in this instance) a vector of length n")
  }
  if(!length(p) %in% c(1, n)) {
    stop("p must be a scalar or (in this instance) a vector of length n")
  }
  if(!length(phi) %in% c(1, n)) {
    stop("phi must be a scalar or (in this instance) a vector of length n")
  }
  if(!length(exposure) %in% c(1, n)) {
    stop("exposure must be a scalar or (in this instance) a vector of length n")
  }
  # Re-parameterise in terms of parameters for underlying poisson and gamma processes
  lambda <- exposure*(mu^(2 - p)/((2 - p) * phi)) # exposure only affects poisson  process
  shape <- (2 - p)/(p - 1)
  scale <- phi * (p - 1) * mu^(p - 1)
  if(length(scale)==1) scale <- rep(scale, n)
  N <- rpois(n, lambda) # Number of events - random poisson
  gs <- rep(scale, N)
  Ids <- rep(1:n, N)
  y <- rgamma(gs * 0 + 1, shape = shape, scale = gs) # cost of events - random gamma
  final <- aggregate(c(y, rep(0, n)), by=list(c(Ids, 1:n)), FUN=sum)[, 2] # sum costs together
  return(final)
}