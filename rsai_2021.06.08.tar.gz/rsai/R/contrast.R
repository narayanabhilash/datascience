
#' knn to highlight local feature contrasts
#' @description this function allows you to easily observe local regions where
#' a geographic feature exhibits sharp contrasts over a
#' @param dt data table containing x/y coordinates and feature
#' @param col the feature name
#' @param x the x coordinate name
#' @param y the y coordinate name
#' @param length size of the local neighbourhood considered (in points)
#' @param scalefn scaling function applied to the feature (e.g. log,
#' for multiplicative factors, may be more illustrative than the raw feature).
#' use "identity" for no transform
#' @param showMap optional to print a map to screen as well as returning data
#' @param ... if showMap = TRUE, optional extra arguments to plotMap
#'
#' @return data table 
#' @export
#'
#' @examples #no
knnContrast <- function (
  dt,
  col,
  x = "x",
  y = "y",
  length = 10,
  scalefn = log,
  showMap = TRUE,
  ...
) {
  

# doing this with data table syntax does not work consistently and is driving me slowly insane 
  #when i think about it. 
dt_cnt <- data.table(x_coord = dt[[x]], y_coord = dt[[y]], multiplier = scalefn(dt[[col]])) [
  , .(value = mean(multiplier)), keyby =.(x_coord, y_coord)
]
#print (head(dt_cnt))


lsq <- length:1
ppp_out <- ppp(
  dt_cnt$x, dt_cnt$y,
  window = owin(
    c(min(dt_cnt$x),  max(dt_cnt$x)),
    c(min(dt_cnt$y),  max(dt_cnt$y))
  ))

tabs <- as.data.table(nncross(ppp_out, ppp_out, what = "which", k = 1 + lsq))

cntMatrix <- sapply(colnames(tabs), function(nm) abs(dt_cnt$value - dt_cnt$value[tabs[[nm]]]))

cnt <- cntMatrix %*% lsq / sum(lsq)

dt_cnt [, contrast:= cntMatrix %*% lsq / sum(lsq)]
if (showMap) print(
  plotMap(dt_cnt, "contrast", colourScale = "linear", ...)
)
return (dt_cnt)
}
