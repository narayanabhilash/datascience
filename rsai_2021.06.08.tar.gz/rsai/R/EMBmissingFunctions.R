#####  EMBmissingFactors  #####
#' Find Missing Factors in your EMBmodel
#'
#' \code{EMBmissingFactors} will list missing factors in your EMBglm model, as compared to your policy data.
#' @param PolicyData object. Your policy data.
#' @param EMBlemModel object. Your EMBglm model.
#' @return Text output (to console) listing missing Factors.
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmissingFactors EMBmissingLevels
#' @export
#' @examples
#' #EMBmissingFactors(dt_polData, allModels)

# This Function lists Differences in Factors between the PolicyData and the EmblemModel
EMBmissingFactors <- function(PolicyData, EMBlemModel) {

  # Finding Factor Fields
  v_Facs <- grep("Factor", names(EMBlemModel), ignore.case = TRUE, value = TRUE)

  # Creating a list and looping through for all factors in the ratebook
  v_modFactors <- character()
  for (i_Fac in v_Facs) {
    v_modFactors <- c(v_modFactors, unique(EMBlemModel[, get(i_Fac)]))
  }
  v_modFactors <- setdiff(v_modFactors, "")

  # Returning the difference in a verbose format
  v_diffs <- setdiff(v_modFactors, unique(names(PolicyData)))
  if (length(v_diffs) > 0) {
    v_txtOutput <- character()
    for (i_diff in v_diffs) {
      v_txtOutput <- paste0(v_txtOutput, i_diff, "\n ")
    }
    cat(noquote(paste0("The following factors appear to be missing:\n ", v_txtOutput, '\n')))
  } else cat("No missing factors found!")

}

#####  EMBmissingLevels  #####
#' Find Missing Levels in your EMBmodel
#'
#' \code{EMBmissingLevels} will list missing Levels (and their corresponding Factors) in your EMBglm model, as compared to your policy data.
#' @param PolicyData object. Your policy data.
#' @param EMBlemModel object. Your EMBglm model.
#' @return Text output (to console) listing missing levels (and their corresponding factors).
#' @keywords DGTools rsai EMBmodelMerge EMBglm EMBmissingFactors EMBmissingLevels
#' @export
#' @examples
#' #EMBmissingLevels(dt_polData, allModels)

# This Function lists Differences in Levels between the PolicyData and the EmblemModel
EMBmissingLevels <- function(PolicyData, EMBlemModel) {

  # Finding Factor and Level Fields
  v_Facs <- grep("Factor", names(EMBlemModel), ignore.case = TRUE, value = TRUE)
  v_Lvls <- grep("Level", names(EMBlemModel), ignore.case = TRUE, value = TRUE)

  # Creating a list and looping through for all factors in the ratebook
  v_modFactors <- character()
  for (i_Fac in v_Facs) {
    v_modFactors <- c(v_modFactors, unique(EMBlemModel[, get(i_Fac)]))
  }
  v_modFactors <- setdiff(v_modFactors, "")

  # Creating a list and finding all missing levels for all factors (looped) in policy data/ratebook
  v_diffsList <- character()
  for (i_modFactor in v_modFactors) {
    v_polData <- unique(PolicyData[, get(i_modFactor)])
    v_lvlFactors <- character()
    for (i in 1:length(v_Facs)) {
      v_lvlFactors <- c(v_lvlFactors,
                        EMBlemModel[get(v_Facs[i]) == i_modFactor, get(v_Lvls[i])])
      }
    # If non-empty, adding to the list
    v_diffs <- unique(setdiff(v_polData, v_lvlFactors))
    if (length(v_diffs) != 0) {
      v_diffsList <- c(v_diffsList, paste0(i_modFactor, " : '", v_diffs, "'"))
    }
  }

  # Returning the difference in a verbose format
  if (length(v_diffsList) > 0) {
    v_txtOutput <- character()
    for (i_diffsList in v_diffsList) {
      v_txtOutput <- paste0(v_txtOutput, i_diffsList, "\n ")
    }
    cat(paste0("The following levels appear to be missing:\n", v_txtOutput, '\n'))
  } else cat("No missing levels found!")
}
