#####  EMBmodelReorder  #####
#' Reorders an Emblem model by numeric and character levels
#'
#' \code{EMBmodelReorder} reorders the rows of an EMBglm object by the factors and levels of the model. The function first determines whether every level of a factor can be expressed as a numeric. If \code{fnv_reorderNumeric = TRUE}, the function then reorders numeric levels, otherwise the original ordering is retained.  If \code{fnv_reorderCharacter = TRUE}, the function then reorders non-numeric levels, otherwise the original ordering is retained. The reordered EMBglm object is returned.
#' @param fnv_EMBlemModel EMBglm, named. An EMBglm object, the Emblem model that you wish to reorder
#' @param fnv_reorderNumeric logical, named. Do you wish to reorder numeric levels?
#' @param fnv_reorderCharacter logical, named. Do you wish to reorder numeric levels?
#' @return EMBglm object with reordered levels.
#' @export
#' @examples
#' EMBmodelReorder <- function(fnv_EMBlemModel = EMBlemModel, fnv_reorderNumeric = TRUE, fnv_reorderCharacter = TRUE)

EMBmodelReorder <- function(fnv_EMBlemModel, ..., fnv_reorderNumeric = FALSE, fnv_reorderCharacter = FALSE){

  EMBlemModel <- copy(fnv_EMBlemModel)
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("^Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("^Level", names(EMBlemModel), ignore.case = TRUE)]

  # Get unique factors and levels
  s_Facs <- unlist(EMBlemModel[, ..Facs])
  s_Lvls <- unlist(EMBlemModel[, ..Lvls])
  dt_FacsLvls <- data.table(Factor = s_Facs, Level = s_Lvls)
  dt_FacsLvls <- unique(dt_FacsLvls)
  #dt_FacsLvls <- dt_FacsLvls[Factor != "" & Level != ""]

  # Get numeric factors
  s_Facs <- unique(dt_FacsLvls[["Factor"]])
  oldw <- getOption("warn")
  options(warn = -1)
  s_numericFactors <- sapply(s_Facs, function(x){
    return(!any(is.na(as.numeric(dt_FacsLvls[Factor == x, Level]))))
  })
  options(warn = oldw)

  s_characterFactors <- s_Facs[!s_numericFactors]
  s_numericFactors <- s_Facs[s_numericFactors]

  # Get ordering for each numeric factor
  for (factor in s_numericFactors){
    dt_FacsLvls[Factor == factor, LevelOrder := if(fnv_reorderNumeric){
      as.numeric(Level)
    } else {
      .I
    }]
  }

  # Get ordering for each character factor
  for (factor in s_characterFactors){
    dt_FacsLvls[Factor == factor, LevelOrder := if(fnv_reorderCharacter){
      order(Level)
    } else {
      .I
    }]
  }

  # add orderings to EMBmodel
  for(i in seq_along(Facs)){
    EMBlemModel <- merge(EMBlemModel, dt_FacsLvls,
                         by.x = paste0(c("Factor", "Level"), i),
                         by.y = c("Factor", "Level"))
    names(EMBlemModel)[names(EMBlemModel) == "LevelOrder"] <- paste0("LevelOrder", i)
  }
  LvlOrds <- names(EMBlemModel)[grep("^LevelOrder", names(EMBlemModel), ignore.case = TRUE)]

  # use new orders to order model
  setkeyv(EMBlemModel, c(Facs, LvlOrds))

  # Remove additional columns
  EMBlemModel <- EMBlemModel[, ..EMBNames]

  return(EMBlemModel)
}
