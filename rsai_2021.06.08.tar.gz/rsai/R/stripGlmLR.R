#####  stripGlmLR  #####
#' Function to strip a glm object down to its bare bones.
#' @description The function takes a glm object and strips out anything that grows in size as the input data grows (by default glm objects contain a full copy of the input data.) The result is a much smaller and more manageable object, still capable of making predictions.
#' @usage stripGlmLR(cm)
#' @param cm A glm model.
#' @return A stripped-down object of class glm (still able to predict).
#' @author Edwin Graham (edwin.graham@uk.rsagroup.com)
#' @examples
#' #glmStripped <- stripGlmLR(glmFitted)
#' @export

stripGlmLR <- function(cm) {
  if(!("glm" %in% class(cm))) stop("cm must be a glm class object")
  cm$y <- c()
  cm$model <- c()
  cm$residuals <- c()
  cm$fitted.values <- c()
  cm$effects <- c()
  cm$qr$qr <- c()
  cm$linear.predictors <- c()
  cm$weights <- c()
  cm$prior.weights <- c()
  cm$data <- c()
  cm$family$variance <- c()
  cm$family$dev.resids <- c()
  cm$family$aic <- c()
  cm$family$validmu <- c()
  cm$family$simulate <- c()
  attr(cm$terms, ".Environment") <- c()
  attr(cm$formula, ".Environment") <- c()
  return(cm)
}