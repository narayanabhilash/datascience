#' Perform KNN target value encoding by location
#' 
#' @description Uses weighted K-Nearest Neighbour (KNN) algorithm to create a target value encoding for location data.
#' It returns another function as its output (a linear combination of the target response of near neighbours).
#' This second function can be used on the original data sent to this function
#' to create an out-of-fold encoding (using \code{trainMode = TRUE}),
#' or on any new data set (using \code{trainMode = FALSE}).
#' @usage locationTargetValueEncoder(
#'  x_coord,
#'  y_coord,
#'  target,
#'  foldId,
#'  weight = NULL,
#'  k = 5,
#'  plot = FALSE
#')
#' @param x_coord The x-coordinate. For best results, use a UTM style grid reference rather than longitude and latitude.
#' @param y_coord The y-coordinate.
#' @param target The target you are modelling. For ground up claims frequency modelling, this would be claims frequency
#' (i.e. claim count / exposure): However in such cases you are likely to obtain a more useful district by modelling
#' a residual, possibly of another model with locational elements. (In which case the target
#' would be claim count / (exposure * annualised offset)).
#' @param foldId As this is target value encoding it is important to define folds. 
#' @param weight The _exposure_ weights to apply in the calculation.
#' For claims frequency modelling, populate this with exposure
#' multiplied by any other weighting you want to apply (e.g. weights to rebalance after downsampling the non-claims.)
#' @param k The maximum number of nearest neighbours to use, in fold or out of fold.
#' @param plot Whether or not to plot the output diagnostics.
#' @return a function that will apply the target value encoding to new locations.
#' @note If a location weighting is not specified the tool uses regularised GLM (via glmnet)
#' to optimise the the _location based_ weights used in the calculation of 
#' the weighted average KNN feature returned. These weights will always decline with distance, 
#' and the weight used for more distant features may be zero. 
#' 
#' @note This function is intended to be used for target value encoding,
#' for nearest neighbour _feature_ blurring / engineering it's recommended that you just use `rsaiKNN`.
#' @seealso `rsaiKNN` `longLatToUTM`  `locationClaimsTVE`
#' 
#' @examples # # Generate random data in the 1x1 unit square
#'# # Generate random data in the 1x1 unit square
#'# n <- 6000
#'# set.seed(1984)
#'# dt <- data.table(
#'#   x = runif(n),
#'#   y = runif(n)
#'# )
#'# 
#'# # Define underlying intensity and plot:
#'# 
#'# dt[, intensity := x + (4 * (y - 0.6) ^ 2)]
#'# plotMap(dt, "intensity", "x", "y", cex = 5)
#'# 
#'# dt[, target := rpois(n, intensity + runif(n))]
#'# dt[, foldId := .I %% 2]
#'# 
#'# # Plot map of target
#'# plotMap(dt, "target", "x", "y", cex = 5)
#'# 
#'# # Use locationTargetValueEncoder to create encoder function
#'# encoderFunction <- locationTargetValueEncoder(
#'#   x_coord = dt[, x],
#'#   y_coord = dt[, y],
#'#   target = dt[, target],
#'#   foldId = dt[, foldId],
#'#   k = 80,
#'#   plot= TRUE
#'# )
#'# 
#'# # Generate new points within the same 1x1 grid
#'# newData <- data.table(
#'#   expand.grid(
#'#     x = seq(0, 1, by = 0.005),
#'#     y = seq(0, 1, by = 0.005)
#'#   )
#'# )
#'# 
#'# # Put the out-of-fold predictions back on the training data
#'# # Use trainMode = TRUE to do this
#'# dt[, KNN_prediction := encoderFunction(x, y, trainMode = TRUE)]
#'# 
#'# # Use encoder function to score new data
#'# # Use trainModel = FALSE for new data
#'# newData[, KNN_prediction := encoderFunction(x, y, trainMode = FALSE)]
#'# 
#'# # Plot the predictions for each fold separately on the training data
#'# # and all together on the new data
#'# layout(matrix(c(1, 2, 3, 3, 3, 3), 3, 2, byrow = TRUE))
#'# plotMap(dt[foldId == 0], "KNN_prediction", "x", "y", cex = 4, main = "Fold 0")
#'# plotMap(dt[foldId == 1], "KNN_prediction", "x", "y", cex = 4, main = "Fold 1")
#'# plotMap(newData, "KNN_prediction", "x", "y", cex = 4, main = "Predictions on new data")
#'# layout(matrix(1,1,1))
#'# 
#'# # The folds should look different because the prediction has been built
#'# # from data on the other fold(s). (In this case there are only two folds,
#'# # so the data is mutually exclusive, but this will not always be the case.)
#' @importFrom glmnet cv.glmnet
#' @export
#' @author Edwin Graham

locationTargetValueEncoder <- function(
  x_coord,
  y_coord,
  target,
  foldId = NULL,
  weight = NULL,
  k = 5,
  plot = FALSE
){
  require(glmnet)
  
  # Validation
  if (
    ! all(
      sapply(
        list(x_coord, y_coord, target),
        is.numeric
      ) 
    )
  ){
    stop("x_coord, y_coord and target must be numeric")
  }
  
  if (
    any(
      sapply(
        list(x_coord, y_coord, target),
        anyNA
      ) 
    )
  ){
    stop("NAs discovered")
  }
  
  if (! is.null(foldId)){
    if(is.list(foldId)) foldId <- folds_ListToVec(foldId)
   check <- list(x_coord, y_coord, target, foldId)
  } else{
   check <- list(x_coord, y_coord, target)
  }
  if (
    length(
      unique(
        sapply(check, length) 
      )
    ) != 1
  ){
    stop("x_coord, y_coord target and foldId must be the same length")
  }
  rm(check)
  
  # Put into a data table
  dt <- data.table(
    x_coord = x_coord,
    y_coord = y_coord,
    target = target,
    foldId = foldId
  )
  
  # Tidy
  rm(x_coord, y_coord, target)
  
  # Add row num
  dt[, rowNum := .I]
  
  # Set folds to integer starting from 1
  if (! is.null(foldId)){
    folds <- unique(dt[, foldId])
    folds <- folds[order(folds)]
    dt[, foldNo := match(foldId, folds)]
    dt[, foldId := NULL]
    nFolds <- length(folds)
    if (nFolds < 2) {
      stop("folds must not be unique")
    }
  }
  
  # Weight
  if (is.null(weight))(
    dt[, weight := 1]
  ) else{
    if (! is.numeric(weight)){
      stop("weight must be numeric")
    }
    if (length(weight) != nrow(dt)){
      stop("weight must be the same length as x_coord, y_coord and target")
    }
    if (anyNA(weight)){
      warning("weight contains NAs, these will be zero weighted")
      weight[is.na(weight)] <- 0
    }
    if (any(weight < 0)){
      stop("weights must not be negative")
    }
    dt[, weight := weight]
    rm(weight)
  }
  
  if (! is.null(foldId)){
    # Create summarised location data
    locSummary <- dt[ 
      ,
      .(
        locationTarget = sum(target * weight) / sum(weight),
        weight = sum(weight)
      ), 
      keyby = .(foldNo, x_coord, y_coord)
    ]
    
    # Use Nearest Neighbour algorithm to find nearby residual values
    KNNtarget <- rsaiKNN(
      locSummary,
      folds = "foldNo",
      weights = seq(k, 1),
      featurestoKNN = "locationTarget",
      return_neighbourhoods = TRUE,
      just_neighbourhoods = TRUE
    )
  } else{
    # Create summarised location data
    locSummary <- dt[ 
      ,
      .(
        locationTarget = sum(target),
        weight = sum(weight)
      ), 
      keyby = .( x_coord, y_coord)
    ]
    
    # Use Nearest Neighbour algorithm to find nearby residual values
    KNNtarget <- rsaiKNN(
      locSummary,
      weights = seq(k+1, 1),
      featurestoKNN = "locationTarget",
      return_neighbourhoods = TRUE,
      just_neighbourhoods = TRUE
    )    
  }

  # Change to matrices
  if (is.data.table(KNNtarget)){
    KNNtarget <- as.matrix(KNNtarget)
  } else{
    KNNtarget <- lapply(KNNtarget, as.matrix)
  }

  if (! is.null(foldId)){
    # Get weighted cumulative averages of target across NNs
    weightedAvs <- do.call(
      rbind,
      lapply(
        seq(1, nFolds),
        function(fold){
          # Out-of-fold target 
          outOfFoldTarget <- locSummary[foldNo != fold, locationTarget]
          outOfFoldWeight <- locSummary[foldNo != fold, weight]
          
          # Targets of NNs from out-of-fold
          NNTargets <- sapply(
            seq(1, k),
            function(i){
              outOfFoldTarget[KNNtarget[[fold]][, i]]
            }
          )
          
          # Weights of NNs from out-of-fold
          NNWeight <- sapply(
            seq(1, k),
            function(i){
              outOfFoldWeight[KNNtarget[[fold]][, i]]
            }
          )
          
          # Multiply target by weight
          NNTargets <- NNTargets * NNWeight
          
          # Get cumulative sums
          NNTargets <- t(apply(
            NNTargets,
            1,
            cumsum
          ))
          
          NNWeight <- t(apply(
            NNWeight,
            1,
            cumsum
          ))
          
          # Divide back by weight to get weighted average
          NNTargets <- NNTargets / NNWeight
          colnames(NNTargets) <- paste0("w", seq(1, k))
          
          return(NNTargets)
        }
      )
    )
  } else{
    # Get weighted cumulative averages of target across NNs
    weightedAvs <- sapply(
      seq(2, k+1),
      function(i){
        locSummary[, locationTarget][KNNtarget[, i]]
      }
    )
    
    # Weights of NNs from out-of-fold
    NNWeight <- sapply(
      seq(2, k+1),
      function(i){
        locSummary[, weight][KNNtarget[, i]]
      }
    )
    
    # Multiply target by weight
    weightedAvs <- weightedAvs * NNWeight
    
    # Get cumulative sums
    weightedAvs <- t(apply(
      weightedAvs,
      1,
      cumsum
    ))
    
    NNWeight <- t(apply(
      NNWeight,
      1,
      cumsum
    ))
    
    # Divide back by weight to get weighted average
    weightedAvs <- weightedAvs / NNWeight
    colnames(weightedAvs) <- paste0("w", seq(1, k))
  }
  
  # Fix for when only 2 folds
  if (! is.null(foldId)){
    locSummary[, glmfold := foldNo]
    if (nFolds == 2){
      set.seed(1984L)
      locSummary[, glmfold := foldNo + nFolds * rbinom(nrow(locSummary), 1, 0.5)]
    }
  } else{
    locSummary[, glmfold := (.I %% 10) + 1]
  }
  
  # Run elastic net regression with cumulative weighted averages
  linMod <- cv.glmnet(
    weightedAvs,
    locSummary[, locationTarget],
    alpha = 0.5,
    family = "gaussian",
    foldid = locSummary[, glmfold],
    weights = locSummary[, weight],
    lower.limits = 0
  )

  # Undo the cumulative sums to get NN weights
  corsWeights <- rev(
    cumsum(
      rev(
        linMod$glmnet.fit$beta[
          ,
          which(linMod$glmnet.fit$lambda == linMod$lambda.min)
        ]
      )
    )
  )
  
  # If no positive relationship found...
  if(sum(corsWeights) == 0) {
    warning("Feature does not appear to be positively correlated with its
            near neighbours: Null model returned.")
    return (
      function(
        x_coord,
        y_coord,
        trainMode,
        foldId = NULL
      ){
        if (! (is.numeric(x_coord) & is.numeric(y_coord))){
          stop("x_coord and y_coord must be numeric")
        }
        if (anyNA(x_coord) | anyNA(y_coord)){
          stop("NAs discovered.")
        }
        if (length(x_coord) != length(y_coord)){
          stop("x_coord and y_coord must have the same length.")
        }
        
        return(rep(0, length(x_coord)))
      }
    )
  }
  
  # Strip out zero weights and clear environment
  corsWeights <- corsWeights[corsWeights > 0]
  rm(KNNtarget, weightedAvs)
  
  # Using these weights, create a location residual
  # based on the residuals of the nearest (out-of-fold) neighbours
  if (is.null(foldId)){
    KNNtarget2 <- rsaiKNN(
      locSummary, 
      weights = c(0, corsWeights),
      weightcol = "weight",
      featurestoKNN = "locationTarget"
    )
  } else{
    KNNtarget2 <- rsaiKNN(
      locSummary, 
      folds = "foldNo",
      weights = corsWeights,
      weightcol = "weight",
      featurestoKNN = "locationTarget"
    ) 
  }
  
  # Put onto data
  locSummary[, LocKNN1 := KNNtarget2$knns$locationTarget]
  rm(KNNtarget2)
  
  # Plot map
  if (plot){
    plotSummary <- locSummary[sample(seq(1, .N), min(20000, .N))]
    set.seed(1984L)
    layout(matrix(c(2, 1), 1, 2, byrow = TRUE))
    # plot(linMod)
    plot(
      corsWeights / (corsWeights[1] + 1E-10),
      main = "Relative Neighbourhood Weightings",
      ylab = "Relative Weight")
    plotMap(
      plotSummary, "LocKNN1",
      cex = median(c(2, 5, 2 * sqrt(20000 / nrow(plotSummary)))),
      main = "Map of out of fold target by location")
    layout(matrix(1, 1, 1))
    rm(plotSummary)
  }
  
  # Merge onto original data
  if (! is.null(foldId)){
    setkey(dt, foldNo, x_coord, y_coord)
    dt <- merge(dt, locSummary[, .(foldNo, x_coord, y_coord, LocKNN1)])
  } else{
    setkey(dt, x_coord, y_coord)
    dt <- merge(dt, locSummary[, .(x_coord, y_coord, LocKNN1)])
  }
  
  setkey(dt, rowNum)
  
  # Strip required data from dt and remove
  original_x <- dt[, x_coord]
  original_y <- dt[, y_coord]
  returnVals <- dt[, LocKNN1]
  locSummary[, glmfold := NULL]
  locSummary[, LocKNN1 := NULL]
  
  rm(dt)
  
  # Create function for encoding locations
  returnFunction <- function(
    x_coord,
    y_coord,
    trainMode,
    foldId = NULL
  ){
    if (! is.logical(trainMode)){
      stop("trainMode must be TRUE or FALSE")
    }
    if (length(trainMode) != 1){
      stop("trainMode must be TRUE or FALSE")
    }
    
    if (trainMode){
      if (is.null(foldId)){
        if (! (identical(original_x, x_coord) & identical(original_y, y_coord))){
          stop(
            "When trainMode = TRUE,
            locations must exactly match the locations used to create encoding function.")
        }
        # Send back the out-of-fold values already calculated
        return(returnVals)
      }
      else{
        # Validation
        if (! (is.numeric(x_coord) & is.numeric(y_coord))){
          stop("x_coord and y_coord must be numeric")
        }
        if (anyNA(x_coord) | anyNA(y_coord)){
          stop("NAs discovered.")
        }
        if (length(x_coord) != length(y_coord)){
          stop("x_coord and y_coord must have the same length.")
        }
        if (length(folds) == 0){
          stop("foldId specified when encoder was built using leave-one-out")
        }
        if (length(foldId) != length(x_coord)){
          stop("foldId must be the same length as x_coord and y_coord")
        }
        if (length(setdiff(unique(foldId), folds)) > 0){
          stop("foldId contains folds not used when creating encoder")
        }
        
        # Put locations into table
        dtForScoring <- data.table(
          x_coord = x_coord,
          y_coord = y_coord,
          foldNo = match(foldId, folds)
        )
        rm(x_coord, y_coord, foldId)
        dtForScoring[, rowNum := .I]

        # Summarise down
        dtSummary <- unique(dtForScoring[, .(x_coord, y_coord, foldNo)])
        
        # Run KNN for new data
        dtSummary <- rbindlist(
          lapply(
            seq(1, length(folds)),
            function(i){
              scoreDT <- dtSummary[foldNo == i]
              if (nrow(scoreDT) == 0){
                return(
                  cbind(scoreDT, LocKNN1 = numeric(0))
                )
              }
              
              KNNtarget3 <- rsaiKNN(
                locSummary[foldNo != i],
                scoreDT,
                weights = corsWeights,
                weightcol = "weight",
                featurestoKNN = "locationTarget"
              )
              
              return(
                cbind(scoreDT, LocKNN1 = KNNtarget3$knn[, locationTarget])
              )
            }
          )
        )

        # Merge with scoring data
        setkey(dtSummary, x_coord, y_coord, foldNo)
        setkey(dtForScoring, x_coord, y_coord, foldNo)
        dtForScoring <- merge(dtForScoring, dtSummary)
        
        # Put back into original order
        setkey(dtForScoring, rowNum)
        
        # Return column
        return(dtForScoring[, LocKNN1])
      }
      
      
    } else{
      # Validation
      if (! (is.numeric(x_coord) & is.numeric(y_coord))){
        stop("x_coord and y_coord must be numeric")
      }
      if (anyNA(x_coord) | anyNA(y_coord)){
        stop("NAs discovered.")
      }
      if (length(x_coord) != length(y_coord)){
        stop("x_coord and y_coord must have the same length.")
      }
      
      # Put locations into table
      dtForScoring <- data.table(
        x_coord = x_coord,
        y_coord = y_coord
      )
      rm(x_coord, y_coord)
      dtForScoring[, rowNum := .I]
      
      # Summarise down
      dtSummary <- unique(dtForScoring[, .(x_coord, y_coord)])
      
      # Run KNN for new data
      KNNtarget3 <- rsaiKNN(
        locSummary,
        dtSummary, 
        weights = corsWeights,
        weightcol = "weight",
        featurestoKNN = "locationTarget"
      )
      
      # Score onto summary
      dtSummary[, LocKNN1 := KNNtarget3$knns$locationTarget]
      
      # Merge with scoring data
      setkey(dtSummary, x_coord, y_coord)
      setkey(dtForScoring, x_coord, y_coord)
      dtForScoring <- merge(dtForScoring, dtSummary)
      
      # Put back into original order
      setkey(dtForScoring, rowNum)
      
      # Return column
      return(dtForScoring[, LocKNN1])
    }
  }
  # Return
  return(returnFunction)
}

#' Perform KNN target value encoding by location
#' 
#' @description Uses weighted K-Nearest Neighbour (KNN) algorithm to create a target value encoding for location data.
#' It returns another function as its output (a linear combination of the target response of near neighbours).
#' This second function can be used on the original data sent to this function
#' to create an out-of-fold encoding (using \code{trainMode = TRUE}),
#' or on any new data set (using \code{trainMode = FALSE}).
#' This works in exactly the same way as the `locationTargetValueEncoder` function but takes a data table
#' as an input and is specifically designed for claims modelling.
#' @usage locationClaimsTVE(
#'  data,
#'  x_coordCol,
#'  y_coordCol,
#'  responseCol,
#'  exposureCol = NULL,
#'  offsetCol = NULL,
#'  sampleWeightCol = NULL,
#'  foldIdCol = NULL,
#'  family = "poisson",
#'  tweedieP = 1.5,
#'  k = 5,
#'  plot = FALSE
#')
#' @param data A data frame or data table containing your data.
#' @param x_coordCol The column name of the x-coordinate. For best results, use a UTM style grid reference rather than longitude and latitude.,
#' @param y_coordCol The column name of the y-coordinate.
#' @param responseCol The column name of the response. This should not be adjusted for exposure, I.E for claims
#' frequency modelling this should be the observed count of claims, for severity this should be the total claim
#' cost for that row of data, and for burning cost it should be the total observed claim cost and *NOT* claim
#' cost per exposure.
#' @param exposureCol The exposure in time. If you're building a severity model and you have rows with more than
#' one claim, this should be the claim count and the response should be the *total* claim cost not the average.
#' @param offsetCol If using an offset, this should be the offset model prediction.
#' I.E. for claim frequency this should be the expected baseline claim frequency per exposure period.
#' For severity it should be the baseline predicted cost per claim.
#' For burning cost it should be the baseline predicted cost per exposure period.
#' @param sampleWeightCol For any additional weighting to be applied.
#' E.G. if you are building a claim frequency model and have sampled down the non-claims in your training data
#' at a sampling rate of 1:3, you should specify a column that has a 1 for a claim and a 3 for a non-claim, thus
#' up-weighting the non-claims to account for the sampling.
#' @param foldIdCol Column separating your data into folds for validation.
#' @param family One of "poisson" for claims frequency, "gamma" for claims severity, or "tweedie" for burining cost.
#' @param tweedieP Used when doing tweedie modelling. Default is 1.5.
#' @param k The maximum number of nearest neighbours to use, in fold or out of fold.
#' @param plot Whether or not to plot the output.
#' @return a function that will apply the target value encoding to new locations.
#' @note This function is intended to be used for target value encoding,
#' for nearest neighbour _feature_ blurring / engineering it's recommended that you just use `rsaiKNN`.
#' @seealso `rsaiKNN` `longLatToUTM` `locationTargetValueEncoder`
#' 
#' @examples # # Generate random data in the 1x1 unit square
#'# # Generate random data in the 1x1 unit square
#'# n <- 6000
#'# set.seed(1984)
#'# dt <- data.table(
#'#   x = runif(n),
#'#   y = runif(n)
#'# )
#'# 
#'# # Define underlying intensity and plot:
#'# 
#'# dt[, intensity := x + (4 * (y - 0.6) ^ 2)]
#'# plotMap(dt, "intensity", "x", "y", cex = 5)
#'# 
#'# dt[, target := rpois(n, intensity + runif(n))]
#'# dt[, foldId := .I %% 2]
#'# 
#'# # Plot map of target
#'# plotMap(dt, "target", "x", "y", cex = 5)
#'# 
#'# # Use locationTargetValueEncoder to create encoder function
#'# encoderFunction <- locationClaimsTVE(
#'#   data = dt,
#'#   x_coordCol = "x",
#'#   y_coordCol = "y",
#'#   responseCol = "target",
#'#   foldIdCol = "foldId",
#'#   family = "poisson",
#'#   k = 80,
#'#   plot= TRUE
#'# )
#'# 
#'# # Generate new points within the same 1x1 grid
#'# newData <- data.table(
#'#   expand.grid(
#'#     x = seq(0, 1, by = 0.005),
#'#     y = seq(0, 1, by = 0.005)
#'#   )
#'# )
#'# 
#'# # Put the out-of-fold predictions back on the training data
#'# # Use trainMode = TRUE to do this
#'# dt[, KNN_prediction := encoderFunction(x, y, trainMode = TRUE)]
#'# 
#'# # Use encoder function to score new data
#'# # Use trainModel = FALSE for new data
#'# newData[, KNN_prediction := encoderFunction(x, y, trainMode = FALSE)]
#'# 
#'# # Plot the predictions for each fold separately on the training data
#'# # and all together on the new data
#'# layout(matrix(c(1, 2, 3, 3, 3, 3), 3, 2, byrow = TRUE))
#'# plotMap(dt[foldId == 0], "KNN_prediction", "x", "y", cex = 4, main = "Fold 0")
#'# plotMap(dt[foldId == 1], "KNN_prediction", "x", "y", cex = 4, main = "Fold 1")
#'# plotMap(newData, "KNN_prediction", "x", "y", cex = 4, main = "Predictions on new data")
#'# layout(matrix(1,1,1))

#'# # The folds should look different because the prediction has been built
#'# # from data on the other fold(s). (In this case there are only two folds,
#'# # so the data is mutually exclusive, but this will not always be the case.)
#' @importFrom glmnet cv.glmnet
#' @export
#' @author Edwin Graham

locationClaimsTVE <- function(
  data,
  x_coordCol,
  y_coordCol,
  responseCol,
  exposureCol = NULL,
  offsetCol = NULL,
  sampleWeightCol = NULL,
  foldIdCol = NULL,
  family = "poisson",
  tweedieP = 1.5,
  k = 5,
  plot = FALSE
){
  # Validation
  if (! is.data.frame(data)){
    stop("data must be a valid data.frame")
  }
  if (! is.data.table(data)){
    data <- data.table(data)
  }
  
  # Validate column names
  columnNames <- c(
    x_coordCol,
    y_coordCol,
    responseCol,
    exposureCol,
    offsetCol,
    sampleWeightCol,
    foldIdCol
  )
  
  # Check no column names are duplicated
  if (anyDuplicated(columnNames)){
    stop("Column names specified have been duplicated.")
  }
  
  # Check column names exist in data
  missingCols <- which(! columnNames %in% names(data))
  
  if (length(missingCols) > 0){
    stop(
      paste0(
        columnNames[missingCols][1],
        " is not in the data frame specified."
      )
    )
  }
  
  # Check family is valid
  if (! family %in% c("poisson", "gamma", "tweedie")){
    stop("family must be one of 'poisson', 'gamma' or 'tweedie'.")
  }
  if (family == "tweedie"){
    if (tweedieP <= 1 | tweedieP >= 2){
      stop("tweedieP should be between 1 and 2")
    }
  } else if (family == "poisson"){
    tweedieP <- 1
  } else if (family == "gamma"){
    tweedieP <- 2
  }
  
  # Exposure
  if (is.null(exposureCol)){
    exposure <- 1
  } else{
    exposure <- data[[exposureCol]]
  }
  
  # Offset
  if (is.null(offsetCol)){
    offset <- 1
  } else{
    offset <- data[[offsetCol]]
  }
  
  # Sample weight
  if (is.null(sampleWeightCol)){
    sampleWeight <- 1
  } else{
    sampleWeight <- data[[sampleWeightCol]]
  }
  
  # Target
  target <- ifelse(
    exposure * offset == 0,
    0,
    data[[responseCol]] / (exposure * offset)
  )
  
  # Weight
  weight <- sampleWeight * exposure * offset ^ (2 - tweedieP)
  if (length(weight) == 1){
    weight <- rep(weight, length.out = nrow(dt))
  }
  
  # Fold Ids
  if (is.null(foldIdCol)){
    foldId <- NULL
  } else{
    foldId <- data[[foldIdCol]]
  }
  
  # Run locationTargetValueEncoder
  returnFunction <- locationTargetValueEncoder(
    x_coord = data[[x_coordCol]],
    y_coord = data[[y_coordCol]],
    target = target,
    foldId = foldId,
    weight = weight,
    k = k,
    plot = plot
  )
  
  # Return output function
  return(returnFunction)
}


