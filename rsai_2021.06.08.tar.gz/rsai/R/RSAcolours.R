RSACorePurple <- "#460085"
RSADeepPurple <- "#3C025F"
RSAPurpleRain <- "#B327CC"
RSAGrey <- "#969696"
RSAMagenta <- "#FF49A4"
RSATurquoise <- "#00C2DB"
RSARed <- "#FF0000"

#' RSA colours
#' @description Set the plotting palette to use RSA colours, or generate a 
#' colour gradient along RSA colour guidelines
#' @usage setRSAPalette()
#' RSAGradientColour(n, b, ...) 
#' @param n Number of colours to return (\code{n=1} will always return the RSA 
#' core purple colour)
#' @param b Secondary RSA colour to use. The mapping is 1=Deep Purple, 2=Purple 
#' Rain, 3=Grey, 4=Magenta, 5=Turquoise, 6=Red.
#' @param ... Further arguments (such as \code{alpha}) to be passed to \code{\link{rgb}}.
#' @details The RSA colours are stored internally in the \code{rsai} package, 
#' as "RSACorePurple","RSADeepPurple","RSAPurpleRain","RSAGrey","RSAMagenta",
#' "RSATurquoise" and "RSAred".
#' @return for \code{setRSAPalette} the palette previously in force, invisibly.
#' for \code{RSAGradientColour}, a vector of colours of length \code{n}.
#' @export
#' @references RSA colour specification from "Brand Guidelines Refresh v1.0", 
#' RSA brand centre, June 2014.
#' @author James Lawrence
#' @note The RSA font names are "RSA Sans Regular","RSA Sans Bold" and so on 
#' (for use in \code{font} or specifying as defaults in \code{\\etc\\rdevga})
#' @seealso \code{\link{rgb}}, \code{\link{palette}}
#' @examples
#' par(mfrow=c(1,2))
#' ## set the RSA palette, keeping the old one for later
#' setRSAPalette() -> oldPalette
#' ## plot something
#' plot(1:7,col=1:7,pch=15,cex=2)
#' ## restore the default palette
#' palette(oldPalette)
#' ## now use a colour gradient from core purple to turquoise
#' plot(1:10,col=RSAGradientColour(10,5),pch=15,cex=2)
#' 

setRSAPalette <- function(){
  palette(c(
    RSACorePurple,
    RSAGrey,
    RSAPurpleRain,
    RSATurquoise,
    RSAMagenta,
    RSADeepPurple,
    RSARed
  ))
}

#' @export
#' @rdname setRSAPalette
RSAGradientColour <- function(n,b,...){
	CorePurple <- c(102,0,133)/255
	EndColour <- switch(b,
		c(60,2,95),
		c(179,39,204),
		c(150,150,150),
		c(255,73,164),
		c(0,194,219),
		c(255,0,0),
		stop("undefined colour")
	)/255
	lambda.seq <- seq(0,1,length.out=n)
	rgb(
		EndColour[1]*lambda.seq + CorePurple[1]*(1-lambda.seq),
		EndColour[2]*lambda.seq + CorePurple[2]*(1-lambda.seq),
		EndColour[3]*lambda.seq + CorePurple[3]*(1-lambda.seq),
		...
	)
}
