#####  plotxgbFactor  #####
#' Plot one-way partial dependency for a factor in an xgboost model.
#' @description Plot one-way partial dependency for a factor in an xgboost model where the factor has been encoded into
#' numeric columns using the \code{xgbSetupdata2} function. UPDATE- plotxgbfactor is now deprecated: you can simply call plot.
#' @usage plotxgbFactor(x,
#'               factorName = "",
#'               n.trees = NULL,
#'               plot = T,
#'               xgbcolnames = "",
#'               levels = NULL,
#'               select = NULL,
#'               minEffect = 0,
#'               inv.link = NULL,
#'               orderByResponse = FALSE,
#'               main = NULL,
#'               xlab = NULL,
#'               ylab = NULL,
#'               ...)
#' @param x An xgb.Booster object
#' @param factorName Name of the factor column in the original data that was encoded to numeric columns by xgbSetupdata2
#' @param n.trees How many trees to use for the model. If left NULL all trees are used.
#' @param plot True (default) or False. If True, returns a plotly plot object, if False returns a data table of values.
#' @param xgbcolnames Names of the columns used to train the model (this is post-encoding.)
#' @param levels Level names of the factor. This is ignored if the factor was one-hot encoded.
#' @param select Which levels to plot or return. If NULL, returns all levels.
#' @param minEffect Only used when the encoding is one-hot. If specified, only returns levels where the effect is higher than this number.
#' @param inv.link Optional. Apply the an inverse link function to the response. Set to exp if using a log-link to get multipliers.
#' @param orderByResponse TRUE or FALSE. If TRUE re-orders the levels from low to high depending on their effect.
#' @param main Main title for chart. Ignored if plot=FALSE.
#' @param xlab Title for x-axis in chart. Ignored if plot=FALSE.
#' @param ylab Title for y-axis in chart. Ignored if plot=FALSE.
#' @param \dots Other arguments to pass through to call to \code{plot_ly}.
#' @return A plotly plot object or a data table of values, depending on the 'plot' argument.
#' @details plotxgbfactor is now deprecated: you can simply call plot.
#' @author Tom Bratcher and Edwin Graham
#' @export

plotxgbFactor <- function ( x,
                            factorName = "",
                            n.trees = NULL, #? not sure what the bestind thing is in plot.xgboost
                            plot = T,
                            # (and possibly raw rates?)
                            # basics first. 
                            xgbcolnames = "", # your col names from xgbsetupdata
                            levels = NULL,
                            # character vector of All the possible levels for your factor. 
                            #REQUIRED for binary encoding, and must be in the same order as they were specified 
                            # when you set up your xgb.DMatrix object.
                            # potentially this includes NAs.
                            # not actually required for one hot factors.
                            select = NULL,
                            # character vector of the levels you actually want to display (if NULL, all of them)
                            # note: nothing displayed if no effect to show.
                            minEffect = 0, # below which, dfkdfc. Only applies to one-hot. Overridden by SELECT
                            inv.link = NULL,
                            orderByResponse = FALSE,
                            main = NULL,
                            xlab = NULL,
                            ylab = NULL,
                            ...
                              
){
  
  # Now deprecated.
  
  warning ("plotxgbfactor is now deprecated: you can simply call plot.")
  
  columns <- grep (paste0("^",factorName,"~"),xgbcolnames) # -1 to follow...
  if (length(columns)==0) stop ("factor name does not appear in xgbcolnames")
  type <- gsub ("~.*$","",gsub (paste0("^",factorName,"~"),"",xgbcolnames[columns[1]])) # should be "is", "binary" or "numeric"
  
  if (type == "numeric"){
    if (is.null (levels)) stop ("level names are required for numeric encodings")
    if(levels[length(levels)] != "NA") levels <- c(levels, "NA")
    dt_chart<- data.table (level = c (levels), response = 0) 
  } else if (type == "binary") {
    if (is.null (levels)) stop ("level names are required for binary encodings")
    dt_chart<- data.table (level = c (levels), response = 0)
    
  } else if(type == "is"){
    if (!is.null (levels)) cat("Level names provided will not be used since levels can be found in the names of the encoded columns.\n")
    dt_chart<- data.table (level = xgbcolnames[columns], response = 0) 
    
  } else stop("Factor encoding not recognised.")
  # nice to just anchor it...
  # but need to then add weight into it... 
  if (is.null (n.trees)) n.trees = x$niter
  
  

  # generate the correct response -------------------------------------------
  
  if (type== "is"){ # get the relevant two way tables and normalise them add them into dt_chart
    for (i in seq_along (columns)){
      #cat (columns[i])
      dt_temp <- plot (x,i.var=columns[i]-1,n.trees = n.trees,continuous.resolution=2,plot=F,var.names="irrelevant")
      if (nrow(dt_temp)>1) dt_chart$response[i]<-dt_temp[2,2]-dt_temp[1,2] # ie deviance from default for that factor level
    }
  } else if (type == "binary"){ # need a multidimensional one...
    # in the unlikely event our columns are disordered,
    namenumbers <- as.integer(gsub(".*~","",xgbcolnames[columns]))   # might need them all because might not split on all...
    columns <- columns [order (namenumbers)]
    dt_temp <-
      plot (
        x,
        i.var = columns - 1,
        n.trees = n.trees,
        continuous.resolution = 2,
        return.grid = T,
        plot = F
      )# variable names apparently do nowt...
    # have checked this simply gives what we need in the order we need it- REGARDLESS of whether the ~bin level is used. 
    dt_chart$response=dt_temp$y[seq_along(dt_chart$level)]
  } else{
    dt_temp <- plot(x,i.var=columns-1,n.trees = n.trees,continuous.resolution=length(levels),plot=F,var.names="irrelevant")
    xdump <- pretty.xgb.trees(x, n.trees)
    pte <- sapply(xdump, prettyTree2Expression, columns - 1, paste0("x", 0:(columns - 1)))
    x.df <- data.frame(Var1=seq(1, length(levels)))
    xString <- paste0("x", columns - 1, "=z[", seq_along(columns - 1), "]", collapse = ",")
    evalfn <-
      eval(parse(
        text = paste0(
          "function(z) sum(sapply(pte,function(e) eval(e,envir=list(",
          xString,
          "))))"
        )
      ))
    dt_chart$response <- apply(x.df, 1, evalfn)
  }
  
  # remove unnecessary values of dt_chart (only works for one hot)
  if (is.null(select)& type=="is") dt_chart<-dt_chart[abs(response)>=minEffect]
  #sort the table?
  if(orderByResponse) dt_chart<- dt_chart[order(dt_chart$response)] # ditto
  dt_chart[,level:=gsub(".*~[A-z]+~","",level)]  # in case it's still there...
  dt_chart$level <- factor (dt_chart$level,levels = unique(dt_chart$level))
  
  if (!is.null (select))dt_chart<-dt_chart[level %in% select]
  
  if(!is.null(inv.link)) dt_chart[, response := inv.link(response)]
  
  if (!plot) return (dt_chart)
  # plotLy dt_chart: KISS for NOW. unfortunately plotLy uses piping so extra bits might be fiddly.
  
  if(is.null(main)) main <- paste0("One-way chart of ", factorName)
  if(is.null(xlab)) xlab <- factorName
  if(is.null(ylab)) ylab <- ""
  
  plotobj<-( plot_ly(data =dt_chart,
    x = ~level,
    y = ~response,
    name = factorName,
    type = 'scatter',
    mode = 'markers'
    ,... # inherits dots?? I hope so. 
  ) %>% layout(
    title = main,
    xaxis = list(title=xlab),
    yaxis = list(title=ylab)
  ) )

# if(!(is.null())) plotobj %>% add_trace(x~level,y~Expected,type ='scatter',mode='lines',name = "Expected", yaxis = 'y2')
  
  # add_trace(x = ~Date, y = ~Temp, type = 'scatter', mode = 'lines', name = 'Temperature', yaxis = 'y2',
  #           line = list(color = '#45171D'),
  #           hoverinfo = "text",
  #           text = ~paste(Temp, '°F'))
  # 
  
  return (plotobj)
  }
