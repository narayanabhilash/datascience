
## currently trying to add fNum but erroring out
# cause is line 150 or so:
# need to keep track of the fscore not just the gain.


# Function to replicate the gain (and Fscore?...)

leaf <- function(node) grepl ("^[0-9]+:leaf", node) 
fNum <- function(node) gsub("([0-9]+:\\[)(f[0-9]+)(.*)", "\\2", node)
nGain <-function(node) as.numeric(gsub("(.*,gain=)(.*)(,cover=.*)", "\\2", node))
yNum <- function(node) as.integer(gsub("(.*yes=)([0-9]+)(,.*)", "\\2", node))
nNum <- function(node) as.integer(gsub("(.*no=)([0-9]+)(,.*)", "\\2", node)) 

# at the very basic level, look at what a node is giving us.
nodeScorer <- function (
  node,
  path = character(),
  currentScore = list(),
  gains = numeric(),
  fNum = list(),
  limit = 2){
  if (!(leaf(node))){
    nodeVal <- fNum(node)
    path = c(path, nodeVal)
    gains = c(gains, nGain(node))
    # Add gains into current score:
    for (i in 1: length (path)){
      # what's the string length?
      if (i < (limit + 2)){ # R: it's not python

        if (i > length(currentScore)){
          currentScore[[i]]<- list()
          fNum[[i]]<- list()  
        }
        pathEnd <- path[(length(path) - i + 1):length(path)]
        pathEnd <- paste(pathEnd[order(pathEnd)], collapse = "|")
        gain = sum(gains[(length(path) - i + 1):length(path)])
        # add a new value to currentScore, fNum if we need to:
        if (pathEnd %in% names(currentScore[[i]])){
          currentScore[[i]][pathEnd] <- as.numeric(currentScore[[i]][pathEnd]) + gain
          fNum[[i]][pathEnd] <- as.integer(fNum[[i]][pathEnd]) + 1L
        } else {
          currentScore[[i]][pathEnd] <- gain
          fNum[[i]][pathEnd] <- 1L
        }
      }
    }
  }
  return(
    list(
      path = path,
      currentScore = currentScore,
      fNum = fNum,
      gains = gains
      ))
}

# Now a recursion to get what this node, and those recursively below it, give.
treeScorer <- function (
  tree,
  row = 2,
  path = character(),
  currentScore = list(),
  fNum = list(),
  gains = numeric(),
  limit = 2) {
  
# this assumes that you start with line 1 of the tree = "booster"...
# so you start at row 2 with path = character(), and currentScore from the previous tree. 
node <- tree[row]  
if (!(leaf(node))){ # this can unfortunately happen: sometimes a tree is just a leaf
  lstring <- paste0("^",yNum(node),":")
  leftRow <- grep(lstring,tree)
  rstring <-paste0("^",nNum(node),":")
  rightRow <- grep(rstring,tree)

temp <- nodeScorer(node, path = path, currentScore = currentScore, fNum = fNum,
                   gains = gains, limit = limit)
topPath = temp$path
topGains = temp$gains
temp <- treeScorer(
  tree, row = leftRow, path = topPath, currentScore = temp$currentScore,
  fNum = temp$fNum, gains = topGains, limit = limit)
temp <- treeScorer(
  tree, row = rightRow,path = topPath, currentScore = temp$currentScore,
  fNum = temp$fNum, gains = topGains, limit = limit)
return(temp)    
} else return(
  list(path = path, currentScore = currentScore,
       fNum = fNum, gains = gains, limit = limit))
}  

# so now score the whole tree...

#' Factor Importance calculation for xgboost
#' 
#' @description Calculates gain, and related statistics, emulating the farOn xgb.fi() macro in R
#' 
#' @details The function takes an xgboost model or text dump and returns lists of data tables
#' containing the factors or interactions ordered by gain.
#' @usage xgbfR(  model,
#' features = NULL,
#' top.k = 100L,
#' condenseFlag = TRUE,
#' condenseSeparator = "~",
#' max.interaction.depth = 2,
#' max.trees = -1)
#' @param model An \code{xgb.Booster} object or dump thereof (with_stats should be \code{TRUE}!).
#' @param features optional vector of column names of your xgb.Dmatrix object
#' @param condenseFlag logical to condense one-hot or other encoded factors: this requires features to be set,
#' and using \code{condenseSeparator} as a separator of factor and level. 
#' @param condenseSeparator the separator for \code{condenseFlag}
#' @param top.k limits the number of rows returned.
#' @param max.interaction.depth Interaction depth limit - as per the original farOn macro,
#' depth 1 = up to 2 factors, etc.
#' @param max.trees Upper bound for trees to be parsed. Default is -1 (no limit)
#' @return A list of tables (by interaction depth, starting at zero). If the maximum tree depth
#' is lower than the limit allows, the list is cut short rather than returning empty data tables.  
#' of data.tables of interactions (by gain).
#' @author Tom Bratcher (tom.bratcher@uk.rsagroup.com)
#' @export
#' @importFrom  xgboost xgb.dump
#' @examples
#' 
#' require(xgboost)
#' set.seed(20160603L)
#' 
#' ## generate random data
#' ## with response y ~ x1*x2+x3
#' df1 <- data.table(
#'   x1=rnorm(1000),
#'   x2=sample(5, 1000, replace=TRUE)
#' )
#' df1[, x3:= rnorm(1000) -0.5 * x1]
#' df1[, y := rnorm(1000, x1*x2 +x3)]
#' 
#' ## fit an xgboost model to the data
#' xgb.train.matrix <- xgb.DMatrix(data=as.matrix(df1[,-4]),label=df1$y)
#' xgb1 <- xgb.train(
#'   data=xgb.train.matrix,
#'   verbose=1,
#'   nrounds=10,
#'   eta=0.5,
#'   max_depth=3L
#' )
#' xgbfR(model =xgb1,features = c("x1", "x2", "x3"))


xgbfR <- function(
  model,
  features = NULL,
  top.k = 100L,
  condenseFlag = TRUE,
  condenseSeparator = "~",
  max.interaction.depth = 2,
  max.trees = -1
  ){
  if ("xgb.Booster" %in% class(model))
    model <- xgb.dump(model, with_stats = TRUE)
  
  treeStarts <- grep("^booster", model)
  treeEnds <- c(setdiff(treeStarts, 1) - 1, length(model))
  
  if (!(length(treeStarts))){
    warning("no trees found: returning empty response")
    return(list())
  }
  runningTotal <- list(
    currentScore = list(),
    fNum = list())
  
  if (!(is.null(features))){
    nameMatch = data.table(
      f = sapply(seq_along(features), function (x) paste0("f", x - 1)),
      n = features)
  }
  
  if(any(grepl("\\|", features))){
    warning ("'|' character removed from feature names")
    features <- gsub("\\|", ".", features)
  }
  
  theseTrees = seq_along(treeStarts)
  if (max.trees >0) theseTrees <- (1: trunc(max.trees))
  for (n in seq_along(treeStarts)){
    tree <- model[treeStarts[n]:treeEnds[n]]
    
    runningTotal <- treeScorer(
      tree,
      currentScore = runningTotal$currentScore,
      fNum = runningTotal$fNum,
      limit = max.interaction.depth
    )
  }
  #turn it into a nice data table:
  output = list()
  for (i in seq_along(runningTotal$currentScore)){
    output[[i]] <- data.table(
      Feature = names(runningTotal$currentScore[[i]]),
      Gain = as.numeric(runningTotal$currentScore[[i]]),
      FScore = as.integer(runningTotal$fNum[[i]])
    )
    if (!(is.null(features))){
        output[[i]][, paste0("c", 1:i) := tstrsplit(Feature, "\\|")]
      splitCols = paste0("c", 1:i)
      for (nm in splitCols){
        output[[i]][[nm]] <- nameMatch$n[match(output[[i]][[nm]], nameMatch$f)]
        } 
      output[[i]]$Feature <- apply(
        output[[i]][, splitCols, with =F] ,1 , paste , collapse = "|")
      output[[i]] <- output[[i]][,.(Feature, Gain, FScore)] 
      
      if (condenseFlag){
       # print(output[[i]])###
          # first rip out any ~s
          constr <- paste0(condenseSeparator, "[^|]*\\|")
          output[[i]][, Feature := gsub(constr, "|", Feature)]
       # print(output[[i]])  
          constr <- paste0(condenseSeparator, ".*")
          output[[i]][, Feature := gsub(constr, "", Feature)]
      #  print(output[[i]])  
          output[[i]] <- output[[i]][, lapply(.SD, sum, na.rm=TRUE), by=.(Feature)] 
          # will screw up average gain etc because isn't a sum.
          # but peeps can do that sum themselves.
        }
      }
    # order and row limits: (after condensation!)
    setorder(output[[i]], -Gain)
    if (!(is.null(top.k))) {
      output[[i]] <- output[[i]][1:min(top.k, nrow(output[[i]]))]
    }
  }
  return(output)
}

