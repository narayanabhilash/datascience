#' Adds base levels to a combined model, i.e. levels with a multiplier of 1.
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param BaseLevsToAdd Object. Your data.table containing all (base) levels you wish to add, in form: Old Factor, New Level.
#' @return An increased EMBglm which is equal to the \code{EMBlemModel} with all \code{BaseLevsToAdd} added.
#' @examples
#' #.EMBmodelAddBaseLev(EMBlemModel, BaseLevsToAdd = BaseLevsToAdd)

.EMBmodelAddBaseLev <- function (EMBlemModel, BaseLevsToAdd)
{
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel),
                                    ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]
  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value",
                                               MdlsToChange))
  }
  FacOld <- c(BaseLevsToAdd[[1]])
  LevNew <- c(BaseLevsToAdd[[2]])

  # Checking that Parent Factor exists
  isPresent <- unique(FacOld) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(FacOld)[!isPresent], collapse = "', '"), "' not in model. Found in 'Base Levels To Add' ")
  }

  # Checking that base Levels do not already exist
  duplicatedParents <- merge(data.table(FacOld, LevNew),
                             data.table(FacOld = unlist(EMBlemModel[, ..Facs]), LevNew = unlist(EMBlemModel[, ..Lvls])),
                             by = c("FacOld", "LevNew"))
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$FacOld,duplicatedParents$LevNew, sep = ":"), collapse = "', '"), "' already exist(s) in Model, cannot add duplicate row(s). Found in 'Base Levels To Add'")
  }

  # Adding base levels
  for (j in 1:length(LevNew)){
    for (i in 1:length(Lvls)) {
      Lvls2 <- Lvls[Lvls != Lvls[i]]
      dt_newrow <- EMBlemModel[get(Facs[i]) == FacOld[j]]
      if (nrow(dt_newrow) > 0) {
        dt_uniquerow <- unique(dt_newrow[, c(Facs, Lvls2), with = FALSE])
        lst_colsToAdd <- setdiff(names(EMBlemModel), names(dt_uniquerow))
        dt_exampleRow <- EMBlemModel[1, lst_colsToAdd, with = FALSE]
        dt_exampleRow[, `:=`(Lvls[i], LevNew[j])]
        set(dt_exampleRow, 1L, 2:(length(lst_colsToAdd)),
            1)
        dt_joined <- cbind(dt_uniquerow, dt_exampleRow)
        setcolorder(dt_joined, EMBNames)
        EMBlemModel <- rbind(dt_joined, EMBlemModel)
      }
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))
}



#' Adds levels to a combined model
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param ChildLevsToAdd Object. Your data.table containing all (child) levels you wish to add, in form: Old Factor, Old Parent Level, New Child Level.
#' @return An increased EMBglm which is equal to the \code{EMBlemModel} with all \code{ChildLevsToAdd} added.
#' @examples
#' #.EMBmodelAddChildLev(EMBlemModel, ChildLevsToAdd = ChildLevsToAdd)

.EMBmodelAddChildLev <- function (EMBlemModel, ChildLevsToAdd)
{
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel),
                                    ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]
  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value",
                                               MdlsToChange))
  }
  Fac <- c(ChildLevsToAdd[[1]])
  LevParent <- c(ChildLevsToAdd[[2]])
  LevChild <- c(ChildLevsToAdd[[3]])

  # Checking that Parent Factor exists
  isPresent <- unique(Fac) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(Fac)[!isPresent], collapse = "', '"), "' not in model. Found in 'Child Levels To Add' ")
  }

  # Checking that Parent Factor and Level exist
  duplicatedParents <- merge(data.table(Fac, LevParent),
                             data.table(Fac = unlist(EMBlemModel[, ..Facs]), LevParent = unlist(EMBlemModel[, ..Lvls]), inModel = TRUE),
                             by = c("Fac", "LevParent"), all.x = TRUE)
  duplicatedParents <- unique(duplicatedParents[is.na(inModel), .(Fac, LevParent)])
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Fac,duplicatedParents$LevParent, sep = ":"), collapse = "', '"), "' in levels to add but not in Model. Found in 'Child Levels To Add'")
  }

  # Checking that Child Levels do not already exist
  duplicatedParents <- merge(data.table(Fac, LevChild),
                             data.table(Fac = unlist(EMBlemModel[, ..Facs]), LevChild = unlist(EMBlemModel[, ..Lvls])),
                             by = c("Fac", "LevChild"))
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Fac,duplicatedParents$LevChild, sep = ":"), collapse = "', '"), "' already exist(s) in Model, cannot add duplicate row(s). Found in 'Child Levels To Add'")
  }

  # Creating new child levels
  for (i in 1:length(Lvls)) {
    for (j in 1:length(LevChild)) {
      dt_Fac_ij <- EMBlemModel[get(Facs[i]) == Fac[j]]

      dt_exampleRow <- unique(dt_Fac_ij[get(Lvls[i]) == LevParent[j]])

      dt_exampleRow[, `:=`(Lvls[i], LevChild[j])]

      EMBlemModel <- rbind(dt_exampleRow, EMBlemModel)

    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))
}



#' Collapses factors from a combined model using the specified level weights
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param FacsToCollapse Object. Your data.table containing all factors you wish to delete.
#' @return A reduced EMBglm which is equal to the \code{EMBlemModel} with all \code{FacsToCollapse} removed.
#' @examples
#' #.EMBmodelFacCollapse(EMBlemModel, FacsToCollapse = FacsToCollapse)
.EMBmodelFacCollapse <- function(EMBlemModel, FacsToCollapse){

  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]

  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value", MdlsToChange))
  }

  FacCol <- unique(FacsToCollapse[[1]])

  names(FacsToCollapse) <- c("Factor", "Level", "Weight")
  FacsToCollapse[, Weight := as.numeric(Weight)/sum(as.numeric(Weight)), Factor]

  # Checking that Parent Factor exists
  isPresent <- unique(FacCol) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(FacCol)[!isPresent], collapse = "', '"), "' not in model. Found in 'Levels To Collapse' ")
  }

  # Checking that Parent Factor and Level exist
  duplicatedParents <- merge(FacsToCollapse[, .(Factor, Level)],
                             data.table(Factor = unlist(EMBlemModel[, ..Facs]), Level = unlist(EMBlemModel[, ..Lvls]), inModel = TRUE),
                             by = c("Factor", "Level"), all.x = TRUE)
  duplicatedParents <- unique(duplicatedParents[is.na(inModel), .(Factor, Level)])
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Factor,duplicatedParents$Level, sep = ":"), collapse = "', '"), "' not in Model. Found in 'Levels To Collapse'")
  }

  # for each Lvls merge on FacsToCollapse then multiply through the weights. Sum relativities over factor, then factor delete.
  for(i_facCol in FacCol){
    asdf <- copy(EMBlemModel)
    asdf_FacsToCollapse <- FacsToCollapse[Factor == i_facCol]

    # attach weights
    for (j in seq_along(Lvls)) {
      asdf[, paste0("Weights", j) := 0]
      for (i in 1:(length(asdf_FacsToCollapse[[3]]))) {
        asdf[(get(Facs[j]) == as.character(asdf_FacsToCollapse[i, 1]) &
                get(Lvls[j]) == as.character(asdf_FacsToCollapse[i, 2]))
             , paste0("Weights", j) := as.numeric(asdf_FacsToCollapse[i, 3])]
      }
    }

    # Remove factors
    for (j in seq_along(Lvls)) {
        asdf[get(Facs[j]) == as.character(asdf_FacsToCollapse[1, 1]),
             c(Facs[j],Lvls[j]) := list("","")]
    }

    # multiply through by weights
    asdf[, Weights := rowSums(.SD), .SDcols = grep("^Weights", names(asdf), value = TRUE)]
    asdf[, (Mdls) := lapply(Mdls, function(x) {get(x) * Weights})]

    # Sum through removed levels
    asdf <- asdf[Weights != 0]
    asdf <- asdf[, lapply(.SD, sum), .SDcols = Mdls, by = c(Facs, Lvls)]
    if(length(Lvls) > 1){
      for (i in 1:(length(Lvls) - 1)) {
        asdf[get(Facs[i]) == "" & get(Facs[i + 1]) != "",
             c(Facs[i], Facs[i + 1], Lvls[i], Lvls[i + 1]) := list(get(Facs[i + 1]), "", get(Lvls[i + 1]), "")]
      }
    }

    # multiply through facotrs + levels to apply mult from removed level
    EMBlemModel <- rbind(EMBlemModel, asdf)
    EMBlemModel <- EMBlemModel[ , lapply(.SD, prod), .SDcols = Mdls, by = c(Facs, Lvls)]

    # deleting factor
    for (j in 1:length(Facs)) {
        EMBlemModel <- EMBlemModel[ !(get(Facs[j]) == asdf_FacsToCollapse[1, Factor]), ]
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))
}


#' Removes factors from a combined model
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param FacsToDelete Object. Your data.table containing all factors you wish to delete.
#' @return A reduced EMBglm which is equal to the \code{EMBlemModel} with all \code{FacsToDelete} removed.
#' @examples
#' #.EMBmodelFacDelete(EMBlemModel, FacsToDelete = FactorsToDelete)

.EMBmodelFacDelete <- function(EMBlemModel, FacsToDelete){

  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]

  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value", MdlsToChange))
  }

  FacDel <- c(FacsToDelete[[1]])

  # Checking that Parent Factor exists
  isPresent <- unique(FacDel) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(FacDel)[!isPresent], collapse = "', '"), "' not in model. Found in 'Factors To Delete' ")
  }

  # deleting factors
  for (j in 1:length(Facs)) {
    for (i in 1:length(FacDel)) {
      mults <- EMBlemModel[get(Facs[j]) == FacDel[i], grep("^Value",names(EMBlemModel)), with = F]
      if(nrow(mults) == 0){
        mults <- 1
      }
      if(!all(mults == 1)){
        warning(paste0(FacDel[i], "  This factor has been deleted but some multipliers were not 1, are you sure you wanted to delete this factor?"))
      }
      EMBlemModel <- EMBlemModel[ !(get(Facs[j]) == FacDel[i]), ]
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))
}



#' Renames factors from a combined model
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param FacsToRename Object. Your data.table containing all factors you wish to rename, in form: Old Name, New Name.
#' @return An EMBglm which is equal to the \code{EMBlemModel} with all \code{FacsToRename} renamed.
#' @examples
#' #.EMBmodelFacRename(EMBlemModel, FacsToRename = FactorsToRename)

.EMBmodelFacRename <- function(EMBlemModel, FacsToRename){
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]

  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value", MdlsToChange))
  }

  FacOld <- c(FacsToRename[[1]])
  FacNew <- c(FacsToRename[[2]])

  # Checking that Parent Factor exists
  isPresent <- unique(FacOld) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(FacOld)[!isPresent], collapse = "', '"), "' not in model. Found in 'Factors To Rename' ")
  }

  # Checking that New Factor Name does not already exist
  isPresent <- unique(FacNew) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (any(isPresent)){
    stop("Factor(s) '", paste(unique(FacNew)[isPresent], collapse = "', '"), "' already in model. Found in 'Factors To Rename' ")
  }

  for (j in 1:length(Facs)){
    for (i in 1:length(FacOld)) {
      EMBlemModel[get(Facs[j]) == FacOld[i], `:=`(Facs[j], FacNew[i])]
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))
}



#' Removes levels from a combined model
#' @import data.table
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param LevsToDelete Object. Your data.table containing all levels you wish to delete, in form: Factor, Level.
#' @return A reduced EMBglm which is equal to the \code{EMBlemModel} with all \code{LevsToDelete} removed.
#' @examples
#' #.EMBmodelLevDelete(allModels, LevsToDelete = LevelsToDelete)

.EMBmodelLevDelete <- function(EMBlemModel, LevsToDelete){

  EMBNames <- names(EMBlemModel)

  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]

  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]

  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)",
                                  names(EMBlemModel), ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]


  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value", MdlsToChange))
  }

  Fac <- c(LevsToDelete[[1]])
  LevDel <- c(LevsToDelete[[2]])

  # Checking that Parent Factor exists
  isPresent <- unique(Fac) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(Fac)[!isPresent], collapse = "', '"), "' not in model. Found in 'Levels To Delete' ")
  }

  # Checking that Parent Factor and Level exist
  duplicatedParents <- merge(data.table(Fac, LevDel),
                             data.table(Fac = unlist(EMBlemModel[, ..Facs]), LevDel = unlist(EMBlemModel[, ..Lvls]), inModel = TRUE),
                             by = c("Fac", "LevDel"), all.x = TRUE)
  duplicatedParents <- unique(duplicatedParents[is.na(inModel), .(Fac, LevDel)])
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Fac,duplicatedParents$LevDel, sep = ":"), collapse = "', '"), "' not in Model. Found in 'Levels To Delete'")
  }

  for (j in 1:length(Lvls)) {
    for (i in 1:length(LevDel)) {
      mults <- EMBlemModel[get(Facs[j]) == Fac[i] & get(Lvls[j]) == LevDel[i], grep("^Value",names(EMBlemModel)), with = F]
      if(nrow(mults) == 0){
        mults <- 1
      }
      if(!all(mults == 1)){
        warning(paste0(Fac[i], ":", LevDel[i], "  This level has been deleted but some multipliers were not 1, are you sure you wanted to delete this level?"))
      }
      EMBlemModel <- EMBlemModel[!(get(Facs[j]) == Fac[i] &
                                  get(Lvls[j]) == LevDel[i]), ]
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))

}



#' Renames levels from a combined model
#' @param EMBlemModel Object. Your combined EMBglm model.
#' @param LevsToRename Object. Your data.table containing all levels you wish to rename, in form: Old Factor, OldLevel, NewLevel.
#' @return An EMBglm which is equal to the \code{EMBlemModel} with all \code{LevsToRename} renamed.
#' @examples
#' #.EMBmodelLevRename(EMBlemModel, LevsToRename = LevelsToRename)

.EMBmodelLevRename <- function(EMBlemModel, LevsToRename){
  EMBNames <- names(EMBlemModel)
  Facs <- EMBNames[grep("Factor", names(EMBlemModel), ignore.case = TRUE)]
  Lvls <- EMBNames[grep("Level", names(EMBlemModel), ignore.case = TRUE)]
  Mdls <- names(EMBlemModel)[!grepl("(Level)|(Factor)", names(EMBlemModel), ignore.case = TRUE)]
  MdlsToChange <- Mdls[!grepl("Value", Mdls, ignore.case = TRUE)]

  if (length(MdlsToChange) != 0) {
    setnames(EMBlemModel, MdlsToChange, paste0("Value", MdlsToChange))
  }

  Fac <- c(LevsToRename[[1]])
  LevOld <- c(LevsToRename[[2]])
  LevNew <- c(LevsToRename[[3]])

  # Checking that Parent Factor exists
  isPresent <- unique(Fac) %in% unique(unlist(EMBlemModel[, ..Facs]))
  if (!all(isPresent)){
    stop("Factor(s) '", paste(unique(Fac)[!isPresent], collapse = "', '"), "' not in model. Found in 'Levels To Rename' ")
  }

  # Checking that Parent Factor and Level exist
  duplicatedParents <- merge(data.table(Fac, LevOld),
                             data.table(Fac = unlist(EMBlemModel[, ..Facs]), LevOld = unlist(EMBlemModel[, ..Lvls]), inModel = TRUE),
                             by = c("Fac", "LevOld"), all.x = TRUE)
  duplicatedParents <- unique(duplicatedParents[is.na(inModel), .(Fac, LevOld)])
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Fac,duplicatedParents$LevOld, sep = ":"), collapse = "', '"), "' in levels to rename but not in Model. Found in 'Levels To Rename'")
  }

  # Checking that new level names do not already exist
  duplicatedParents <- merge(data.table(Fac, LevNew),
                             data.table(Fac = unlist(EMBlemModel[, ..Facs]), LevNew = unlist(EMBlemModel[, ..Lvls])),
                             by = c("Fac", "LevNew"))
  if(nrow(duplicatedParents) > 0){
    stop("'",paste(paste(duplicatedParents$Fac,duplicatedParents$LevNew, sep = ":"), collapse = "', '"), "' already exist(s) in Model, cannot rename a level to something that already exists. Found in 'Levels To Rename'")
  }

  # Renaming levels
  for (j in 1:length(Lvls)) {
    for (i in 1:length(LevOld)) {
      EMBlemModel[ get(Facs[j]) == Fac[i] & get(Lvls[j]) == LevOld[i],
                 `:=`(Lvls[j], LevNew[i])]
    }
  }

  setkeyv(EMBlemModel, c(Facs, Lvls))
  return(as.EMBglm(EMBlemModel))

}
