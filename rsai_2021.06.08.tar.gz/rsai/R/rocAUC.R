#' Generalisation of the ROC AUC model metric

#' @description Generalisation of the ROC AUC model metric that works with weighted data and with outcomes drawn
#' from any distribution where the outcomes are non-negative and where it makes sense to sum outcomes together to a total,
#' for example, Poisson or Gamma distributed data. The result will be consistent with the normal definition of ROC AUC
#' (https://en.wikipedia.org/wiki/Receiver_operating_characteristic) and if you supply the function with unweighted
#' binary data, you should get consistent results here with other packages, at least down to rounding error.
#' The results for non-binary data seem to be inconsistent with \code{xgboost}, however the result of \code{rocAUC} is
#' constrained to be between 0 and 1 and the \code{xgboost} results look like they are a linear transformation of the
#' results from this function.
#' @usage rocAUC(y, y_hat, w=NULL)
#' @param y Vector of observed outcomes.
#' @param y_hat Vector of model predictions.
#' @param w Optional vector of weights.
#' @return ROC AUC value.
#' @importFrom data.table data.table
#' @examples
#' # # Binary example (https://en.wikipedia.org/wiki/Receiver_operating_characteristic#/media/File:ROC.png)
#' # y <- c(0,1,0,0,1,0,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
#' # y_hat <- c(98,95,92,90,86,77,74,72,65,59,56,54,52,48,46,44,43,40,35,26,21,19,18,16,15,12,8,7,5,3)
#' # 
#' # rocAUC(y, y_hat) # Check model AUC
#' # rocAUC(y, y) # Check perfect model returns 1
#' # rocAUC(y, -y) # Check negative perfect model returns 0
#' # rocAUC(y, 1) # Check constant predictions returns 0.5
#' # 
#' # # Weighted poisson example
#' # n <- 30
#' # set.seed(1984)
#' # y_hat <- pmax(rnorm(n, 2, 1), 0.2)
#' # w <- runif(n, 0.5, 2)
#' # y <- rpois(n, y_hat*w)/w
#' # 
#' # rocAUC(y, y_hat, w) # Check model AUC
#' # rocAUC(y, y, w) # Check perfect model returns 1
#' # rocAUC(y, -y, w) # Check negative perfect model returns 0
#' # rocAUC(y, 1, w) # Check constant predictions returns 0.5 
#' @export

rocAUC <- function(y, y_hat, w=NULL){
  # Set w to 1 if NULL
  if(is.null(w)) w <- 1
  
  # Check lengths are correct
  if(length(unique(y)) <= 1) stop("AUC undefined unless more than one unique value of y.")
  if(!length(y_hat) %in% c(1, length(y))) stop("y and y_hat must be the same length.")
  if(!length(w) %in% c(1, length(y))) stop("y and w must be the same length.")
  
  # Create table of predictions / observations
  dt <- data.table(y=y, y_hat=y_hat, w=w)
  # Normalise weights to sum to 1
  # Also yw is the weighted total observation for each row, normalised to sum to 1
  dt[, ':=' (w = w/sum(w),
             yw = y*w/sum(y*w))]
  
  # Group and order by predictions descending
  dt1 <- dt[, .(w=sum(w), yw=sum(yw)), keyby=-y_hat]
  # If only one unique prediction, AUC must be a half
  if(nrow(dt1)==1) return(0.5)
  # Calculate cumulative sums of actuals as a proportion of the total
  dt1[, sumY := cumsum(yw)]
  # Calculate average cumulative actuals between pairs of rows for summing area using trapezoids 
  set(dt1, j="meanSumY", value=(c(0, dt1$sumY[1:(nrow(dt1)-1)]) + dt1$sumY)/2)
  # Sum the area under the total operating characteristic curve (not the ROC AUC)
  tocAuc <- dt1[, sum(meanSumY*w)]
  
  # Now group and order by actuals ascending
  dt2 <- dt[, .(w=sum(w), yw=sum(yw)), keyby=-y]
  # Calculate cumulative sums of actuals again
  # this time in the best possible ordering
  dt2[, sumYMax := cumsum(yw)]
  # Calculate average cumulative actuals between pairs of rows again
  set(dt2, j="meanSumYMax", value=(c(0, dt2$sumYMax[1:(nrow(dt2)-1)]) + dt2$sumYMax)/2)
  # Sum the area under the total operating characteristic curve again
  # This is the maximum possible TOC AUC
  tocAucMax <- dt2[, sum(meanSumYMax*w)]
  
  # Finally some manipulation to find the area under the ROC curve
  # Mins and maxs just in case of rounding errors
  rocAuc <- min(max((tocAuc+tocAucMax-1)/(2*tocAucMax-1), 0), 1)
  
  # Return
  return(rocAuc)
}