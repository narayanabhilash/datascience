#' Pocket finder function for xgb trees
#'
#' @description The function takes in an xgboost model and returns a human readable
#' instruction set as a data table.
#' @usage xgbRulesFinder (xgbModel, xgbData, ntreelimit, returnPreds = TRUE, returnSummary = TRUE, invLink = exp)
#' @param xgbModel an xgboost model
#' @param xgbData data for xgboost (i.e. output of `xgbsetupdata2`) or list of them
#' @param ntreelimit number of trees to use in the pocket.
#' @param returnPreds return prediction effects (ie over and above offset) and other stats as well as the pocket summary
#' @param returnSummary summarises by pocket rather than giving a line by line
#' @param invLink inverse of the link function (so `invlogit` if you're doing a propensity model)
#'
#' @return data table (or list of them) of rule criteria - one for each row of the data or one for each rule pocket in the data.
#' @export
#' @author Tom Bratcher and Wei Lun Wong
#' @examples
#' require(xgboost)
#' data ("UKTheftFreq") # gets dt_postcodes
#' rowList <- list (
#'   All = seq_along (UKTheftFreq$foldId))
#' modelVars <- c(
#' "ACQ_hhld_03km_bnd",
#' "Density",
#' "Dist.01",
#' "Dist.04")
#'
#' xgbData <- xgbSetupdata2(
#'   UKTheftFreq,
#'   response = "numClaims",
#'   explanatory_vars = modelVars,
#'   exposure = "exposure",
#'   sampleWeight = "weight",
#'   offset_model = "offset",
#'   rowIndicesList = rowList)
#'
#' foldList <- folds_VecToList(UKTheftFreq$foldId)
#'
#' param <- list(
#'   objective = "count:poisson",
#'   max_depth = 3L,
#'   subsample = 0.9,
#'   colsample_bytree = 0.9,
#'   min.child.weight = 100,
#'   eta = 0.1
#' )
#' set.seed(1234L)
#'
#' xgbFit <- xgb.train(
#'   params                 = param,
#'   data                   = xgbData$All,
#'   nrounds                = 100,
#'   base_score             = 1,
#'   verbose                = 0
#' )
#' temp <- xgbRulesFinder(xgbFit, xgbData$All, 5)
#' rm(temp)
#'
xgbRulesFinder <- function (xgbModel,
                            xgbData,
                            ntreelimit,
                            returnPreds = TRUE,
                            returnSummary = TRUE,
                            invLink = exp)
{
  if (class(xgbModel) != "xgb.Booster")
    stop("xgbModel must be of class xgb.Booster")
  
  if (!(class(ntreelimit) %in% c("numeric", "integer")))
    stop("ntreelimit must be of class numeric or integer")
  if (ntreelimit %% 1 != 0)
    stop("ntreelimit must be a whole number")
  if (ntreelimit > xgbModel$niter)
    stop("ntreelimit must be smaller than model's iterations")
  
  if (class(xgbData) == "list")
    return(lapply (xgbData, function (x)
      xgbRulesFinder(xgbModel, x, ntreelimit, returnPreds, returnSummary, invLink)))
  if (class(xgbData) != "xgb.DMatrix")
    stop("xgbData must be of class xgb.DMatrix or a list of them")
  
  # Determine all decisions to leaf nodes ----
  # ModelTrees
  modelTrees <- xgb.model.dt.tree(colnames(xgbData), xgbModel)
  modelTrees <- modelTrees[Tree < ntreelimit]
  
  # Identify all decision nodes
  Yes <- modelTrees[!(Feature == "Leaf"), .(ID, Feature, Split, Yes)]
  Yes[, BranchDecision := "Yes"]
  setnames(Yes, "Yes", "Branch")
  No <- modelTrees[!(Feature == "Leaf"), .(ID, Feature, Split, No)]
  No[, BranchDecision := "No"]
  setnames(No, "No", "Branch")
  Nodes <- rbind(Yes, No)
  rm(Yes, No)
  
  setnames(Nodes, "ID", "Nodes")
  Nodes[BranchDecision == "Yes", ":=" (SplitLow = as.numeric(NA), SplitHigh = Split)]
  Nodes[BranchDecision == "No", ":=" (SplitLow = Split, SplitHigh = as.numeric(NA))]
  Nodes <-
    dcast(Nodes,
          Nodes + Branch ~ Feature,
          value.var = c("SplitLow", "SplitHigh"))
  featuresCols <-
    gsub("SplitLow_", "", names(Nodes)[grepl("SplitLow_", names(Nodes))])
  keepCols <- c("Leaf", setdiff(names(Nodes), "Nodes"))
  for (f in featuresCols)
  {
    Nodes[is.na(get(paste0("SplitLow_", f))), eval(paste0("SplitLow_", f)) := -Inf]
    Nodes[is.na(get(paste0("SplitHigh_", f))), eval(paste0("SplitHigh_", f)) := Inf]
  }
  rm(f)
  
  # Identify all leaf nodes
  Leaf <- modelTrees[Feature == "Leaf", .(ID)]
  setnames(Leaf, "ID", "Leaf")
  Leaf[, Branch := Leaf]
  
  # Merge leaf nodes with decision nodes to get path to leaves
  while (sum(as.integer(gsub(".*-", "", Leaf$Branch)) != 0, na.rm = TRUE))
  {
    Leaf <-
      merge(
        Leaf,
        Nodes,
        by = "Branch",
        all.x = TRUE,
        suffixes = c(".xxx", ".yyy")
      )
    Leaf[, Branch := NULL]
    setnames(Leaf, "Nodes", "Branch")
    for (f in featuresCols)
    {
      set(Leaf, j = paste0("SplitLow_", f), value = Leaf[, apply(.SD, 1, max, na.rm =
                                                                   TRUE), .SDcols = grepl(paste0("SplitLow_", f), names(Leaf))])
      set(Leaf, j = paste0("SplitHigh_", f), value = Leaf[, apply(.SD, 1, min, na.rm =
                                                                    TRUE), .SDcols = grepl(paste0("SplitHigh_", f), names(Leaf))])
    }
    Leaf <- Leaf[, keepCols, with = FALSE]
  }
  Leaf[, Branch := NULL]
  rm(Nodes, keepCols, f)
  
  # Finding Rules for each data point ----
  # Identify leaves for each tree for each data point
  Data_Rules1 <-
    data.table(predict(
      xgbModel,
      xgbData,
      ntreelimit = ntreelimit,
      predleaf = TRUE
    ))
  for (i in seq(ncol(Data_Rules1))) {
    set(Data_Rules1,
        j = paste0("V", i),
        value = paste0(i - 1, "-", Data_Rules1[[paste0("V", i)]]))
  }
  Data_Rules1[, RowNum := seq(.N)]
  
  # Merge to get decisions path for each tree
  Data_Rules2 <- melt(
    Data_Rules1,
    id.vars = "RowNum",
    variable.name = "Trees",
    value.name = "Leaf"
  )
  Data_Rules2 <- merge(Data_Rules2, Leaf, by = "Leaf", all.x = TRUE)
  setkeyv(Data_Rules2, c("RowNum", "Leaf"))
  
  # Combine rules for all trees
  for (f in featuresCols)
  {
    Data_Rules3 <-
      Data_Rules2[, .(minV = max(get(paste0("SplitLow_", f)), na.rm = TRUE),
                      maxV = min(get(paste0("SplitHigh_", f)), na.rm =
                                   TRUE)),
                  by = RowNum]
    Data_Rules3[, temp := paste0(minV, " to ", maxV)]
    setnames(Data_Rules3, "temp", f)
    Data_Rules1 <- merge(Data_Rules1,
                         Data_Rules3[, c("RowNum", f), with = FALSE],
                         by = "RowNum",
                         all.x = TRUE)
  }
  rm(featuresCols, f, i)
  rm(Leaf, Data_Rules2, Data_Rules3)
  
  # Final dataset to return
  Data_Rules1 <- Data_Rules1[, (ntreelimit + 2):ncol(Data_Rules1)]
  keys <- names(Data_Rules1)
  
  # Add pocket number label
  rowLab <- "PocketNumber"
  while (rowLab %in% keys)
    rowLab <- paste0(rowLab, "x")
  
  # Add weights and preds
  
  if (returnPreds) {
    predCol = "preds"
    while (predCol %in% names (Data_Rules1))
      predCol <- paste0(predCol, "X")
    weightCol = "weight"
    while (weightCol %in% names (Data_Rules1))
      weightCol <- paste0(weightCol, "X")
    labelCol = "label"
    while (labelCol %in% names (Data_Rules1))
      labelCol <- paste0(labelCol, "X")
    marginCol <- "Expected"
    while (marginCol %in% names (Data_Rules1))
      marginCol <- paste0(marginCol, "X")
    
    bm <- getinfo(xgbData, name = "base_margin")
    if (is.null(bm))
      bm <- 0L
    
    wt <- getinfo(xgbData, name = "weight")
    if (is.null(wt))
      wt <- 1L
    
    Data_Rules1[[marginCol]] <- bm
    Data_Rules1[[weightCol]] <- wt
    Data_Rules1[[predCol]] <-
      invLink(
        predict(
          xgbModel,
          xgbData,
          ntreelimit = ntreelimit,
          outputmargin = TRUE
        ) - Data_Rules1[[marginCol]]
      )
    
    #print (head (Data_Rules1))
    
    #Apply weights:
    
    Data_Rules1[[labelCol]] <-
      getinfo(xgbData, name = "label") * Data_Rules1[[weightCol]]
    Data_Rules1[[marginCol]] <-
      invLink (Data_Rules1[[marginCol]]) * Data_Rules1[[weightCol]]
    
# glue all the keys together:
    keystr = "key"
    while (keystr %in% names(Data_Rules1)) keystr <- paste0(keystr, "x")
    Data_Rules1[, eval(keystr) := do.call(paste0,.SD), .SDcols= keys]
    
    # if summarising, summarise everything:
    if (returnSummary) {
      keyVec <- Data_Rules1[[keystr]]
      Data_Rules1[, eval(keystr) := NULL]
      
      temp <- Data_Rules1[,
                          lapply(.SD, mean, na.rm = TRUE),
                          keyby = keys]
      
      Data_Rules1 <- Data_Rules1[,
                                 lapply(.SD, sum, na.rm = TRUE),
                                 keyby = keys]
      
      Data_Rules1[[predCol]] <- temp[[predCol]]
      Data_Rules1[[rowLab]] <-
        1:nrow(Data_Rules1) # avoids the "warning"...
      # setkeyv(Data_Rules1, predCol)
      Data_Rules1[[keystr]] <- unique(keyVec)
      return(copy(Data_Rules1))
    }
   
  }
   # otherwise, add a pocket indicator
    rowsTab <- Data_Rules1[,
                           .(Rowsxxxx = .(unlist(.I))),
                           keyby = keys]
    
    Data_Rules1[[rowLab]] <- 0
    for (i in seq_along(rowsTab$Rowsxxxx)) {
      Data_Rules1[rowsTab$Rowsxxx[[i]], eval(rowLab) := i]
    }
  
  return(copy(Data_Rules1))
}